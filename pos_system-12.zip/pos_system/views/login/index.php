<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no, viewport-fit=cover">
    <title>تسجيل الدخول | نظام كاشير متطور</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: system-ui, 'Segoe UI', 'Cairo', -apple-system, BlinkMacSystemFont, 'Roboto', sans-serif;
            background: radial-gradient(circle at 10% 30%, #0b1120, #0a0f1c);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            /* هامش علوي 40px وسفلي 40px */
            padding: 40px 20px;
        }

        /* خلفية متحركة ناعمة */
        body::before {
            content: "";
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-image: radial-gradient(rgba(255,255,240,0.02) 1px, transparent 1px);
            background-size: 28px 28px;
            pointer-events: none;
            z-index: 0;
        }

        /* البطاقة الرئيسية - تتكيف مع كل الارتفاعات */
        .auth-card {
            max-width: 520px;
            width: 100%;
            background: rgba(18, 25, 45, 0.75);
            backdrop-filter: blur(18px);
            border-radius: 2.5rem;
            border: 1px solid rgba(255, 255, 255, 0.08);
            box-shadow: 0 30px 50px -20px rgba(0, 0, 0, 0.6), 0 0 0 0.5px rgba(255, 255, 255, 0.05);
            transition: transform 0.25s ease, box-shadow 0.3s ease;
            overflow: hidden;
            z-index: 2;
            /* ارتفاع تلقائي حسب المحتوى */
            height: auto;
        }

        .auth-card:hover {
            transform: translateY(-3px);
            box-shadow: 0 35px 55px -20px rgba(0, 0, 0, 0.7);
            border-color: rgba(255, 255, 255, 0.15);
        }

        /* رأس البطاقة */
        .card-header {
            background: linear-gradient(115deg, rgba(46, 125, 200, 0.7) 0%, rgba(91, 72, 185, 0.8) 100%);
            padding: 1.8rem 2rem;
            text-align: center;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }

        .brand-icon {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            background: rgba(255,255,255,0.15);
            width: 76px;
            height: 76px;
            border-radius: 28px;
            margin-bottom: 1rem;
            font-size: 3.2rem;
            backdrop-filter: blur(4px);
            box-shadow: 0 8px 14px rgba(0,0,0,0.2);
        }

        .card-header h1 {
            font-size: 1.9rem;
            font-weight: 700;
            letter-spacing: -0.3px;
            background: linear-gradient(135deg, #ffffff, #e0e7ff);
            background-clip: text;
            -webkit-background-clip: text;
            color: transparent;
            margin-bottom: 0.3rem;
        }

        .card-header p {
            color: #b9c7e6;
            font-weight: 500;
            font-size: 0.85rem;
        }

        /* محتوى البطاقة */
        .card-content {
            padding: 2rem 2rem 1.8rem;
        }

        /* رسائل التنبيه */
        .message {
            padding: 0.9rem 1rem;
            border-radius: 1.2rem;
            margin-bottom: 1.6rem;
            display: flex;
            align-items: center;
            gap: 0.75rem;
            font-weight: 500;
            font-size: 0.85rem;
            animation: fadeSlide 0.25s ease;
        }

        @keyframes fadeSlide {
            from { opacity: 0; transform: translateY(-6px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .message-error {
            background: rgba(220, 38, 38, 0.12);
            border-left: 3px solid #f97373;
            color: #ffe0e0;
        }

        .message-warning {
            background: rgba(245, 158, 11, 0.12);
            border-left: 3px solid #fbbf24;
            color: #fef3c7;
        }

        .message-success {
            background: rgba(34, 197, 94, 0.12);
            border-left: 3px solid #4ade80;
            color: #dcfce7;
        }

        /* مجموعة الحقول */
        .input-group {
            margin-bottom: 1.5rem;
        }

        .input-group label {
            display: flex;
            align-items: center;
            gap: 8px;
            font-size: 0.85rem;
            font-weight: 600;
            margin-bottom: 0.6rem;
            color: #cfdbf5;
            letter-spacing: 0.2px;
        }

        .input-field {
            position: relative;
            display: flex;
            align-items: center;
        }

        .input-field input, .input-field select {
            width: 100%;
            background: rgba(12, 18, 34, 0.8);
            border: 1.5px solid rgba(255,255,255,0.12);
            border-radius: 1.2rem;
            padding: 0.9rem 1rem;
            font-size: 0.95rem;
            font-family: inherit;
            color: #f0f3fc;
            transition: all 0.2s;
            outline: none;
        }

        .input-field select {
            appearance: none;
            background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='18' height='18' viewBox='0 0 24 24' fill='none' stroke='%23a0b3d9' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpolyline points='6 9 12 15 18 9'%3E%3C/polyline%3E%3C/svg%3E");
            background-repeat: no-repeat;
            background-position: left 1rem center;
            background-size: 1rem;
        }

        .input-field input:focus, .input-field select:focus {
            border-color: #5f7ef2;
            box-shadow: 0 0 0 3px rgba(95, 126, 242, 0.2);
            background: rgba(18, 25, 48, 0.9);
        }

        .input-field input:disabled, .input-field select:disabled {
            opacity: 0.6;
            cursor: not-allowed;
        }

        /* زر إظهار كلمة المرور */
        .toggle-pwd {
            position: absolute;
            left: 1rem;
            background: transparent;
            border: none;
            font-size: 1.2rem;
            cursor: pointer;
            color: #8d9bd0;
            transition: color 0.2s;
            padding: 0;
            display: flex;
            align-items: center;
            justify-content: center;
            line-height: 1;
        }

        .toggle-pwd:hover {
            color: #bbd1ff;
        }

        /* زر تسجيل الدخول */
        .login-btn {
            width: 100%;
            background: linear-gradient(100deg, #3b6eff, #8b5cf6);
            border: none;
            border-radius: 1.6rem;
            padding: 0.9rem;
            font-size: 1rem;
            font-weight: 700;
            font-family: inherit;
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            margin-top: 0.6rem;
            cursor: pointer;
            transition: all 0.25s ease;
            box-shadow: 0 5px 12px rgba(59, 110, 255, 0.25);
        }

        .login-btn:hover:not(:disabled) {
            transform: scale(0.98);
            background: linear-gradient(100deg, #2d5bec, #7c4aed);
            box-shadow: 0 8px 18px rgba(59, 110, 255, 0.35);
        }

        .login-btn:disabled {
            opacity: 0.6;
            cursor: not-allowed;
            transform: none;
        }

        /* عداد المحاولات */
        .attempts-badge {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 0.5rem;
            font-size: 0.75rem;
            background: rgba(0, 0, 0, 0.3);
            width: fit-content;
            margin: 1rem auto 0;
            padding: 0.4rem 1rem;
            border-radius: 3rem;
            color: #a0b2df;
        }

        /* رابط تسجيل الدخول الاحتياطي */
        .backup-link {
            display: block;
            text-align: center;
            margin-top: 1.2rem;
            color: #93abff;
            text-decoration: none;
            font-size: 0.8rem;
            font-weight: 500;
            transition: 0.2s;
            background: rgba(255,255,255,0.02);
            width: fit-content;
            margin-left: auto;
            margin-right: auto;
            padding: 0.4rem 1rem;
            border-radius: 2rem;
        }

        .backup-link:hover {
            color: #c4d2ff;
            background: rgba(255,255,255,0.07);
        }

        /* مؤقت العد التنازلي */
        .countdown-timer {
            text-align: center;
            font-size: 2.1rem;
            font-weight: 800;
            font-family: monospace;
            letter-spacing: 2px;
            color: #ff9f7c;
            background: rgba(0,0,0,0.4);
            border-radius: 2rem;
            padding: 0.2rem;
            margin: 0.5rem 0;
        }

        /* تذييل البطاقة */
        .card-footer {
            background: rgba(0, 0, 0, 0.25);
            padding: 1rem;
            text-align: center;
            border-top: 1px solid rgba(255,255,255,0.05);
            font-size: 0.7rem;
            color: #7c8bb3;
        }

        /* مودال تسجيل الدخول الاحتياطي */
        .modal-overlay {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.7);
            backdrop-filter: blur(8px);
            z-index: 1000;
            align-items: center;
            justify-content: center;
        }

        .modal-card {
            background: #111827e6;
            backdrop-filter: blur(20px);
            width: 90%;
            max-width: 420px;
            border-radius: 2rem;
            border: 1px solid rgba(255,255,255,0.15);
            overflow: hidden;
            animation: modalUp 0.25s cubic-bezier(0.2, 0.9, 0.4, 1.1);
        }

        @keyframes modalUp {
            from { opacity: 0; transform: scale(0.96) translateY(12px); }
            to { opacity: 1; transform: scale(1) translateY(0); }
        }

        .modal-header {
            background: linear-gradient(115deg, #9747ff, #d946ef);
            padding: 1.5rem;
            text-align: center;
            position: relative;
        }

        .close-modal {
            position: absolute;
            left: 1.2rem;
            top: 1.2rem;
            background: rgba(0,0,0,0.3);
            border: none;
            font-size: 1rem;
            width: 32px;
            height: 32px;
            border-radius: 20px;
            cursor: pointer;
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .modal-header h3 {
            font-size: 1.6rem;
            font-weight: 700;
            color: white;
        }

        .modal-header p {
            font-size: 0.75rem;
            color: #ffecb3;
        }

        .modal-content {
            padding: 1.8rem;
        }

        .modal-footer {
            padding: 0 1.8rem 1.8rem;
            display: flex;
            gap: 0.8rem;
        }

        .btn-primary, .btn-secondary {
            flex: 1;
            border: none;
            padding: 0.7rem;
            border-radius: 2rem;
            font-weight: 600;
            font-family: inherit;
            cursor: pointer;
            transition: 0.2s;
        }

        .btn-primary {
            background: linear-gradient(100deg, #9747ff, #e879f9);
            color: white;
        }

        .btn-secondary {
            background: rgba(255,255,255,0.12);
            color: #e2e8ff;
        }

        .btn-primary:hover {
            background: linear-gradient(100deg, #8642e6, #cf6af0);
        }

        /* ========== تحسين التجاوب مع جميع الشاشات ========== */
        @media (max-width: 640px) {
            body {
                padding: 40px 16px;  /* الحفاظ على الهامش العلوي والسفلي 40px */
            }
            .auth-card {
                max-width: 100%;
                border-radius: 2rem;
            }
            .card-header {
                padding: 1.4rem 1.5rem;
            }
            .brand-icon {
                width: 65px;
                height: 65px;
                font-size: 2.6rem;
            }
            .card-header h1 {
                font-size: 1.6rem;
            }
            .card-content {
                padding: 1.5rem;
            }
            .input-field input, .input-field select {
                padding: 0.8rem 1rem;
                font-size: 0.9rem;
            }
            .login-btn {
                padding: 0.8rem;
            }
        }

        @media (max-width: 480px) {
            body {
                padding: 40px 12px;
            }
            .card-content {
                padding: 1.2rem;
            }
            .brand-icon {
                width: 55px;
                height: 55px;
                font-size: 2.2rem;
                border-radius: 20px;
            }
            .card-header h1 {
                font-size: 1.4rem;
            }
            .input-group {
                margin-bottom: 1.2rem;
            }
            .toggle-pwd {
                left: 0.8rem;
                font-size: 1rem;
            }
        }

        /* للشاشات الطويلة جداً (مثل الهواتف ذات الارتفاع الكبير) */
        @media (min-height: 800px) {
            body {
                padding: 40px 20px; /* يضمن مسافة 40px ثابتة أعلى وأسفل */
            }
        }

        /* للشاشات الصغيرة جداً في الارتفاع (مثلاً هواتف صغيرة) */
        @media (max-height: 700px) {
            body {
                padding: 40px 20px;
            }
            .card-header {
                padding: 1rem 1.5rem;
            }
            .brand-icon {
                width: 50px;
                height: 50px;
                font-size: 2rem;
                margin-bottom: 0.5rem;
            }
            .card-header h1 {
                font-size: 1.3rem;
            }
            .card-content {
                padding: 1rem 1.2rem;
            }
            .input-group {
                margin-bottom: 0.9rem;
            }
            .card-footer {
                padding: 0.6rem;
            }
        }

        /* للشاشات العريضة جداً (حوالي 1400px+) */
        @media (min-width: 1400px) {
            .auth-card {
                max-width: 560px;
            }
            .card-header {
                padding: 2rem 2.2rem;
            }
            .card-content {
                padding: 2.2rem;
            }
            .brand-icon {
                width: 85px;
                height: 85px;
                font-size: 3.5rem;
            }
        }
    </style>
</head>
<body>
<div class="auth-card">
    <div class="card-header">
        <div class="brand-icon">
            🧾✨
        </div>
        <h1>نظام كاشير</h1>
        <p>📊 إدارة ذكية | مخزون دقيق | مبيعات سريعة</p>
    </div>

    <div class="card-content">
        <!-- PHP رسائل الجلسة (تظهر بشكل جميل) -->
        <?php if (isset($_SESSION['backup_login_notice'])): ?>
            <div class="message message-success">
                <span>✅</span>
                <span><?= htmlspecialchars($_SESSION['backup_login_notice']) ?></span>
                <?php unset($_SESSION['backup_login_notice']); ?>
            </div>
        <?php endif; ?>

        <?php if (isset($error)): ?>
            <div class="message message-error">
                <span>⚠️</span>
                <span><?= htmlspecialchars($error) ?></span>
            </div>

             <?php if (isset($attempts) && $attempts > 0 && !($isLocked ?? false)): ?>
            <div class="attempts-badge">
                <span>🛡️</span> <span>المحاولات الفاشلة: <?= $attempts ?> / <?= $maxAttempts ?? 15 ?></span>
            </div>
        <?php endif; ?>

        <?php endif; ?>

        <?php if ($isLocked ?? false): ?>
            <div class="message message-warning">
                <span>🔒</span>
                <span>تم تجاوز عدد المحاولات المسموحة</span>
            </div>
            <div class="countdown-timer" id="countdown">--:--</div>
            <a href="#" id="backupLoginLink" class="backup-link">🔐 الدخول الاحتياطي (مدير)</a>
        <?php endif; ?>

        <form action="<?= BASE_URL ?>/login" method="POST" id="loginForm" autocomplete="off">
<div class="input-group">
    <label><span>👤</span> اسم المستخدم</label>
    <div class="input-field">
        <input type="text" 
               id="username" 
               name="username" 
               autocomplete="off"
               placeholder="أدخل اسم المستخدم"
               required <?= ($isLocked ?? false) ? 'disabled' : '' ?>>
    </div>
</div>
            <div class="input-group">
                <label><span>🔐</span> كلمة المرور</label>
                <div class="input-field">
                    <input type="password" id="password" name="password"
                           autocomplete="new-password" readonly
                           onfocus="this.removeAttribute('readonly')"
                           placeholder="········"
                           required <?= ($isLocked ?? false) ? 'disabled' : '' ?>>
                    <button type="button" class="toggle-pwd" onclick="togglePassword()" aria-label="إظهار/إخفاء">
                        <span id="toggleIcon">👁️‍🗨️</span>
                    </button>
                </div>
            </div>

            <?php if (!($isLocked ?? false)): ?>
                <button type="submit" class="login-btn">
                    <span>🚀</span> تسجيل الدخول
                </button>
            <?php else: ?>
                <button type="button" class="login-btn" disabled>
                    <span>⏳</span> النظام مقفل مؤقتاً
                </button>
            <?php endif; ?>
        </form>

       
       
    </div>

    <div class="card-footer">
        <span>© <?= date('Y') ?> · نظام متكامل للمبيعات والمخزون</span>
    </div>
</div>

<!-- مودال تسجيل الدخول الاحتياطي (بدون مكتبات خارجية) -->
<div id="backupModal" class="modal-overlay">
    <div class="modal-card">
        <div class="modal-header">
            <button class="close-modal" onclick="closeModal()">✖️</button>
            <h3>🛡️ دخول احتياطي</h3>
            <p>🔐 خاص بالمديرين فقط</p>
        </div>
        <form action="<?= BASE_URL ?>/backup-login" method="POST" autocomplete="off">
            <div class="modal-content">
                <div class="input-group">
                    <label><span>👤</span> اسم المستخدم</label>
                    <div class="input-field">
                        <input type="text" name="username" autocomplete="off" placeholder="اسم المدير" required>
                    </div>
                </div>
                <div class="input-group">
                    <label><span>🗝️</span> كلمة المرور الاحتياطية</label>
                    <div class="input-field">
                        <input type="password" name="backup_password" id="backupPassword"
                               autocomplete="new-password" readonly
                               onfocus="this.removeAttribute('readonly')"
                               placeholder="········" required>
                        <button type="button" class="toggle-pwd" onclick="toggleBackupPassword()">
                            <span id="backupToggleIcon">👁️‍🗨️</span>
                        </button>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="submit" class="btn-primary"><span>✅</span> دخول</button>
                <button type="button" class="btn-secondary" onclick="closeModal()"><span>❌</span> إلغاء</button>
            </div>
        </form>
    </div>
</div>

<script>
    // =====================================================
    // كود منع التعبئة التلقائية (Chrome Autofill)
    // =====================================================
    (function() {
        const obliterateChromeAutofill = () => {
            // استهداف جميع حقول كلمة المرور
            const passwordInputs = document.querySelectorAll('input[type="password"]');

            passwordInputs.forEach(originalInput => {
                // تجاهل الحقل إذا تم تطبيق الخدعة عليه مسبقاً
                if (originalInput.hasAttribute('data-cloned')) return;
                originalInput.setAttribute('data-cloned', 'true');

                // حفظ معرف فريد للحقل الأصلي للربط مع البديل
                const originalId = originalInput.id || 'pwd_' + Math.random().toString(36).substr(2, 8);
                if (!originalInput.id) originalInput.id = originalId;

                // 1. إخفاء الحقل الأصلي تماماً عن المتصفح والمستخدم
                originalInput.style.position = 'absolute';
                originalInput.style.opacity = '0';
                originalInput.style.pointerEvents = 'none';
                originalInput.style.zIndex = '-9999';
                originalInput.tabIndex = -1; // منع الوصول إليه بزر Tab

                // 2. إنشاء حقل بديل "وهمي" آمن تماماً
                const clone = document.createElement('input');
                clone.type = 'text'; // نوع نصي عادي
                clone.className = originalInput.className; // نسخ نفس التصميم
                clone.placeholder = originalInput.placeholder; // نسخ النص الإرشادي
                
                // إضافة سمات تمنع إضافات الطرف الثالث
                clone.setAttribute('autocomplete', 'new-password');
                clone.setAttribute('data-lpignore', 'true');
                clone.setAttribute('data-form-type', 'other');
                clone.setAttribute('spellcheck', 'false');
                
                // ربط الحقل البديل مع الحقل الأصلي
                clone.setAttribute('data-original-id', originalId);

                // تشفير النص بصرياً ليظهر كنقاط
                clone.style.webkitTextSecurity = 'disc';
                clone.style.textSecurity = 'disc';

                // 3. المزامنة السرية: أي شيء يكتب في البديل، ينسخ للأصلي
                clone.addEventListener('input', function() {
                    originalInput.value = this.value;
                    originalInput.dispatchEvent(new Event('input', { bubbles: true }));
                });

                // 4. إدراج الحقل البديل في الواجهة قبل الحقل الأصلي
                originalInput.parentNode.insertBefore(clone, originalInput);

                // 5. منع النقر المزدوج
                clone.addEventListener('mousedown', function(e) {
                    if (e.detail > 1) e.preventDefault();
                });
            });
        };

        // التنفيذ فوراً عند تحميل الصفحة
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', obliterateChromeAutofill);
        } else {
            obliterateChromeAutofill();
        }

        // مراقبة النوافذ المنبثقة (Modals) لتطبيق الخدعة
        const observer = new MutationObserver(obliterateChromeAutofill);
        observer.observe(document.body, { childList: true, subtree: true });
    })();

    // =====================================================
    // متغير عام لتخزين مؤقت إغلاق المودال
    // =====================================================
    let modalTimeout;

    // =====================================================
    // دالة مساعدة لوضع التركيز على حقل الإدخال (متوافقة مع كود منع Autofill)
    // =====================================================
    function focusOnInput(inputElement, fieldName = '') {
        if (!inputElement || inputElement.disabled) return false;
        
        // البحث عن الحقل البديل (clone) إذا كان موجوداً
        let targetField = inputElement;
        
        // إذا كان الحقل الأصلي من نوع password ومخفي، نبحث عن الحقل البديل المرتبط به
        if (inputElement.type === 'password' && inputElement.hasAttribute('data-cloned')) {
            const originalId = inputElement.id;
            const cloneField = document.querySelector(`input[data-original-id="${originalId}"]`);
            if (cloneField) {
                targetField = cloneField;
            }
        }
        
        // إزالة خاصية readonly (لأن حقولنا تحتوي عليها)
        targetField.removeAttribute('readonly');
        
        // التركيز على الحقل
        targetField.focus();
        
        // وضع المؤشر في نهاية النص إن وجد
        const length = targetField.value.length;
        targetField.setSelectionRange(length, length);
        
        // إضافة تأثير وميض بسيط
        targetField.style.boxShadow = '0 0 0 3px rgba(95, 126, 242, 0.4)';
        targetField.style.transition = 'box-shadow 0.2s';
        setTimeout(() => {
            targetField.style.boxShadow = '';
        }, 400);
        
        // إعادة تعيين readonly عند فقدان التركيز (إذا كان الحقل فارغاً)
        targetField.addEventListener('blur', function onBlur() {
            if (!targetField.value) {
                targetField.setAttribute('readonly', 'readonly');
            }
            targetField.removeEventListener('blur', onBlur);
        }, { once: true });
        
        return true;
    }

    // =====================================================
    // دالة للبحث عن الحقل الأصلي أو البديل
    // =====================================================
    function getActivePasswordField() {
        // البحث عن حقل كلمة المرور الأصلي
        const originalPassword = document.getElementById('password');
        if (originalPassword && originalPassword.hasAttribute('data-cloned')) {
            const cloneField = document.querySelector(`input[data-original-id="${originalPassword.id}"]`);
            if (cloneField) return cloneField;
        }
        return document.getElementById('password');
    }

    function getActiveBackupPasswordField() {
        const originalBackup = document.getElementById('backupPassword');
        if (originalBackup && originalBackup.hasAttribute('data-cloned')) {
            const cloneField = document.querySelector(`input[data-original-id="${originalBackup.id}"]`);
            if (cloneField) return cloneField;
        }
        return document.getElementById('backupPassword');
    }

    // =====================================================
    // منع التنقل العشوائي بالأسهم في قائمة الاختيار (select)
    // =====================================================
    function preventRandomArrowNavigation() {
        const roleSelect = document.getElementById('role');
        if (roleSelect) {
            roleSelect.addEventListener('keydown', function(e) {
                if (e.key === 'ArrowUp' || e.key === 'ArrowDown') {
                    e.preventDefault();
                }
            });
        }
    }

// =====================================================
// إضافة اختصارات لوحة المفاتيح (محدثة)
// =====================================================
function initKeyboardShortcuts() {
    const loginForm = document.getElementById('loginForm');
    
    // عناصر المودال (تسجيل الدخول الاحتياطي)
    const modalUsernameInput = document.querySelector('#backupModal input[name="username"]');
    
    // متغير لتخزين آخر حقل تم التركيز عليه
    let lastFocusedField = null;

    // تسجيل آخر حقل تم التركيز عليه
    document.addEventListener('focusin', function(e) {
        if (e.target && (e.target.tagName === 'INPUT' || e.target.tagName === 'SELECT')) {
            lastFocusedField = e.target;
        }
    });

    document.addEventListener('keydown', function(e) {
        // =============================================
        // Ctrl + سهم فوق ⬆️: التركيز على حقل اسم المستخدم
        // =============================================
        if (e.ctrlKey && e.key === 'ArrowUp') {
            e.preventDefault();
            
            const modal = document.getElementById('backupModal');
            const isModalOpen = modal && modal.style.display === 'flex';
            
            if (!isModalOpen) {
                // الصفحة الرئيسية: التركيز على حقل اسم المستخدم
                const usernameField = document.getElementById('username');
                if (usernameField && !usernameField.disabled) {
                    focusOnInput(usernameField, 'username');
                }
            } else {
                // المودال: التركيز على حقل اسم المستخدم في المودال
                const modalUsername = document.querySelector('#backupModal input[name="username"]');
                if (modalUsername && !modalUsername.disabled) {
                    focusOnInput(modalUsername, 'modal_username');
                }
            }
        }
        
        // =============================================
        // Ctrl + سهم تحت ⬇️: التركيز على حقل كلمة المرور
        // =============================================
        else if (e.ctrlKey && e.key === 'ArrowDown') {
            e.preventDefault();
            
            const modal = document.getElementById('backupModal');
            const isModalOpen = modal && modal.style.display === 'flex';
            
            if (!isModalOpen) {
                // الصفحة الرئيسية: التركيز على حقل كلمة المرور
                const activePasswordField = getActivePasswordField();
                if (activePasswordField && !activePasswordField.disabled) {
                    focusOnInput(activePasswordField, 'password');
                }
            } else {
                // المودال: التركيز على حقل كلمة المرور الاحتياطية
                const activeBackupField = getActiveBackupPasswordField();
                if (activeBackupField && !activeBackupField.disabled) {
                    focusOnInput(activeBackupField, 'backup_password');
                }
            }
        }
        
        // =============================================
        // Enter لتنفيذ زر تسجيل الدخول
        // =============================================
        else if (e.key === 'Enter' && !e.altKey && !e.shiftKey && !e.ctrlKey) {
            const modal = document.getElementById('backupModal');
            const isModalOpen = modal && modal.style.display === 'flex';
            
            if (isModalOpen) {
                e.preventDefault();
                const modalSubmit = document.querySelector('#backupModal .btn-primary');
                if (modalSubmit && !modalSubmit.disabled) {
                    modalSubmit.style.transform = 'scale(0.98)';
                    setTimeout(() => { modalSubmit.style.transform = ''; }, 150);
                    modalSubmit.click();
                }
            } else {
                const submitBtnElement = document.querySelector('.login-btn');
                if (submitBtnElement && !submitBtnElement.disabled) {
                    e.preventDefault();
                    submitBtnElement.style.transform = 'scale(0.98)';
                    setTimeout(() => { submitBtnElement.style.transform = ''; }, 150);
                    submitBtnElement.click();
                }
            }
        }
    });
}
    // =====================================================
    // toggle كلمة المرور (متوافق مع الحقول البديلة)
    // =====================================================
    function togglePassword() {
        const originalInput = document.getElementById('password');
        if (originalInput && originalInput.hasAttribute('data-cloned')) {
            const cloneField = document.querySelector(`input[data-original-id="${originalInput.id}"]`);
            if (cloneField) {
                if (cloneField.style.webkitTextSecurity === 'disc' || cloneField.style.textSecurity === 'disc') {
                    cloneField.style.webkitTextSecurity = 'none';
                    cloneField.style.textSecurity = 'none';
                    document.getElementById('toggleIcon').innerText = '🙈';
                } else {
                    cloneField.style.webkitTextSecurity = 'disc';
                    cloneField.style.textSecurity = 'disc';
                    document.getElementById('toggleIcon').innerText = '👁️‍🗨️';
                }
                return;
            }
        }
        
        // Fallback للمتصفحات القديمة
        const pwdInput = document.getElementById('password');
        const toggleSpan = document.getElementById('toggleIcon');
        if (pwdInput.type === 'password') {
            pwdInput.type = 'text';
            toggleSpan.innerText = '🙈';
        } else {
            pwdInput.type = 'password';
            toggleSpan.innerText = '👁️‍🗨️';
        }
    }

    function toggleBackupPassword() {
        const originalInput = document.getElementById('backupPassword');
        if (originalInput && originalInput.hasAttribute('data-cloned')) {
            const cloneField = document.querySelector(`input[data-original-id="${originalInput.id}"]`);
            if (cloneField) {
                if (cloneField.style.webkitTextSecurity === 'disc' || cloneField.style.textSecurity === 'disc') {
                    cloneField.style.webkitTextSecurity = 'none';
                    cloneField.style.textSecurity = 'none';
                    document.getElementById('backupToggleIcon').innerText = '🙈';
                } else {
                    cloneField.style.webkitTextSecurity = 'disc';
                    cloneField.style.textSecurity = 'disc';
                    document.getElementById('backupToggleIcon').innerText = '👁️‍🗨️';
                }
                return;
            }
        }
        
        const pwdInput = document.getElementById('backupPassword');
        const toggleSpan = document.getElementById('backupToggleIcon');
        if (pwdInput.type === 'password') {
            pwdInput.type = 'text';
            toggleSpan.innerText = '🙈';
        } else {
            pwdInput.type = 'password';
            toggleSpan.innerText = '👁️‍🗨️';
        }
    }

    // =====================================================
    // مؤقت العد التنازلي (عند قفل النظام)
    // =====================================================
    <?php if (isset($lockUntil) && $lockUntil > time()): ?>
    let countdownInterval;
    function updateCountdown() {
        const now = Math.floor(Date.now() / 1000);
        let remaining = <?= $lockUntil ?> - now;
        if (remaining <= 0) {
            clearInterval(countdownInterval);
            location.reload();
        } else {
            const countdownElement = document.getElementById('countdown');
            if (countdownElement) {
                const minutes = Math.floor(remaining / 60);
                const seconds = remaining % 60;
                countdownElement.innerText = `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
            }
        }
    }
    countdownInterval = setInterval(updateCountdown, 1000);
    updateCountdown();
    <?php endif; ?>

    // =====================================================
    // التحكم في المودال
    // =====================================================
    const modal = document.getElementById('backupModal');
    const openLinks = document.querySelectorAll('#backupLoginLink, #backupLoginLinkNormal');

    function openModal(e) {
        if(e) e.preventDefault();
        if(modal) {
            modal.style.display = 'flex';
            document.body.style.overflow = 'hidden';
            
            if(modalTimeout) clearTimeout(modalTimeout);
            
            modalTimeout = setTimeout(function() {
                if(modal.style.display === 'flex') {
                    closeModal();
                }
            }, 60000);
            
            setTimeout(() => {
                const firstInput = modal.querySelector('input[name="username"]');
                if(firstInput) {
                    firstInput.removeAttribute('readonly');
                    firstInput.focus();
                    const length = firstInput.value.length;
                    firstInput.setSelectionRange(length, length);
                }
            }, 100);
        }
    }

    function closeModal() {
        if(modal) {
            modal.style.display = 'none';
            document.body.style.overflow = 'auto';
            
            if(modalTimeout) {
                clearTimeout(modalTimeout);
                modalTimeout = null;
            }
        }
    }

    openLinks.forEach(link => {
        if(link) link.addEventListener('click', openModal);
    });

    if(modal) {
        modal.addEventListener('click', function(e) {
            if(e.target === modal) closeModal();
        });
    }

    // =====================================================
    // تهيئة الصفحة عند التحميل
    // =====================================================
    document.addEventListener('DOMContentLoaded', () => {
        const allPasswordInputs = document.querySelectorAll('input[type="password"]');
        allPasswordInputs.forEach(input => {
            input.addEventListener('contextmenu', (e) => e.preventDefault());
        });
        
        const forms = document.querySelectorAll('form');
        forms.forEach(form => {
            form.setAttribute('autocomplete', 'off');
        });
        
        preventRandomArrowNavigation();
        initKeyboardShortcuts();
        
        // إضافة مستمع لحقل كلمة المرور الرئيسية (الحقل البديل)
        const passwordField = getActivePasswordField();
        if(passwordField) {
            passwordField.addEventListener('click', function() {
                if(this.hasAttribute('readonly')) {
                    this.removeAttribute('readonly');
                    this.focus();
                    const length = this.value.length;
                    this.setSelectionRange(length, length);
                }
            });
        }
        
        // إضافة مستمع لحقول المودال
        const modalUsername = document.querySelector('#backupModal input[name="username"]');
        const modalPassword = getActiveBackupPasswordField();
        
        if(modalUsername) {
            modalUsername.addEventListener('click', function() {
                if(this.hasAttribute('readonly')) {
                    this.removeAttribute('readonly');
                    this.focus();
                    const length = this.value.length;
                    this.setSelectionRange(length, length);
                }
            });
        }
        
        if(modalPassword) {
            modalPassword.addEventListener('click', function() {
                if(this.hasAttribute('readonly')) {
                    this.removeAttribute('readonly');
                    this.focus();
                    const length = this.value.length;
                    this.setSelectionRange(length, length);
                }
            });
        }
    });
</script>
</body>
</html>