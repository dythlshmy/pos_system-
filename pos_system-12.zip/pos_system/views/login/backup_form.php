<?php
// منع التخزين المؤقت
header("Cache-Control: no-cache, no-store, must-revalidate");
header("Pragma: no-cache");
header("Expires: 0");
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
    <title>تسجيل الدخول - نظام الكاشير المتقدم</title>
    <link rel="stylesheet" href="<?= asset('css/style.css') ?>">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Tajawal', 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        .login-page {
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            position: relative;
            overflow: hidden;
        }

        .login-page::before {
            content: '';
            position: absolute;
            width: 200%;
            height: 200%;
            background: radial-gradient(circle, rgba(255,255,255,0.1) 1%, transparent 1%);
            background-size: 50px 50px;
            animation: bgMove 20s linear infinite;
        }

        @keyframes bgMove {
            0% { transform: translate(0, 0); }
            100% { transform: translate(50px, 50px); }
        }

        .login-container {
            width: 100%;
            max-width: 450px;
            padding: 20px;
            position: relative;
            z-index: 1;
        }

        .login-box {
            background: rgba(255, 255, 255, 0.98);
            border-radius: 20px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
            padding: 45px 40px;
            backdrop-filter: blur(10px);
            transition: transform 0.3s ease;
        }

        .login-box:hover {
            transform: translateY(-5px);
        }

        .login-header {
            text-align: center;
            margin-bottom: 35px;
        }

        .login-header h2 {
            color: #1a237e;
            font-size: 28px;
            margin-bottom: 10px;
            font-weight: 700;
        }

        .login-header p {
            color: #666;
            font-size: 14px;
        }

        .form-group {
            margin-bottom: 25px;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            color: #333;
            font-weight: 600;
            font-size: 14px;
        }

        .form-group select,
        .form-group input {
            width: 100%;
            height: 50px;
            padding: 0 15px;
            border: 2px solid #e0e0e0;
            border-radius: 12px;
            font-size: 14px;
            transition: all 0.3s;
            font-family: inherit;
        }

        .form-group select:focus,
        .form-group input:focus {
            outline: none;
            border-color: #667eea;
            box-shadow: 0 0 0 3px rgba(102,126,234,0.1);
        }

        .input-group {
            position: relative;
        }

        .toggle-password {
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
            cursor: pointer;
            color: #999;
            font-size: 20px;
            transition: color 0.3s;
        }

        .toggle-password:hover {
            color: #667eea;
        }

        .btn {
            width: 100%;
            height: 50px;
            border: none;
            border-radius: 12px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            font-family: inherit;
        }

        .btn-primary {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
        }

        .btn-primary:hover:not(:disabled) {
            transform: translateY(-2px);
            box-shadow: 0 10px 25px rgba(102,126,234,0.4);
        }

        .btn-primary:disabled {
            opacity: 0.6;
            cursor: not-allowed;
        }

        .btn-secondary {
            background: #6c757d;
            color: white;
            margin-top: 10px;
        }

        .btn-secondary:hover {
            background: #5a6268;
        }

        .alert {
            padding: 12px 15px;
            border-radius: 12px;
            margin-bottom: 20px;
            text-align: center;
            font-size: 14px;
            animation: slideIn 0.3s ease;
        }

        @keyframes slideIn {
            from {
                opacity: 0;
                transform: translateY(-10px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .alert-error {
            background: #fee;
            color: #c62828;
            border: 1px solid #ffcdd2;
        }

        .alert-warning {
            background: #fff3e0;
            color: #e65100;
            border: 1px solid #ffe0b2;
        }

        .alert-success {
            background: #e8f5e9;
            color: #2e7d32;
            border: 1px solid #c8e6c9;
        }

        .countdown {
            text-align: center;
            font-size: 24px;
            font-weight: bold;
            color: #c62828;
            margin: 15px 0;
            direction: ltr;
        }

        .backup-link {
            display: block;
            text-align: center;
            margin-top: 20px;
            color: #667eea;
            text-decoration: none;
            font-size: 14px;
            transition: color 0.3s;
        }

        .backup-link:hover {
            color: #764ba2;
            text-decoration: underline;
        }

        .footer {
            text-align: center;
            margin-top: 25px;
            color: #999;
            font-size: 12px;
        }

        /* Modal Styles */
        .modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0,0,0,0.5);
            animation: fadeIn 0.3s;
        }

        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }

        .modal-content {
            background-color: white;
            margin: 10% auto;
            padding: 30px;
            border-radius: 20px;
            width: 90%;
            max-width: 450px;
            position: relative;
            animation: slideUp 0.3s;
        }

        @keyframes slideUp {
            from {
                transform: translateY(50px);
                opacity: 0;
            }
            to {
                transform: translateY(0);
                opacity: 1;
            }
        }

        .close {
            position: absolute;
            left: 20px;
            top: 20px;
            font-size: 28px;
            font-weight: bold;
            cursor: pointer;
            color: #999;
            transition: color 0.3s;
        }

        .close:hover {
            color: #333;
        }

        .modal-content h3 {
            color: #1a237e;
            margin-bottom: 20px;
            text-align: center;
            font-size: 24px;
        }

        .attempts-info {
            text-align: center;
            font-size: 12px;
            color: #999;
            margin-top: 15px;
        }

        @media (max-width: 480px) {
            .login-box {
                padding: 30px 20px;
            }
            
            .login-header h2 {
                font-size: 24px;
            }
        }
    </style>
</head>
<body class="login-page">
    <div class="login-container">
        <div class="login-box">
            <div class="login-header">
                <h2>🏪 نظام الكاشير</h2>
                <p>تسجيل الدخول إلى لوحة التحكم</p>
            </div>
            
            <?php if (isset($_SESSION['backup_login_notice'])): ?>
                <div class="alert alert-success">
                    <?= htmlspecialchars($_SESSION['backup_login_notice']) ?>
                    <?php unset($_SESSION['backup_login_notice']); ?>
                </div>
            <?php endif; ?>
            
            <?php if (isset($error)): ?>
                <div class="alert alert-error"><?= htmlspecialchars($error) ?></div>
            <?php endif; ?>
            
            <?php if ($isLocked ?? false): ?>
                <div class="alert alert-warning">
                    ⚠️ تم تجاوز الحد المسموح للمحاولات
                    <div class="countdown" id="countdown"></div>
                    <a href="#" id="backupLoginLink" class="backup-link">🔐 الدخول باستخدام كلمة المرور الاحتياطية</a>
                </div>
            <?php endif; ?>
            
            <form action="<?= BASE_URL ?>/login" method="POST" id="loginForm" autocomplete="off">
                <div class="form-group">
                    <label for="role">👤 نوع المستخدم</label>
                    <select id="role" name="role" required <?= ($isLocked ?? false) ? 'disabled' : '' ?>>
                        <option value="">-- اختر نوع المستخدم --</option>
                        <option value="admin">👑 مدير النظام</option>
                        <option value="staff">👔 موظف</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label for="password">🔒 كلمة المرور</label>
                    <div class="input-group">
                        <input type="password" 
                               id="password" 
                               name="password" 
                               autocomplete="new-password" 
                               readonly
                               onfocus="this.removeAttribute('readonly')"
                               placeholder="أدخل كلمة المرور"
                               required <?= ($isLocked ?? false) ? 'disabled' : '' ?>>
                        <span class="toggle-password" onclick="togglePassword()">👁️</span>
                    </div>
                </div>
                
                <?php if (!($isLocked ?? false)): ?>
                    <button type="submit" class="btn btn-primary" id="submitBtn">🚪 دخول</button>
                <?php else: ?>
                    <button type="button" class="btn btn-primary" disabled>⏳ النظام مقفل مؤقتاً</button>
                <?php endif; ?>
            </form>
            
            <?php if (isset($attempts) && $attempts > 0 && !($isLocked ?? false)): ?>
                <div class="attempts-info">
                    🔒 محاولات فاشلة: <?= $attempts ?> / <?= $maxAttempts ?? 15 ?>
                </div>
            <?php endif; ?>
            
            <?php if (!($isLocked ?? false)): ?>
                <a href="#" id="backupLoginLinkNormal" class="backup-link">🔐 تسجيل الدخول الاحتياطي (للمدير فقط)</a>
            <?php endif; ?>
            
            <div class="footer">
                <p>نظام إدارة المخزون والمبيعات المتقدم</p>
                <p>© <?= date('Y') ?> جميع الحقوق محفوظة</p>
            </div>
        </div>
    </div>

    <!-- Modal لتسجيل الدخول الاحتياطي -->
    <div id="backupModal" class="modal">
        <div class="modal-content">
            <span class="close">&times;</span>
            <h3>🔐 تسجيل الدخول الاحتياطي</h3>
            <p style="text-align: center; color: #666; margin-bottom: 20px; font-size: 14px;">
                ⚠️ هذا الخيار مخصص للمديرين فقط
            </p>
            <form action="<?= BASE_URL ?>/backup-login" method="POST" autocomplete="off">
                <div class="form-group">
                    <label for="modal_username">👤 اسم المستخدم</label>
                    <input type="text" 
                           id="modal_username" 
                           name="username" 
                           autocomplete="off"
                           placeholder="أدخل اسم المستخدم"
                           required>
                </div>
                <div class="form-group">
                    <label for="modal_backup_password">🔑 كلمة المرور الاحتياطية</label>
                    <div class="input-group">
                        <input type="password" 
                               id="modal_backup_password" 
                               name="backup_password" 
                               autocomplete="new-password" 
                               readonly
                               onfocus="this.removeAttribute('readonly')"
                               placeholder="أدخل كلمة المرور الاحتياطية"
                               required>
                        <span class="toggle-password" onclick="toggleBackupPassword()">👁️</span>
                    </div>
                </div>
                <button type="submit" class="btn btn-primary">✅ تسجيل الدخول الاحتياطي</button>
                <button type="button" class="btn btn-secondary" id="closeModal">↩️ رجوع</button>
            </form>
        </div>
    </div>

    <script>
        // toggle password visibility
        function togglePassword() {
            const pwd = document.getElementById('password');
            const icon = event.target;
            if (pwd.type === 'password') {
                pwd.type = 'text';
                icon.textContent = '🙈';
            } else {
                pwd.type = 'password';
                icon.textContent = '👁️';
            }
        }
        
        function toggleBackupPassword() {
            const pwd = document.getElementById('modal_backup_password');
            const icon = event.target;
            if (pwd.type === 'password') {
                pwd.type = 'text';
                icon.textContent = '🙈';
            } else {
                pwd.type = 'password';
                icon.textContent = '👁️';
            }
        }
        
        // Countdown timer
        <?php if (isset($lockUntil) && $lockUntil > time()): ?>
        let countdownInterval;
        function updateCountdown() {
            const now = Math.floor(Date.now() / 1000);
            let remaining = <?= $lockUntil ?> - now;
            if (remaining <= 0) {
                clearInterval(countdownInterval);
                location.reload();
            } else {
                const countdownElement = document.getElementById('countdown');
                if (countdownElement) {
                    countdownElement.innerText = '⏱️ انتظر ' + remaining + ' ثانية';
                }
            }
        }
        countdownInterval = setInterval(updateCountdown, 1000);
        updateCountdown();
        <?php endif; ?>
        
        // Modal handling
        const modal = document.getElementById('backupModal');
        const openModalBtns = document.querySelectorAll('#backupLoginLink, #backupLoginLinkNormal');
        const closeBtn = document.querySelector('.close');
        const closeModalBtn = document.getElementById('closeModal');
        
        function openModal(e) {
            if(e) e.preventDefault();
            modal.style.display = 'block';
            document.body.style.overflow = 'hidden';
        }
        
        function closeModalFunction() {
            modal.style.display = 'none';
            document.body.style.overflow = 'auto';
        }
        
        openModalBtns.forEach(btn => {
            if(btn) btn.onclick = openModal;
        });
        
        if(closeBtn) closeBtn.onclick = closeModalFunction;
        if(closeModalBtn) closeModalBtn.onclick = closeModalFunction;
        
        window.onclick = function(e) {
            if(e.target == modal) closeModalFunction();
        }
        
        // Prevent browser password saving
        document.addEventListener('DOMContentLoaded', function() {
            const forms = document.querySelectorAll('form');
            forms.forEach(form => {
                form.addEventListener('submit', function() {
                    const passwordFields = form.querySelectorAll('input[type="password"]');
                    passwordFields.forEach(field => {
                        field.setAttribute('autocomplete', 'off');
                    });
                });
            });
        });
        
        // Disable right click on password fields
        const passwordFields = document.querySelectorAll('input[type="password"]');
        passwordFields.forEach(field => {
            field.addEventListener('contextmenu', (e) => e.preventDefault());
        });
    </script>
</body>
</html>