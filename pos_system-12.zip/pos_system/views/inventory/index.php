<?php
ob_start();
// تعطيل جميع الأخطاء في PHP
error_reporting(0);
ini_set('display_errors', 0);
ini_set('display_startup_errors', 0);
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="robots" content="noindex, nofollow, noarchive, nosnippet">
    <meta http-equiv="Cache-Control" content="no-store, no-cache, must-revalidate, max-age=0">
    <meta http-equiv="Pragma" content="no-cache">
    <meta http-equiv="Expires" content="0">
    <meta name="format-detection" content="telephone=no">
    <meta name="format-detection" content="address=no">
    <title><?= $title ?? 'المخزن الرئيسي' ?></title>
    <link rel="stylesheet" href="<?= asset('css/style.css') ?>">
    <style>
        /* ===== تطبيق نمط سطح المكتب المتقدم ===== */
        * {
            user-select: none;
            -webkit-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
        }

        /* السماح بالتحديد فقط في الحقول */
        input, textarea, [contenteditable="true"] {
            user-select: text !important;
            -webkit-user-select: text !important;
            -moz-user-select: text !important;
            -ms-user-select: text !important;
        }

        /* تثبيت تخطيط الصفحة */
        html, body {
            overflow: hidden !important;
            height: 100vh !important;
            width: 100vw !important;
            margin: 0 !important;
            padding: 0 !important;
            cursor: default;
            min-width: 1200px;
        }

        /* منع الطباعة */
        @media print {
            body { display: none !important; }
        }

        /* إزالة القصداير */
        [contenteditable], [draggable] {
            -webkit-user-drag: none;
            user-drag: none;
        }

        /* منع سحب الصور */
        img {
            -webkit-user-drag: none;
            user-drag: none;
            pointer-events: none;
        }

        /* ===== المتغيرات العامة ===== */
        :root {
            --primary: #1a237e;
            --primary-light: #283593;
            --accent: #1976d2;
            --success: #2e7d32;
            --danger: #c62828;
            --warning: #ed6c02;
            --info: #0288d1;
            --gray-100: #f5f5f5;
            --gray-200: #e0e0e0;
            --gray-300: #bdbdbd;
            --gray-600: #757575;
            --gray-800: #424242;
            --shadow: 0 2px 4px rgba(0,0,0,0.1);
            --shadow-lg: 0 4px 12px rgba(0,0,0,0.15);
        }

        /* ===== التخطيط العام ===== */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        .inventory-page {
            height: calc(100vh - 60px);
            margin-top: 0;
            display: flex;
            gap: 15px;
            padding: 15px;
            overflow: hidden;
            background: #F5F7FA;
            min-width: 1200px;
        }

        body {
            margin: 0;
            padding: 0;
            background: var(--gray-100);
            height: 100vh;
            overflow: hidden;
        }

        .main-container {
            padding: 0 !important;
            min-height: auto !important;
        }

        /* ===== الجانب الأيمن ===== */
        .right-panel {
            width: 320px;
            background: white;
            border-radius: 12px;
            box-shadow: var(--shadow);
            display: flex;
            flex-direction: column;
            overflow: hidden;
        }

        /* ===== التبويبات ===== */
        .tabs-header {
            display: flex;
            border-bottom: 2px solid var(--gray-200);
            background: white;
        }

        .tab-btn {
            flex: 1;
            padding: 12px 5px;
            border: none;
            background: none;
            cursor: pointer;
            font-size: 13px;
            font-weight: 500;
            color: var(--gray-600);
            transition: all 0.3s;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 5px;
        }

        .tab-btn i {
            font-size: 16px;
        }

        .tab-btn:hover {
            background: var(--gray-100);
            color: var(--accent);
        }

        .tab-btn.active {
            color: var(--primary);
            border-bottom: 2px solid var(--primary);
            background: #e8eaf6;
        }

        /* ===== محتوى التبويبات ===== */
        .tabs-content {
            flex: 1;
            overflow-y: auto;
            padding: 15px;
            scrollbar-width: thin;
            scrollbar-color: var(--accent) var(--gray-200);
        }

        .tabs-content::-webkit-scrollbar {
            width: 6px;
        }

        .tabs-content::-webkit-scrollbar-track {
            background: var(--gray-200);
            border-radius: 3px;
        }

        .tabs-content::-webkit-scrollbar-thumb {
            background: var(--accent);
            border-radius: 3px;
        }

        .tab-panel {
            display: none;
        }

        .tab-panel.active {
            display: block;
        }

        /* ===== البطاقات ===== */
        .card {
            background: white;
            border-radius: 8px;
            padding: 15px;
            margin-bottom: 15px;
            border: 1px solid var(--gray-200);
        }

        .card-title {
            font-size: 14px;
            font-weight: 600;
            color: var(--primary);
            margin-bottom: 15px;
            padding-bottom: 8px;
            border-bottom: 1px solid var(--gray-200);
            display: flex;
            align-items: center;
            gap: 8px;
        }

        /* ===== حقول الإدخال ===== */
        .form-group {
            margin-bottom: 12px;
        }

        .form-group label {
            display: block;
            font-size: 12px;
            color: var(--gray-600);
            margin-bottom: 4px;
        }

        .form-group label .required {
            color: var(--danger);
            margin-right: 2px;
        }

        .form-control {
            width: 100%;
            height: 36px;
            padding: 0 10px;
            border: 1px solid var(--gray-200);
            border-radius: 6px;
            font-size: 13px;
            transition: all 0.3s;
        }

        .form-control:focus {
            outline: none;
            border-color: var(--accent);
            box-shadow: 0 0 0 2px rgba(25,118,210,0.1);
        }

        textarea.form-control {
            height: 60px;
            padding: 8px 10px;
            resize: vertical;
        }

        /* ===== تحكم الكمية ===== */
        .quantity-control {
            display: flex;
            align-items: center;
            gap: 5px;
        }

        .quantity-control input {
            width: 70px;
            text-align: center;
            -moz-appearance: textfield;
        }

        .quantity-control input::-webkit-outer-spin-button,
        .quantity-control input::-webkit-inner-spin-button {
            -webkit-appearance: none;
            margin: 0;
        }

        .quantity-btn {
            width: 28px;
            height: 28px;
            border: 1px solid var(--gray-200);
            background: white;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: all 0.3s;
        }

        .quantity-btn:hover {
            background: var(--accent);
            color: white;
            border-color: var(--accent);
        }

        /* ===== الأزرار ===== */
        .btn-group {
            display: flex;
            gap: 8px;
            margin-top: 15px;
        }

        .btn {
            height: 34px;
            padding: 0 15px;
            border: none;
            border-radius: 6px;
            font-size: 12px;
            font-weight: 500;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 5px;
            transition: all 0.3s;
        }

        .btn-sm {
            height: 28px;
            padding: 0 10px;
            font-size: 11px;
        }

        .btn-primary { background: var(--accent); color: white; }
        .btn-primary:hover { background: #1565c0; }

        .btn-success { background: var(--success); color: white; }
        .btn-success:hover { background: #1b5e20; }

        .btn-danger { background: var(--danger); color: white; }
        .btn-danger:hover { background: #b71c1c; }

        .btn-warning { background: var(--warning); color: white; }
        .btn-warning:hover { background: #e65100; }

        .btn-info { background: var(--info); color: white; }
        .btn-info:hover { background: #01579b; }

        .btn-outline {
            background: white;
            border: 1px solid var(--gray-200);
            color: var(--gray-600);
        }
        .btn-outline:hover { background: var(--gray-100); }

        /* ===== الجانب الأيسر ===== */
        .left-panel {
            flex: 1;
            background: white;
            border-radius: 12px;
            box-shadow: var(--shadow);
            display: flex;
            flex-direction: column;
            overflow: hidden;
        }

        /* ===== شريط الأدوات ===== */
        .toolbar {
            padding: 12px 15px;
            background: var(--gray-100);
            border-bottom: 1px solid var(--gray-200);
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 10px;
        }

        .toolbar-left {
            display: flex;
            gap: 8px;
            flex-wrap: wrap;
        }

        .toolbar-right {
            display: flex;
            align-items: center;
            gap: 15px;
            font-size: 13px;
        }

        .page-size {
            width: 60px;
            height: 30px;
            border: 1px solid var(--gray-200);
            border-radius: 4px;
            padding: 0 5px;
        }

        /* ===== شريط الإحصائيات ===== */
        .stats-bar {
            background: var(--gray-800);
            color: white;
            padding: 12px;
            display: grid;
            grid-template-columns: repeat(6, 1fr);
            gap: 1px;
        }

        .stat-item {
            text-align: center;
            padding: 5px;
            cursor: pointer;
            transition: all 0.3s;
        }

        .stat-item:hover {
            background: rgba(255,255,255,0.1);
            transform: translateY(-2px);
        }

        .stat-number {
            font-size: 16px;
            font-weight: bold;
        }

        .stat-label {
            font-size: 10px;
            opacity: 0.8;
        }

        /* ===== الجدول ===== */
        .table-container {
            flex: 1;
            overflow: auto;
            padding: 15px;
            scrollbar-width: thin;
            scrollbar-color: var(--accent) var(--gray-200);
        }

        table {
            width: 100%;
            border-collapse: collapse;
            min-width: 1000px;
            font-size: 13px;
        }

        th {
            background: var(--gray-200);
            padding: 10px;
            font-weight: 600;
            color: var(--gray-800);
            position: sticky;
            top: 0;
            z-index: 10;
        }

        td {
            padding: 10px;
            border-bottom: 1px solid var(--gray-200);
        }

        tr:hover {
            background: #f5f5f5;
        }

        /* ===== أزرار الإجراءات ===== */
        .action-buttons {
            display: flex;
            gap: 4px;
            justify-content: center;
        }

        .btn-icon {
            width: 26px;
            height: 26px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 14px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            transition: all 0.2s;
        }

        .btn-icon:hover {
            transform: scale(1.1);
        }

        /* ===== حالات المنتج ===== */
        .status-badge {
            display: inline-block;
            padding: 4px 8px;
            border-radius: 12px;
            font-size: 11px;
            font-weight: 500;
        }

        .status-available { background: #c8e6c9; color: #1b5e20; }
        .status-low { background: #fff3e0; color: #e65100; }
        .status-expired { background: #ffcdd2; color: #b71c1c; }
        .status-warning { background: #fff3e0; color: #e65100; }

        /* ===== البحث بالباركود ===== */
        .search-container {
            position: relative;
            margin-bottom: 15px;
        }

        .search-input {
            width: 100%;
            height: 36px;
            padding: 0 35px;
            border: 1px solid var(--gray-200);
            border-radius: 18px;
            font-size: 13px;
        }

        .search-icon {
            position: absolute;
            right: 12px;
            top: 50%;
            transform: translateY(-50%);
            color: var(--gray-600);
        }

        .barcode-results {
            position: absolute;
            top: 100%;
            right: 0;
            left: 0;
            background: white;
            border: 1px solid var(--gray-200);
            border-radius: 8px;
            box-shadow: var(--shadow-lg);
            z-index: 1000;
            max-height: 250px;
            overflow-y: auto;
        }

        .result-item {
            padding: 8px 12px;
            border-bottom: 1px solid var(--gray-200);
            cursor: pointer;
            font-size: 12px;
        }

        .result-item:hover {
            background: var(--gray-100);
        }

        .result-item strong {
            display: block;
            color: var(--gray-800);
        }

        .result-item small {
            color: var(--gray-600);
        }

        /* ===== النوافذ المنبثقة ===== */
        .modal {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0,0,0,0.5);
            display: none;
            align-items: center;
            justify-content: center;
            z-index: 10000;
        }

        .modal.active {
            display: flex;
        }

        .modal-content {
            background: white;
            border-radius: 12px;
            width: 90%;
            max-width: 600px;
            max-height: 80vh;
            overflow-y: auto;
        }

        .modal-header {
            padding: 15px 20px;
            border-bottom: 1px solid var(--gray-200);
            display: flex;
            justify-content: space-between;
            align-items: center;
            background: var(--primary);
            color: white;
            border-radius: 12px 12px 0 0;
        }

        .modal-header h3 {
            font-size: 16px;
        }

        .modal-close {
            background: none;
            border: none;
            color: white;
            font-size: 20px;
            cursor: pointer;
        }

        .modal-body {
            padding: 20px;
        }

        /* ===== تجاوب ===== */
        @media (max-width: 1200px) {
            .inventory-page {
                flex-direction: column;
            }
            .right-panel {
                width: 100%;
                height: 400px;
            }
            .stats-bar {
                grid-template-columns: repeat(3, 1fr);
            }
        }

        /* تنسيق شريط التمرير */
        ::-webkit-scrollbar {
            width: 8px;
            height: 8px;
        }

        ::-webkit-scrollbar-track {
            background: #f1f1f1;
            border-radius: 4px;
        }

        ::-webkit-scrollbar-thumb {
            background: #B0BEC5;
            border-radius: 4px;
        }

        ::-webkit-scrollbar-thumb:hover {
            background: #90A4AE;
        }

        /* منع ظهور أدوات المطور */
        .dev-tools-hide {
            display: none !important;
        }

        
    </style>
</head>
<body>

    <div class="inventory-page">
        <!-- ===== الجانب الأيمن ===== -->
        <div class="right-panel">
            <div class="tabs-header">
                <button class="tab-btn active" data-target="tab1">
                    <span>📦</span> المنتج
                </button>
                <button class="tab-btn" data-target="tab2">
                    <span>🏭</span> إضافة دفعة
                </button>
                <button class="tab-btn" data-target="tab3">
                    <span>🔍</span> فلاتر
                </button>
            </div>

            <div class="tabs-content">
                <!-- تبويب معلومات المنتج -->
                <div class="tab-panel active" id="tab1">
                    <div class="card">
                        <div class="card-title">
                            <span>📋</span> معلومات المنتج
                        </div>
                        
                        <div class="form-group">
                            <label>اسم المنتج <span class="required">*</span></label>
                            <input type="text" class="form-control" id="product_name" placeholder="أدخل اسم المنتج">
                        </div>

                        <div class="form-group">
                            <label>الباركود <span class="required">*</span></label>
                            <input type="text" class="form-control" id="product_barcode" placeholder="أدخل الباركود">
                        </div>
                        
                        <div class="form-group">
                            <label>القسم</label>
                            <div style="display: flex; gap: 5px;">
                                <select class="form-control" id="product_category" style="flex: 1;">
                                    <option value="">اختر القسم</option>
                                    <?php foreach ($categories as $category): ?>
                                        <option value="<?= $category['id'] ?>"><?= htmlspecialchars($category['name']) ?></option>
                                    <?php endforeach; ?>
                                </select>
                                <button type="button" class="btn btn-info" style="width: 40px;" onclick="openAddCategoryModal()" title="إضافة قسم جديد">
                                    <span>➕</span>
                                </button>
                            </div>
                        </div>

                        <div class="form-group">
                            <label>وحدات/كرتون <span class="required">*</span></label>
                            <div class="quantity-control">
                                <button class="quantity-btn" onclick="decrementUnits()">-</button>
                                <input type="number" class="form-control" id="units_per_carton" value="1" min="1">
                                <button class="quantity-btn" onclick="incrementUnits()">+</button>
                            </div>
                        </div>

                        <div class="btn-group">
                            <button class="btn btn-success" onclick="addProduct()" style="flex: 2;">
                                <span>➕</span> إضافة
                            </button>
                            <button class="btn btn-outline" onclick="clearProductForm()" style="flex: 1;">
                                <span>🔄</span> مسح
                            </button>
                        </div>
                    </div>
                </div>

                <!-- تبويب إضافة دفعة -->
                <div class="tab-panel" id="tab2">
                    <div class="card">
                        <div class="card-title">
                            <span>🏭</span> إضافة دفعة جديدة
                        </div>

                        <div class="search-container">
                            <span class="search-icon">🔍</span>
                            <input type="text" class="search-input" id="barcode_search" 
                                   placeholder="ابحث بالباركود أو اسم المنتج...">
                            <div id="barcode_results"></div>
                        </div>

                        <div class="form-group">
                            <label>المنتج <span class="required">*</span></label>
                            <select class="form-control" id="batch_product_id">
                                <option value="">اختر المنتج</option>
                                <?php foreach ($products as $product): ?>
                                    <option value="<?= $product['id'] ?>" data-units="<?= $product['units_per_carton'] ?>">
                                        <?= htmlspecialchars($product['name']) ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="form-group">
                            <label>رقم الدفعة <span class="required">*</span></label>
                            <div style="display: flex; gap: 5px;">
                                <input type="text" class="form-control" id="batch_number" style="flex: 1;">
                                <button class="btn btn-outline" style="width: 36px;" onclick="generateBatchNumber()">🔄</button>
                            </div>
                        </div>

                        <div class="form-group">
                            <label>عدد الكراتين <span class="required">*</span></label>
                            <div class="quantity-control">
                                <button class="quantity-btn" onclick="decrementCartons()">-</button>
                                <input type="number" class="form-control" id="cartons_quantity" value="1" min="1">
                                <button class="quantity-btn" onclick="incrementCartons()">+</button>
                            </div>
                        </div>

                        <div class="form-group">
                            <label>تكلفة الكرتون <span class="required">*</span></label>
                            <input type="number" step="0.01" class="form-control" id="cost_price_carton" value="0.00">
                        </div>

                        <div class="form-group">
                            <label>سعر الوحدة <span class="required">*</span></label>
                            <input type="number" step="0.01" class="form-control" id="selling_price_unit" value="0.00">
                            <small id="profitDisplay" style="color: var(--success); font-size: 11px; display: block; margin-top: 4px;">
                                الربح المتوقع: 0.00 ريال
                            </small>
                        </div>

                        <div class="form-group">
                            <label>تاريخ الانتهاء <span class="required">*</span></label>
                            <input type="date" class="form-control" id="expiry_date" value="<?= date('Y-m-d', strtotime('+1 year')) ?>">
                        </div>

                        <div class="form-group">
                            <label>ملاحظات</label>
                            <textarea class="form-control" id="batch_notes" placeholder="ملاحظات إضافية..."></textarea>
                        </div>

                        <div class="btn-group">
                            <button class="btn btn-success" onclick="addBatch()" style="flex: 2;">
                                <span>✅</span> إضافة
                            </button>
                            <button class="btn btn-outline" onclick="clearBatchForm()" style="flex: 1;">
                                <span>🔄</span> مسح
                            </button>
                        </div>
                    </div>
                </div>

                <!-- تبويب فلاتر البحث -->
                <div class="tab-panel" id="tab3">
                    <div class="card">
                        <div class="card-title">
                            <span>🔍</span> فلاتر البحث
                        </div>

                        <div class="form-group">
                            <label>بحث سريع</label>
                            <input type="text" class="form-control" id="quickSearch" 
                                   placeholder="ابحث باسم المنتج أو الباركود...">
                        </div>

                        <div style="margin: 15px 0;">
                            <label style="font-size: 12px; color: var(--gray-600); margin-bottom: 8px; display: block;">
                                تصفية حسب الحالة:
                            </label>
                            <div style="display: flex; flex-direction: column; gap: 6px;">
                                <label style="display: flex; align-items: center; gap: 8px; font-size: 12px;">
                                    <input type="radio" name="status_filter" value="" checked> الكل
                                </label>
                                <label style="display: flex; align-items: center; gap: 8px; font-size: 12px;">
                                    <input type="radio" name="status_filter" value="expired"> 🔴 منتهي الصلاحية
                                </label>
                                <label style="display: flex; align-items: center; gap: 8px; font-size: 12px;">
                                    <input type="radio" name="status_filter" value="expiring"> 🟡 قريب الانتهاء
                                </label>
                                <label style="display: flex; align-items: center; gap: 8px; font-size: 12px;">
                                    <input type="radio" name="status_filter" value="low"> ⚠️ مخزون منخفض
                                </label>
                            </div>
                        </div>

                        <div class="form-group">
                            <label>المنتج</label>
                            <select class="form-control" id="filterProduct">
                                <option value="">الكل</option>
                                <?php foreach ($products as $product): ?>
                                    <option value="<?= $product['id'] ?>"><?= htmlspecialchars($product['name']) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="form-group">
                            <label>القسم</label>
                            <select class="form-control" id="filterCategory">
                                <option value="">الكل</option>
                                <?php foreach ($categories as $category): ?>
                                    <option value="<?= $category['id'] ?>"><?= htmlspecialchars($category['name']) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div style="display: flex; gap: 10px; margin: 15px 0;">
                            <input type="date" class="form-control" id="dateFrom" placeholder="من">
                            <input type="date" class="form-control" id="dateTo" placeholder="إلى">
                        </div>

                        <div class="btn-group">
                            <button class="btn btn-primary" onclick="applyFilters()" style="flex: 1;">
                                <span>🔍</span> تطبيق
                            </button>
                            <button class="btn btn-outline" onclick="resetFilters()" style="flex: 1;">
                                <span>🔄</span> إعادة تعيين
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- ===== الجانب الأيسر ===== -->
        <div class="left-panel">
            <!-- شريط الأدوات -->
            <div class="toolbar">
                <div class="toolbar-left">
                    <button class="btn btn-outline btn-sm" onclick="refreshData()">
                        <span>🔄</span>
                    </button>
                </div>
                <div class="toolbar-right">
                    
                    <span style="font-weight: bold;" id="totalBatches"> <?= $stats['total_batches'] ?? 0 ?> :منتج</span>
                </div>
            </div>

            <!-- شريط الإحصائيات -->
            <div class="stats-bar">
                <div class="stat-item" onclick="filterByType('all')">
                    <div class="stat-number"><?= $stats['total_batches'] ?? 0 ?></div>
                    <div class="stat-label">إجمالي الدفعات</div>
                </div>
                <div class="stat-item" onclick="filterByType('cartons')">
                    <div class="stat-number"><?= $stats['total_cartons'] ?? 0 ?></div>
                    <div class="stat-label">إجمالي الكراتين</div>
                </div>
                <div class="stat-item" onclick="filterByType('value')">
                    <div class="stat-number"><?= number_format($stats['total_selling_value'] ?? 0, 0) ?></div>
                    <div class="stat-label">قيمة المخزون</div>
                </div>
                <div class="stat-item" onclick="filterByType('expired')">
                    <div class="stat-number" style="color: #ff8a80;"><?= $stats['expired_batches'] ?? 0 ?></div>
                    <div class="stat-label">منتهي</div>
                </div>
                <div class="stat-item" onclick="filterByType('expiring')">
                    <div class="stat-number" style="color: #ffb74d;"><?= $stats['expiring_soon'] ?? 0 ?></div>
                    <div class="stat-label">قريب</div>
                </div>
                <div class="stat-item" onclick="filterByType('low')">
                    <div class="stat-number" style="color: #ffb74d;"><?= ($stats['low_stock_count'] ?? 0) ?></div>
                    <div class="stat-label">منخفض</div>
                </div>
            </div>

            <!-- الجدول -->
            <div class="table-container">
                <table>
                    <thead>
                        <tr>
                            <th style="width: 30px;"><input type="checkbox" id="selectAll" onchange="toggleSelectAll()"></th>
                            <th style="width: 40px;">#</th>
                            <th>المنتج</th>
                            <th>رقم الدفعة</th>
                            <th>الكراتين</th>
                            <th>تكلفة الكرتون</th>
                            <th>سعر الوحدة</th>
                            <th>تاريخ الانتهاء</th>
                            <th>الحالة</th>
                            <th style="width: 100px;">إجراءات</th>
                        </tr>
                    </thead>
                    <tbody id="inventoryTableBody">
                        <?php if (empty($batches)): ?>
                            <tr>
                                <td colspan="10" style="text-align: center; padding: 40px;">
                                    <span style="font-size: 40px; display: block; margin-bottom: 10px;">📦</span>
                                    <p>لا توجد دفعات في المخزون</p>
                                </td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($batches as $index => $batch): 
                                $today = strtotime(date('Y-m-d'));
                                $expiry = strtotime($batch['expiry_date']);
                                $daysLeft = ($expiry - $today) / (60 * 60 * 24);
                                
                                if ($expiry < $today) {
                                    $status = 'منتهي';
                                    $statusClass = 'status-expired';
                                } elseif ($daysLeft <= 30) {
                                    $status = 'قريب';
                                    $statusClass = 'status-warning';
                                } elseif ($batch['cartons_remaining'] < 5) {
                                    $status = 'منخفض';
                                    $statusClass = 'status-low';
                                } else {
                                    $status = 'متاح';
                                    $statusClass = 'status-available';
                                }
                            ?>
                            <tr data-id="<?= $batch['id'] ?>" onclick="selectRow(this)">
                                <td><input type="checkbox" class="row-checkbox" value="<?= $batch['id'] ?>" onclick="event.stopPropagation()"></td>
                                <td><?= $index + 1 ?></td>
                                <td><?= htmlspecialchars($batch['product_name']) ?></td>
                                <td><?= htmlspecialchars($batch['batch_number']) ?></td>
                                <td style="<?= $batch['cartons_remaining'] == 0 ? 'color: #999;' : ($batch['cartons_remaining'] < 5 ? 'color: #e65100; font-weight: bold;' : '') ?>">
                                    <?= $batch['cartons_remaining'] ?>
                                </td>
                                <td><?= number_format($batch['cost_price_carton'], 2) ?> ريال</td>
                                <td><?= number_format($batch['selling_price_unit'], 2) ?> ريال</td>
                                <td style="background: <?= $expiry < $today ? '#ffebee' : ($daysLeft <= 30 ? '#fff3e0' : 'transparent') ?>">
                                    <?= date('Y-m-d', strtotime($batch['expiry_date'])) ?>
                                </td>
                                <td><span class="status-badge <?= $statusClass ?>"><?= $status ?></span></td>
<td class="action-buttons">
    <button class="btn-icon btn-success" onclick="moveToShelf(<?= $batch['id'] ?>)" title="رفع إلى الرف">🔼</button>
    <button class="btn-icon btn-primary" onclick="editBatch(<?= $batch['id'] ?>)" title="تعديل">✏️</button>
    <button class="btn-icon btn-info" onclick="showDetails(<?= $batch['id'] ?>)" title="عرض التفاصيل">📋</button>
    <button class="btn-icon btn-danger" onclick="showDeleteBatchModal(<?= $batch['id'] ?>, '<?= htmlspecialchars($batch['product_name']) ?>', '<?= htmlspecialchars($batch['batch_number']) ?>')" title="حذف الدفعة">🗑️</button>
</td>
                            </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

                <!-- أزرار الإجراءات السريعة -->
            <div style="padding: 12px 15px; background: var(--gray-100); border-top: 1px solid var(--gray-200); display: flex; gap: 8px;">
                <button class="btn btn-primary btn-sm" style="flex: 1;" onclick="openActivityLog()">
                    <span>📝</span> سجل الحركات
                </button>
                <button class="btn btn-primary btn-sm" style="flex: 1;" onclick="openAlerts()">
                    <span>⚠️</span> تنبيهات
                    <?php if (($stats['expired_batches'] ?? 0) > 0): ?>
                        <span class="alert-badge" style="background: var(--danger); color: white; padding: 2px 6px; border-radius: 10px; margin-right: 5px;">
                            <?= $stats['expired_batches'] ?>
                        </span>
                    <?php endif; ?>
                </button>
                <button class="btn btn-danger btn-sm" style="flex: 1;" onclick="showDeleteOptions()">
                    <span>🗑️</span> حذف
                </button>
            </div>
        </div>
    </div>

    <!-- ===== نافذة إضافة قسم جديد ===== -->
    <div class="modal" id="addCategoryModal">
        <div class="modal-content" style="max-width: 450px;">
            <div class="modal-header">
                <h3>➕ إضافة قسم جديد</h3>
                <button class="modal-close" onclick="closeAddCategoryModal()">✕</button>
            </div>
            <div class="modal-body">
                <div class="form-group">
                    <label>اسم القسم <span class="required">*</span></label>
                    <input type="text" id="new_category_name" class="form-control" placeholder="أدخل اسم القسم" maxlength="50">
                </div>
                
                <div class="form-group">
                    <label>وصف القسم</label>
                    <textarea id="new_category_description" class="form-control" rows="3" placeholder="وصف القسم (اختياري)"></textarea>
                </div>
                
                <div class="btn-group" style="margin-top: 20px;">
                    <button class="btn btn-success" onclick="saveNewCategory()" style="flex: 2;">
                        <span>💾</span> حفظ
                    </button>
                    <button class="btn btn-outline" onclick="closeAddCategoryModal()" style="flex: 1;">
                        <span>❌</span> إلغاء
                    </button>
                </div>
            </div>
        </div>
    </div>

    <script>
        const BASE_URL = '<?= BASE_URL ?>';
    </script>
    
    <!-- تحميل JavaScript مع التأكد من وجوده -->
    <script src="<?= BASE_URL ?>/assets/js/inventory.js?v=<?= time() ?>"></script>
    
    <script>
        // ===== تعطيل جميع رسائل Console في الإنتاج =====
        (function disableConsole() {
            if (window.location.hostname !== 'localhost' && 
                !window.location.hostname.includes('127.0.0.1') && 
                !window.location.hostname.includes('::1')) {
                
                const noop = function() {};
                const methods = ['log', 'info', 'warn', 'error', 'debug', 'trace', 'table', 'group', 'groupCollapsed', 'groupEnd'];
                
                methods.forEach(method => {
                    console[method] = noop;
                });
                
                window.onerror = function() { return true; };
                window.onunhandledrejection = function() { return true; };
            }
        })();

        // دالة تحديد الصف
        function selectRow(row) {
            document.querySelectorAll('tr.selected').forEach(r => {
                r.classList.remove('selected');
                r.style.background = '';
            });
            
            row.classList.add('selected');
            row.style.background = '#e3f2fd';
            
            const moveBtn = document.getElementById('moveSelectedBtn');
            if (moveBtn) {
                moveBtn.disabled = false;
            }
        }

        // دالة تحديد الكل
        function toggleSelectAll() {
            const selectAll = document.getElementById('selectAll');
            const checkboxes = document.querySelectorAll('.row-checkbox');
            
            checkboxes.forEach(cb => {
                cb.checked = selectAll.checked;
            });
            
            const moveBtn = document.getElementById('moveSelectedBtn');
            if (moveBtn) {
                const anyChecked = document.querySelectorAll('.row-checkbox:checked').length > 0;
                moveBtn.disabled = !anyChecked;
            }
        }

        // تحديث زر النقل عند تغيير التحديد
        document.addEventListener('change', function(e) {
            if (e.target.classList.contains('row-checkbox')) {
                const anyChecked = document.querySelectorAll('.row-checkbox:checked').length > 0;
                const moveBtn = document.getElementById('moveSelectedBtn');
                if (moveBtn) {
                    moveBtn.disabled = !anyChecked;
                }
            }
        });

        // ===== دوال إدارة الأقسام =====
        function openAddCategoryModal() {
            document.getElementById('new_category_name').value = '';
            document.getElementById('new_category_description').value = '';
            document.getElementById('addCategoryModal').classList.add('active');
        }

        function closeAddCategoryModal() {
            document.getElementById('addCategoryModal').classList.remove('active');
        }

        function saveNewCategory() {
            const name = document.getElementById('new_category_name').value.trim();
            const description = document.getElementById('new_category_description').value.trim();
            
            if (!name) {
                alert('الرجاء إدخال اسم القسم');
                return;
            }
            
            const saveBtn = document.querySelector('#addCategoryModal .btn-success');
            const originalText = saveBtn.innerHTML;
            saveBtn.innerHTML = '⏳ جاري الحفظ...';
            saveBtn.disabled = true;
            
            const data = { name: name, description: description };
            
            fetch(BASE_URL + '/inventory/add-category', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(data)
            })
            .then(response => response.json())
            .then(result => {
                saveBtn.innerHTML = originalText;
                saveBtn.disabled = false;
                
                if (result.success) {
                    alert('✅ تم إضافة القسم بنجاح');
                    closeAddCategoryModal();
                    
                    if (result.categories && Array.isArray(result.categories)) {
                        updateCategoriesDropdown(result.categories);
                    } else {
                        refreshCategories();
                    }
                } else {
                    alert('❌ ' + (result.message || 'فشل إضافة القسم'));
                }
            })
            .catch(() => {
                saveBtn.innerHTML = originalText;
                saveBtn.disabled = false;
                alert('حدث خطأ في الاتصال بالخادم');
            });
        }

        function refreshCategories() {
            fetch(BASE_URL + '/inventory/get-categories')
                .then(response => response.json())
                .then(data => {
                    if (data.success && data.categories) {
                        updateCategoriesDropdown(data.categories);
                    }
                })
                .catch(() => {});
        }

        function updateCategoriesDropdown(categories) {
            const select = document.getElementById('product_category');
            if (!select) return;
            
            const currentValue = select.value;
            select.innerHTML = '<option value="">اختر القسم</option>';
            
            if (categories && Array.isArray(categories) && categories.length > 0) {
                categories.forEach(category => {
                    const option = document.createElement('option');
                    option.value = category.id;
                    option.textContent = category.name;
                    select.appendChild(option);
                });
            }
            
            if (currentValue && Array.from(select.options).some(opt => opt.value == currentValue)) {
                select.value = currentValue;
            }
        }
    </script>
</body>
</html>

<?php
$content = ob_get_clean();
require BASE_PATH . 'views/layouts/main.php';
?>