<?php
ob_start();
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $title ?? 'رف البيع' ?></title>
    
    <!-- منع فهرسة النظام في محركات البحث -->
    <meta name="robots" content="noindex, nofollow, noarchive">
    
    <link rel="stylesheet" href="<?= asset('css/style.css') ?>">
    
   <style>
    /* ===== منع الطباعة تماماً ===== */
    @media print {
        body { display: none !important; }
    }
    
    /* ===== منع تحديد النص في النظام كامل ===== */
    * {
        user-select: none !important;
        -webkit-user-select: none !important;
        -moz-user-select: none !important;
        -ms-user-select: none !important;
        -webkit-touch-callout: none !important;
        -khtml-user-select: none !important;
    }
    
    /* السماح بتحديد النص فقط داخل حقول الإدخال */
    input, textarea, select, [contenteditable="true"] {
        user-select: text !important;
        -webkit-user-select: text !important;
        -moz-user-select: text !important;
        -ms-user-select: text !important;
    }
    
    /* منع مؤشر الكتابة (I-beam) في كل مكان ما عدا الحقول */
    body, div, span, table, tr, td, th, h1, h2, h3, p, button, .shelf-code, .product-name, .status-badge {
        cursor: default !important;
    }
    
    input, textarea, select, .search-input {
        cursor: text !important;
    }
    
    button, .tab-btn, .filter-btn, .toolbar-btn, .action-btn, .dropdown-header, .field-icon.barcode {
        cursor: pointer !important;
    }
    
    /* ===== المتغيرات العامة - ألوان هادئة احترافية ===== */
    :root {
        --primary: #1a237e;
        --primary-light: #283593;
        --primary-soft: #e8eaf6;
        --accent: #1976d2;
        --success: #2e7d32;
        --success-soft: #e8f5e9;
        --danger: #c62828;
        --danger-soft: #ffebee;
        --warning: #ed6c02;
        --warning-soft: #fff3e0;
        --info: #0288d1;
        --gray-50: #fafafa;
        --gray-100: #f5f7fa;
        --gray-200: #eef2f7;
        --gray-300: #e0e0e0;
        --gray-400: #bdbdbd;
        --gray-600: #757575;
        --gray-800: #424242;
        --shadow: 0 2px 8px rgba(0,0,0,0.05);
        --shadow-lg: 0 8px 24px rgba(0,0,0,0.12);
        --transition: all 0.2s ease;
    }

    /* ===== إعادة تعيين ===== */
    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    }

    body {
        background: var(--gray-100);
        height: 100vh;
        overflow: hidden;
        margin: 0;
        padding: 0;
    }

    /* ===== تخطيط ثابت مثل برنامج سطح المكتب ===== */
    .desktop-app {
        height: 100vh;
        display: flex;
        flex-direction: column;
        overflow: hidden;
        margin: 0;
        padding: 0;
    }

    /* الشريط العلوي ثابت */
    .top-nav {
        flex-shrink: 0;
        height: 60px;
        background: linear-gradient(135deg, var(--primary), var(--primary-light));
        color: white;
        display: flex;
        align-items: center;
        padding: 0 20px;
        box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        z-index: 100;
    }

    /* المحتوى الرئيسي - يملأ باقي الشاشة */
    .main-content {
        flex: 1;
        min-height: 0;
        padding: 20px;
        overflow: hidden;
        margin: 0;
    }

    /* ===== الحاوية الرئيسية - تقسيم الشاشة ===== */
    .shelf-page {
        height: 100%;
        display: flex;
        gap: 20px;
        overflow: hidden;
        margin: 0;
        padding: 0;
    }

    /* ===== الجانب الأيمن - ثابت العرض مع تمرير داخلي ===== */
    .right-panel {
        width: 30%;
        background: white;
        border-radius: 16px;
        box-shadow: var(--shadow);
        display: flex;
        flex-direction: column;
        overflow: hidden;
        min-height: 0;
        border: 1px solid var(--gray-200);
        
    }

    /* ===== شريط التبديل - ثابت ===== */
    .tabs-header {
        flex-shrink: 0;
        display: flex;
        gap: 8px;
        padding: 20px 20px 10px 20px;
        border-bottom: 1px solid var(--gray-200);

    }

    .tab-btn {
        flex: 1;
        height: 34px;
        border: 1px solid var(--gray-300);
        border-radius: 10px;
        background: white;
        color: var(--gray-800);
        font-size: 14px;
        font-weight: 600;
        cursor: pointer;
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 8px;
        transition: var(--transition);
    }

    .tab-btn i {
        font-size: 18px;
    }

    .tab-btn:hover {
        background: var(--gray-100);
        border-color: var(--gray-400);
    }

    .tab-btn.active {
        background: var(--primary);
        color: white;
        border-color: var(--primary);
    }

    /* ===== منطقة عرض اللوحات - قابلة للتمرير ===== */
    .panels-container {
        flex: 1;
        overflow-y: auto;
        padding: 20px;
        scrollbar-width: thin;
        scrollbar-color: var(--accent) var(--gray-200);
    }

    .panels-container::-webkit-scrollbar {
        width: 6px;
    }

    .panels-container::-webkit-scrollbar-track {
        background: var(--gray-200);
        border-radius: 3px;
    }

    .panels-container::-webkit-scrollbar-thumb {
        background: var(--accent);
        border-radius: 3px;
    }

    .panel {
        display: none;
    }

    .panel.active {
        display: block;
    }

    /* ===== قسم البحث المحسن ===== */
    .search-section {
        background: white;
        border-radius: 12px;
        padding: 20px;
        margin-bottom: 20px;
        box-shadow: 0 2px 8px rgba(0,0,0,0.03);
        border: 1px solid var(--gray-200);
        
    }

    .section-header {
        display: flex;
        align-items: center;
        gap: 8px;
        margin-bottom: 16px;
        font-size: 15px;
        font-weight: 600;
        color: var(--primary);
                height: 2px;

    }

    .section-header i {
        font-size: 18px;
    }

    .search-fields {
        display: flex;
        flex-direction: column;
        gap: 12px;
        margin-bottom: 20px;
    }

    .search-field {
        display: flex;
        align-items: center;
        background: var(--gray-50);
        border: 1px solid var(--gray-300);
        border-radius: 10px;
        overflow: hidden;
        transition: var(--transition);
    }

    .search-field:focus-within {
        border-color: var(--accent);
        box-shadow: 0 0 0 3px rgba(25,118,210,0.1);
    }

    .field-icon {
        width: 48px;
        height: 48px;
        display: flex;
        align-items: center;
        justify-content: center;
        color: var(--gray-600);
        background: var(--gray-200);
        font-size: 18px;
    }

    .field-icon.barcode {
        background: var(--primary);
        color: white;
        cursor: pointer;
        transition: var(--transition);
    }

    .field-icon.barcode:hover {
        background: var(--primary-light);
    }

    .search-input {
        flex: 1;
        height: 48px;
        padding: 0 15px;
        border: none;
        background: transparent;
        font-size: 14px;
        color: var(--gray-800);
        outline: none;
    }

    .search-input::placeholder {
        color: var(--gray-600);
        font-size: 13px;
    }

    /* ===== أزرار الفلاتر - حجم صغير ===== */
    .filter-buttons {
        display: grid;
        grid-template-columns: repeat(4, 1fr);
        gap: 6px;
        margin-top: 15px;
    }

    .filter-btn.small {
        display: flex;
        flex-direction: column;
        align-items: center;
        padding: 8px 2px;
        border: 1px solid var(--gray-300);
        border-radius: 8px;
        background: white;
        cursor: pointer;
        transition: all 0.2s ease;
        min-width: 0;
    }

    .filter-btn.small .filter-icon {
        font-size: 16px;
        margin-bottom: 2px;
    }

    .filter-btn.small .filter-text {
        font-size: 11px;
        font-weight: 600;
        color: var(--gray-800);
        margin-bottom: 2px;
    }

    .filter-btn.small .filter-count {
        font-size: 13px;
        font-weight: 700;
        color: var(--primary);
    }

    .filter-btn.small.available .filter-count { color: var(--success); }
    .filter-btn.small.low .filter-count { color: var(--warning); }
    .filter-btn.small.expired .filter-count { color: var(--danger); }

    .filter-btn.small:hover {
        transform: translateY(-1px);
        box-shadow: 0 2px 6px rgba(0,0,0,0.05);
    }

    .filter-btn.small.active {
        border-width: 2px;
    }

    .filter-btn.small.active[data-filter="all"] {
        border-color: var(--primary);
        background: #e8eaf6;
    }

    .filter-btn.small.active[data-filter="available"] {
        border-color: var(--success);
        background: #e8f5e9;
    }

    .filter-btn.small.active[data-filter="low"] {
        border-color: var(--warning);
        background: #fff3e0;
    }

    .filter-btn.small.active[data-filter="expired"] {
        border-color: var(--danger);
        background: #ffebee;
    }

    /* ===== بطاقات المعلومات ===== */
    .info-card {
        background: white;
        border-radius: 12px;
        padding: 10px;
        margin-bottom: 10px;
        box-shadow: 0 2px 8px rgba(0,0,0,0.03);
        border: 1px solid var(--gray-200);
        
    }

    .info-card:last-child {
        margin-bottom: 0;
    }

    .info-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 16px;
        font-size: 15px;
        font-weight: 600;
        color: var(--primary);
        padding-bottom: 12px;
        border-bottom: 1px solid var(--gray-200);
    }

    .info-header i {
        font-size: 18px;
    }

    .refresh-icon {
        font-size: 18px;
        color: var(--gray-600);
        cursor: pointer;
        transition: var(--transition);
        width: 32px;
        height: 32px;
        display: flex;
        align-items: center;
        justify-content: center;
        border-radius: 6px;
    }

    .refresh-icon:hover {
        background: var(--gray-200);
        color: var(--primary);
        transform: rotate(180deg);
    }

    /* ===== شبكة الإحصائيات ===== */
    .stats-grid {
        display: grid;
        grid-template-columns: repeat(2, 1fr);
        gap: 12px;
    }

    .stat-item {
        background: var(--gray-50);
        padding: 15px 12px;
        border-radius: 10px;
        text-align: center;
        border: 1px solid var(--gray-200);
    }

    .stat-value {
        font-size: 24px;
        font-weight: 700;
        color: var(--primary);
        margin-bottom: 4px;
    }

    .stat-label {
        font-size: 12px;
        color: var(--gray-600);
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 4px;
    }

    /* ===== توزيع الحالات ===== */
    .status-distribution {
        display: flex;
        flex-direction: column;
        gap: 10px;
    }

    .status-row {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 12px 15px;
        background: var(--gray-50);
        border-radius: 10px;
        border: 1px solid var(--gray-200);
    }

    .status-badge {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        padding: 6px 12px;
        border-radius: 20px;
        font-size: 13px;
        font-weight: 500;
    }

    .status-badge.available {
        background: var(--success-soft);
        color: var(--success);
    }

    .status-badge.low {
        background: var(--warning-soft);
        color: var(--warning);
    }

    .status-badge.expired {
        background: var(--danger-soft);
        color: var(--danger);
    }

    /* ===== اللوحة المنسدلة ===== */
    .dropdown-panel {
        background: white;
        border-radius: 12px;
        overflow: hidden;
        border: 1px solid var(--gray-200);
    }

    .dropdown-header {
        padding: 16px 20px;
        background: white;
        display: flex;
        justify-content: space-between;
        align-items: center;
        cursor: pointer;
        font-weight: 600;
        color: var(--primary);
        border-bottom: 1px solid var(--gray-200);
    }

    .dropdown-header i {
        font-size: 18px;
    }

    .dropdown-icon {
        font-size: 16px;
        transition: var(--transition);
    }

    .dropdown-content {
        padding: 20px;
        display: none;
        background: var(--gray-50);
    }

    .dropdown-content.active {
        display: block;
    }

    .info-row {
        display: flex;
        justify-content: space-between;
        padding: 10px 0;
        border-bottom: 1px dashed var(--gray-300);
        font-size: 13px;
    }

    .info-row:last-child {
        border-bottom: none;
    }

    .info-label {
        color: var(--gray-600);
    }

    .info-value {
        font-weight: 600;
        color: var(--gray-800);
    }

    .info-value.success { color: var(--success); }
    .info-value.primary { color: var(--primary); }

    /* ===== قائمة الدفعات ===== */
    .batches-list {
        max-height: 350px;
        overflow-y: auto;
        scrollbar-width: thin;
    }

    .batch-item {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 12px 15px;
        border-bottom: 1px solid var(--gray-200);
        font-size: 13px;
    }

    .batch-item:last-child {
        border-bottom: none;
    }

    .batch-product {
        font-weight: 600;
        color: var(--primary);
    }

    .batch-qty {
        background: var(--gray-200);
        padding: 4px 10px;
        border-radius: 20px;
        font-size: 12px;
    }

    .batch-date {
        color: var(--gray-600);
        font-size: 12px;
    }

    /* ===== الجانب الأيسر - تعديل جذري ===== */
    .left-panel {
        width: 70%;
        background: white;
        border-radius: 16px;
        box-shadow: var(--shadow);
        display: flex;
        flex-direction: column;
        overflow: hidden;
        border: 1px solid var(--gray-200);
        height: 100%;
        margin: 0;
        padding: 0;
    }

    /* ===== شريط الأدوات ===== */
    .toolbar {
        flex-shrink: 0;
        background: white;
        padding: 16px 20px;
        display: flex;
        justify-content: space-between;
        align-items: center;
        border-bottom: 1px solid var(--gray-200);
        height: 70px;
        margin: 0;
    }

    .toolbar-left {
        display: flex;
        gap: 8px;
    }

    .toolbar-btn {
        height: 40px;
        padding: 0 16px;
        background: white;
        border: 1px solid var(--gray-300);
        border-radius: 8px;
        font-size: 13px;
        font-weight: 500;
        cursor: pointer;
        display: flex;
        align-items: center;
        gap: 8px;
        transition: var(--transition);
        color: var(--gray-800);
    }

    .toolbar-btn i {
        font-size: 16px;
    }

    .toolbar-btn:hover {
        background: var(--gray-100);
        border-color: var(--gray-400);
    }

    .toolbar-right {
        display: flex;
        align-items: center;
        gap: 20px;
    }

    .page-size-select {
        height: 40px;
        padding: 0 12px;
        border: 1px solid var(--gray-300);
        border-radius: 8px;
        font-size: 13px;
        background: white;
        color: var(--gray-800);
        outline: none;
    }

    .total-count {
        font-weight: 600;
        color: var(--primary);
        font-size: 14px;
    }

    /* ===== منطقة الجدول - بدون مسافات سفلية ===== */
   /* ===== منطقة الجدول - مع تحكم بالارتفاع ===== */
.table-container {
    flex: none; /* إلغاء التمدد التلقائي */
    height: 400px; /* حدد الارتفاع الذي تريده هنا */
    overflow: auto;
    padding: 20px 20px 0 20px !important;
    margin: 0 !important;
    scrollbar-width: thin;
    scrollbar-color: var(--accent) var(--gray-100);
}
    .table-container::-webkit-scrollbar {
        width: 8px;
        height: 8px;
    }

    .table-container::-webkit-scrollbar-track {
        background: var(--gray-200);
        border-radius: 4px;
    }

    .table-container::-webkit-scrollbar-thumb {
        background: var(--accent);
        border-radius: 4px;
    }

    table {
        width: 100%;
        border-collapse: collapse;
        min-width: 1100px;
        font-size: 13px;
        margin-bottom: 0 !important;
    }

    th {
        background: var(--gray-200);
        padding: 14px 12px;
        font-weight: 600;
        color: var(--gray-800);
        text-align: center;
        position: sticky;
        top: 0;
        z-index: 10;
        font-size: 13px;
    }

    td {
        padding: 14px 12px;
        border-bottom: 1px solid var(--gray-200);
        text-align: center;
        vertical-align: middle;
    }

    /* إزالة الحد السفلي لآخر صف */
    tr:last-child td {
        border-bottom: none !important;
    }

    tr:hover {
        background: var(--gray-50);
    }

    .shelf-code {
        color: var(--primary);
        font-weight: 600;
        font-size: 13px;
    }

    .product-name {
        font-weight: 500;
        color: var(--gray-800);
        text-align: right;
    }

    .units-progress {
        display: flex;
        align-items: center;
        gap: 8px;
        justify-content: center;
    }

    .progress-indicator {
        width: 70px;
        height: 6px;
        background: var(--gray-300);
        border-radius: 3px;
        overflow: hidden;
    }

    .progress-fill {
        height: 100%;
        border-radius: 3px;
    }

    .progress-fill.available { background: var(--success); }
    .progress-fill.low { background: var(--warning); }
    .progress-fill.expired { background: var(--danger); }
    .progress-fill.warning { background: var(--warning); }

    .expiry-date {
        display: inline-block;
        padding: 5px 10px;
        border-radius: 20px;
        font-size: 12px;
        font-weight: 500;
    }

    .expiry-date.available { background: var(--success-soft); color: var(--success); }
    .expiry-date.low { background: var(--warning-soft); color: var(--warning); }
    .expiry-date.expired { background: var(--danger-soft); color: var(--danger); }
    .expiry-date.warning { background: var(--warning-soft); color: var(--warning); }

    .status-badge {
        display: inline-flex;
        align-items: center;
        gap: 4px;
        padding: 5px 10px;
        border-radius: 20px;
        font-size: 12px;
        font-weight: 500;
    }

    .status-badge.available { background: var(--success-soft); color: var(--success); }
    .status-badge.low { background: var(--warning-soft); color: var(--warning); }
    .status-badge.expired { background: var(--danger-soft); color: var(--danger); }
    .status-badge.warning { background: var(--warning-soft); color: var(--warning); }

    .action-buttons {
        display: flex;
        gap: 6px;
        justify-content: center;
    }

    .action-btn {
        width: 34px;
        height: 34px;
        border: none;
        border-radius: 8px;
        cursor: pointer;
        font-size: 16px;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        transition: var(--transition);
        color: white;
    }

    .action-btn.edit {
        background: var(--accent);
    }

    .action-btn.details {
        background: #9c27b0;
    }

    .action-btn.delete {
        background: var(--danger);
    }

    .action-btn:hover {
        transform: scale(1.1);
        filter: brightness(1.1);
    }

    /* ===== شريط الإحصائيات السفلي - ملتصق تماماً ===== */
    .stats-footer {
        flex-shrink: 0;
        background: linear-gradient(135deg, var(--gray-800), #2c3e50);
        margin: 0 !important;
        padding: 12px 20px !important;
        display: flex;
        justify-content: space-between;
        align-items: center;
        flex-wrap: wrap;
        gap: 5px;
        width: 100% !important;
        border-radius: 0 !important;
        border: none !important;
        border-top: none !important;
        height: auto;
        min-height: 60px;
        box-sizing: border-box !important;
    }

    .footer-stat {
        text-align: center;
        cursor: pointer;
        padding: 5px 8px;
        border-radius: 6px;
        transition: all 0.2s ease;
        flex: 1;
        min-width: 60px;
    }

    .footer-stat:hover {
        background: rgba(255,255,255,0.1);
    }

    .footer-number {
        font-size: 15px;
        font-weight: 700;
        color: white;
        margin-bottom: 2px;
        line-height: 1.2;
    }

    .footer-number.green { color: #a5d6a7; }
    .footer-number.red { color: #ef9a9a; }
    .footer-number.blue { color: #90caf9; }

    .footer-label {
        font-size: 9px;
        color: #e0e0e0;
        white-space: nowrap;
    }

    /* تحسين للشاشات المتوسطة */
    @media (max-width: 1400px) {
        .filter-buttons {
            grid-template-columns: repeat(2, 1fr);
        }
        
        .stats-footer {
            padding: 10px;
        }
        
        .footer-number {
            font-size: 14px;
        }
        
        .footer-label {
            font-size: 8px;
        }
    }

    /* تحسين للشاشات الصغيرة */
    @media (max-width: 1200px) {
        .shelf-page {
            flex-direction: column;
        }
        
        .right-panel, .left-panel {
            width: 100%;
        }
        
        .right-panel {
            height: 40%;
        }
        
        .left-panel {
            height: 60%;
        }
        
        .stats-footer {
            margin: 0 !important;
            padding: 8px !important;
        }
        
        .footer-stat {
            min-width: 50px;
            padding: 4px 6px;
        }
        
        .footer-number {
            font-size: 13px;
        }
        
        .footer-label {
            font-size: 7px;
        }
    }

    /* ===== النوافذ المنبثقة ===== */
    .modal {
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: rgba(0,0,0,0.6);
        display: flex;
        align-items: center;
        justify-content: center;
        z-index: 10000;
        animation: fadeIn 0.2s ease;
    }

    .modal-content {
        background: white;
        border-radius: 20px;
        box-shadow: var(--shadow-lg);
        max-height: 85vh;
        overflow-y: auto;
        min-width: 450px;
        max-width: 550px;
        animation: slideUp 0.3s ease;
    }

    .modal-header {
        padding: 20px 25px;
        border-bottom: 1px solid var(--gray-200);
        display: flex;
        justify-content: space-between;
        align-items: center;
        background: linear-gradient(135deg, var(--primary), var(--primary-light));
        color: white;
        border-radius: 20px 20px 0 0;
    }

    .modal-header h3 {
        font-size: 18px;
        font-weight: 600;
        display: flex;
        align-items: center;
        gap: 10px;
    }

    .modal-close {
        background: rgba(255,255,255,0.2);
        border: none;
        font-size: 22px;
        cursor: pointer;
        color: white;
        width: 36px;
        height: 36px;
        border-radius: 8px;
        display: flex;
        align-items: center;
        justify-content: center;
        transition: var(--transition);
    }

    .modal-close:hover {
        background: rgba(255,255,255,0.3);
        transform: rotate(90deg);
    }

    .modal-body {
        padding: 25px;
    }

    .info-grid {
        display: grid;
        grid-template-columns: repeat(2, 1fr);
        gap: 15px;
        margin-bottom: 25px;
    }

    .info-box {
        background: var(--gray-50);
        padding: 15px;
        border-radius: 12px;
        border: 1px solid var(--gray-200);
    }

    .info-box .info-label {
        font-size: 11px;
        color: var(--gray-600);
        margin-bottom: 6px;
        text-transform: uppercase;
        letter-spacing: 0.5px;
    }

    .info-box .info-value {
        font-weight: 700;
        font-size: 16px;
        color: var(--gray-800);
    }

    .modal-actions {
        display: flex;
        gap: 12px;
        margin-top: 25px;
    }

    .modal-btn {
        flex: 1;
        height: 48px;
        border: none;
        border-radius: 10px;
        font-size: 14px;
        font-weight: 600;
        cursor: pointer;
        transition: var(--transition);
    }

    .modal-btn.primary {
        background: var(--success);
        color: white;
    }

    .modal-btn.primary:hover {
        background: #1b5e20;
    }

    .modal-btn.danger {
        background: var(--danger);
        color: white;
    }

    .modal-btn.danger:hover {
        background: #b71c1c;
    }

    .modal-btn.secondary {
        background: var(--gray-200);
        color: var(--gray-800);
    }

    .modal-btn.secondary:hover {
        background: var(--gray-300);
    }

    @keyframes fadeIn {
        from { opacity: 0; }
        to { opacity: 1; }
    }

    @keyframes slideUp {
        from {
            transform: translateY(30px);
            opacity: 0;
        }
        to {
            transform: translateY(0);
            opacity: 1;
        }
    }

    /* ===== إزالة أي هوامض أو مسافات زائدة ===== */
    .left-panel > *:last-child {
        margin-bottom: 0;
    }
    </style>
</head>
<body oncontextmenu="return false;" onkeydown="return disableKeys(event)">
    
    <div class="desktop-app">
        <!-- الشريط العلوي للنظام (يأتي من top_nav.php) -->
        
        <!-- المحتوى الرئيسي -->
        <div class="main-content">
            <div class="shelf-page">
                <!-- ===== الجانب الأيمن ===== -->
                <div class="right-panel">
                    <!-- شريط التبديل -->
                    <div class="tabs-header">
                        <button class="tab-btn active" onclick="switchPanel('stats')">
                            <i>📊</i> إحصائيات
                        </button>
                        <button class="tab-btn" onclick="switchPanel('batches')">
                            <i>📦</i> دفعات
                        </button>
                    </div>

                    <!-- منطقة عرض اللوحات -->
                    <div class="panels-container">
                        <!-- لوحة الإحصائيات -->
                        <div class="panel active" id="statsPanel">
                            <!-- قسم البحث المحسن -->
                            <div class="search-section">
                                <div class="section-header">
                                    <i>🔍</i> بحث سريع
                                </div>
                                
                                <div class="search-fields">
                                    <!-- حقل البحث بالباركود -->
                                    <div class="search-field">
                                        <div class="field-icon">🔍</div>
                                        <input type="text" id="barcodeSearch" class="search-input" placeholder="بحث بالباركود..." onkeyup="searchShelf()">
                                        <div class="field-icon barcode" onclick="focusBarcode()">📷</div>
                                    </div>
                                    
                                    <!-- حقل البحث بالمنتج -->
                                    <div class="search-field">
                                        <div class="field-icon">🔍</div>
                                        <input type="text" id="productSearch" class="search-input" placeholder="بحث باسم المنتج..." onkeyup="searchShelf()">
                                    </div>
                                </div>
                                
                                <!-- أزرار الفلاتر المحسنة -->
                                <div class="filter-buttons">
                                    <button class="filter-btn active" data-filter="all" onclick="filterShelf('all')">
                                        <span class="filter-icon">📋</span>
                                        <span class="filter-text">الكل</span>
                                        <span class="filter-count" id="count-all"><?= $stats['total_shelves'] ?? 0 ?></span>
                                    </button>
                                    
                                    <button class="filter-btn available" data-filter="available" onclick="filterShelf('available')">
                                        <span class="filter-icon">🟢</span>
                                        <span class="filter-text">متاح</span>
                                        <span class="filter-count" id="count-available"><?= $stats['available_count'] ?? 0 ?></span>
                                    </button>
                                    
                                    <button class="filter-btn low" data-filter="low" onclick="filterShelf('low')">
                                        <span class="filter-icon">🟡</span>
                                        <span class="filter-text">منخفض</span>
                                        <span class="filter-count" id="count-low"><?= $stats['low_stock_count'] ?? 0 ?></span>
                                    </button>
                                    
                                    <button class="filter-btn expired" data-filter="expired" onclick="filterShelf('expired')">
                                        <span class="filter-icon">🔴</span>
                                        <span class="filter-text">منتهي</span>
                                        <span class="filter-count" id="count-expired"><?= $stats['expired_count'] ?? 0 ?></span>
                                    </button>
                                </div>
                            </div>

                            <!-- بطاقة إحصائيات سريعة -->
                            <div class="info-card">
                                <div class="info-header">
                                    <span><i>📊</i> إحصائيات سريعة</span>
                                    <span class="refresh-icon" onclick="refreshStats()">↻</span>
                                </div>
                                <div class="stats-grid">
                                    <div class="stat-item">
                                        <div class="stat-value"><?= $stats['total_shelves'] ?? 0 ?></div>
                                        <div class="stat-label">إجمالي الرفوف</div>
                                    </div>
                                    <div class="stat-item">
                                        <div class="stat-value"><?= $stats['total_units'] ?? 0 ?></div>
                                        <div class="stat-label">إجمالي الوحدات</div>
                                    </div>
                                    <div class="stat-item">
                                        <div class="stat-value" style="color: var(--success);"><?= $stats['available_count'] ?? 0 ?></div>
                                        <div class="stat-label"><span>🟢</span> متاح</div>
                                    </div>
                                    <div class="stat-item">
                                        <div class="stat-value" style="color: var(--warning);"><?= $stats['low_stock_count'] ?? 0 ?></div>
                                        <div class="stat-label"><span>🟡</span> منخفض</div>
                                    </div>
                                    <div class="stat-item">
                                        <div class="stat-value" style="color: var(--danger);"><?= $stats['expired_count'] ?? 0 ?></div>
                                        <div class="stat-label"><span>🔴</span> منتهي</div>
                                    </div>
                                    <div class="stat-item">
                                        <div class="stat-value"><?= number_format($stats['total_value'] ?? 0, 0) ?> ريال</div>
                                        <div class="stat-label">قيمة المخزون</div>
                                    </div>
                                </div>
                            </div>

                          
                        </div>

                        <!-- لوحة الدفعات -->
                        <div class="panel" id="batchesPanel">
                            
                            <div class="info-card">
                                <div class="info-header">
                                    <span><i>📦</i> آخر الدفعات المرفوعة</span>
                                </div>
                                <div class="batches-list" id="batchesList">
                                    <?php
                                    $recentBatches = isset($recentBatches) ? $recentBatches : [];
                                    if (empty($recentBatches)): ?>
                                        <div style="text-align: center; padding: 30px; color: var(--gray-600);">
                                            <i style="font-size: 40px; display: block; margin-bottom: 10px;">📦</i>
                                            <p>لا توجد دفعات مرفوعة</p>
                                        </div>
                                    <?php else: ?>
                                        <?php foreach ($recentBatches as $batch): ?>
                                            <div class="batch-item">
                                                <span class="batch-product"><?= htmlspecialchars($batch['product_name'] ?? 'منتج') ?></span>
                                                <span class="batch-qty"><?= $batch['cartons_quantity'] ?? 1 ?> كرتون</span>
                                                <span class="batch-date"><?= date('Y-m-d', strtotime($batch['entry_date'] ?? 'now')) ?></span>
                                            </div>
                                        <?php endforeach; ?>
                                    <?php endif; ?>
                                </div>
                            </div>
                            
                        </div>
                    </div>
                </div>

                <!-- ===== الجانب الأيسر مع الشريط الملتصق ===== -->
                <div class="left-panel">
                    <!-- شريط الأدوات -->
                    <div class="toolbar">
                        <div class="toolbar-left">

                           
                            <button class="toolbar-btn" onclick="refreshData()">
                                <i>🔄</i> تحديث
                            </button>
                        </div>
                        <div class="toolbar-right">
                           
                            <span class="total-count">إجمالي: <span id="totalShelves"><?= count($shelves) ?>صف</span></span>
                        </div>
                    </div>

                    <!-- جدول رف البيع -->
                    <div class="table-container">
                        <table id="shelfTable">
                            <thead>
                                <tr>
                                    <th>كود الرف</th>
                                    <th>المنتج</th>
                                    <th>كرتون</th>
                                    <th>الوحدات</th>
                                    <th>السعر</th>
                                    <th>تاريخ الانتهاء</th>
                                    <th>الحالة</th>
                                    <th>عمليات</th>
                                </tr>
                            </thead>
                            <tbody id="shelfTableBody">
                                <?php if (empty($shelves)): ?>
                                    <tr>
                                        <td colspan="8" style="text-align: center; padding: 60px;">
                                            <i style="font-size: 48px; display: block; margin-bottom: 15px; opacity: 0.5;">🛒</i>
                                            <p style="color: var(--gray-600); font-size: 16px;">لا توجد منتجات في الرف</p>
                                        </td>
                                    </tr>
                                <?php else: ?>
                                    <?php foreach ($shelves as $shelf): 
                                        $totalUnits = $shelf['units_remaining'];
                                        $maxUnits = $shelf['units_per_carton'] ?? 30;
                                        $percentage = $maxUnits > 0 ? round(($totalUnits / $maxUnits) * 100) : 0;
                                        
                                        $today = strtotime(date('Y-m-d'));
                                        $expiry = strtotime($shelf['expiry_date']);
                                        $daysLeft = ($expiry - $today) / (60 * 60 * 24);
                                        
                                        if ($expiry < $today) {
                                            $status = 'expired';
                                            $statusText = 'منتهي';
                                            $statusClass = 'expired';
                                        } elseif ($daysLeft <= 30) {
                                            $status = 'warning';
                                            $statusText = 'قريب';
                                            $statusClass = 'warning';
                                        } elseif ($shelf['units_remaining'] < 10) {
                                            $status = 'low';
                                            $statusText = 'منخفض';
                                            $statusClass = 'low';
                                        } else {
                                            $status = 'available';
                                            $statusText = 'متاح';
                                            $statusClass = 'available';
                                        }
                                    ?>
                                    <tr data-id="<?= $shelf['id'] ?>" data-code="<?= htmlspecialchars($shelf['shelf_code']) ?>">
                                        <td class="shelf-code"><?= htmlspecialchars($shelf['shelf_code']) ?></td>
                                        <td class="product-name"><?= htmlspecialchars($shelf['product_name']) ?></td>
                                        <td><i>📦</i> 1</td>
                                        <td>
                                            <div class="units-progress">
                                                <span style="font-weight: 600;"><?= $totalUnits ?></span>
                                                <div class="progress-indicator">
                                                    <div class="progress-fill <?= $statusClass ?>" style="width: <?= $percentage ?>%"></div>
                                                </div>
                                                <span style="color: var(--gray-600); font-size: 11px;"><?= $percentage ?>%</span>
                                            </div>
                                        </td>
                                        <td style="font-weight: 600;"><?= number_format($shelf['selling_price_unit'], 2) ?> ريال</td>
                                        <td>
                                            <span class="expiry-date <?= $statusClass ?>">
                                                <?= date('Y-m-d', strtotime($shelf['expiry_date'])) ?>
                                            </span>
                                        </td>
                                        <td>
                                            <span class="status-badge <?= $statusClass ?>">
                                                <?php
                                                if ($status == 'available') echo '🟢 متاح';
                                                elseif ($status == 'low') echo '🟡 منخفض';
                                                elseif ($status == 'expired') echo '🔴 منتهي';
                                                elseif ($status == 'warning') echo '⚠️ قريب';
                                                ?>
                                            </span>
                                        </td>
                                        <td>
                                            <div class="action-buttons">
                                                <button class="action-btn edit" onclick="editShelf(<?= $shelf['id'] ?>)" title="تعديل">✏️</button>
                                                <button class="action-btn details" onclick="showDetails(<?= $shelf['id'] ?>)" title="تفاصيل">📋</button>
                                                <button class="action-btn delete" onclick="confirmDelete(<?= $shelf['id'] ?>, '<?= htmlspecialchars($shelf['shelf_code']) ?>', '<?= htmlspecialchars($shelf['product_name']) ?>')" title="حذف">🗑️</button>
                                            </div>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>

                    <!-- شريط الإحصائيات السفلي - ملتصق تماماً -->
                    <div class="stats-footer">
                        <div class="footer-stat" onclick="filterByStat('all')">
                            <div class="footer-number"><?= $stats['total_shelves'] ?? 0 ?></div>
                            <div class="footer-label">إجمالي الرفوف</div>
                        </div>
                        <div class="footer-stat" onclick="filterByStat('available')">
                            <div class="footer-number green"><?= $stats['available_count'] ?? 0 ?></div>
                            <div class="footer-label">متاح</div>
                        </div>
                        <div class="footer-stat" onclick="filterByStat('low')">
                            <div class="footer-number" style="color: #ffb74d;"><?= $stats['low_stock_count'] ?? 0 ?></div>
                            <div class="footer-label">منخفض</div>
                        </div>
                        <div class="footer-stat" onclick="filterByStat('expired')">
                            <div class="footer-number red"><?= $stats['expired_count'] ?? 0 ?></div>
                            <div class="footer-label">منتهي</div>
                        </div>
                        <div class="footer-stat" onclick="filterByStat('value')">
                            <div class="footer-number green"><?= number_format($stats['total_value'] ?? 0, 0) ?></div>
                            <div class="footer-label">القيمة</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        const BASE_URL = '<?= BASE_URL ?>';
        let currentFilter = 'all';

   
        // ===== دوال التبديل بين اللوحات =====
        function switchPanel(panel) {
            document.querySelectorAll('.tab-btn').forEach(btn => btn.classList.remove('active'));
            document.querySelectorAll('.panel').forEach(p => p.classList.remove('active'));
            
            if (panel === 'stats') {
                document.querySelector('.tab-btn[onclick="switchPanel(\'stats\')"]').classList.add('active');
                document.getElementById('statsPanel').classList.add('active');
            } else {
                document.querySelector('.tab-btn[onclick="switchPanel(\'batches\')"]').classList.add('active');
                document.getElementById('batchesPanel').classList.add('active');
                loadBatches();
            }
        }

        // ===== دوال البحث والتصفية =====
        function searchShelf() {
            const barcode = document.getElementById('barcodeSearch').value;
            const product = document.getElementById('productSearch').value;
            
            const params = new URLSearchParams();
            if (product) params.append('search', product);
            if (barcode) params.append('barcode', barcode);
            if (currentFilter !== 'all') params.append('status', currentFilter);
            
            fetch(`${BASE_URL}/shelf/search?${params}`)
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        updateTable(data.data);
                    }
                })
                .catch(error => console.error('Search error:', error));
        }

        function filterShelf(filter) {
            currentFilter = filter;
            
            document.querySelectorAll('.filter-btn').forEach(btn => {
                btn.classList.remove('active');
            });
            event.target.closest('.filter-btn').classList.add('active');
            
            searchShelf();
        }

        function filterByStat(type) {
            if (type === 'all') {
                document.querySelector('.filter-btn[data-filter="all"]').click();
            } else if (type === 'available') {
                document.querySelector('.filter-btn[data-filter="available"]').click();
            } else if (type === 'low') {
                document.querySelector('.filter-btn[data-filter="low"]').click();
            } else if (type === 'expired') {
                document.querySelector('.filter-btn[data-filter="expired"]').click();
            }
        }

        // ===== دوال تحديث الجدول =====
        function updateTable(data) {
            const tbody = document.getElementById('shelfTableBody');
            if (!tbody) return;
            
            if (!data || data.length === 0) {
                tbody.innerHTML = '<tr><td colspan="8" style="text-align: center; padding: 60px;"><i style="font-size: 48px; display: block; margin-bottom: 15px; opacity: 0.5;">🔍</i><p style="color: var(--gray-600);">لا توجد نتائج</p></td></tr>';
                document.getElementById('totalShelves').textContent = '0';
                return;
            }
            
            let html = '';
            data.forEach(item => {
                const maxUnits = item.units_per_carton || 30;
                const percentage = maxUnits > 0 ? Math.round((item.units_remaining / maxUnits) * 100) : 0;
                
                let statusClass = '';
                let statusText = '';
                let statusIcon = '';
                
                if (item.status === 'available') {
                    statusClass = 'available';
                    statusText = 'متاح';
                    statusIcon = '🟢';
                } else if (item.status === 'low_stock') {
                    statusClass = 'low';
                    statusText = 'منخفض';
                    statusIcon = '🟡';
                } else if (item.status === 'out_of_stock' || item.status === 'expired') {
                    statusClass = 'expired';
                    statusText = 'منتهي';
                    statusIcon = '🔴';
                } else {
                    statusClass = 'available';
                    statusText = 'متاح';
                    statusIcon = '🟢';
                }
                
                html += `
                    <tr data-id="${item.id}">
                        <td class="shelf-code">${item.shelf_code || '---'}</td>
                        <td class="product-name">${item.product_name || '---'}</td>
                        <td><i>📦</i> 1</td>
                        <td>
                            <div class="units-progress">
                                <span style="font-weight: 600;">${item.units_remaining || 0}</span>
                                <div class="progress-indicator">
                                    <div class="progress-fill ${statusClass}" style="width: ${percentage}%"></div>
                                </div>
                                <span style="color: var(--gray-600); font-size: 11px;">${percentage}%</span>
                            </div>
                        </td>
                        <td style="font-weight: 600;">${parseFloat(item.selling_price_unit || 0).toFixed(2)} ريال </td>
                        <td>
                            <span class="expiry-date ${statusClass}">
                                ${item.expiry_date || '---'}
                            </span>
                        </td>
                        <td>
                            <span class="status-badge ${statusClass}">${statusIcon} ${statusText}</span>
                        </td>
                        <td>
                            <div class="action-buttons">
                                <button class="action-btn edit" onclick="editShelf(${item.id})" title="تعديل">✏️</button>
                                <button class="action-btn details" onclick="showDetails(${item.id})" title="تفاصيل">📋</button>
                                <button class="action-btn delete" onclick="confirmDelete(${item.id}, '${item.shelf_code || ''}', '${item.product_name || ''}')" title="حذف">🗑️</button>
                            </div>
                        </td>
                    </tr>
                `;
            });
            tbody.innerHTML = html;
            document.getElementById('totalShelves').textContent = data.length;
        }

        // ===== دوال النوافذ المنبثقة =====
        function showDetails(id) {
            showLoading('جاري تحميل البيانات...');
            
            fetch(`${BASE_URL}/shelf/item-details?id=${id}`)
                .then(response => response.json())
                .then(data => {
                    hideLoading();
                    
                    if (data.success) {
                        showDetailsModal(data.data);
                    } else {
                        alert('خطأ في تحميل البيانات: ' + (data.message || ''));
                    }
                })
                .catch(error => {
                    hideLoading();
                    alert('حدث خطأ في الاتصال: ' + error.message);
                });
        }

        function showDetailsModal(data) {
            const shelfItem = data.shelf_item || {};
            const product = data.product || {};
            
            const modal = document.createElement('div');
            modal.className = 'modal';
            modal.innerHTML = `
                <div class="modal-content">
                    <div class="modal-header">
                        <h3><i>📋</i> تفاصيل الكرتون</h3>
                        <button class="modal-close" onclick="this.closest('.modal').remove()">✕</button>
                    </div>
                    <div class="modal-body">
                        <div class="info-grid">
                            <div class="info-box">
                                <div class="info-label">كود الرف</div>
                                <div class="info-value">${shelfItem.shelf_code || '---'}</div>
                            </div>
                            <div class="info-box">
                                <div class="info-label">المنتج</div>
                                <div class="info-value">${product.name || '---'}</div>
                            </div>
                            <div class="info-box">
                                <div class="info-label">الكراتين</div>
                                <div class="info-value"><i>📦</i> 1</div>
                            </div>
                            <div class="info-box">
                                <div class="info-label">الوحدات</div>
                                <div class="info-value">${shelfItem.units_remaining || 0}</div>
                            </div>
                            <div class="info-box">
                                <div class="info-label">السعر</div>
                                <div class="info-value">${parseFloat(shelfItem.selling_price_unit || 0).toFixed(2)} ريال</div>
                            </div>
                            <div class="info-box">
                                <div class="info-label">الحالة</div>
                                <div class="info-value">
                                    ${shelfItem.status === 'available' ? '🟢 متاح' : 
                                      shelfItem.status === 'low_stock' ? '🟡 منخفض' : 
                                      shelfItem.status === 'expired' ? '🔴 منتهي' : '---'}
                                </div>
                            </div>
                        </div>
                        <div style="text-align: center;">
                            <button class="modal-btn secondary" style="flex: none; width: auto; padding: 0 30px;" onclick="this.closest('.modal').remove()">إغلاق</button>
                        </div>
                    </div>
                </div>
            `;
            document.body.appendChild(modal);
        }

        function editShelf(id) {
            showLoading('جاري تحميل البيانات...');
            
            fetch(`${BASE_URL}/shelf/item-details?id=${id}`)
                .then(response => response.json())
                .then(data => {
                    hideLoading();
                    
                    if (data.success) {
                        showEditModal(data.data);
                    } else {
                        alert('خطأ في تحميل البيانات: ' + (data.message || ''));
                    }
                })
                .catch(error => {
                    hideLoading();
                    alert('حدث خطأ في الاتصال: ' + error.message);
                });
        }

        function showEditModal(data) {
            const shelfItem = data.shelf_item || {};
            const product = data.product || {};
            
            const modal = document.createElement('div');
            modal.className = 'modal';
            modal.innerHTML = `
                <div class="modal-content">
                    <div class="modal-header">
                        <h3><i>✏️</i> تعديل الكرتون</h3>
                        <button class="modal-close" onclick="this.closest('.modal').remove()">✕</button>
                    </div>
                    <div class="modal-body">
                        <div style="background: var(--gray-50); padding: 15px; border-radius: 10px; margin-bottom: 20px; border: 1px solid var(--gray-200);">
                            <p style="margin-bottom: 8px;"><strong>المنتج:</strong> ${product.name || '---'}</p>
                            <p><strong>كود الرف:</strong> ${shelfItem.shelf_code || '---'}</p>
                        </div>
                        
                        <div style="margin-bottom: 20px;">
                            <label style="display: block; margin-bottom: 8px; font-weight: 600; font-size: 13px;">الوحدات المتبقية</label>
                            <input type="number" id="editUnits" class="page-size-select" style="width: 100%; height: 45px;" value="${shelfItem.units_remaining || 0}">
                        </div>
                        
                        <div style="margin-bottom: 20px;">
                            <label style="display: block; margin-bottom: 8px; font-weight: 600; font-size: 13px;">سعر البيع</label>
                            <input type="number" step="0.01" id="editPrice" class="page-size-select" style="width: 100%; height: 45px;" value="${shelfItem.selling_price_unit || 0}">
                        </div>
                        
                        <div style="margin-bottom: 25px;">
                            <label style="display: block; margin-bottom: 8px; font-weight: 600; font-size: 13px;">الحالة</label>
                            <select id="editStatus" class="page-size-select" style="width: 100%; height: 45px;">
                                <option value="available" ${shelfItem.status === 'available' ? 'selected' : ''}>🟢 متاح</option>
                                <option value="low_stock" ${shelfItem.status === 'low_stock' ? 'selected' : ''}>🟡 منخفض</option>
                                <option value="out_of_stock" ${shelfItem.status === 'out_of_stock' ? 'selected' : ''}>🔴 نافد</option>
                                <option value="expired" ${shelfItem.status === 'expired' ? 'selected' : ''}>🔴 منتهي</option>
                            </select>
                        </div>
                        
                        <div class="modal-actions">
                            <button class="modal-btn primary" onclick="saveEdit(${shelfItem.id})">💾 حفظ التعديلات</button>
                            <button class="modal-btn secondary" onclick="this.closest('.modal').remove()">إلغاء</button>
                        </div>
                    </div>
                </div>
            `;
            document.body.appendChild(modal);
        }

        function saveEdit(id) {
            const units = document.getElementById('editUnits').value;
            const price = document.getElementById('editPrice').value;
            const status = document.getElementById('editStatus').value;
            
            const formData = new URLSearchParams();
            formData.append('id', id);
            formData.append('units_remaining', units);
            formData.append('selling_price_unit', price);
            formData.append('status', status);
            
            showLoading('جاري حفظ التعديلات...');
            
            fetch(`${BASE_URL}/shelf/update`, {
                method: 'POST',
                headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                hideLoading();
                
                if (data.success) {
                    document.querySelector('.modal').remove();
                    alert('تم التحديث بنجاح');
                    setTimeout(() => location.reload(), 1000);
                } else {
                    alert(data.message || 'فشل التحديث');
                }
            })
            .catch(error => {
                hideLoading();
                alert('حدث خطأ في الاتصال: ' + error.message);
            });
        }

        function confirmDelete(id, code, product) {
            // إزالة أي نافذة تأكيد سابقة لتجنب التكرار (مشكلة اللوب)
            document.querySelectorAll('.modal').forEach(m => m.remove());

            const modal = document.createElement('div');
            modal.className = 'modal';
            modal.innerHTML = `
                <div class="modal-content" style="max-width: 400px;">
                    <div class="modal-header" style="background: linear-gradient(135deg, var(--danger), #b71c1c);">
                        <h3><i>🗑️</i> تأكيد الحذف</h3>
                        <button class="modal-close" onclick="this.closest('.modal').remove()">✕</button>
                    </div>
                    <div class="modal-body" style="text-align: center;">
                        <i style="font-size: 60px; display: block; margin-bottom: 15px; color: var(--danger);">⚠️</i>
                        <p style="font-size: 16px; margin-bottom: 15px;">هل أنت متأكد من حذف هذا الكرتون؟</p>
                        <p style="font-weight: bold; margin-bottom: 5px; color: var(--danger);">${code || ''}</p>
                        <p style="color: var(--gray-600); margin-bottom: 25px;">${product || ''}</p>
                        <div class="modal-actions">
                            <button class="modal-btn danger" id="confirmDeleteBtn_${id}" onclick="deleteShelf(${id})">نعم، حذف</button>
                            <button class="modal-btn secondary" onclick="this.closest('.modal').remove()">إلغاء</button>
                        </div>
                    </div>
                </div>
            `;
            document.body.appendChild(modal);

            // نقل التركيز لزر الحذف لكي يتفاعل مع زر Enter مباشرة
            const confirmBtn = document.getElementById(`confirmDeleteBtn_${id}`);
            if (confirmBtn) {
                // نستخدم setTimeout لضمان أن العنصر تم رسمه في الشاشة بالكامل قبل التركيز عليه
                setTimeout(() => confirmBtn.focus(), 50);
            }
            
            // إضافة مستمع للأزرار في حال أراد المستخدم الإلغاء بزر Escape
            modal.addEventListener('keydown', function(event) {
                if (event.key === 'Escape') {
                    this.remove();
                }
            });
        }

        function deleteShelf(id) {
            document.querySelector('.modal').remove();
            
            const formData = new URLSearchParams();
            formData.append('id', id);
            
            showLoading('جاري الحذف...');
            
            fetch(`${BASE_URL}/shelf/delete`, {
                method: 'POST',
                headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                hideLoading();
                
                if (data.success) {
                    alert('تم الحذف بنجاح');
                    setTimeout(() => location.reload(), 1000);
                } else {
                    alert(data.message || 'فشل الحذف');
                }
            })
            .catch(error => {
                hideLoading();
                alert('حدث خطأ في الاتصال: ' + error.message);
            });
        }

        // ===== دوال مساعدة =====
        function toggleDropdown() {
            const content = document.getElementById('infoDropdown');
            const icon = document.querySelector('.dropdown-icon');
            
            if (content.classList.contains('active')) {
                content.classList.remove('active');
                icon.textContent = '▼';
            } else {
                content.classList.add('active');
                icon.textContent = '▲';
            }
        }

        function loadBatches() {
            fetch(`${BASE_URL}/inventory/filter?limit=10`)
                .then(response => response.json())
                .then(data => {
                    if (data.success && data.data) {
                        const list = document.getElementById('batchesList');
                        if (!list) return;
                        
                        let html = '';
                        data.data.slice(0, 6).forEach(batch => {
                            html += `
                                <div class="batch-item">
                                    <span class="batch-product">${batch.product_name || ''}</span>
                                    <span class="batch-qty">${batch.cartons_remaining || 0} كرتون</span>
                                    <span class="batch-date">${batch.entry_date ? batch.entry_date.substring(0,10) : ''}</span>
                                </div>
                            `;
                        });
                        if (html) list.innerHTML = html;
                    }
                });
        }

        function refreshStats() {
            location.reload();
        }

        function refreshData() {
            location.reload();
        }

        function exportToExcel() {
            window.location.href = `${BASE_URL}/reports/export-excel?type=shelf`;
        }

        function printTable() {
            window.print();
        }

        function changePageSize(size) {
            // للتوسع المستقبلي
        }

        function focusBarcode() {
            document.getElementById('barcodeSearch').focus();
        }

        // ===== دوال التحميل =====
        function showLoading(message) {
            const loader = document.createElement('div');
            loader.id = 'loadingOverlay';
            loader.style.cssText = `
                position: fixed;
                top: 0;
                left: 0;
                right: 0;
                bottom: 0;
                background: rgba(0,0,0,0.5);
                display: flex;
                align-items: center;
                justify-content: center;
                z-index: 20000;
                animation: fadeIn 0.2s ease;
            `;
            
            loader.innerHTML = `
                <div style="background: white; padding: 25px 40px; border-radius: 16px; text-align: center; box-shadow: 0 10px 30px rgba(0,0,0,0.2);">
                    <div style="font-size: 40px; margin-bottom: 15px;">⏳</div>
                    <div style="font-size: 16px; color: var(--gray-800);">${message || 'جاري التحميل...'}</div>
                </div>
            `;
            
            document.body.appendChild(loader);
        }

        function hideLoading() {
            const loader = document.getElementById('loadingOverlay');
            if (loader) loader.remove();
        }
    </script>
</body>
</html>

<?php
$content = ob_get_clean();
require BASE_PATH . 'views/layouts/main.php';
?>