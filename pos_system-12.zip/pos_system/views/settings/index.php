<?php
ob_start();
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="robots" content="noindex, nofollow, noarchive">
    <title><?= $title ?? 'إعدادات الطباعة' ?></title>
    <link rel="stylesheet" href="<?= asset('css/style.css') ?>">
    
    <style>
        /* ===== تنسيقات إضافية خاصة بصفحة الإعدادات ===== */
        :root {
            --primary-gradient: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            --success-gradient: linear-gradient(135deg, #84fab0 0%, #8fd3f4 100%);
            --warning-gradient: linear-gradient(135deg, #fad0c4 0%, #ffd1ff 100%);
            --danger-gradient: linear-gradient(135deg, #fbc2eb 0%, #a6c1ee 100%);
        }

        /* ===== حاوية الصفحة ===== */
        .settings-page {
            height: calc(90vh - 60px);
            padding: 24px;
            overflow-y: auto;
            background: #ffffffff;
        }

      

        .page-header h1 {
            font-size: 24px;
            font-weight: 600;
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .page-header h1 span {
            font-size: 32px;
        }

        .help-icon {
            width: 40px;
            height: 40px;
            background: rgba(255,255,255,0.2);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 20px;
            cursor: help;
            transition: all 0.3s;
        }

        .help-icon:hover {
            background: rgba(255,255,255,0.3);
            transform: scale(1.1);
        }

        /* ===== منطقة الرسائل ===== */
        .alerts-container {
            margin-bottom: 0px;
            min-height: 5px;
        }

        .alert {
            padding: 16px 20px;
            border-radius: 10px;
            margin-bottom: 12px;
            display: flex;
            align-items: center;
            gap: 12px;
            animation: slideDown 0.3s ease;
            border-right-width: 4px;
            border-right-style: solid;
        }

        .alert-success {
            background: #2f6ba7ff;
            color: #fefffdff;
            border-right-color: #2a28a7ff;
        }

        .alert-error {
            background: #9a2921ff;
            color: #721c24;
            border-right-color: #dc3545;
        }

        .alert-warning {
            background: #0b3429ff;
            color: #856404;
            border-right-color: #ffc107;
        }

        .alert-info {
            background: #100836ff;
            color: #0c5460;
            border-right-color: #17a2b8;
        }

        .alert-icon {
            font-size: 24px;
        }

        .alert-content {
            flex: 1;
        }

        .alert-title {
            font-weight: bold;
            margin-bottom: 4px;
        }

        .alert-close {
            cursor: pointer;
            font-size: 20px;
            opacity: 0.5;
            transition: opacity 0.3s;
        }

        .alert-close:hover {
            opacity: 1;
        }

        /* ===== شبكة البطاقات (التصميم الجديد للقوائم) ===== */
        .settings-layout {
            display: flex;
            gap: 24px;
            height: calc(100% - 60px);
            align-items: flex-start;
        }

        .settings-sidebar {
            width: 260px;
            background: #1e293b; /* Dark theme for sidebar */
            border-radius: 16px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            padding: 24px 12px;
            flex-shrink: 0;
            position: sticky;
            top: 24px;
        }

        .sidebar-menu {
            list-style: none;
            padding: 0;
            margin: 0;
        }

        .sidebar-menu li {
            padding: 0;
            margin-bottom: 8px;
        }

        .sidebar-menu a {
            display: flex;
            align-items: center;
            gap: 15px;
            padding: 14px 18px;
            color: #94a3b8;
            text-decoration: none;
            border-radius: 12px;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            font-weight: 500;
            font-size: 15px;
        }

        .sidebar-menu a:hover {
            background: rgba(255,255,255,0.05);
            color: #f8fafc;
            transform: translateX(-4px);
        }

        .sidebar-menu a.active {
            background: var(--primary-gradient);
            color: #ffffff;
            box-shadow: 0 4px 15px rgba(102, 126, 234, 0.4);
        }

        .sidebar-menu a .menu-icon {
            font-size: 20px;
            width: 24px;
            text-align: center;
            transition: transform 0.3s;
        }
        
        .sidebar-menu a:hover .menu-icon {
            transform: scale(1.1);
        }

        .settings-content {
            flex: 1;
            background: transparent; /* Remove background to rely on cards */
            border-radius: 20px;
            overflow: hidden;
            min-height: 500px;
        }

        /* ===== البطاقة ===== */
        .settings-card {
            display: none;
            height: 100%;
            background: white;
            border-radius: 20px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.03);
            animation: fadeIn 0.4s ease;
            border: 1px solid rgba(0,0,0,0.05);
        }

        .settings-card.active {
            display: block;
        }



        .card-header {
            padding: 20px 25px;
            border-bottom: 1px solid #dee2e6;
            display: flex;
            align-items: center;
            gap: 15px;
            background: #f8f9fa;
        }

        .card-header .card-icon {
            width: 40px;
            height: 40px;
            background: var(--primary-gradient);
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 20px;
            color: white;
        }

        .card-header .card-title {
            flex: 1;
        }

        .card-header .card-title h2 {
            font-size: 18px;
            font-weight: 600;
            color: #343a40;
            margin-bottom: 4px;
        }

        .card-header .card-title p {
            font-size: 13px;
            color: #6c757d;
            margin: 0;
        }

        .card-body {
            padding: 25px;
        }

        /* ===== عناصر التحكم ===== */
        .form-group {
            margin-bottom: 0px;
        }

        .form-group label {
            display: block;
            font-size: 14px;
            font-weight: 500;
            color: #495057;
            margin-bottom: 8px;
        }

        .form-group label .required {
            color: #dc3545;
            margin-right: 4px;
        }

        .form-control {
            width: 100%;
            height: 25px;
            padding: 0 15px;
            border: 2px solid #e9ecef;
            border-radius: 10px;
            font-size: 14px;
            transition: all 0.3s;
            background: white;
        }

        .form-control:focus {
            outline: none;
            border-color: #667eea;
            box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
        }

        .form-control:disabled {
            background: #e9ecef;
            opacity: 0.6;
            cursor: not-allowed;
        }

        textarea.form-control {
            height: 120px;
            padding: 12px 15px;
            resize: vertical;
            font-family: inherit;
        }

        .help-text {
            font-size: 12px;
            color: #6c757d;
            margin-top: 6px;
            display: flex;
            align-items: center;
            gap: 4px;
        }

        /* ===== خيار التبديل (Toggle) ===== */
        .toggle-switch {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .toggle-label {
            font-size: 14px;
            color: #495057;
            flex: 1;
        }

        .toggle {
            width: 52px;
            height: 28px;
            background: #ced4da;
            border-radius: 34px;
            position: relative;
            cursor: pointer;
            transition: background 0.3s;
        }

        .toggle.active {
            background: #667eea;
        }

        .toggle-slider {
            width: 24px;
            height: 24px;
            background: white;
            border-radius: 50%;
            position: absolute;
            top: 2px;
            right: 2px;
            transition: right 0.3s;
            box-shadow: 0 2px 4px rgba(0,0,0,0.2);
        }

        .toggle.active .toggle-slider {
            right: 26px;
        }

        /* ===== أزرار التبديل بين اللوحات ===== */
        .panel-tabs {
            display: flex;
            gap: 10px;
            margin-bottom: 20px;
            background: #f8f9fa;
            padding: 5px;
            border-radius: 10px;
        }

        .panel-tab {
            flex: 1;
            padding: 10px;
            border: none;
            background: transparent;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 500;
            color: #6c757d;
            cursor: pointer;
            transition: all 0.3s;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 6px;
        }

        .panel-tab.active {
            background: white;
            color: #667eea;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }

        .panel-content {
            display: none;
        }

        .panel-content.active {
            display: block;
        }

        /* ===== معرض التصاميم ===== */
        .templates-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 15px;
            margin-bottom: 20px;
        }

        .template-item {
            background: #79a6d2ff;
            border-radius: 12px;
            padding: 15px;
            cursor: pointer;
            border: 2px solid transparent;
            transition: all 0.3s;
            text-align: center;
        }

        .template-item:hover {
            transform: translateY(-5px);
        }

        .template-item.selected {
            border-color: #667eea;
            background: #f0f3ff;
        }

        .template-preview {
            height: 60px;
            border-radius: 8px;
            margin-bottom: 5px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 22px;
        }

        .template-name {
            font-weight: 600;
            color: #343a40;
            margin-bottom: 4px;
                        height: 30px;

        }

        .template-desc {
            font-size: 12px;
            color: #6c757d;
           height: 40px;

        }

        /* أنماط التصاميم */
        .template-classic .template-preview {
            background: linear-gradient(45deg, #e9ecef 25%, #dee2e6 25%, #dee2e6 50%, #e9ecef 50%, #e9ecef 75%, #dee2e6 75%);
            background-size: 20px 20px;
        }

        .template-modern .template-preview {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
        }

        .template-luxury .template-preview {
            background: linear-gradient(135deg, #b8860b 0%, #8b4513 100%);
            color: gold;
            font-size: 40px;
        }

        .template-simple .template-preview {
            background: white;
            border: 2px solid #343a40;
            color: #343a40;
        }

        /* ===== أزرار ===== */
        .btn {
            height: 35px;
            padding: 0 5px;
            border: none;
            border-radius: 10px;
            font-size: 14px;
            font-weight: 500;
            cursor: pointer;
            display: 50;
            align-items: center;
            justify-content: center;
            gap: 8px;
            transition: all 0.3s;
        }

        .btn-block {
            width: 100%;
        }

        .btn-primary {
            background: var(--primary-gradient);
            color: white;
            box-shadow: 0 4px 15px rgba(102, 126, 234, 0.3);
        }

        .btn-primary:hover:not(:disabled) {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(102, 126, 234, 0.4);
        }

        .btn-success {
            background: var(--success-gradient);
            color: #155724;
        }

        .btn-warning {
            background: var(--warning-gradient);
            color: #856404;
        }

        .btn-secondary {
            background: #6c757d;
            color: white;
        }

        .btn:disabled {
            opacity: 0.5;
            cursor: not-allowed;
        }

        .btn-lg {
            height: 52px;
            font-size: 16px;
        }

        /* ===== قسم الاختبار ===== */
        .test-section {
            background: #f8f9fa;
            border-radius: 12px;
            padding: 20px;
            margin-bottom: 20px;
        }

        .test-section h4 {
            font-size: 16px;
            font-weight: 600;
            color: #495057;
            margin-bottom: 8px;
        }

        .test-section p {
            font-size: 13px;
            color: #6c757d;
            margin-bottom: 15px;
        }

        /* ===== النافذة المنبثقة ===== */
        .modal {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0,0,0,0.5);
            display: none;
            align-items: center;
            justify-content: center;
            z-index: 10000;
            animation: fadeIn 0.3s ease;
        }

        .modal.active {
            display: flex;
        }

        .modal-content {
            background: white;
            border-radius: 20px;
            width: 90%;
            max-width: 800px;
            max-height: 90vh;
            overflow: hidden;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
            animation: slideUp 0.3s ease;
        }

        .modal-header {
            padding: 20px 25px;
            border-bottom: 1px solid #dee2e6;
            display: flex;
            justify-content: space-between;
            align-items: center;
            background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
        }

        .modal-header h3 {
            font-size: 18px;
            font-weight: 600;
            color: #343a40;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .modal-close {
            width: 36px;
            height: 36px;
            border-radius: 50%;
            border: none;
            background: white;
            font-size: 20px;
            cursor: pointer;
            transition: all 0.3s;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .modal-close:hover {
            background: #dc3545;
            color: white;
        }

        .modal-body {
            padding: 25px;
            max-height: calc(90vh - 140px);
            overflow-y: auto;
        }

        .modal-footer {
            padding: 20px 25px;
            border-top: 1px solid #dee2e6;
            background: #f8f9fa;
            display: flex;
            gap: 10px;
            justify-content: flex-end;
        }

        /* ===== معاينة الفاتورة ===== */
        .invoice-preview {
            background: white;
            border: 1px solid #dee2e6;
            border-radius: 12px;
            padding: 30px;
            font-family: 'Courier New', monospace;
        }

        .invoice-header {
            text-align: center;
            margin-bottom: 30px;
            padding-bottom: 20px;
            border-bottom: 2px dashed #dee2e6;
        }

        .invoice-header h2 {
            font-size: 24px;
            color: #343a40;
            margin-bottom: 10px;
        }

        .invoice-info {
            display: flex;
            justify-content: space-between;
            margin-bottom: 20px;
            font-size: 14px;
            color: #6c757d;
        }

        .invoice-table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        .invoice-table th {
            background: #f8f9fa;
            padding: 10px;
            font-size: 13px;
            font-weight: 600;
            color: #495057;
            border-bottom: 2px solid #dee2e6;
        }

        .invoice-table td {
            padding: 10px;
            border-bottom: 1px solid #e9ecef;
            font-size: 13px;
        }

        .invoice-total {
            text-align: left;
            margin-top: 20px;
            padding-top: 20px;
            border-top: 2px solid #dee2e6;
        }

        .invoice-total table {
            width: 300px;
            margin-left: auto;
        }

        .invoice-total td {
            padding: 5px;
            font-size: 14px;
        }

        .invoice-total .grand-total {
            font-size: 18px;
            font-weight: bold;
            color: #28a745;
        }

        .invoice-footer {
            margin-top: 30px;
            text-align: center;
            font-size: 12px;
            color: #6c757d;
            padding-top: 20px;
            border-top: 2px dashed #dee2e6;
        }

        /* ===== System Reset Modal ===== */
        .reset-modal .modal-header {
            background: linear-gradient(135deg, #fff5f5 0%, #ffe3e3 100%);
            border-bottom: 1px solid #ffc9c9;
        }

        .reset-modal .modal-header h3 {
            color: #c92a2a;
        }

        .reset-warning-box {
            background: #fff5f5;
            border: 1px solid #ffc9c9;
            border-radius: 12px;
            padding: 20px;
            margin-bottom: 25px;
        }

        .reset-warning-box ul {
            color: #c92a2a;
            font-weight: 500;
            margin-top: 10px;
            padding-right: 20px;
        }

        .reset-warning-box ul li {
            margin-bottom: 5px;
        }

        .confirm-reset-group {
            background: #f8f9fa;
            border: 1px solid #dee2e6;
            border-radius: 12px;
            padding: 20px;
        }

        .reset-countdown-btn {
            position: relative;
            overflow: hidden;
        }
        
        .reset-countdown-btn::after {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            height: 100%;
            background: rgba(0,0,0,0.1);
            width: 0%;
            transition: width 1s linear;
        }

        .reset-countdown-btn.counting::after {
            width: 100%;
        }

        /* ===== تحكم عدد النسخ ===== */
        .copy-control {
            display: flex;
            align-items: center;
            gap: 10px;
            background: #f8f9fa;
            padding: 8px 12px;
            border-radius: 8px;
        }

        .copy-control button {
            width: 32px;
            height: 32px;
            border: none;
            background: white;
            border-radius: 6px;
            cursor: pointer;
            font-size: 18px;
            transition: all 0.3s;
        }

        .copy-control button:hover:not(:disabled) {
            background: #667eea;
            color: white;
        }

        .copy-control span {
            min-width: 40px;
            text-align: center;
            font-weight: bold;
        }

        /* ===== حركات ===== */
        @keyframes slideDown {
            from {
                transform: translateY(-100%);
                opacity: 0;
            }
            to {
                transform: translateY(0);
                opacity: 1;
            }
        }

        @keyframes slideUp {
            from {
                transform: translateY(50px);
                opacity: 0;
            }
            to {
                transform: translateY(0);
                opacity: 1;
            }
        }

        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }

        @keyframes spin {
            from { transform: rotate(0deg); }
            to { transform: rotate(360deg); }
        }

        /* ===== تجاوب ===== */
        @media (max-width: 1200px) {
            .settings-layout {
                flex-direction: column;
            }
            .settings-sidebar {
                width: 100%;
                position: static;
                margin-bottom: 20px;
            }
            .sidebar-menu {
                display: flex;
                flex-wrap: wrap;
                gap: 10px;
            }
            .sidebar-menu li {
                flex: 1;
                min-width: 150px;
                padding: 0;
                margin-bottom: 0;
            }
            .sidebar-menu a {
                justify-content: center;
            }
            
            .templates-grid {
                grid-template-columns: 1fr;
            }
        }

        @media (max-width: 768px) {
            .settings-page {
                padding: 16px;
            }
            
            .page-header {
                flex-direction: column;
                text-align: center;
                gap: 15px;
            }
        }

        /* ===== إجبار ظهور شريط التمرير العمودي في جميع التبويبات ===== */

/* تثبيت الصفحة بالكامل */
html, body {
    height: 100vh;
    overflow: hidden;
    margin: 0;
    padding: 0;
}

/* تثبيت حاوية الصفحة */
.settings-page {
    height: 100vh;
    display: flex;
    flex-direction: column;
    overflow: hidden;
    padding: 0 !important;
}

/* تثبيت رأس الصفحة */
.page-header {
    flex-shrink: 0;
}

/* جعل الـ Layout يأخذ المساحة المتبقية */
.settings-layout {
    flex: 1;
    display: flex;
    overflow: hidden;
    min-height: 0;
    padding: 20px 24px;
}

/* تثبيت الشريط الجانبي */
.settings-sidebar {
    flex-shrink: 0;
    overflow-y: auto;
    height: 100%;
}

/* جعل منطقة المحتوى مرنة */
.settings-content {
    flex: 1;
    display: flex;
    flex-direction: column;
    overflow: hidden;
    min-height: 0;
}

/* تحويل جميع البطاقات إلى حاويات مرنة */
.settings-card {
    display: none;
    flex-direction: column;
    height: 100%;
    overflow: hidden;
}

.settings-card.active {
    display: flex;
}

/* تثبيت رأس البطاقة */
.card-header {
    flex-shrink: 0;
}

/* ===== الحل الجازم لشريط التمرير ===== */
/* إضافة شريط تمرير إلى جسم كل بطاقة */
.card-body {
    flex: 1;
    overflow-y: auto !important; /* إجبار ظهور شريط التمرير */
    min-height: 0;
    max-height: 100%;
    padding: 20px 25px;
}

/* تأكيد أن تبويب backup تحديداً سيظهر له شريط تمرير */
#backupTab .card-body,
.settings-card#backupTab .card-body,
.settings-card .card-body {
    overflow-y: auto !important;
    min-height: 100px;
    max-height: calc(100vh - 200px);
}

/* تثبيت أزرار التبديل */
.panel-tabs {
    flex-shrink: 0;
    position: sticky;
    top: 0;
    background: #f8f9fa;
    z-index: 10;
}

/* تنسيق شريط التمرير ليكون مرئياً بوضوح */
.card-body::-webkit-scrollbar {
    width: 8px !important;
    height: 8px !important;
}

.card-body::-webkit-scrollbar-track {
    background: #e2e8f0 !important;
    border-radius: 10px !important;
}

.card-body::-webkit-scrollbar-thumb {
    background: #667eea !important;
    border-radius: 10px !important;
}

.card-body::-webkit-scrollbar-thumb:hover {
    background: #5a67d8 !important;
}

/* تأكيد أن المحتوى الطويل سيظهر معه شريط تمرير */
#backupTab .card-body > div,
.settings-card .card-body > div {
    overflow: visible;
}
    </style>
</head>
<body>

    <div class="settings-page">
        <!-- شريط العنوان -->
      

        <!-- منطقة الرسائل -->
        <div class="alerts-container" id="alertsContainer"></div>

        <!-- Layout -->
        <div class="settings-layout">
            <!-- الشريط الجانبي (القائمة) -->
            <div class="settings-sidebar">
                <ul class="sidebar-menu">
                      

                     
                    <li>
                        <a href="#" class="active" onclick="showSettingsTab('general', this); return false;">
                            <span class="menu-icon">🖨️</span>
                            الإعدادات العامة
                        </a>
                    </li>
                    <li>
                        <a href="#" onclick="showSettingsTab('format', this); return false;">
                            <span class="menu-icon">📄</span>
                            تنسيق الفاتورة
                        </a>
                    </li>
                    <li>
                        <a href="#" onclick="showSettingsTab('design', this); return false;">
                            <span class="menu-icon">🎨</span>
                            التصاميم والفلاتر
                        </a>
                    </li>
                    <li>
                        <a href="#" onclick="showSettingsTab('backup', this); return false;">
                            <span class="menu-icon">💾</span>
                            النسخ الاحتياطي
                        </a>
                    </li>
                    <li>    <button class="btn btn-primary btn-block" id="testPrintBtn" onclick="testPrint()">
                            <span>🧪</span> اختبار الطباعة
                        </button></li>
                    
                    <button class="btn btn-success btn-block btn-lg" id="saveSettingsBtn" onclick="saveSettings()">
                        <span>💾</span> حفظ الإعدادات
                    </button>
                </ul>
            </div>

            <!-- المحتوى / البطاقات -->
            <div class="settings-content">
                <!-- البطاقة الأولى: الإعدادات العامة -->
                <div class="settings-card active" id="generalTab">
                <div class="card-header">
                    <div class="card-icon">🖨️</div>
                    <div class="card-title">
                        <h2>الإعدادات العامة</h2>
                        <p>التحكم الأساسي في نظام الطباعة</p>
                    </div>
                </div>
                <div class="card-body">
                    <!-- تفعيل نظام الطباعة -->
                    <div class="form-group">
                        <div class="toggle-switch">
                            <span class="toggle-label">تفعيل نظام الطباعة التلقائي</span>
                            <div class="toggle <?= ($settings['print_enabled'] ?? '1') == '1' ? 'active' : '' ?>" id="printEnabledToggle" onclick="togglePrintEnabled()">
                                <div class="toggle-slider"></div>
                            </div>
                        </div>
                    </div>

                    <!-- مسار حفظ الملفات -->
                    <div class="form-group">
                        <label>مسار حفظ الملفات <span class="required">*</span></label>
                        <input type="text" class="form-control" id="printSavePath" 
                               value="<?= htmlspecialchars($settings['print_save_path'] ?? 'C:/invoices/') ?>" 
                               placeholder="مثال: C:/invoices/">
                        <div class="help-text">
                            <span>💡</span> المجلد الذي ستحفظ فيه ملفات PDF المطبوعة
                        </div>
                        <div class="help-text" id="pathValidation">
                            <?php if ($save_path_valid['success']): ?>
                                <span style="color: #28a745;">✅ <?= $save_path_valid['message'] ?></span>
                            <?php else: ?>
                                <span style="color: #dc3545;">❌ <?= $save_path_valid['message'] ?></span>
                            <?php endif; ?>
                        </div>
                    </div>

                    <!-- فتح نافذة الطباعة تلقائياً -->
                    <div class="form-group">
                        <div class="toggle-switch">
                            <span class="toggle-label">فتح نافذة الطباعة تلقائياً بعد البيع</span>
                            <div class="toggle <?= ($settings['print_open_automatically'] ?? '1') == '1' ? 'active' : '' ?>" id="printAutoToggle" onclick="togglePrintAuto()">
                                <div class="toggle-slider"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- البطاقة الثانية: تنسيق الفاتورة -->
            <div class="settings-card" id="formatTab">
                <div class="card-header">
                    <div class="card-icon">📄</div>
                    <div class="card-title">
                        <h2>تنسيق الفاتورة</h2>
                        <p>تخصيص محتوى الفاتورة</p>
                    </div>
                </div>
                <div class="card-body">
                    <!-- أزرار التبديل -->
                    <div class="panel-tabs">
                        <button class="panel-tab active" onclick="switchPanel('text')">
                            <span>📄</span> نص الفاتورة
                        </button>
                        <button class="panel-tab" onclick="switchPanel('company')">
                            <span>🏢</span> معلومات الشركة
                        </button>
                    </div>

                    <!-- لوحة نص الفاتورة -->
                    <div class="panel-content active" id="textPanel">
                        <div class="form-group">
                            <label>نص رأس الفاتورة</label>
                            <input type="text" class="form-control" id="printHeader" 
                                   value="<?= htmlspecialchars($settings['print_header_text'] ?? '') ?>">
                        </div>
                        <div class="form-group">
                            <label>نص تذييل الفاتورة</label>
                            <input type="text" class="form-control" id="printFooter" 
                                   value="<?= htmlspecialchars($settings['print_footer_text'] ?? '') ?>">
                        </div>
                    </div>

                    <!-- لوحة معلومات الشركة -->
                    <div class="panel-content" id="companyPanel">
                        <div class="form-group">
                            <label>معلومات الشركة</label>
                            <textarea class="form-control" id="printCompanyInfo" rows="5"><?= htmlspecialchars($settings['print_company_info'] ?? "سوبر ماركت النخبة\nهاتف: 0123456789\nالعنوان: المدينة - الحي\nالرقم الضريبي: 123456789") ?></textarea>
                            <div class="help-text">
                            </div>
                        </div>
                    </div>
                </div>
                
            </div>

            <!-- البطاقة الثالثة: فلاتر وتصاميم الفاتورة -->
            <div class="settings-card" id="designTab">
                <div class="card-header">
                    <div class="card-icon">🎨</div>
                    <div class="card-title">
                        <h2>فلاتر الفاتورة</h2>
                        <p>اختر تصميم الفاتورة المناسب</p>
                    </div>
                </div>
                <div class="card-body">
                    <!-- معرض التصاميم -->
                    <div class="templates-grid">
                        <div class="template-item template-classic <?= ($settings['print_template_id'] ?? '1') == '1' ? 'selected' : '' ?>" 
                             onclick="selectTemplate(1)">
                            <div class="template-preview">📄</div>
                            <div class="template-name">كلاسيكي</div>
                            <div class="template-desc">تصميم تقليدي بسيط</div>
                        </div>
                        <div class="template-item template-modern <?= ($settings['print_template_id'] ?? '1') == '2' ? 'selected' : '' ?>" 
                             onclick="selectTemplate(2)">
                            <div class="template-preview">✨</div>
                            <div class="template-name">حديث</div>
                            <div class="template-desc">تصميم عصري جذاب</div>
                        </div>
                        <div class="template-item template-luxury <?= ($settings['print_template_id'] ?? '1') == '3' ? 'selected' : '' ?>" 
                             onclick="selectTemplate(3)">
                            <div class="template-preview">👑</div>
                            <div class="template-name">فاخر</div>
                            <div class="template-desc">للمنتجات الفاخرة</div>
                        </div>
                        <div class="template-item template-simple <?= ($settings['print_template_id'] ?? '1') == '4' ? 'selected' : '' ?>" 
                             onclick="selectTemplate(4)">
                            <div class="template-preview">⚫</div>
                            <div class="template-name">مبسط</div>
                            <div class="template-desc">أبيض وأسود، مثالي للطابعات الحرارية</div>
                        </div>
                    </div>

                    <!-- زر تطبيق التصميم -->
                    
                    <input type="hidden" id="selectedTemplate" value="<?= $settings['print_template_id'] ?? '1' ?>">
                </div>
                                <button class="btn btn-primary btn-block" onclick="applyTemplate()">
                        <span>✨</span> تطبيق التصميم المحدد
                    </button>
            </div>

            

            <!-- البطاقة الرابعه: إدارة النسخ الاحتياطي وقاعدة البيانات -->
            <div class="settings-card" style="height: auto; margin-bottom: 20px;" id="backupTab">
                <div class="card-header" style="height: auto;">
                    <div class="card-icon">💾</div>
                    <div class="card-title">
                        <h2>إدارة النسخ الاحتياطي وقاعدة البيانات</h2>
                        <p>إدارة النسخ التلقائي لقاعدة البيانات، التصدير، الاستيراد، وإعادة ضبط النظام.</p>
                    </div>
                </div>
                <div class="card-body" style="padding: 25px;">
                    <div style="display: grid; grid-template-columns: 1fr; gap: 40px;">
                        
                        <!-- القسم الأول: النسخ الاحتياطي التلقائي -->
                        <div>
                            <h3 style="font-size: 18px; font-weight: 600; margin-bottom: 10px; color: #343a40; border-bottom: 2px solid #e9ecef; padding-bottom: 10px;">النسخ الاحتياطي التلقائي</h3>
                            <p style="font-size: 13px; color: #6c757d; margin-bottom: 20px;">يقوم النظام بإنشاء نسخة احتياطية مشفرة من قاعدة البيانات في الوقت المحدد.</p>
                            
                            <!-- 1. حقل تحديد مسار الحفظ -->
                            <div class="form-group" style="margin-bottom: 20px;">
                                <label style="display: block; font-size: 14px; font-weight: 500; color: #495057; margin-bottom: 8px;">مسار حفظ النسخة الاحتياطية</label>
                                <div style="display: flex; gap: 10px;">
                                    <input type="text" class="form-control" id="backupPathInput" value="<?= htmlspecialchars($settings['backup_path'] ?? '') ?>" placeholder="مسار الحفظ..." style="height: 40px; flex: 1; padding: 0 15px; border: 2px solid #e9ecef; border-radius: 10px; font-size: 14px;" oninput="checkBackupForm()">
                                    <button class="btn btn-secondary" style="height: 40px; white-space: nowrap; padding: 0 20px;" onclick="selectBackupPath()">تحديد المسار</button>
                                </div>
                            </div>
                            
                            <!-- 2. حقل تحديد وقت النسخ (Dropdowns) -->
                            <div class="form-group" style="margin-bottom: 20px;">
                                <label style="display: block; font-size: 14px; font-weight: 500; color: #495057; margin-bottom: 8px;">وقت النسخ التلقائي</label>
                                <div style="display: flex; gap: 10px; align-items: center;">
                                    <select class="form-control" id="backupHourInput" style="height: 40px; width: 80px; padding: 0 10px;" onchange="updateBackupVisuals(); checkBackupForm()">
                                        <option value="" <?= !isset($settings['backup_hour']) ? 'selected' : '' ?> disabled>الساعة</option>
                                        <?php for($i=1; $i<=12; $i++): 
                                            $h = str_pad($i, 2, '0', STR_PAD_LEFT);
                                            $sel = (isset($settings['backup_hour']) && $settings['backup_hour'] == $h) ? 'selected' : '';
                                        ?>
                                            <option value="<?= $h ?>" <?= $sel ?>><?= $h ?></option>
                                        <?php endfor; ?>
                                    </select>
                                    <span style="font-weight: bold;">:</span>
                                    <select class="form-control" id="backupMinuteInput" style="height: 40px; width: 80px; padding: 0 10px;" onchange="updateBackupVisuals(); checkBackupForm()">
                                        <option value="" <?= !isset($settings['backup_minute']) ? 'selected' : '' ?> disabled>الدقيقة</option>
                                        <option value="00" <?= (isset($settings['backup_minute']) && $settings['backup_minute'] == '00') ? 'selected' : '' ?>>00</option>
                                        <option value="15" <?= (isset($settings['backup_minute']) && $settings['backup_minute'] == '15') ? 'selected' : '' ?>>15</option>
                                        <option value="30" <?= (isset($settings['backup_minute']) && $settings['backup_minute'] == '30') ? 'selected' : '' ?>>30</option>
                                        <option value="45" <?= (isset($settings['backup_minute']) && $settings['backup_minute'] == '45') ? 'selected' : '' ?>>45</option>
                                    </select>
                                    <select class="form-control" id="backupAmPmInput" style="height: 40px; width: 90px; padding: 0 10px; background-color: #f8f9fa; font-weight: bold;" onchange="updateBackupVisuals(); checkBackupForm()">
                                        <option value="" <?= !isset($settings['backup_ampm']) ? 'selected' : '' ?> disabled>am/pm</option>
                                        <option value="AM" <?= (isset($settings['backup_ampm']) && $settings['backup_ampm'] == 'AM') ? 'selected' : '' ?>>صباحاً (AM)</option>
                                        <option value="PM" <?= (isset($settings['backup_ampm']) && $settings['backup_ampm'] == 'PM') ? 'selected' : '' ?>>مساءً (PM)</option>
                                    </select>
                                    <span style="font-size: 20px; margin-right: 10px;">⏰</span>
                                </div>
                            </div>
                            
                            <!-- 3. عداد النسخة القادمة -->
                            <div class="form-group" style="margin-bottom: 20px;">
                                <label style="display: block; font-size: 14px; font-weight: 500; color: #495057; margin-bottom: 8px;">النسخة القادمة بعد</label>
                                <div style="background: #f8f9fa; padding: 15px; border-radius: 12px; text-align: center; font-size: 24px; font-weight: bold; color: #667eea; letter-spacing: 2px; border: 2px solid #e9ecef; box-shadow: inset 0 2px 4px rgba(0,0,0,0.02);" id="backupCountdown">
                                    -- : -- : --
                                </div>
                                <div style="text-align: center; font-size: 12px; color: #6c757d; margin-top: 5px;" id="backupNextScheduleText">غير محدد</div>
                            </div>
                            
                            <!-- 4. زر التفعيل -->
                            <button class="btn btn-primary btn-block" id="enableAutoBackupBtn" disabled onclick="toggleAutoBackup()" style="height: 45px; font-size: 16px; width: 100%; margin-top: 10px;">
                                تفعيل النسخ الاحتياطي التلقائي
                            </button>
                        </div>

                        <!-- القسم الثاني: إدارة قاعدة البيانات -->
                        <div style="margin-top: 20px;">
                            <h3 style="font-size: 18px; font-weight: 600; margin-bottom: 10px; color: #343a40; border-bottom: 2px solid #e9ecef; padding-bottom: 10px;">إدارة قاعدة البيانات والنظام</h3>
                            <p style="font-size: 13px; color: #6c757d; margin-bottom: 20px;">النسخ الاحتياطي اليدوي، استعادة البيانات، وإعادة ضبط النظام بالكامل.</p>
                            
                            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-top: 20px;">
                                <button class="btn btn-warning" style="height: 50px; font-size: 15px; display: flex; align-items: center; justify-content: center; gap: 10px; font-weight: bold; box-shadow: 0 4px 15px rgba(255, 193, 7, 0.2);" onclick="exportDatabase()">
                                    <span style="font-size: 20px;">📤</span> تصدير قاعدة البيانات
                                </button>
                                <button class="btn btn-success" style="height: 50px; font-size: 15px; display: flex; align-items: center; justify-content: center; gap: 10px; font-weight: bold; box-shadow: 0 4px 15px rgba(40, 167, 69, 0.2);" onclick="importDatabase()">
                                    <span style="font-size: 20px;">📥</span> استيراد نسخة محفوظة
                                </button>
                                <button class="btn btn-danger" style="height: 50px; font-size: 15px; display: flex; align-items: center; justify-content: center; gap: 10px; font-weight: bold; grid-column: 1 / -1; background: linear-gradient(135deg, #fa709a 0%, #fee140 100%); color: #fff; border:none; box-shadow: 0 4px 15px rgba(250, 112, 154, 0.4);" onclick="openSystemResetModal()">
                                    <span style="font-size: 20px;">⚠️</span> إعادة ضبط النظام (حذف جميع البيانات)
                                </button>
                            </div>
                        </div>
                        
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- نافذة معاينة الطباعة المنبثقة -->
    <div class="modal" id="printPreviewModal">
        <div class="modal-content">
            <div class="modal-header">
                <h3>
                    <span>🖨️</span>
                    معاينة الفاتورة
                </h3>
                <button class="modal-close" onclick="closePreviewModal()">✖</button>
            </div>
            <div class="modal-body" id="previewBody">
                <!-- محتوى المعاينة سيتم إضافته ديناميكياً -->
            </div>
            <div class="modal-footer">
                <div class="copy-control">
                    <button onclick="decrementCopies()" id="decrementCopy">-</button>
                    <span id="copyCount">1</span>
                    <button onclick="incrementCopies()" id="incrementCopy">+</button>
                    <span style="margin-right: 10px;">نسخ</span>
                </div>
                <button class="btn btn-primary" onclick="printInvoice()">
                    <span>🖨️</span> طباعة
                </button>
                <button class="btn btn-secondary" onclick="closePreviewModal()">
                    <span>❌</span> إغلاق
                </button>
            </div>
        </div>
    </div>

    <!-- نافذة إعادة ضبط النظام المنبثقة -->
    <div class="modal reset-modal" id="resetSystemModal">
        <div class="modal-content" style="max-width: 500px;">
            <div class="modal-header">
                <h3>
                    <span>⚠️</span>
                    إعادة ضبط النظام
                </h3>
                <button class="modal-close" onclick="closeResetModal()">✖</button>
            </div>
            <div class="modal-body">
                <div class="reset-warning-box">
                    <strong>تحذير هام جداً:</strong> هذه العملية ستقوم بمسح جميع بيانات النظام بشكل نهائي ولا يمكن التراجع عنها. سيشمل الحذف:
                    <ul>
                        <li>جميع المنتجات والأصناف</li>
                        <li>المخزون وحركات المستودع</li>
                        <li>بيانات العملاء والفواتير</li>
                        <li>إعدادات النظام والتقارير</li>
                    </ul>
                </div>
                
                <div class="confirm-reset-group">
                    <label style="display: flex; align-items: flex-start; gap: 10px; cursor: pointer; margin-bottom: 15px;">
                        <input type="checkbox" id="confirmResetCheck" style="margin-top: 4px; width: 18px; height: 18px;" onchange="checkResetConfirm()">
                        <span style="font-size: 14px; font-weight: 500; color: #495057; line-height: 1.5;">
                            أقر بأنني قمت بأخذ نسخة احتياطية من البيانات وأتحمل المسؤولية الكاملة عن عملية إعادة الضبط.
                        </span>
                    </label>
                    
                    <button class="btn reset-countdown-btn" id="executeResetBtn" disabled onclick="executeSystemReset()" style="width: 100%; height: 45px; font-size: 15px; font-weight: bold; background: #c92a2a; color: white; border: none;">
                        انتظر (15) ثانية للموافقة
                    </button>
                </div>
            </div>
        </div>
    </div>
    
    <script>
        const BASE_URL = '<?= BASE_URL ?>';
        let currentTemplate = <?= $settings['print_template_id'] ?? 1 ?>;
        let hasUnsavedChanges = false;
        let copyCount = 1;
        let currentTestInvoice = null;

        // ===== تفعيل/تعطيل الحقول =====
        function togglePrintEnabled() {
            const toggle = document.getElementById('printEnabledToggle');
            const isEnabled = toggle.classList.contains('active');
            
            if (isEnabled) {
                toggle.classList.remove('active');
            } else {
                toggle.classList.add('active');
            }
            
            hasUnsavedChanges = true;
        }

        function togglePrintAuto() {
            const toggle = document.getElementById('printAutoToggle');
            toggle.classList.toggle('active');
            hasUnsavedChanges = true;
        }

        // ===== التبديل بين لوحات تنسيق الفاتورة =====
        function switchPanel(panel) {
            document.querySelectorAll('.panel-tab').forEach(tab => tab.classList.remove('active'));
            document.querySelectorAll('.panel-content').forEach(content => content.classList.remove('active'));
            
            if (panel === 'text') {
                document.querySelectorAll('.panel-tab')[0].classList.add('active');
                document.getElementById('textPanel').classList.add('active');
            } else {
                document.querySelectorAll('.panel-tab')[1].classList.add('active');
                document.getElementById('companyPanel').classList.add('active');
            }
        }

        // ===== اختيار التصميم =====
        function selectTemplate(id) {
            document.querySelectorAll('.template-item').forEach(item => item.classList.remove('selected'));
            document.querySelectorAll('.template-item')[id-1].classList.add('selected');
            document.getElementById('selectedTemplate').value = id;
            currentTemplate = id;
            hasUnsavedChanges = true;
        }

        function applyTemplate() {
            showAlert('success', '✅ تم تطبيق التصميم بنجاح');
        }

        // ===== عرض الرسائل =====
        function showAlert(type, message) {
            const container = document.getElementById('alertsContainer');
            const alertDiv = document.createElement('div');
            alertDiv.className = `alert alert-${type}`;
            
            const icons = {
                success: '✅',
                error: '❌',
                warning: '⚠️',
                info: '💡'
            };
            
            alertDiv.innerHTML = `
                <div class="alert-icon">${icons[type] || '📢'}</div>
                <div class="alert-content">
                    <div class="alert-title">${type === 'success' ? 'نجاح' : type === 'error' ? 'خطأ' : type === 'warning' ? 'تحذير' : 'معلومة'}</div>
                    <div>${message}</div>
                </div>
                <div class="alert-close" onclick="this.parentElement.remove()">✖</div>
            `;
            
            container.appendChild(alertDiv);
            
            // إزالة تلقائية بعد 5 ثوان
            setTimeout(() => {
                if (alertDiv.parentElement) {
                    alertDiv.remove();
                }
            }, 5000);
        }

        // ===== حفظ الإعدادات =====
        function saveSettings() {
            const saveBtn = document.getElementById('saveSettingsBtn');
            const originalText = saveBtn.innerHTML;
            
            // تغيير نص الزر
            saveBtn.innerHTML = '<span>⏳</span> جاري الحفظ...';
            saveBtn.disabled = true;
            
            // جمع البيانات
            const formData = new URLSearchParams();
            formData.append('print_enabled', document.getElementById('printEnabledToggle').classList.contains('active') ? 'on' : 'off');
            formData.append('print_save_path', document.getElementById('printSavePath').value);
            formData.append('print_open_automatically', document.getElementById('printAutoToggle').classList.contains('active') ? 'on' : 'off');
            formData.append('print_header_text', document.getElementById('printHeader').value);
            formData.append('print_footer_text', document.getElementById('printFooter').value);
            formData.append('print_company_info', document.getElementById('printCompanyInfo').value);
            formData.append('print_template_id', document.getElementById('selectedTemplate').value);
            formData.append('store_name', 'نظام الكاشير');
            
            // Backup settings
            formData.append('backup_path', document.getElementById('backupPathInput').value);
            formData.append('backup_hour', document.getElementById('backupHourInput').value || '');
            formData.append('backup_minute', document.getElementById('backupMinuteInput').value || '');
            formData.append('backup_ampm', document.getElementById('backupAmPmInput').value || '');
            formData.append('backup_enabled', document.getElementById('enableAutoBackupBtn').classList.contains('btn-success') ? '1' : '0');
            
            fetch(`${BASE_URL}/settings/save`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                saveBtn.innerHTML = originalText;
                saveBtn.disabled = false;
                
                if (data.success) {
                    showAlert('success', data.message);
                    hasUnsavedChanges = false;
                    
                    // تحديث رسالة التحقق من المسار
                    const pathValidation = document.getElementById('pathValidation');
                    if (data.settings && data.settings.print_save_path) {
                        // يمكن تحديث رسالة التحقق هنا إذا رجعتها من الخادم
                    }
                } else {
                    showAlert('error', data.message);
                }
            })
            .catch(error => {
                saveBtn.innerHTML = originalText;
                saveBtn.disabled = false;
                showAlert('error', 'حدث خطأ في الاتصال بالخادم');
                console.error('Error:', error);
            });
        }

        // ===== اختبار الطباعة =====
        function testPrint() {
            const testBtn = document.getElementById('testPrintBtn');
            const originalText = testBtn.innerHTML;
            
            testBtn.innerHTML = '<span>⏳</span> جاري الاختبار...';
            testBtn.disabled = true;
            
            fetch(`${BASE_URL}/settings/test-print`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                }
            })
            .then(response => response.json())
            .then(data => {
                testBtn.innerHTML = originalText;
                testBtn.disabled = false;
                
                if (data.success) {
                    currentTestInvoice = data.invoice;
                    showPrintPreview(data.invoice, data.settings);
                } else {
                    showAlert('error', data.message);
                }
            })
            .catch(error => {
                testBtn.innerHTML = originalText;
                testBtn.disabled = false;
                showAlert('error', 'حدث خطأ في الاتصال بالخادم');
                console.error('Error:', error);
            });
        }

        // ===== عرض معاينة الطباعة =====
      function showPrintPreview(invoice, settings) {
    const modal = document.getElementById('printPreviewModal');
    const previewBody = document.getElementById('previewBody');
    
    // قراءة النصوص من الحقول
    const headerText = document.getElementById('printHeader').value;
    const footerText = document.getElementById('printFooter').value;
    const companyInfo = document.getElementById('printCompanyInfo').value;
    const templateId = document.getElementById('selectedTemplate').value;
    
    // تقسيم معلومات الشركة (كلها تظهر كتفاصيل عادية، لا عنوان رئيسي)
    const companyLines = companyInfo.split('\n').filter(line => line.trim() !== '');
    
    // ===== أنماط التصاميم المختلفة =====
    let styles = '';
    
    switch(templateId) {
        case '1': // كلاسيكي
            styles = `
                <style>
                    .invoice-wrapper { font-family: 'Courier New', monospace; max-width: 300px; margin: 0 auto; background: white; border: 1px solid #ddd; }
                    .invoice-header { background: #f8f9fa; padding: 15px; text-align: center; border-bottom: 2px solid #333; }
                    .invoice-header h1 { margin: 0; font-size: 22px; color: #333; }
                    .company-info { background: white; padding: 12px; text-align: center; font-size: 11px; border-bottom: 1px dashed #ccc; }
                    .invoice-details { padding: 12px; font-size: 11px; border-bottom: 1px solid #eee; }
                    .items-table { width: 100%; border-collapse: collapse; font-size: 11px; }
                    .items-table th { background: #f8f9fa; padding: 6px; text-align: center; border-bottom: 1px solid #333; }
                    .items-table td { padding: 6px; text-align: center; border-bottom: 1px solid #eee; }
                    .total-section { padding: 12px; text-align: left; border-top: 2px solid #333; margin-top: 10px; }
                    .invoice-footer { padding: 12px; text-align: center; font-size: 10px; border-top: 1px dashed #ccc; color: #666; }
                </style>
            `;
            break;
        case '2': // حديث
            styles = `
                <style>
                    .invoice-wrapper { font-family: 'Segoe UI', sans-serif; max-width: 300px; margin: 0 auto; background: white; border-radius: 12px; overflow: hidden; box-shadow: 0 4px 12px rgba(0,0,0,0.1); }
                    .invoice-header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); padding: 20px; text-align: center; }
                    .invoice-header h1 { margin: 0; font-size: 20px; color: white; }
                    .company-info { background: #f8f9fa; padding: 12px; text-align: center; font-size: 11px; border-bottom: 1px solid #e9ecef; }
                    .invoice-details { padding: 12px; background: #f8f9fa; font-size: 11px; }
                    .items-table { width: 100%; border-collapse: collapse; font-size: 11px; }
                    .items-table th { background: #667eea; color: white; padding: 8px; text-align: center; }
                    .items-table td { padding: 8px; text-align: center; border-bottom: 1px solid #e9ecef; }
                    .total-section { padding: 12px; background: #f8f9fa; text-align: left; }
                    .grand-total { font-size: 14px; font-weight: bold; color: #28a745; }
                    .invoice-footer { padding: 12px; text-align: center; font-size: 10px; color: #6c757d; }
                </style>
            `;
            break;
        case '3': // فاخر
            styles = `
                <style>
                    .invoice-wrapper { font-family: 'Times New Roman', serif; max-width: 300px; margin: 0 auto; background: #fdf8f0; border: 1px solid #d4af37; }
                    .invoice-header { background: linear-gradient(135deg, #b8860b 0%, #8b4513 100%); padding: 20px; text-align: center; }
                    .invoice-header h1 { margin: 0; font-size: 22px; color: #ffd700; letter-spacing: 2px; }
                    .company-info { background: #fdf8f0; padding: 12px; text-align: center; font-size: 11px; border-bottom: 1px solid #d4af37; }
                    .invoice-details { padding: 12px; font-size: 11px; border-bottom: 1px solid #d4af37; }
                    .items-table { width: 100%; border-collapse: collapse; font-size: 11px; }
                    .items-table th { background: #d4af37; color: #5c3d2e; padding: 6px; text-align: center; }
                    .items-table td { padding: 6px; text-align: center; border-bottom: 1px solid #e8d5b7; }
                    .total-section { padding: 12px; text-align: left; border-top: 2px solid #d4af37; }
                    .invoice-footer { padding: 12px; text-align: center; font-size: 10px; color: #8b4513; border-top: 1px solid #d4af37; }
                </style>
            `;
            break;
        case '4': // مبسط (أبيض وأسود)
            styles = `
                <style>
                    .invoice-wrapper { font-family: monospace; max-width: 300px; margin: 0 auto; background: white; border: 1px solid black; }
                    .invoice-header { background: black; padding: 15px; text-align: center; }
                    .invoice-header h1 { margin: 0; font-size: 18px; color: white; text-transform: uppercase; }
                    .company-info { padding: 10px; text-align: center; font-size: 10px; border-bottom: 1px solid black; }
                    .invoice-details { padding: 10px; font-size: 10px; border-bottom: 1px solid black; }
                    .items-table { width: 100%; border-collapse: collapse; font-size: 10px; }
                    .items-table th { background: black; color: white; padding: 5px; text-align: center; }
                    .items-table td { padding: 5px; text-align: center; border-bottom: 1px solid black; }
                    .total-section { padding: 10px; text-align: left; border-top: 1px solid black; }
                    .invoice-footer { padding: 10px; text-align: center; font-size: 9px; border-top: 1px solid black; }
                </style>
            `;
            break;
        default:
            styles = `<style>.invoice-wrapper { font-family: monospace; max-width: 300px; margin: 0 auto; }</style>`;
    }
    
    // بناء جدول المنتجات
    let itemsHtml = '';
    invoice.items.forEach(item => {
        itemsHtml += `
            <tr>
                <td>${item.name}</td>
                <td>${item.quantity}</td>
                <td>${item.price.toFixed(2)}</td>
                <td>${item.total.toFixed(2)}</td>
            </tr>
        `;
    });
    
    // بناء HTML الفاتورة بالكامل
    previewBody.innerHTML = `
        ${styles}
        <div class="invoice-wrapper">
            
            <!-- ===== رأس الفاتورة ===== -->
            <div class="invoice-header">
                <h1>${headerText || 'فاتورة البيع'}</h1>
            </div>
            
            <!-- ===== معلومات الشركة (كلها كتفاصيل عادية) ===== -->
            <div class="company-info">
                ${companyLines.map(line => `<div>${line}</div>`).join('')}
            </div>
            
            <!-- ===== تفاصيل الفاتورة ===== -->
            <div class="invoice-details">
                <div>📄 رقم الفاتورة: ${invoice.invoice_number}</div>
                <div>📅 التاريخ: ${invoice.date}</div>
                <div>👤 البائع: ${invoice.seller}</div>
            </div>
            
            <!-- ===== جدول المنتجات ===== -->
            <table class="items-table">
                <thead>
                    <tr>
                        <th>المنتج</th>
                        <th>الكمية</th>
                        <th>السعر</th>
                        <th>الإجمالي</th>
                    </tr>
                </thead>
                <tbody>
                    ${itemsHtml}
                </tbody>
            </table>
            
            <!-- ===== الإجمالي ===== -->
            <div class="total-section">
                <div style="display: flex; justify-content: space-between; margin-bottom: 5px;">
                    <span>الإجمالي:</span>
                    <span>${invoice.total.toFixed(2)} ريال</span>
                </div>
                <div style="display: flex; justify-content: space-between; font-weight: bold;">
                    <span>الصافي:</span>
                    <span class="${templateId === '2' ? 'grand-total' : ''}">${invoice.total.toFixed(2)} ريال</span>
                </div>
            </div>
            
            <!-- ===== تذييل الفاتورة ===== -->
            ${footerText ? `<div class="invoice-footer">${footerText}</div>` : '<div class="invoice-footer">شكراً لزيارتكم</div>'}
            
        </div>
    `;
    
    modal.classList.add('active');
}
        // ===== التحكم بعدد النسخ =====
        function incrementCopies() {
            if (copyCount < 5) {
                copyCount++;
                document.getElementById('copyCount').textContent = copyCount;
            }
        }

        function decrementCopies() {
            if (copyCount > 1) {
                copyCount--;
                document.getElementById('copyCount').textContent = copyCount;
            }
        }

        // ===== طباعة الفاتورة =====
        function printInvoice() {
            const printContent = document.querySelector('.invoice-preview').cloneNode(true);
            const printWindow = window.open('', '_blank');
            
            printWindow.document.write(`
                <html dir="rtl">
                <head>
                    <title>طباعة الفاتورة</title>
                    <style>
                        body { font-family: 'Courier New', monospace; padding: 20px; }
                        .invoice-header { text-align: center; margin-bottom: 30px; }
                        .invoice-table { width: 100%; border-collapse: collapse; }
                        .invoice-table th, .invoice-table td { padding: 8px; border-bottom: 1px solid #000; }
                        .invoice-total { text-align: left; margin-top: 20px; }
                    </style>
                </head>
                <body>
                    ${printContent.outerHTML}
                </body>
                </html>
            `);
            
            printWindow.document.close();
            printWindow.focus();
            printWindow.print();
            printWindow.close();
            
            closePreviewModal();
        }

        // ===== إغلاق نافذة المعاينة =====
        function closePreviewModal() {
            document.getElementById('printPreviewModal').classList.remove('active');
            copyCount = 1;
            document.getElementById('copyCount').textContent = '1';
        }

        // ===== العودة للرئيسية =====
        function goBack() {
            if (hasUnsavedChanges) {
                if (confirm('لديك تغييرات غير محفوظة، هل أنت متأكد من المغادرة؟')) {
                    window.location.href = `${BASE_URL}/dashboard`;
                }
            } else {
                window.location.href = `${BASE_URL}/dashboard`;
            }
        }

        // ===== منع فقدان التغييرات عند الإغلاق =====
        window.addEventListener('beforeunload', function(e) {
            if (hasUnsavedChanges) {
                e.preventDefault();
                e.returnValue = '';
            }
        });

        // ===== مراقبة التغييرات في الحقول =====
        document.querySelectorAll('input, textarea').forEach(input => {
            input.addEventListener('change', () => hasUnsavedChanges = true);
            input.addEventListener('keyup', () => hasUnsavedChanges = true);
        });

        // ===== Backup Management functions =====
        let backupInterval = null;
        let countdownTarget = null;

        function updateBackupVisuals() {
            var hr = parseInt(document.getElementById('backupHourInput').value);
            var min = parseInt(document.getElementById('backupMinuteInput').value);
            var ampm = document.getElementById('backupAmPmInput').value;
            
            if (!isNaN(hr) && !isNaN(min) && ampm) {
                let hourString = hr.toString().padStart(2, '0');
                let minString = min.toString().padStart(2, '0');
                
                document.getElementById('backupNextScheduleText').innerHTML = `موعد النسخ المجدول يومياً في ${hourString}:${minString} ${ampm === 'AM' ? 'صباحاً' : 'مساءً'}`;
                
                // حساب الفارق الفعلي بالساعات والدقائق والثواني للنسخة القادمة
                let now = new Date();
                let targetDate = new Date(now);
                
                let targetHour = hr;
                if (ampm === 'PM' && hr !== 12) {
                    targetHour += 12;
                } else if (ampm === 'AM' && hr === 12) {
                    targetHour = 0;
                }
                
                targetDate.setHours(targetHour, min, 0, 0);
                
                // إذا كان الوقت المطلوب قد مر في هذا اليوم، نجعله لليوم التالي
                if (targetDate.getTime() <= now.getTime()) {
                    targetDate.setDate(targetDate.getDate() + 1);
                }
                
                countdownTarget = targetDate;
                updateCountdownDisplay();
                
            } else {
                document.getElementById('backupNextScheduleText').innerHTML = 'غير محدد';
                document.getElementById('backupCountdown').innerHTML = '-- : -- : --';
                countdownTarget = null;
            }
        }
        
        function updateCountdownDisplay() {
            if (!countdownTarget) return;
            
            let now = new Date();
            let diffMs = countdownTarget.getTime() - now.getTime();
            
            if (diffMs < 0) {
                // Time reached, reset for next day
                countdownTarget.setDate(countdownTarget.getDate() + 1);
                diffMs = countdownTarget.getTime() - now.getTime();
            }
            
            let diffSec = Math.floor(diffMs / 1000);
            
            let h = Math.floor(diffSec / 3600).toString().padStart(2, '0');
            let m = Math.floor((diffSec % 3600) / 60).toString().padStart(2, '0');
            let s = (diffSec % 60).toString().padStart(2, '0');
            
            // Limit to max 24 hours (86399 seconds = 23:59:59)
            if (diffSec >= 86400) {
                 h = '23'; m = '59'; s = '59';
            }
            
            document.getElementById('backupCountdown').innerHTML = `${h} : ${m} : ${s}`;
        }

        function checkBackupForm() {
            var path = document.getElementById('backupPathInput').value;
            var hr = document.getElementById('backupHourInput').value;
            var min = document.getElementById('backupMinuteInput').value;
            var ampm = document.getElementById('backupAmPmInput').value;
            
            var btn = document.getElementById('enableAutoBackupBtn');
            if (path.trim() !== '' && hr && min && ampm) {
                btn.disabled = false;
            } else {
                btn.disabled = true;
                if (btn.classList.contains('btn-success')) {
                    toggleAutoBackup();
                }
            }
        }
        
        function toggleAutoBackup() {
            var btn = document.getElementById('enableAutoBackupBtn');
            if (btn.classList.contains('btn-primary')) {
                btn.classList.remove('btn-primary');
                btn.classList.add('btn-success');
                btn.innerHTML = 'تم التفعيل';
                showAlert('success', 'تم تفعيل النسخ الاحتياطي التلقائي');
                
                updateBackupVisuals(); // Ensure target is calculated
                if(backupInterval) clearInterval(backupInterval);
                backupInterval = setInterval(updateCountdownDisplay, 1000);
            } else {
                btn.classList.add('btn-primary');
                btn.classList.remove('btn-success');
                btn.innerHTML = 'تفعيل النسخ الاحتياطي التلقائي';
                showAlert('info', 'تم إيقاف النسخ الاحتياطي التلقائي');
                if(backupInterval) clearInterval(backupInterval);
                updateBackupVisuals(); // Show static time
            }
        }
        function selectBackupPath() {
            var path = prompt('أدخل مسار الحفظ:', document.getElementById('backupPathInput').value || 'C:/backups/');
            if (path !== null) {
                document.getElementById('backupPathInput').value = path;
                checkBackupForm();
            }
        }
        async function importDatabase() {
            try {
                let file;
                // Try using the modern File System Access API if available
                if (window.showOpenFilePicker) {
                    const [fileHandle] = await window.showOpenFilePicker({
                        types: [{
                            description: 'SQL Database Backup',
                            accept: {'application/sql': ['.sql']}
                        }],
                        excludeAcceptAllOption: true,
                        multiple: false
                    });
                    file = await fileHandle.getFile();
                } else {
                    // Fallback to traditional file input
                    file = await new Promise((resolve) => {
                        let fileInput = document.createElement('input');
                        fileInput.type = 'file';
                        fileInput.accept = '.sql';
                        fileInput.onchange = e => resolve(e.target.files[0]);
                        fileInput.click();
                    });
                }
                
                if (!file) return;
                
                showAlert('info', 'جاري رفع واستيراد قاعدة البيانات، يرجى الانتظار...');
                
                let formData = new FormData();
                formData.append('backup_file', file);
                
                const response = await fetch(`${BASE_URL}/settings/import-db`, {
                    method: 'POST',
                    body: formData
                });
                
                const data = await response.json();
                if (data.success) {
                    showAlert('success', 'تم استيراد قاعدة البيانات بنجاح!');
                } else {
                    showAlert('error', 'فشل في الاستيراد: ' + (data.message || 'خطأ غير معروف'));
                }
            } catch (error) {
                if (error.name !== 'AbortError') {
                    showAlert('error', 'حدث خطأ في الاتصال بالخادم أو أثناء اختيار الملف');
                    console.error('Error:', error);
                }
            }
        }
        
        async function exportDatabase() {
            try {
                // Generate a filename with current date/time
                const date = new Date();
                const filename = `pos_backup_${date.getFullYear()}${(date.getMonth()+1).toString().padStart(2,'0')}${date.getDate().toString().padStart(2,'0')}_${date.getHours().toString().padStart(2,'0')}${date.getMinutes().toString().padStart(2,'0')}.sql`;
                
                let fileHandle = null;
                
                // Try modern File System Access API to pick save location *first*
                if (window.showSaveFilePicker) {
                    fileHandle = await window.showSaveFilePicker({
                        suggestedName: filename,
                        types: [{
                            description: 'SQL Database Backup',
                            accept: {'application/sql': ['.sql']},
                        }]
                    });
                }
                
                showAlert('info', 'جاري تجهيز وتصدير قاعدة البيانات...');
                
                const response = await fetch(`${BASE_URL}/settings/export-db`, {
                    method: 'POST'
                });
                
                if (!response.ok) {
                    const data = await response.json();
                    throw new Error(data.message || 'فشل التصدير');
                }
                
                const blob = await response.blob();
                
                if (fileHandle) {
                    // Save directly to the chosen file location
                    const writable = await fileHandle.createWritable();
                    await writable.write(blob);
                    await writable.close();
                    showAlert('success', 'تم تصدير قاعدة البيانات وحفظها بنجاح!');
                } else {
                    // Fallback: trigger standard browser download
                    const url = window.URL.createObjectURL(blob);
                    const a = document.createElement('a');
                    a.style.display = 'none';
                    a.href = url;
                    a.download = filename;
                    document.body.appendChild(a);
                    a.click();
                    window.URL.revokeObjectURL(url);
                    document.body.removeChild(a);
                    showAlert('success', 'تم تصدير قاعدة البيانات بنجاح!');
                }
                
            } catch (error) {
                if (error.name !== 'AbortError') {
                    showAlert('error', 'حدث خطأ أثناء التصدير: ' + error.message);
                    console.error('Error:', error);
                }
            }
        }
        // ===== التبديل بين اللوحات (Tabs) الجانبية =====
        function showSettingsTab(tabId, linkEl) {
            // إخفاء كل البطاقات
            document.querySelectorAll('.settings-card').forEach(card => {
                card.classList.remove('active');
            });
            
            // إظهار البطاقة المستهدفة
            document.getElementById(tabId + 'Tab').classList.add('active');
            
            // تحديث حالة الأزرار الجانبية
            document.querySelectorAll('.sidebar-menu a').forEach(link => {
                link.classList.remove('active');
            });
            linkEl.classList.add('active');
        }

        // ===== System Reset Functions =====
        let resetTimerInterval = null;
        let resetSecondsLeft = 15;

        function openSystemResetModal() {
            const modal = document.getElementById('resetSystemModal');
            const btn = document.getElementById('executeResetBtn');
            const check = document.getElementById('confirmResetCheck');
            
            check.checked = false;
            btn.disabled = true;
            btn.innerHTML = 'إعادة ضبط النظام';
            btn.style.opacity = '0.5';
            btn.classList.remove('counting');
            
            modal.classList.add('active');
        }

        function closeResetModal() {
            document.getElementById('resetSystemModal').classList.remove('active');
            if (resetTimerInterval) clearInterval(resetTimerInterval);
        }

        function checkResetConfirm() {
            const check = document.getElementById('confirmResetCheck');
            const btn = document.getElementById('executeResetBtn');
            
            if (check.checked) {
                btn.style.opacity = '1';
                btn.classList.add('counting');
                resetSecondsLeft = 15;
                btn.innerHTML = `انتظر (${resetSecondsLeft}) ثانية للموافقة`;
                
                if (resetTimerInterval) clearInterval(resetTimerInterval);
                
                resetTimerInterval = setInterval(() => {
                    resetSecondsLeft--;
                    if (resetSecondsLeft > 0) {
                        btn.innerHTML = `انتظر (${resetSecondsLeft}) ثانية للموافقة`;
                    } else {
                        clearInterval(resetTimerInterval);
                        btn.innerHTML = 'تأكيد إعادة ضبط النظام نهائياً';
                        btn.disabled = false;
                        btn.classList.remove('counting');
                    }
                }, 1000);
            } else {
                if (resetTimerInterval) clearInterval(resetTimerInterval);
                btn.disabled = true;
                btn.innerHTML = 'إعادة ضبط النظام';
                btn.style.opacity = '0.5';
                btn.classList.remove('counting');
            }
        }

        function executeSystemReset() {
            closeResetModal();
            showAlert('warning', 'جاري إعادة ضبط النظام بالكامل، يرجى الانتظار...');
            
            fetch(`${BASE_URL}/settings/reset-system`, {
                method: 'POST'
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    showAlert('success', 'تم إعادة ضبط النظام بنجاح! سيتم إعادة توجيهك...');
                    setTimeout(() => {
                        window.location.href = `${BASE_URL}/login/logout`;
                    }, 3000);
                } else {
                    showAlert('error', 'فشل في إعادة ضبط النظام: ' + (data.message || 'خطأ غير معروف'));
                }
            })
            .catch(error => {
                showAlert('error', 'حدث خطأ استثنائي أثناء إعادة ضبط النظام!');
                console.error('Error Reset:', error);
            });
        }
        
        // Initialize backup state on page load
        document.addEventListener('DOMContentLoaded', () => {
            let isBackupEnabled = <?= $settings['backup_enabled'] ?? '0' ?>;
            let btn = document.getElementById('enableAutoBackupBtn');
            
            if (isBackupEnabled == '1') {
                btn.disabled = false;
                btn.classList.add('btn-success');
                btn.classList.remove('btn-primary');
                btn.innerHTML = 'تم التفعيل';
                
                updateBackupVisuals();
                if(backupInterval) clearInterval(backupInterval);
                backupInterval = setInterval(updateCountdownDisplay, 1000);
            } else {
                checkBackupForm();
                updateBackupVisuals();
            }
        });

    </script>
</body>
</html>

<?php
$content = ob_get_clean();
require BASE_PATH . 'views/layouts/main.php';
?>