
 <?php
ob_start();
// تعطيل جميع الأخطاء في PHP
error_reporting(0);
ini_set('display_errors', 0);
ini_set('display_startup_errors', 0);
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="robots" content="noindex, nofollow, noarchive">
    <title><?= $title ?? 'نقطة البيع' ?></title>
    <link rel="stylesheet" href="<?= asset('css/style.css') ?>">
    <style>
    /* ===== تطبيق نمط سطح المكتب المتقدم ===== */
    * {
        user-select: none; /* منع تحديد النص */
        -webkit-user-select: none;
        -moz-user-select: none;
        -ms-user-select: none;
    }

    /* السماح بالتحديد فقط في الحقول */
    input, textarea, [contenteditable="true"] {
        user-select: text !important;
        -webkit-user-select: text !important;
        -moz-user-select: text !important;
        -ms-user-select: text !important;
    }

    /* تثبيت تخطيط الصفحة */
    html, body {
        overflow: hidden !important;
        height: 100vh !important;
        width: 100vw !important;
        margin: 0 !important;
        padding: 0 !important;
        cursor: default;
        min-width: 1200px; /* عرض أدنى ثابت */
    }

    /* منع الطباعة */
    @media print {
        body { display: none !important; }
    }

    /* تنسيق الصفحة الرئيسية */
    .pos-page {
        height: calc(100vh - 60px) !important;
        max-height: calc(100vh - 60px) !important;
        overflow: hidden !important;
        padding: 15px !important;
        gap: 15px !important;
        background: #F5F7FA !important;
        min-width: 1200px;
    }

    /* تثبيت ارتفاع لوحة التحكم */
    .pos-control-panel {
        width: 320px !important;
        height: 100% !important;
        overflow-y: auto !important;
        background: white;
        border-radius: 8px;
        box-shadow: 0 2px 6px rgba(0,0,0,0.05);
    }

    /* تثبيت ارتفاع السلة */
    .pos-cart {
        flex: 1 !important;
        height: 100% !important;
        overflow: hidden !important;
        background: white;
        border-radius: 8px;
        box-shadow: 0 2px 6px rgba(0,0,0,0.05);
        display: flex;
        flex-direction: column;
    }

    /* تثبيت رأس السلة */
    .cart-header {
        height: 70px !important;
        min-height: 70px !important;
        padding: 0 20px;
        border-bottom: 1px solid #F0F0F0;
        flex-shrink: 0;
    }

    /* تثبيت حاوية الجدول */
    .cart-table-container {
        flex: 1 !important;
        overflow-y: auto !important;
        padding: 15px;
        height: calc(100% - 70px) !important;
        max-height: calc(100% - 70px) !important;
    }

    /* تثبيت رأس الجدول */
    .cart-table th {
        position: sticky !important;
        top: 0 !important;
        background: linear-gradient(135deg, #233e97ff, #054784ff) !important; /* ألوان هادئة */
        color: white;
        z-index: 10;
        height: 45px;
    }

    /* إزالة القصداير */
    [contenteditable], [draggable] {
        -webkit-user-drag: none;
        user-drag: none;
    }

    /* منع سحب الصور */
    img {
        -webkit-user-drag: none;
        user-drag: none;
        pointer-events: none;
    }

    /* تنسيق النوافذ المنبثقة */
    .return-modal {
        background: rgba(0,0,0,0.3);
        backdrop-filter: blur(2px);
    }

    .return-modal-content {
        width: 900px;
        max-width: 900px;
        border-radius: 8px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.1);
    }

    /* تثبيت أزرار البيع */
    .sale-btn, .control-btn {
        height: 50px !important;
        min-height: 50px !important;
        border-radius: 6px !important;
    }

    /* تثبيت حقول الإدخال */
    input, select, button {
        border-radius: 6px !important;
        height: 45px;
        min-height: 45px;
    }

    /* تنسيق شريط التمرير */
    ::-webkit-scrollbar {
        width: 8px;
        height: 8px;
    }

    ::-webkit-scrollbar-track {
        background: #f1f1f1;
        border-radius: 4px;
    }

    ::-webkit-scrollbar-thumb {
        background: #B0BEC5;
        border-radius: 4px;
    }

    ::-webkit-scrollbar-thumb:hover {
        background: #90A4AE;
    }

    /* منع ظهور أدوات المطور */
    .dev-tools-hide {
        display: none !important;
    }
</style>

<!-- إضافة meta tags للأمان -->
<meta name="robots" content="noindex, nofollow, noarchive, nosnippet">
<meta http-equiv="Cache-Control" content="no-store, no-cache, must-revalidate, max-age=0">
<meta http-equiv="Pragma" content="no-cache">
<meta http-equiv="Expires" content="0">
<meta name="format-detection" content="telephone=no">
<meta name="format-detection" content="address=no">
    <style>
        

        /* ===== تنسيقات نقطة البيع ===== */
        :root {
            --pos-primary: #2196F3;
            --pos-success: #4CAF50;
            --pos-danger: #f44336;
            --pos-warning: #FF9800;
            --pos-info: #00BCD4;
            --pos-dark: #333;
            --pos-light: #f5f5f5;
            --pos-gray: #9e9e9e;
            --pos-border: #e0e0e0;
        }

        /* ===== التخطيط العام ===== */
        .pos-page {
            height: calc(100vh - 60px);
            display: flex;
            gap: 15px;
            padding: 15px;
            overflow: hidden;
            background: #F5F7FA;
        }

        /* ===== الجزء الأيمن - لوحة التحكم ===== */
        .pos-control-panel {
            width: 320px;
            background: white;
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.05);
            border: 1px solid #F0F0F0;
            padding: 20px;
            overflow-y: auto;
            display: flex;
            flex-direction: column;
            gap: 15px;
        }

        /* ===== منطقة الرسائل ===== */
        .alerts-area {
            min-height: 60px;
        }

        .alert-message {
            height: 60px;
            width: 100%;
            border-radius: 8px;
            display: flex;
            align-items: center;
            padding: 0 15px;
            gap: 12px;
            animation: slideDown 0.3s ease;
            box-shadow: 0 2px 8px rgba(0,0,0,0.05);
        }

        .alert-success {
            background: #E8F5E9;
            border-right: 4px solid #2E7D32;
        }

        .alert-error {
            background: #FFEBEE;
            border-right: 4px solid #C62828;
        }

        .alert-icon {
            width: 24px;
            height: 24px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 14px;
        }

        .alert-success .alert-icon {
            background: #2E7D32;
        }

        .alert-error .alert-icon {
            background: #C62828;
        }

        .alert-content {
            flex: 1;
            font-size: 14px;
            font-weight: 500;
        }

        .alert-success .alert-content {
            color: #1B5E20;
        }

        .alert-error .alert-content {
            color: #B71C1C;
        }

        .alert-close {
            cursor: pointer;
            font-size: 16px;
            color: #666;
            opacity: 0.6;
            transition: opacity 0.3s;
        }

        .alert-close:hover {
            opacity: 1;
        }

        /* ===== حقل البحث ===== */
        .search-field {
            position: relative;
            height: 50px;
        }

        .search-field input {
            width: 100%;
            height: 50px;
            padding: 0 45px 0 40px;
            border: 1.5px solid #E0E0E0;
            border-radius: 10px;
            font-size: 15px;
            transition: all 0.3s;
        }

        .search-field input:focus {
            outline: none;
            border-color: #2196F3;
            box-shadow: 0 0 0 3px rgba(22, 105, 172, 0.9);
        }

        .search-field .search-icon {
            position: absolute;
            right: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: #9E9E9E;
            font-size: 18px;
        }

        .search-field .clear-icon {
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: #757575;
            font-size: 16px;
            cursor: pointer;
            display: none;
        }

        .search-field input:not(:placeholder-shown) + .clear-icon {
            display: block;
        }

        /* ===== نتائج البحث ===== */
        .search-results {
            position: absolute;
            width: 100%;
            max-height: 300px;
            background: white;
            border: 1px solid #E0E0E0;
            border-radius: 0 0 8px 8px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
            overflow-y: auto;
            z-index: 1000;
            display: none;
        }

        .search-results.active {
            display: block;
        }

        .search-result-item {
            padding: 12px;
            border-bottom: 1px solid #F0F0F0;
            cursor: pointer;
            transition: background 0.3s;
        }

        .search-result-item:hover {
            background: #F5F9FF;
        }

        .result-row {
            display: flex;
            justify-content: space-between;
            margin-bottom: 4px;
        }

        .result-name {
            font-size: 16px;
            font-weight: bold;
            color: #212121;
        }

        .result-price {
            font-size: 16px;
            font-weight: bold;
            color: #2E7D32;
        }

        .result-details {
            display: flex;
            justify-content: space-between;
            font-size: 12px;
            color: #757575;
        }

        .result-stock {
            color: #2E7D32;
        }

        .result-stock.low {
            color: #F57C00;
        }

        .result-stock.critical {
            color: #C62828;
        }

        .result-expiry {
            display: flex;
            align-items: center;
            gap: 4px;
        }

        .expiry-warning {
            color: #F57C00;
        }

        .expiry-danger {
            color: #C62828;
        }

        /* ===== حقل الباركود ===== */
        .barcode-field {
            position: relative;
            height: 50px;
        }

        .barcode-field input {
            width: 100%;
            height: 50px;
            padding: 0 45px 0 45px;
            border: 1.5px solid #E0E0E0;
            border-radius: 10px;
            font-size: 15px;
            transition: all 0.3s;
        }

        .barcode-field input:focus {
            outline: none;
            border-color: #4CAF50;
            box-shadow: 0 0 0 3px rgba(76,175,80,0.1);
        }

        .barcode-field .barcode-icon {
            position: absolute;
            right: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: #9E9E9E;
            font-size: 20px;
        }

        .barcode-field .status-indicator {
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
            width: 10px;
            height: 10px;
            border-radius: 50%;
            background: #9E9E9E;
            transition: background 0.3s;
        }

        .barcode-field .status-indicator.success {
            background: #4CAF50;
            animation: blink 1s;
        }

        .barcode-field .status-indicator.error {
            background: #F44336;
            animation: blink 1s;
        }

        @keyframes blink {
            0%, 100% { opacity: 1; }
            50% { opacity: 0.3; }
        }

        /* ===== التحكم في الكمية ===== */
        .quantity-control {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .qty-btn {
            width: 45px;
            height: 45px;
            border: 1px solid #E0E0E0;
            border-radius: 50%;
            background: #F5F5F5;
            font-size: 20px;
            cursor: pointer;
            transition: all 0.3s;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .qty-btn.minus:hover {
            background: #FFEBEE;
            color: #C62828;
            border-color: #EF5350;
        }

        .qty-btn.plus:hover {
            background: #E8F5E9;
            color: #2E7D32;
            border-color: #4CAF50;
        }

        .qty-btn:disabled {
            background: #EEEEEE;
            color: #BDBDBD;
            cursor: not-allowed;
        }

        .qty-input {
            width: 80px;
            height: 45px;
            border: 1px solid #E0E0E0;
            border-radius: 8px;
            text-align: center;
            font-size: 18px;
            font-weight: bold;
        }

        .qty-input:focus {
            outline: none;
            border-color: #2196F3;
        }

        .qty-max {
            color: #9E9E9E;
            font-size: 14px;
        }

        /* ===== حقل المبلغ المدفوع ===== */
        .paid-amount-field {
            position: relative;
            height: 55px;
        }

        .paid-amount-field input {
            width: 100%;
            height: 55px;
            padding: 0 45px 0 70px;
            border: 2px solid #E0E0E0;
            border-radius: 10px;
            font-size: 18px;
            font-weight: bold;
            text-align: right;
            transition: all 0.3s;
        }

        .paid-amount-field input.insufficient {
            border-color: #FFCDD2;
            background: #FFEBEE;
        }

        .paid-amount-field input.sufficient {
            border-color: #C8E6C9;
            background: #F1F8E9;
        }

        .paid-amount-field .money-icon {
            position: absolute;
            right: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: #FFB300;
            font-size: 20px;
        }

        .paid-amount-field .currency {
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: #757575;
            font-size: 14px;
        }

        .remaining-amount {
            margin-top: 5px;
            padding-right: 5px;
            font-size: 14px;
            display: flex;
            align-items: center;
            gap: 5px;
        }

        .remaining-amount .label {
            color: #757575;
        }

        .remaining-amount .value {
            font-size: 20px;
            font-weight: bold;
        }

        .remaining-amount .value.negative {
            color: #2936c6ff;
        }

        .remaining-amount .value.positive {
            color: #2E7D32;
        }

        .remaining-amount .change {
            color: #2E7D32;
            font-size: 14px;
            margin-right: 5px;
        }

        /* ===== قائمة العملاء ===== */
        .customers-dropdown {
            position: relative;
            height: 50px;
        }

        .customers-dropdown select {
            width: 100%;
            height: 50px;
            padding: 0 45px 0 15px;
            border: 1.5px solid #E0E0E0;
            border-radius: 10px;
            font-size: 15px;
            appearance: none;
            background: white;
            cursor: pointer;
        }

        .customers-dropdown .dropdown-icon {
            position: absolute;
            right: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: #2196F3;
            font-size: 20px;
            pointer-events: none;
        }

        .customer-info {
            margin-top: 8px;
            padding: 8px 12px;
            background: #F5F5F5;
            border-radius: 6px;
            font-size: 12px;
            display: flex;
            justify-content: space-between;
        }

        .customer-balance {
            color: #F57C00;
            font-weight: bold;
        }

        .customer-limit {
            color: #757575;
        }

        /* ===== أزرار البيع ===== */
        .sale-buttons {
            display: flex;
            gap: 4%;
            margin-top: 10px;
        }

        .sale-btn {
            width: 48%;
            height: 55px;
            border: none;
            border-radius: 10px;
            font-size: 16px;
            font-weight: bold;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            transition: all 0.3s;
        }

        .sale-btn.cash {
            background: linear-gradient(135deg, #4CAF50, #388E3C);
            color: white;
            box-shadow: 0 4px 6px rgba(76,175,80,0.2);
        }

        .sale-btn.cash:hover:not(:disabled) {
            transform: scale(1.02);
            box-shadow: 0 6px 10px rgba(76,175,80,0.3);
        }

        .sale-btn.credit {
            background: linear-gradient(135deg, #2196F3, #1976D2);
            color: white;
            box-shadow: 0 4px 6px rgba(33,150,243,0.2);
        }

        .sale-btn.credit:hover:not(:disabled) {
            transform: scale(1.02);
            box-shadow: 0 6px 10px rgba(33,150,243,0.3);
        }

        .sale-btn:disabled {
            background: #BDBDBD;
            cursor: not-allowed;
            box-shadow: none;
        }

        .sale-shortcut {
            font-size: 12px;
            opacity: 0.8;
            margin-right: 5px;
        }

        /* ===== أزرار التحكم ===== */
        .control-buttons {
            display: flex;
            gap: 4%;
            margin-top: 10px;
        }

        .control-btn {
            width: 48%;
            height: 50px;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 500;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            transition: all 0.3s;
        }

        .control-btn.return {
            background: #E3F2FD;
            border: 1px solid #2196F3;
            color: #0D47A1;
        }

        .control-btn.return:hover {
            background: #BBDEFB;
        }

        .control-btn.remove {
            background: #FFF3E0;
            border: 1px solid #F57C00;
            color: #E65100;
        }

        .control-btn.remove:hover {
            background: #FFE0B2;
        }

        .control-btn:disabled {
            opacity: 0.5;
            cursor: not-allowed;
        }

        /* ===== الجزء الأيسر - سلة المبيعات ===== */
        .pos-cart {
            flex: 1;
            background: white;
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.05);
            border: 1px solid #F0F0F0;
            display: flex;
            flex-direction: column;
            overflow: hidden;
        }

        /* ===== رأس السلة ===== */
        .cart-header {
            height: 70px;
            padding: 0 20px;
            border-bottom: 1px solid #F0F0F0;
            display: flex;
            align-items: center;
            justify-content: space-between;
        }

        .cart-title {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .cart-title .icon {
            font-size: 24px;
        }

        .cart-title h2 {
            font-size: 18px;
            color: #212121;
            font-weight: bold;
        }

        .cart-badge {
            background: #C62828;
            color: white;
            font-size: 12px;
            font-weight: bold;
            width: 20px;
            height: 20px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .cart-totals {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .total-box {
            padding: 8px 16px;
            border-radius: 20px;
            display: flex;
            align-items: center;
            gap: 8px;
            font-size: 14px;
        }

        .total-box.total {
            background: linear-gradient(135deg, #4527b0ff, #1f2aa2ff);
            color: white;
        }

        .total-box.remaining {
            background: linear-gradient(135deg, #6898c8ff, #083d87ff);
            color: white;
        }

        .total-box.change {
            background: linear-gradient(135deg, #4CAF50, #388E3C);
            color: white;
        }

        .total-box .value {
            font-size: 16px;
            font-weight: bold;
        }

        .clear-cart-btn {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: #FFEBEE;
            border: 1px solid #233d92ff;
            color: #2b469dff;
            font-size: 20px;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: all 0.3s;
        }

        .clear-cart-btn:hover {
            background: #FFCDD2;
        }

        /* ===== جدول السلة ===== */
        .cart-table-container {
            flex: 1;
            overflow-y: auto;
            padding: 15px;
        }

        .cart-table {
            width: 100%;
            border-collapse: collapse;
        }

        .cart-table th {
            position: sticky;
            top: 0;
            height: 45px;
            background: linear-gradient(135deg, #3a51b7ff, #354ab1ff);
            color: white;
            font-size: 13px;
            font-weight: 600;
            z-index: 10;
        }

        .cart-table th:first-child {
            border-radius: 0 8px 8px 0;
        }

        .cart-table th:last-child {
            border-radius: 8px 0 0 8px;
        }

        .cart-table td {
            height: 55px;
            border-bottom: 1px solid #F0F0F0;
            font-size: 13px;
        }

        .cart-table tbody tr {
            transition: background 0.3s;
        }

        .cart-table tbody tr:hover {
            background: #F5F5F5;
        }

        .cart-table tbody tr.selected {
            background: #E3F2FD;
            border-right: 3px solid #2196F3;
        }

        .product-cell {
            text-align: right;
            padding-right: 15px;
        }

        .product-name {
            font-weight: bold;
            color: #212121;
            margin-bottom: 2px;
        }

        .product-details {
            display: flex;
            gap: 15px;
            font-size: 11px;
            color: #757575;
        }

        .product-barcode {
            color: #9E9E9E;
        }

        .product-shelf {
            color: #9E9E9E;
        }

        .product-warning {
            color: #F57C00;
            margin-right: 5px;
        }

        .quantity-cell {
            text-align: center;
        }

        .quantity-number {
            font-size: 16px;
            font-weight: bold;
            position: relative;
            display: inline-block;
        }

        .quantity-number.multiple {
            background: #E3F2FD;
            padding: 2px 8px;
            border-radius: 12px;
        }

        .edit-quantity {
            margin-right: 5px;
            opacity: 0;
            transition: opacity 0.3s;
            cursor: pointer;
            color: #2196F3;
        }

        tr:hover .edit-quantity {
            opacity: 1;
        }

        .price-cell {
            text-align: center;
            color: #388E3C;
        }

        .subtotal-cell {
            text-align: center;
            font-weight: bold;
        }

        .actions-cell {
            text-align: center;
        }

        .delete-row {
            width: 28px;
            height: 28px;
            border: none;
            border-radius: 4px;
            background: transparent;
            color: #C62828;
            cursor: pointer;
            transition: all 0.3s;
        }

        .delete-row:hover {
            background: #FFEBEE;
        }

        /* Tooltip */
        [data-tooltip] {
            position: relative;
            cursor: help;
        }

        [data-tooltip]:before {
            content: attr(data-tooltip);
            position: absolute;
            bottom: 100%;
            left: 50%;
            transform: translateX(-50%);
            padding: 4px 8px;
            background: #333;
            color: white;
            font-size: 11px;
            border-radius: 4px;
            white-space: nowrap;
            display: none;
            z-index: 100;
        }

        [data-tooltip]:hover:before {
            display: block;
        }

        /* ===== نافذة الإرجاع ===== */
        .return-modal {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0,0,0,0.5);
            display: none;
            align-items: center;
            justify-content: center;
            z-index: 10000;
            animation: fadeIn 0.3s ease;
        }

        .return-modal.active {
            display: flex;
        }

        .return-modal-content {
            width: 900px;
            max-height: 80vh;
            background: white;
            border-radius: 12px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
            overflow: hidden;
            animation: slideUp 0.3s ease;
        }

        .return-modal-header {
            height: 70px;
            padding: 0 24px;
            border-bottom: 2px solid #F0F0F0;
            display: flex;
            align-items: center;
            justify-content: space-between;
        }

        .return-modal-header h3 {
            display: flex;
            align-items: center;
            gap: 8px;
            font-size: 20px;
            color: #212121;
        }

        .return-modal-close {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: #F5F5F5;
            border: none;
            font-size: 20px;
            cursor: pointer;
            transition: all 0.3s;
        }

        .return-modal-close:hover {
            background: #FFEBEE;
            color: #C62828;
        }

        .return-modal-body {
            padding: 24px;
            overflow-y: auto;
            max-height: calc(80vh - 70px);
        }

        /* ===== رسائل التحميل ===== */
        .loading-overlay {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0,0,0,0.5);
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 20000;
        }

        .loading-spinner {
            background: white;
            padding: 20px 40px;
            border-radius: 10px;
            text-align: center;
        }

        .spinner {
            width: 40px;
            height: 40px;
            border: 4px solid #F0F0F0;
            border-top: 4px solid #2196F3;
            border-radius: 50%;
            animation: spin 1s linear infinite;
            margin: 0 auto 10px;
        }

        /* ===== تنسيق حقل الكمية في الجدول ===== */
.cart-quantity-input {
    width: 70px;
    height: 30px;
    padding: 0 5px;
    border: 1px solid #ddd;
    border-radius: 4px;
    text-align: center;
    font-size: 14px;
    font-weight: bold;
}

.cart-quantity-input:focus {
    outline: none;
    border-color: #2196F3;
    box-shadow: 0 0 0 2px rgba(33,150,243,0.1);
}

.cart-quantity-input:hover {
    border-color: #999;
}



        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }

        @keyframes slideDown {
            from { transform: translateY(-100%); opacity: 0; }
            to { transform: translateY(0); opacity: 1; }
        }

        @keyframes slideUp {
            from { transform: translateY(50px); opacity: 0; }
            to { transform: translateY(0); opacity: 1; }
        }

        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }
        /* تحسين حقول إدخال الكمية */
.cart-quantity-input {
    width: 70px;
    height: 35px;
    padding: 5px;
    border: 2px solid #ddd;
    border-radius: 6px;
    text-align: center;
    font-size: 14px;
    font-weight: bold;
    background: white;
    transition: all 0.3s;
}

.cart-quantity-input:focus {
    outline: none;
    border-color: #2196F3;
    box-shadow: 0 0 0 3px rgba(33,150,243,0.2);
}

.cart-quantity-input:hover {
    border-color: #999;
}

/* حقل الكمية في اللوحة اليمنى */
.qty-input {
    width: 80px;
    height: 45px;
    border: 2px solid #e0e0e0;
    border-radius: 8px;
    text-align: center;
    font-size: 18px;
    font-weight: bold;
    background: white;
    transition: all 0.3s;
}

.qty-input:focus {
    outline: none;
    border-color: #4CAF50;
    box-shadow: 0 0 0 3px rgba(76,175,80,0.2);
}
    </style>
</head>
<body>

    <div class="pos-page">
        <!-- ===== الجزء الأيمن - لوحة التحكم ===== -->
        <div class="pos-control-panel">
            <!-- منطقة الرسائل -->
            <div class="alerts-area" id="alertsArea"></div>

            <!-- حقل البحث عن المنتج -->
            <div class="search-field">
                <span class="search-icon">🔍</span>
                <input type="text" id="productSearch" placeholder="🔍 اكتب اسم المنتج أو الباركود..." autocomplete="off">
                <span class="clear-icon" onclick="clearSearch()">✖</span>
                <div class="search-results" id="searchResults"></div>
            </div>

            <!-- حقل الباركود -->
            <div class="barcode-field">
                <span class="barcode-icon">📟</span>
                <input type="text" id="barcodeInput" placeholder="📟 امسح الباركود أو أدخل الرقم..." autocomplete="off">
                <span class="status-indicator" id="barcodeStatus"></span>
            </div>

            <!-- التحكم في الكمية -->
       <div class="quantity-control">
    <input type="number" class="qty-input" id="quantityInput" value="1" min="1" step="1" onkeyup="validateQuantityInput(this)">
    <span class="qty-max" id="maxQuantity"></span>
</div>
            <!-- حقل المبلغ المدفوع -->
            <div class="paid-amount-field">
                <span class="money-icon">💰</span>
                <input type="number" id="paidAmount" value="0" step="0.01" min="0" oninput="calculateRemaining()">
                <span class="currency">ريال</span>
            </div>
            <div class="remaining-amount" id="remainingDisplay">
                <span class="label">المتبقي:</span>
                <span class="value" id="remainingValue">0.00</span>
                <span class="change" id="changeValue"></span>
            </div>

            <!-- قائمة العملاء -->
            <div class="customers-dropdown">
                <span class="dropdown-icon">👥</span>
                <select id="customerSelect" onchange="updateCustomerInfo()">
                    <option value="">👤 اختر العميل (للبيع الآجل)</option>
                    <?php foreach ($customers as $customer): ?>
                        <option value="<?= $customer['id'] ?>" 
                                data-balance="<?= $customer['current_balance'] ?>"
                                data-limit="<?= $customer['credit_limit'] ?>">
                            <?= htmlspecialchars($customer['name']) ?> - الرصيد: <?= number_format($customer['current_balance'], 2) ?> ريال
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="customer-info" id="customerInfo" style="display: none;">
                <span class="customer-balance" id="customerBalance"></span>
                <span class="customer-limit" id="customerLimit"></span>
            </div>

            <!-- أزرار البيع -->
            <div class="sale-buttons">
                <button class="sale-btn cash" onclick="processSale('cash')" id="cashSaleBtn">
                    <span>💰</span>
                    بيع نقدي
                    <span class="sale-shortcut">F2</span>
                </button>
                <button class="sale-btn credit" onclick="processSale('credit')" id="creditSaleBtn" disabled>
                    <span>📅</span>
                    بيع آجل
                    <span class="sale-shortcut">F3</span>
                </button>
            </div>

            <!-- أزرار التحكم -->
            <div class="control-buttons">
                <button class="control-btn return" onclick="openReturnWindow()">
                    <span>🔄</span>
                    إرجاع منتج
                    <span class="sale-shortcut">Ctrl+R</span>
                </button>
                <button class="control-btn remove" onclick="removeSelectedItem()" id="removeItemBtn" disabled>
                    <span>🗑️</span>
                    إزالة منتج
                    <span class="sale-shortcut">Del</span>
                </button>
            </div>
        </div>

        <!-- ===== الجزء الأيسر - سلة المبيعات ===== -->
        <div class="pos-cart">
            <!-- رأس السلة -->
            <div class="cart-header">
                <div class="cart-title">
                    <span class="icon">🛒</span>
                    <h2>سلة المبيعات</h2>
                    <span class="cart-badge" id="cartCount">0</span>
                </div>
                <div class="cart-totals">
                    <div class="total-box total">
                        <span>💰</span>
                        <span class="value" id="cartTotal">0.00</span>
                    </div>
                    <div class="total-box remaining" id="remainingBox">
                        <span>📊</span>
                        <span class="value" id="cartRemaining">0.00</span>
                    </div>
                    <div class="total-box change" id="changeBox" style="display: none;">
                        <span>🎁</span>
                        <span class="value" id="cartChange">0.00</span>
                    </div>
                    <button class="clear-cart-btn" onclick="confirmClearCart()" title="تفريغ السلة">✖</button>
                </div>
            </div>

            <!-- جدول المنتجات -->
            <div class="cart-table-container">
                <table class="cart-table">
                    <thead>
                        <tr>
                            <th style="width: 35%;">المنتج</th>
                            <th style="width: 15%;">الكمية</th>
                            <th style="width: 15%;">السعر</th>
                            <th style="width: 20%;">الإجمالي</th>
                            <th style="width: 15%;">عمليات</th>
                        </tr>
                    </thead>
                    <tbody id="cartItems">
                        <!-- سيتم إضافة العناصر هنا عبر JavaScript -->
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- نافذة الإرجاع المنبثقة -->
    <div class="return-modal" id="returnModal">
        <div class="return-modal-content">
            <div class="return-modal-header">
                <h3>
                    <span style="color: #2196F3;">🔄</span>
                    إرجاع منتج من الفاتورة
                </h3>
                <button class="return-modal-close" onclick="closeReturnWindow()">✖</button>
            </div>
            <div class="return-modal-body" id="returnModalBody">
                <!-- محتوى النافذة سيتم إضافته عبر JavaScript -->
            </div>
        </div>
    </div>

    <script>



// ============================================
// المتغيرات العامة
// ============================================
let cart = [];
let selectedRowId = null;
let searchTimeout = null;
let currentProduct = null;
let maxQuantity = 9999;


// ============================================
// حفظ واسترجاع السلة من التخزين المحلي
// ============================================

// حفظ السلة في sessionStorage
function saveCartToStorage() {
    sessionStorage.setItem('pos_cart', JSON.stringify(cart));
    sessionStorage.setItem('pos_selectedRow', selectedRowId);
}

// استرجاع السلة من sessionStorage
function loadCartFromStorage() {
    const savedCart = sessionStorage.getItem('pos_cart');
    const savedSelectedRow = sessionStorage.getItem('pos_selectedRow');
    
    if (savedCart) {
        cart = JSON.parse(savedCart);
        selectedRowId = savedSelectedRow ? parseInt(savedSelectedRow) : null;
        updateCart();
        
        // إعادة تفعيل زر الحذف إذا كان هناك منتج محدد
        if (selectedRowId) {
            document.getElementById('removeItemBtn').disabled = false;
        }
        
        console.log('✅ تم استرجاع السلة من التخزين');
    }
}

// تعديل دالة updateCart لحفظ السلة بعد كل تحديث
const originalUpdateCart = updateCart;
updateCart = function() {
    originalUpdateCart();
    saveCartToStorage();
};

// تعديل دالة addToCart لحفظ السلة
const originalAddToCart = addToCart;
addToCart = function(product) {
    originalAddToCart(product);
    saveCartToStorage();
};

// تعديل دالة removeFromCart لحفظ السلة
const originalRemoveFromCart = removeFromCart;
removeFromCart = function(id) {
    originalRemoveFromCart(id);
    saveCartToStorage();
};

// تعديل دالة clearCart لحفظ السلة
const originalClearCart = clearCart;
clearCart = function() {
    originalClearCart();
    sessionStorage.removeItem('pos_cart');
    sessionStorage.removeItem('pos_selectedRow');
};

// تعديل دالة updateItemQuantity لحفظ السلة
const originalUpdateItemQuantity = updateItemQuantity;
updateItemQuantity = function(input) {
    originalUpdateItemQuantity(input);
    saveCartToStorage();
};

// استرجاع السلة عند تحميل الصفحة
document.addEventListener('DOMContentLoaded', function() {
    loadCartFromStorage();
    
    // باقي الكود الموجود...
    document.getElementById('productSearch').focus();
    document.getElementById('paidAmount').addEventListener('input', calculateRemaining);
    document.getElementById('customerSelect').addEventListener('change', updateCustomerInfo);
    
    document.querySelectorAll('input').forEach(input => {
        input.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                e.preventDefault();
            }
        });
    });
});
// ===== تعطيل جميع رسائل Console في الإنتاج =====
(function disableConsole() {
    // التحقق إذا كان الموقع ليس localhost
    if (window.location.hostname !== 'localhost' && 
        !window.location.hostname.includes('127.0.0.1') && 
        !window.location.hostname.includes('::1')) {
        
        // تعطيل جميع وظائف console
        const noop = function() {};
        const methods = ['log', 'info', 'warn', 'error', 'debug', 'trace', 'table', 'group', 'groupCollapsed', 'groupEnd'];
        
        methods.forEach(method => {
            console[method] = noop;
        });
        
        // تعطيل عرض الأخطاء في الصفحة
        window.onerror = function() { return true; };
        window.onunhandledrejection = function() { return true; };
        
        console.log('✅ تم تعطيل جميع رسائل Console'); // هذه لن تظهر لأن console.log معطل
    }
})();
// ===== التحقق من صحة الكمية عند الكتابة يدوياً =====
document.getElementById('quantityInput').addEventListener('input', function(e) {
    let val = parseInt(e.target.value);
    if (isNaN(val) || val < 1) {
        e.target.value = 1;
    } else if (val > maxQuantity) {
        e.target.value = maxQuantity;
        showAlert('warning', `الحد الأقصى ${maxQuantity} وحدة`);
    }
});
// ===== تفعيل حقل الكمية =====
// ============================================
// التهيئة عند تحميل الصفحة
// ============================================
document.addEventListener('DOMContentLoaded', function() {
    // ===== تفعيل الكتابة في حقل الكمية باللوحة اليمنى =====
    const qtyInput = document.getElementById('quantityInput');
    if (qtyInput) {
        // إزالة أي خاصية readonly
        qtyInput.removeAttribute('readonly');
        
        // التأكد من أن الحقل قابل للكتابة
        qtyInput.readOnly = false;
        
        // تمكين الكتابة المباشرة
        qtyInput.addEventListener('keydown', function(e) {
            // السماح بكل المفاتيح
            e.stopPropagation(); // منع تداخل الأحداث
        });
        
        // التحقق من صحة الإدخال بعد الكتابة
        qtyInput.addEventListener('input', function(e) {
            let val = parseInt(e.target.value);
            const maxVal = parseInt(document.getElementById('maxQuantity').textContent.replace('/', '').trim()) || 9999;
            
            if (isNaN(val) || val < 1) {
                e.target.value = 1;
            } else if (val > maxVal) {
                e.target.value = maxVal;
                showAlert('warning', `الحد الأقصى ${maxVal} وحدة`);
            }
        });
    }
    
    // تركيز على حقل الباركود
    setTimeout(() => {
        document.getElementById('barcodeInput').focus();
    }, 500);
    
    // إضافة مستمعين للأحداث
    document.getElementById('paidAmount').addEventListener('input', calculateRemaining);
    document.getElementById('customerSelect').addEventListener('change', updateCustomerInfo);
    
    // منع إرسال النموذج عند الضغط على Enter فقط (وليس منع الكتابة)
    document.querySelectorAll('input').forEach(input => {
        input.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                e.preventDefault();
            }
        });
    });
});
// ===== التحقق من صحة الكمية في الواجهة اليمنى =====
function validateQuantityInput(input) {
    let val = parseInt(input.value);
    
    // إذا كان المدخل غير رقمي أو فارغ
    if (isNaN(val) || input.value === '') {
        input.value = 1;
        return;
    }
    
    // التحقق من الحد الأدنى
    if (val < 1) {
        input.value = 1;
        showAlert('warning', 'الحد الأدنى 1 وحدة');
    }
    
    // التحقق من الحد الأقصى
    if (val > maxQuantity) {
        input.value = maxQuantity;
        showAlert('warning', `الحد الأقصى ${maxQuantity} وحدة`);
    }
}

// ===== تفعيل أزرار + و - مع الحفاظ على خاصية الكتابة =====
function incrementQuantity() {
    const input = document.getElementById('quantityInput');
    let val = parseInt(input.value) || 1;
    if (val < maxQuantity) {
        input.value = val + 1;
    }
}

function decrementQuantity() {
    const input = document.getElementById('quantityInput');
    let val = parseInt(input.value) || 1;
    if (val > 1) {
        input.value = val - 1;
    }
}

// ============================================
// المسارات الأساسية
// ============================================
const BASE_URL = '<?= BASE_URL ?>';
const API_URL = BASE_URL + '/index.php?url=';

// ============================================
// دوال المساعدة العامة
// ============================================
// ===== عرض الرسائل =====
function showAlert(type, message, duration = 3000) {
    const area = document.getElementById('alertsArea');
    if (!area) return;
    
    const alertDiv = document.createElement('div');
    alertDiv.className = `alert-message alert-${type}`;
    alertDiv.style.cssText = `
        height: 60px;
        width: 100%;
        border-radius: 8px;
        display: flex;
        align-items: center;
        padding: 0 15px;
        gap: 12px;
        animation: slideDown 0.3s ease;
        box-shadow: 0 2px 8px rgba(0,0,0,0.05);
        background: ${type === 'success' ? '#E8F5E9' : '#FFEBEE'};
        border-right: 4px solid ${type === 'success' ? '#2E7D32' : '#C62828'};
        margin-bottom: 10px;
    `;
    
    alertDiv.innerHTML = `
        <div class="alert-icon" style="width: 24px; height: 24px; border-radius: 50%; background: ${type === 'success' ? '#2E7D32' : '#C62828'}; color: white; display: flex; align-items: center; justify-content: center; font-size: 14px;">
            ${type === 'success' ? '✅' : '❌'}
        </div>
        <div class="alert-content" style="flex: 1; font-size: 14px; font-weight: 500; color: ${type === 'success' ? '#1B5E20' : '#B71C1C'};">${message}</div>
        <div class="alert-close" style="cursor: pointer; font-size: 16px; color: #666;" onclick="this.parentElement.remove()">✖</div>
    `;
    
    area.appendChild(alertDiv);
    
    setTimeout(() => {
        if (alertDiv.parentElement) alertDiv.remove();
    }, duration);
}
// ===== إظهار/إخفاء مؤشر التحميل =====
// ===== إظهار/إخفاء مؤشر التحميل =====
function showLoading(show, message = 'جاري التحميل...') {
    let overlay = document.getElementById('loadingOverlay');
    
    if (show) {
        if (!overlay) {
            overlay = document.createElement('div');
            overlay.id = 'loadingOverlay';
            overlay.style.cssText = `
                position: fixed;
                top: 0;
                left: 0;
                right: 0;
                bottom: 0;
                background: rgba(0,0,0,0.5);
                display: flex;
                align-items: center;
                justify-content: center;
                z-index: 20000;
            `;
            
            const spinner = document.createElement('div');
            spinner.style.cssText = `
                background: white;
                padding: 20px 40px;
                border-radius: 10px;
                text-align: center;
                box-shadow: 0 4px 12px rgba(0,0,0,0.2);
            `;
            
            spinner.innerHTML = `
                <div class="spinner" style="width: 40px; height: 40px; border: 4px solid #f3f3f3; border-top: 4px solid #2196F3; border-radius: 50%; animation: spin 1s linear infinite; margin: 0 auto 10px;"></div>
                <div id="loadingMessage">${message}</div>
            `;
            
            overlay.appendChild(spinner);
            document.body.appendChild(overlay);
        } else {
            const msgEl = document.getElementById('loadingMessage');
            if (msgEl) msgEl.textContent = message;
        }
    } else if (overlay && overlay.parentNode) {
        overlay.remove();
    }
}


// ============================================
// دوال البحث عن المنتجات
// ============================================
document.getElementById('productSearch').addEventListener('input', function(e) {
    clearTimeout(searchTimeout);
    const query = e.target.value.trim();
    
    if (query.length >= 1) {
        searchTimeout = setTimeout(() => searchProducts(query), 300);
    } else {
        document.getElementById('searchResults').classList.remove('active');
    }
});
function searchProducts(query) {
    showLoading(true);
    
    fetch(`pos/search-products?q=${encodeURIComponent(query)}`)
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            return response.json();
        })
        .then(products => {
            showLoading(false);
            // تأكد من أن products مصفوفة
            if (Array.isArray(products)) {
                displaySearchResults(products);
            } else {
                console.error('❌ البيانات المرتجعة ليست مصفوفة:', products);
                displaySearchResults([]);
            }
        })
        .catch(error => {
            showLoading(false);
            console.error('❌ Search error:', error);
            displaySearchResults([]);
        });
}

function displaySearchResults(products) {
    const resultsDiv = document.getElementById('searchResults');
    resultsDiv.innerHTML = '';
    
    // تأكد من أن products مصفوفة
    
    
    products.forEach(product => {
        const div = document.createElement('div');
        div.className = 'search-result-item';
        
        const price = parseFloat(product.price || 0).toFixed(2);
        const quantity = parseInt(product.quantity || 0);
        
        // تحديد لون الكمية
        const stockClass = quantity > 0 ? '' : 'out-of-stock';
        const stockText = quantity > 0 ? `المتاح: ${quantity}` : 'غير متوفر';
        
        div.innerHTML = `
            <div class="result-row">
                <strong>${product.name || 'غير معروف'}</strong>
                <span class="result-price">${price} ريال</span>
            </div>
            <div class="result-details">
                <small>${product.barcode || '---'}</small>
                <small class="${stockClass}">${stockText}</small>
            </div>
        `;
        
        if (quantity > 0) {
            div.onclick = () => {
                addToCart(product);
                hideSearchResults();
            };
            div.style.cursor = 'pointer';
        } else {
            div.style.opacity = '0.6';
            div.style.cursor = 'not-allowed';
            div.title = 'هذا المنتج غير متوفر حالياً';
        }
        
        resultsDiv.appendChild(div);
    });
    
    resultsDiv.classList.add('active');
}
function hideSearchResults() {
    document.getElementById('searchResults').classList.remove('active');
    document.getElementById('productSearch').value = '';
}

function clearSearch() {
    document.getElementById('productSearch').value = '';
    document.getElementById('searchResults').classList.remove('active');
}

// ============================================
// دوال البحث بالباركود
// ============================================
// ============================================
// دوال البحث بالباركود - نسخة محسنة تعمل فوراً مع قارئ الباركود
// ============================================
let barcodeTimeout = null;

document.getElementById('barcodeInput').addEventListener('input', function(e) {
    const barcode = e.target.value.trim();
    
    // مسح التايمر السابق
    clearTimeout(barcodeTimeout);
    
    // تجاهل القيم القصيرة جداً (تجنب البحث بأرقام صغيرة)
    if (barcode.length >= 3) {
        // تأخير بسيط لمنع البحث المتكرر أثناء القراءة
        barcodeTimeout = setTimeout(() => {
            searchByBarcode(barcode);
        }, 150); // 150 ملي ثانية تأخير
    }
});

// إبقاء مستمع Enter كخيار احتياطي (اختياري)
document.getElementById('barcodeInput').addEventListener('keypress', function(e) {
    if (e.key === 'Enter') {
        e.preventDefault(); // منع السلوك الافتراضي
        const barcode = e.target.value.trim();
        if (barcode) {
            clearTimeout(barcodeTimeout);
            searchByBarcode(barcode);
        }
    }
});

function searchByBarcode(barcode) {
    const statusIndicator = document.getElementById('barcodeStatus');
    if (statusIndicator) {
        statusIndicator.className = 'status-indicator';
    }
    
    showLoading(true);
    
    fetch(`pos/search-by-barcode?barcode=${encodeURIComponent(barcode)}`)
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            return response.json();
        })
        .then(data => {
            showLoading(false);
            
            if (data.success && data.product) {
                if (statusIndicator) {
                    statusIndicator.classList.add('success');
                }
                addToCart(data.product);
                document.getElementById('barcodeInput').value = '';
                
                setTimeout(() => {
                    if (statusIndicator) {
                        statusIndicator.className = 'status-indicator';
                    }
                }, 1000);
            } else {
                if (statusIndicator) {
                    statusIndicator.classList.add('error');
                }
                showAlert('error', data.message || '❌ المنتج غير موجود');
                
                setTimeout(() => {
                    if (statusIndicator) {
                        statusIndicator.className = 'status-indicator';
                    }
                }, 1000);
            }
        })
        .catch(error => {
            showLoading(false);
            console.error('❌ Barcode error:', error);
            showAlert('error', 'حدث خطأ في الاتصال بالخادم');
            
            if (statusIndicator) {
                statusIndicator.classList.add('error');
                setTimeout(() => {
                    statusIndicator.className = 'status-indicator';
                }, 1000);
            }
        });
}

// ============================================
// دوال المنتج والكمية
// ============================================
// ===== اختيار منتج من نتائج البحث =====
function selectProduct(product) {
    console.log('🔍 اختيار منتج:', product);
    
    currentProduct = product;
    maxQuantity = product.stock || product.quantity || 0;
    
    // تحديث عرض الحد الأقصى
    document.getElementById('maxQuantity').textContent = `/ ${maxQuantity}`;
    
    // إعادة تعيين الكمية
    document.getElementById('quantityInput').value = 1;
    document.getElementById('quantityInput').max = maxQuantity;
    
    document.getElementById('searchResults').classList.remove('active');
    document.getElementById('productSearch').value = product.name;
}
// ===== اختيار منتج من نتائج البحث =====
// ===== اختيار منتج من نتائج البحث =====

// ===== التحكم في الكمية =====
function incrementQuantity() {
    const input = document.getElementById('quantityInput');
    if (input) {
        let val = parseInt(input.value) || 1;
        if (val < maxQuantity) {
            input.value = val + 1;
        }
    }
}

function decrementQuantity() {
    const input = document.getElementById('quantityInput');
    let qty = parseInt(input.value) || 1;
    if (qty > 1) {
        qty--;
        input.value = qty;
    }
}

// ===== تحديث الحد الأقصى عند تغيير المنتج =====
function updateMaxQuantity(max) {
    maxQuantity = max;
    document.getElementById('maxQuantity').textContent = `/ ${max}`;
    const input = document.getElementById('quantityInput');
    if (parseInt(input.value) > max) {
        input.value = max;
    }
}

function decrementQuantity() {
    let qty = parseInt(document.getElementById('quantityInput').value);
    if (qty > 1) {
        qty--;
        document.getElementById('quantityInput').value = qty;
        document.getElementById('incrementBtn').disabled = false;
        document.getElementById('decrementBtn').disabled = qty <= 1;
    }
}

// ============================================
// دوال إضافة المنتج للسلة
// ============================================

// ===== إضافة المنتج للسلة =====
// ===== إضافة المنتج للسلة مع التحقق =====
function addToCart(product) {
    // الحصول على الكمية من الحقل
    const quantity = parseInt(document.getElementById('quantityInput').value) || 1;
    
    console.log(`🔍 محاولة إضافة: ${product.name}, الكمية: ${quantity}, المتوفر: ${product.stock}`);
    
    // التحقق من أن الكمية أكبر من 0
    if (quantity <= 0) {
        showAlert('error', '❌ الكمية يجب أن تكون أكبر من 0');
        document.getElementById('quantityInput').value = 1;
        return;
    }
    
    // التحقق من أن المنتج متوفر
    if (product.stock <= 0) {
        showAlert('error', `❌ المنتج "${product.name}" غير متوفر في الرف`);
        return;
    }
    
    // التحقق من الكمية قبل الإضافة
    if (quantity > product.stock) {
        showAlert('الكميه غير كافيه', `❌ الكمية المطلوبة (${quantity}) أكبر من المتوفر (${product.stock})`);
        return;
    }
    
    // البحث إذا كان المنتج موجوداً بالفعل في السلة
    const existingItem = cart.find(item => item.product_id === product.id);
    
    if (existingItem) {
        // إذا كان المنتج موجوداً، احسب الكمية الجديدة
        const newQuantity = existingItem.quantity + quantity;
        
        console.log(`🔍 المنتج موجود مسبقاً، الكمية الحالية: ${existingItem.quantity}, الجديدة: ${newQuantity}`);
        
        // التحقق من عدم تجاوز المخزون
        if (newQuantity > product.stock) {
            showAlert('error', `❌ إجمالي الكمية (${newQuantity}) أكبر من المتوفر (${product.stock})`);
            return;
        }
        
        existingItem.quantity = newQuantity;
        showAlert('success', `✅ تم تحديث الكمية إلى ${newQuantity}`);
    } else {
        // إذا كان المنتج جديداً، أضفه كعنصر جديد
        const cartItem = {
            id: Date.now(),
            product_id: product.id,
            name: product.name,
            barcode: product.barcode,
            price: parseFloat(product.price),
            quantity: quantity,
            shelf_id: product.shelf_id,
            shelf_code: product.shelf_code,
            main_inventory_id: product.main_inventory_id,
            max_stock: product.stock
        };
        
        cart.push(cartItem);
        showAlert('success', '✅ تمت إضافة المنتج إلى السلة');
    }
    
    updateCart();
    
    // إعادة تعيين الكمية إلى 1
    document.getElementById('quantityInput').value = 1;
}
// ============================================
// دوال السلة
// ============================================
// ===== تحديث عرض السلة مع حقل تعديل الكمية =====
// ===== تحديث عرض السلة مع حقل تعديل الكمية =====
function updateCart() {
    const tbody = document.getElementById('cartItems');
    tbody.innerHTML = '';
    
    let total = 0;
    
    cart.forEach((item, index) => {
        const subtotal = item.quantity * item.price;
        total += subtotal;
        
        const row = document.createElement('tr');
        row.className = selectedRowId === item.id ? 'selected' : '';
        row.onclick = () => selectRow(item.id);
        
        row.innerHTML = `
            <td class="product-cell">
                <div class="product-name">${item.name}</div>
                <div class="product-details">
                    <span class="product-barcode">${item.barcode}</span>
                    <span class="product-shelf">${item.shelf_code || ''}</span>
                </div>
            </td>
            <td class="quantity-cell">
                <input type="number" class="cart-quantity-input" 
                       value="${item.quantity}" 
                       min="1" 
                       max="${item.max_stock}"
                       data-id="${item.id}"
                       onchange="updateItemQuantity(this)"
                       onkeyup="if(event.key==='Enter') this.blur()"
                       onkeydown="event.stopPropagation()">  <!-- إضافة هذا السطر -->
            </td>
            <td class="price-cell">${item.price.toFixed(2)}</td>
            <td class="subtotal-cell">${subtotal.toFixed(2)}</td>
            <td class="actions-cell">
                <button class="delete-row" onclick="removeFromCart(${item.id})" title="حذف">🗑️</button>
            </td>
        `;
        
        tbody.appendChild(row);
    });
    
    document.getElementById('cartCount').textContent = cart.length;
    document.getElementById('cartTotal').textContent = total.toFixed(2);
    
    calculateRemaining();
}
// ===== تحديث كمية المنتج من حقل الإدخال =====

// ===== تحديث كمية المنتج من الجدول مع التحقق =====
// ===== تحديث كمية المنتج من الجدول مع التحقق =====
function updateItemQuantity(input) {
    const itemId = parseInt(input.dataset.id);
    const newQuantity = parseInt(input.value);
    const maxQty = parseInt(input.max);
    
    console.log(`🔍 تحديث كمية المنتج: ${itemId}, القيمة الجديدة: ${newQuantity}, الحد الأقصى: ${maxQty}`);
    
    // التحقق من صحة الرقم
    if (isNaN(newQuantity) || newQuantity < 1) {
        showAlert('error', '❌ الرجاء إدخال رقم صحيح أكبر من 0');
        input.value = 1;
        return;
    }
    
    // التحقق من الكمية
    if (newQuantity > maxQty) {
        showAlert('error', `❌ الكمية المطلوبة (${newQuantity}) أكبر من المتوفر (${maxQty})`);
        input.value = maxQty;
        return;
    }
    
    const item = cart.find(i => i.id === itemId);
    if (item) {
        item.quantity = newQuantity;
        updateCart();
        showAlert('success', '✅ تم تحديث الكمية');
    }
}
function selectRow(id) {
    selectedRowId = id;
    document.getElementById('removeItemBtn').disabled = false;
    updateCart();
}

function removeFromCart(id) {
    cart = cart.filter(item => item.id !== id);
    if (selectedRowId === id) {
        selectedRowId = null;
        document.getElementById('removeItemBtn').disabled = true;
    }
    updateCart();
    showAlert('success', '✅ تم حذف المنتج من السلة');
}

function removeSelectedItem() {
    if (selectedRowId) {
        removeFromCart(selectedRowId);
    }
}

function editQuantity(id) {
    const item = cart.find(i => i.id === id);
    if (!item) return;
    
    const newQty = prompt('أدخل الكمية الجديدة:', item.quantity);
    if (newQty && !isNaN(newQty) && newQty > 0 && newQty <= item.max_stock) {
        item.quantity = parseInt(newQty);
        updateCart();
        showAlert('success', '✅ تم تحديث الكمية');
    } else {
        showAlert('error', '❌ الكمية غير صالحة');
    }
}

// ===== تفريغ السلة =====
function clearCart() {
    cart = [];
    selectedRowId = null;
    document.getElementById('removeItemBtn').disabled = true;
    updateCart();
}


function confirmClearCart() {
    if (cart.length > 0 && confirm('هل أنت متأكد من تفريغ السلة بالكامل؟')) {
        clearCart();
        showAlert('success', '✅ تم تفريغ السلة');
    }
}

// ============================================
// دوال المبالغ والمدفوعات
// ============================================
// ===== حساب المتبقي =====
function calculateRemaining() {
    const total = parseFloat(document.getElementById('cartTotal').textContent) || 0;
    const paid = parseFloat(document.getElementById('paidAmount').value) || 0;
    const remaining = total - paid;
    
    const remainingValue = document.getElementById('remainingValue');
    const changeValue = document.getElementById('changeValue');
    const remainingBox = document.getElementById('remainingBox');
    const changeBox = document.getElementById('changeBox');
    const paidInput = document.getElementById('paidAmount');
    
    if (paid >= total) {
        const change = paid - total;
        paidInput.classList.remove('insufficient');
        paidInput.classList.add('sufficient');
        remainingValue.className = 'value positive';
        remainingValue.textContent = '0.00';
        changeValue.textContent = `الباقي للعميل: ${change.toFixed(2)} ريال 🎁`;
        changeBox.style.display = 'flex';
        remainingBox.style.display = 'none';
        
        // البيع النقدي متاح
        document.getElementById('cashSaleBtn').disabled = false;
    } else {
        paidInput.classList.remove('sufficient');
        paidInput.classList.add('insufficient');
        remainingValue.className = 'value negative';
        remainingValue.textContent = remaining.toFixed(2);
        changeValue.textContent = '';
        changeBox.style.display = 'none';
        remainingBox.style.display = 'flex';
        
        // البيع النقدي غير متاح (المبلغ غير كافٍ)
        document.getElementById('cashSaleBtn').disabled = true;
    }
    
    document.getElementById('cartRemaining').textContent = remaining.toFixed(2);
    
    // التحقق من البيع الآجل (لا نمرر paid هنا لأن البيع الآجل لا يشترط الدفع)
    checkCreditSale();
}

// ============================================
// دوال العملاء
// ============================================
function updateCustomerInfo() {
    const select = document.getElementById('customerSelect');
    const info = document.getElementById('customerInfo');
    const selected = select.options[select.selectedIndex];
    
    if (select.value) {
        const balance = parseFloat(selected.dataset.balance);
        const limit = parseFloat(selected.dataset.limit);
        
        document.getElementById('customerBalance').textContent = `الرصيد الحالي: ${balance.toFixed(2)} ريال`;
        document.getElementById('customerLimit').textContent = `الحد الائتماني: ${limit.toFixed(2)} ريال`;
        info.style.display = 'flex';
    } else {
        info.style.display = 'none';
    }
    
    checkCreditSale();
}

// ===== التحقق من البيع الآجل =====
function checkCreditSale() {
    const customerId = document.getElementById('customerSelect').value;
    const total = parseFloat(document.getElementById('cartTotal').textContent) || 0;
    const paid = parseFloat(document.getElementById('paidAmount').value) || 0;
    const remaining = total - paid;
    
    if (customerId && cart.length > 0) {
        const select = document.getElementById('customerSelect');
        const selected = select.options[select.selectedIndex];
        const balance = parseFloat(selected.dataset.balance) || 0;
        const limit = parseFloat(selected.dataset.limit) || 0;
        
        // التحقق من وجود عميل
        if (!customerId) {
            document.getElementById('creditSaleBtn').disabled = true;
            return;
        }
        
        // السماح بالبيع الآجل بدون دفع (حتى لو كان المدفوع = 0)
        // فقط نتحقق من عدم تجاوز الحد الائتماني
        if (balance + total <= limit) {
            document.getElementById('creditSaleBtn').disabled = false;
        } else {
            document.getElementById('creditSaleBtn').disabled = true;
            showAlert('error', `🚫 تجاوزت الحد الائتماني للعميل (الحد: ${limit} ريال، الرصيد الحالي: ${balance} ريال، الإجمالي: ${total} ريال)`, 4000);
        }
    } else {
        document.getElementById('creditSaleBtn').disabled = true;
    }
}

// ============================================
// دوال معالجة البيع
// ============================================

// ===== معالجة البيع =====

// ===== معالجة البيع مع التحقق من الكميات =====
function processSale(type) {
    // التحقق من السلة فارغة
    if (cart.length === 0) {
        showAlert('error', '❌ السلة فارغة');
        return;
    }
    
    showLoading(true, 'جاري التحقق من الكميات...');
    
    // التحقق من أن جميع الكميات أكبر من 0
    for (let i = 0; i < cart.length; i++) {
        let item = cart[i];
        
        if (item.quantity <= 0) {
            showLoading(false);
            showAlert('error', `❌ المنتج "${item.name}" لديه كمية غير صالحة (${item.quantity})`);
            return;
        }
        
        if (item.quantity > item.max_stock) {
            showLoading(false);
            showAlert('error', `❌ المنتج "${item.name}" الكمية المطلوبة (${item.quantity}) أكبر من المتوفر (${item.max_stock})`);
            return;
        }
    }
    
    // تجهيز البيانات للتحقق
    const checkData = cart.map(item => ({
        shelf_id: item.shelf_id,
        quantity: item.quantity,
        name: item.name
    }));
    
    // ===== التحقق من الكميات في قاعدة البيانات قبل البيع =====
    fetch(BASE_URL + '/pos/check-quantities', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(checkData)
    })
    .then(response => {
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        return response.text().then(text => {
            try {
                return JSON.parse(text);
            } catch (e) {
                console.error('❌ استجابة غير JSON:', text);
                throw new Error('الخادم أرجع استجابة غير صالحة');
            }
        });
    })
    .then(checkResult => {
        if (!checkResult.success) {
            showLoading(false);
            
            // عرض المنتجات التي بها مشكلة
            let errorMessage = '❌ لا يمكن إتمام البيع:\n';
            if (checkResult.problems && checkResult.problems.length > 0) {
                checkResult.problems.forEach(p => {
                    errorMessage += `\n- ${p.name}: المطلوب ${p.requested}، المتوفر ${p.available}`;
                });
            } else {
                errorMessage += '\n- بعض المنتجات غير متوفرة';
            }
            
            showAlert('error', errorMessage);
            return;
        }
        
        console.log('✅ تم التحقق من الكميات بنجاح');
        
        // متابعة عملية البيع بعد التحقق
        const total = parseFloat(document.getElementById('cartTotal').textContent);
        const paid = parseFloat(document.getElementById('paidAmount').value) || 0;
        
        if (type === 'cash' && paid < total) {
            showLoading(false);
            showAlert('error', '❌ المبلغ المدفوع أقل من الإجمالي');
            return;
        }
        
        // تجهيز بيانات البيع
        const saleData = {
            items: cart.map(item => ({
                product_id: item.product_id,
                shelf_id: item.shelf_id,
                main_inventory_id: item.main_inventory_id,
                batch_number: item.batch_number,
                expiry_date: item.expiry_date,
                quantity: item.quantity,
                price: item.price,
                cost: item.cost || 0
            })),
            total_amount: total,
            paid_amount: paid,
            sale_type: type,
            customer_id: document.getElementById('customerSelect').value || null,
            discount: 0
        };
        
        // إرسال عملية البيع
        return fetch(BASE_URL + '/pos/process-sale', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(saleData)
        });
    })
    .then(response => {
        if (!response) return; // إذا كان هناك خطأ في التحقق
        
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        return response.text().then(text => {
            try {
                return JSON.parse(text);
            } catch (e) {
                console.error('❌ استجابة غير JSON:', text);
                throw new Error('الخادم أرجع استجابة غير صالحة');
            }
        });
    })
    .then(data => {
        showLoading(false);
        
        if (data && data.success) {
            showAlert('success', '✅ تمت عملية البيع بنجاح');
            
            if (data.print && data.print.success && data.auto_open) {
                printInvoiceDirect(data.print.file_path);
            }
            
            clearCart();
            document.getElementById('paidAmount').value = 0;
            calculateRemaining();
        } else if (data) {
            showAlert('error', data.message || '❌ فشلت عملية البيع');
        }
    })
    .catch(error => {
        showLoading(false);
        console.error('❌ Process sale error:', error);
        showAlert('error', 'حدث خطأ في الاتصال بالخادم: ' + error.message);
    });
}
// ===== تنفيذ البيع بعد التأكيد =====
function executeSale(type) {
    const total = parseFloat(document.getElementById('cartTotal').textContent) || 0;
    const paid = parseFloat(document.getElementById('paidAmount').value) || 0;
    
    if (type === 'cash' && paid < total) {
        showAlert('error', '❌ المبلغ المدفوع أقل من الإجمالي');
        return;
    }
    
    const saleData = {
        items: cart.map(item => ({
            product_id: item.product_id,
            shelf_id: item.shelf_id,
            main_inventory_id: item.main_inventory_id,
            batch_number: item.batch_number,
            expiry_date: item.expiry_date,
            quantity: item.quantity,
            price: item.price,
            cost: item.cost || 0
        })),
        total_amount: total,
        paid_amount: paid,
        sale_type: type,
        customer_id: document.getElementById('customerSelect').value || null,
        discount: 0
    };
    
    showLoading(true, 'جاري معالجة البيع...');
    
    fetch(BASE_URL + '/pos/process-sale', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify(saleData)
    })
    .then(response => {
        if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
        return response.text().then(text => {
            try {
                return JSON.parse(text);
            } catch (e) {
                console.error('❌ استجابة غير JSON:', text);
                throw new Error('الخادم أرجع استجابة غير صالحة');
            }
        });
    })
    .then(data => {
        showLoading(false);
        
        if (data.success) {
            showAlert('success', '✅ تمت عملية البيع بنجاح');
            
            if (data.print && data.print.success && data.auto_open) {
                printInvoiceDirect(data.print.file_path);
            }
            
            clearCart();
            document.getElementById('paidAmount').value = 0;
            calculateRemaining();
        } else {
            showAlert('error', data.message || '❌ فشلت عملية البيع');
        }
    })
    .catch(error => {
        showLoading(false);
        console.error('❌ Process sale error:', error);
        showAlert('error', 'حدث خطأ في الاتصال بالخادم');
    });





}

// ===== نافذة تأكيد مخصصة =====
function showConfirmDialog(message, onConfirm, onCancel) {
    // إزالة أي نافذة سابقة
    const oldOverlay = document.getElementById('confirmOverlay');
    if (oldOverlay) oldOverlay.remove();
    
    const overlay = document.createElement('div');
    overlay.id = 'confirmOverlay';
    overlay.style.cssText = `
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: rgba(0,0,0,0.5);
        display: flex;
        align-items: center;
        justify-content: center;
        z-index: 20000;
    `;
    
    const dialog = document.createElement('div');
    dialog.style.cssText = `
        background: white;
        width: 450px;
        max-width: 90%;
        border-radius: 12px;
        box-shadow: 0 10px 40px rgba(0,0,0,0.3);
        animation: slideIn 0.3s ease;
    `;
    
    dialog.innerHTML = `
        <div style="padding: 25px;">
            <div style="text-align: center; margin-bottom: 20px;">
                <div style="font-size: 48px; margin-bottom: 15px;">⚠️</div>
                <h3 style="font-size: 20px; color: #333; margin-bottom: 15px;">تأكيد العملية</h3>
                <div style="background: #f5f5f5; padding: 15px; border-radius: 8px; text-align: right; white-space: pre-line; font-size: 14px; max-height: 200px; overflow-y: auto;">
                    ${message}
                </div>
            </div>
            <div style="display: flex; gap: 10px;">
                <button id="confirmYes" style="flex: 1; padding: 12px; background: #4CAF50; color: white; border: none; border-radius: 6px; font-size: 16px; cursor: pointer;">نعم، متابعة</button>
                <button id="confirmNo" style="flex: 1; padding: 12px; background: #f44336; color: white; border: none; border-radius: 6px; font-size: 16px; cursor: pointer;">لا، إلغاء</button>
            </div>
        </div>
    `;
    
    overlay.appendChild(dialog);
    document.body.appendChild(overlay);
    
    // ربط الأزرار
    document.getElementById('confirmYes').onclick = function() {
        overlay.remove();
        if (onConfirm) onConfirm();
    };
    
    document.getElementById('confirmNo').onclick = function() {
        overlay.remove();
        if (onCancel) onCancel();
    };
}
// ============================================
// دوال الإرجاع
// ============================================
// ===== فتح نافذة الإرجاع =====
function openReturnWindow() {
    const modal = document.getElementById('returnModal');
    const body = document.getElementById('returnModalBody');
    
    body.innerHTML = `
        <div style="padding: 20px;">
            <div style="display: flex; gap: 10px; margin-bottom: 20px;">
                <input type="text" id="returnInvoiceSearch" 
                       style="flex: 1; height: 55px; padding: 0 15px; border: 2px solid #E0E0E0; border-radius: 10px; font-size: 16px;" 
                       placeholder="🔍 أدخل رقم الفاتورة...">
                <button onclick="searchInvoice()" 
                        style="width: 150px; height: 55px; background: linear-gradient(135deg, #2196F3, #1976D2); color: white; border: none; border-radius: 10px; font-size: 16px; cursor: pointer;">
                    📋 جلب العناصر
                </button>
            </div>
            <div id="invoiceDetails" style="display: none;"></div>
        </div>
    `;
    
    modal.classList.add('active');
    
    setTimeout(() => {
        document.getElementById('returnInvoiceSearch').focus();
    }, 300);
}

// ===== إغلاق نافذة الإرجاع =====
function closeReturnWindow() {
    document.getElementById('returnModal').classList.remove('active');
}

// ===== البحث عن فاتورة =====
function searchInvoice() {
    const invoiceNumber = document.getElementById('returnInvoiceSearch').value;
    
    if (!invoiceNumber) {
        showAlert('error', 'الرجاء إدخال رقم الفاتورة');
        return;
    }
    
    showLoading(true);
    
    fetch(`return/search-invoice?invoice=${encodeURIComponent(invoiceNumber)}`)
        .then(response => response.json())
        .then(data => {
            showLoading(false);
            
            if (data.success) {
                displayInvoiceDetails(data.data);
            } else {
                showAlert('error', data.message || 'الفاتورة غير موجودة');
            }
        })
        .catch(error => {
            showLoading(false);
            console.error('❌ Search error:', error);
            showAlert('error', 'حدث خطأ في الاتصال بالخادم');
        });
}

// ===== عرض تفاصيل الفاتورة =====

// ===== عرض تفاصيل الفاتورة مع رقم الرف والكميات المتاحة =====
function displayInvoiceDetails(data) {
    const sale = data.sale;
    const items = data.items;
    
    // ===== إصلاح المشكلة: التأكد من أن totalReturned رقم =====
    const totalReturned = parseFloat(data.total_returned) || 0;
    const returnableAmount = parseFloat(data.returnable_amount) || parseFloat(sale.paid_amount) || 0;
    
    const detailsDiv = document.getElementById('invoiceDetails');
    
    // تحديد حالة الدفع
    let statusClass = '';
    let statusText = '';
    
    if (sale.payment_status === 'paid') {
        statusClass = 'success';
        statusText = '🟢 مسدد';
    } else if (sale.payment_status === 'partial') {
        statusClass = 'warning';
        statusText = '🟡 جزئي';
    } else {
        statusClass = 'error';
        statusText = '🔴 غير مسدد';
    }
    
    // حساب نسبة الإرجاع بأمان
    const safePaidAmount = parseFloat(sale.paid_amount) || 1; // تجنب القسمة على صفر
    const returnPercentage = ((totalReturned / safePaidAmount) * 100).toFixed(1);
    
    let itemsHtml = '';
    items.forEach(item => {
        // حساب الكمية المتاحة للإرجاع (الكمية المباعة - المرتجعات السابقة)
        const availableQty = parseInt(item.available_for_return) || parseInt(item.quantity) || 0;
        const isFullyReturned = availableQty <= 0;
        
        itemsHtml += `
            <tr>
                <td style="padding: 10px; border-bottom: 1px solid #eee;">
                    <div style="font-weight: bold;">${item.product_name || 'منتج'}</div>
                    <div style="font-size: 11px; color: #666; display: flex; gap: 15px; flex-wrap: wrap;">
                        <span>📟 <strong>${item.barcode || '---'}</strong></span>
                        <span>🪑 <strong style="color: #2196F3;">${item.shelf_code || 'غير محدد'}</strong></span>
                        ${item.returned_quantity ? `<span style="color: #F57C00;">🔄 مرتجع سابق: ${item.returned_quantity}</span>` : ''}
                    </div>
                </td>
                <td style="padding: 10px; text-align: center; border-bottom: 1px solid #eee;">${parseInt(item.quantity) || 0}</td>
                <td style="padding: 10px; text-align: center; border-bottom: 1px solid #eee;">${parseFloat(item.price_unit).toFixed(2) || '0.00'}</td>
                <td style="padding: 10px; text-align: center; border-bottom: 1px solid #eee;">
                    <input type="number" 
                           id="returnQty_${item.id}" 
                           value="${isFullyReturned ? 0 : 1}" 
                           min="0" 
                           max="${availableQty}" 
                           ${isFullyReturned ? 'disabled' : ''}
                           data-shelf="${item.shelf_code || ''}"
                           data-max="${availableQty}"
                           style="width: 80px; height: 35px; padding: 5px; text-align: center; border: 2px solid ${isFullyReturned ? '#ffcdd2' : '#4CAF50'}; border-radius: 6px; font-weight: bold; background: ${isFullyReturned ? '#ffebee' : '#ffffff'};"
                           onchange="validateReturnQuantity(this)">
                    ${isFullyReturned ? '<div style="color: #f44336; font-size: 11px; margin-top: 3px;">⛔ تم إرجاع الكمية كاملة</div>' : ''}
                </td>
                <td style="padding: 10px; text-align: center; border-bottom: 1px solid #eee;">
                    <input type="checkbox" 
                           id="returnItem_${item.id}" 
                           onchange="toggleReturnItem(${item.id})" 
                           ${isFullyReturned ? 'disabled' : 'checked'}
                           style="width: 20px; height: 20px; cursor: ${isFullyReturned ? 'not-allowed' : 'pointer'};">
                </td>
            </tr>
        `;
    });
    
    detailsDiv.innerHTML = `
        <div style="background: linear-gradient(135deg, #673AB7, #5E35B1); color: white; padding: 15px; border-radius: 10px; margin-bottom: 20px;">
            <div style="display: flex; justify-content: space-between; align-items: center;">
                <div>
                    <div style="font-size: 14px;">رقم الفاتورة</div>
                    <div style="font-size: 24px; font-weight: bold;">${sale.invoice_number || '---'}</div>
                </div>
                <div style="text-align: left;">
                    <div style="font-size: 14px;">التاريخ</div>
                    <div style="font-size: 16px;">${sale.created_at ? new Date(sale.created_at).toLocaleString('ar-EG') : '---'}</div>
                </div>
            </div>
        </div>
        
        <div style="background: #F5F5F5; padding: 15px; border-radius: 10px; margin-bottom: 20px; display: flex; justify-content: space-around; flex-wrap: wrap;">
            <div style="text-align: center; min-width: 120px;">
                <div style="font-size: 12px; color: #666;">الإجمالي</div>
                <div style="font-size: 20px; font-weight: bold; color: #2E7D32;">${parseFloat(sale.total_amount).toFixed(2) || '0.00'} ريال</div>
            </div>
            <div style="text-align: center; min-width: 120px;">
                <div style="font-size: 12px; color: #666;">المدفوع</div>
                <div style="font-size: 20px; font-weight: bold; color: #1976D2;">${parseFloat(sale.paid_amount).toFixed(2) || '0.00'} ريال</div>
            </div>
            <div style="text-align: center; min-width: 120px;">
                <div style="font-size: 12px; color: #666;">المتبقي</div>
                <div style="font-size: 20px; font-weight: bold; color: #C62828;">${parseFloat(sale.remaining_amount).toFixed(2) || '0.00'} ريال</div>
            </div>
            <div style="text-align: center; min-width: 120px;">
                <div style="font-size: 12px; color: #666;">الحالة</div>
                <div style="font-size: 16px; font-weight: bold; color: ${statusClass === 'success' ? '#2E7D32' : (statusClass === 'warning' ? '#F57C00' : '#C62828')};">${statusText}</div>
            </div>
        </div>
        
        ${totalReturned > 0 ? `
        <div style="background: #E8F0FE; padding: 15px; border-radius: 10px; margin-bottom: 20px;">
            <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 10px;">
                <div>
                    <span style="font-size: 14px; color: #1976D2;">💰 إجمالي المرتجعات السابقة:</span>
                    <span style="font-size: 18px; font-weight: bold; color: #C62828; margin-right: 10px;">${totalReturned.toFixed(2)} ريال</span>
                </div>
                <div>
                    <span style="font-size: 14px; color: #1976D2;">📊 نسبة الإرجاع:</span>
                    <span style="font-size: 16px; font-weight: bold; color: #F57C00; margin-right: 10px;">${returnPercentage}%</span>
                </div>
                <div>
                    <span style="font-size: 14px; color: #1976D2;">✨ المتبقي للإرجاع:</span>
                    <span style="font-size: 18px; font-weight: bold; color: #2E7D32; margin-right: 10px;">${returnableAmount.toFixed(2)} ريال</span>
                </div>
            </div>
        </div>
        ` : ''}
        
        ${sale.customer_name ? `
        <div style="background: #E3F2FD; padding: 15px; border-radius: 10px; margin-bottom: 20px;">
            <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 10px;">
                <div>
                    <span style="font-size: 14px; color: #1976D2;">👤 العميل:</span>
                    <span style="font-size: 16px; font-weight: bold; margin-right: 10px;">${sale.customer_name}</span>
                </div>
                <div>
                    <span style="font-size: 14px; color: #1976D2;">💰 الرصيد الحالي:</span>
                    <span style="font-size: 16px; font-weight: bold; color: #F57C00; margin-right: 10px;">${parseFloat(sale.customer_balance || 0).toFixed(2)} ريال</span>
                </div>
                <div>
                    <span style="font-size: 14px; color: #1976D2;">📊 الحد الائتماني:</span>
                    <span style="font-size: 16px; font-weight: bold; color: #2E7D32; margin-right: 10px;">${parseFloat(sale.credit_limit || 0).toFixed(2)} ريال</span>
                </div>
            </div>
        </div>
        ` : ''}
        
        <h4 style="margin: 20px 0 15px; font-size: 18px; color: #333; border-right: 4px solid #4CAF50; padding-right: 10px;">
            📋 منتجات الفاتورة
        </h4>
        
        <div style="overflow-x: auto; border: 1px solid #e0e0e0; border-radius: 10px; margin-bottom: 20px;">
            <table style="width: 100%; border-collapse: collapse;">
                <thead>
                    <tr style="background: linear-gradient(135deg, #4CAF50, #388E3C); color: white;">
                        <th style="padding: 12px; text-align: right;">المنتج</th>
                        <th style="padding: 12px; text-align: center;">الكمية المباعة</th>
                        <th style="padding: 12px; text-align: center;">السعر</th>
                        <th style="padding: 12px; text-align: center;">الكمية المرتجعة</th>
                        <th style="padding: 12px; text-align: center;">اختيار</th>
                    </tr>
                </thead>
                <tbody>
                    ${itemsHtml}
                </tbody>
            </table>
        </div>
        
        <div style="margin-top: 20px; display: flex; gap: 15px; align-items: center; background: #f8f9fa; padding: 15px; border-radius: 10px;">
            <div style="min-width: 200px;">
                <label style="display: block; margin-bottom: 5px; color: #666; font-size: 13px;">طريقة الاسترداد</label>
                <select id="returnType" style="width: 100%; height: 45px; border: 2px solid #e0e0e0; border-radius: 8px; padding: 0 10px; font-size: 14px;">
                    <option value="cash">💵 نقدي</option>
                    <option value="customer_balance" ${sale.customer_id ? '' : 'disabled'}>📅 آجل (رصيد عميل)</option>
                </select>
            </div>
            
            <div style="flex: 1; background: linear-gradient(135deg, #E8F0FE, #ffffff); padding: 15px; border-radius: 10px; display: flex; gap: 30px; align-items: center; justify-content: space-around;">
                <div style="text-align: center;">
                    <div style="font-size: 13px; color: #666;">عدد المنتجات</div>
                    <div style="font-size: 24px; font-weight: bold; color: #1976D2;" id="returnCount">0</div>
                </div>
                <div style="text-align: center;">
                    <div style="font-size: 13px; color: #666;">إجمالي الكمية</div>
                    <div style="font-size: 24px; font-weight: bold; color: #F57C00;" id="returnTotalQty">0</div>
                </div>
                <div style="text-align: center;">
                    <div style="font-size: 13px; color: #666;">المبلغ المسترد</div>
                    <div style="font-size: 28px; font-weight: bold; color: #2E7D32;" id="returnAmount">0.00 ريال</div>
                </div>
            </div>
        </div>
        
        <div style="margin-top: 25px; display: flex; gap: 15px; justify-content: flex-end;">
            <button id="confirmReturnBtn" 
                    style="width: 200px; height: 55px; background: linear-gradient(135deg, #4CAF50, #388E3C); color: white; border: none; border-radius: 10px; font-size: 16px; font-weight: bold; cursor: pointer; display: flex; align-items: center; justify-content: center; gap: 8px; box-shadow: 0 4px 6px rgba(76,175,80,0.2); transition: all 0.3s;"
                    onmouseover="this.style.transform='scale(1.02)'"
                    onmouseout="this.style.transform='scale(1)'">
                ✅ تأكيد الإرجاع
            </button>
            <button id="cancelReturnBtn" 
                    style="width: 150px; height: 55px; background: white; border: 2px solid #f44336; color: #f44336; border-radius: 10px; font-size: 16px; font-weight: bold; cursor: pointer; display: flex; align-items: center; justify-content: center; gap: 8px; transition: all 0.3s;"
                    onmouseover="this.style.background='#ffebee'"
                    onmouseout="this.style.background='white'">
                ❌ إلغاء
            </button>
        </div>
    `;
    
    detailsDiv.style.display = 'block';
    
    // تحديث الملخص
    updateReturnSummary();
    
    // ربط أزرار الإرجاع
    document.getElementById('confirmReturnBtn').onclick = function() {
        const saleId = sale.id;
        const invoiceNumber = sale.invoice_number;
        const customerId = sale.customer_id;
        submitReturn(saleId, invoiceNumber, customerId);
    };
    
    document.getElementById('cancelReturnBtn').onclick = function() {
        closeReturnWindow();
    };
}

// ===== التحقق من صحة الكمية المرتجعة =====
function validateReturnQuantity(input) {
    let val = parseInt(input.value);
    const maxVal = parseInt(input.getAttribute('data-max') || input.max);
    
    if (isNaN(val) || val < 0) {
        input.value = 0;
    } else if (val > maxVal) {
        input.value = maxVal;
        showAlert('warning', `الحد الأقصى للإرجاع ${maxVal} وحدة`);
    }
    
    updateReturnSummary();
}

// ===== تفعيل/تعطيل حقل الكمية =====
function toggleReturnItem(itemId) {
    const checkbox = document.getElementById(`returnItem_${itemId}`);
    const qtyInput = document.getElementById(`returnQty_${itemId}`);
    
    if (checkbox && qtyInput) {
        qtyInput.disabled = !checkbox.checked;
        if (!checkbox.checked) {
            qtyInput.value = 0;
        } else {
            const maxVal = parseInt(qtyInput.getAttribute('data-max') || qtyInput.max);
            if (maxVal > 0) {
                qtyInput.value = 1;
            }
        }
    }
    updateReturnSummary();
}

// ===== تحديث ملخص الإرجاع =====
function updateReturnSummary() {
    const checkboxes = document.querySelectorAll('input[id^="returnItem_"]');
    let count = 0;
    let totalQty = 0;
    let totalAmount = 0;
    
    checkboxes.forEach(checkbox => {
        if (checkbox.checked) {
            const id = checkbox.id.replace('returnItem_', '');
            const qtyInput = document.getElementById(`returnQty_${id}`);
            
            if (qtyInput && !qtyInput.disabled) {
                const qty = parseInt(qtyInput.value) || 0;
                if (qty > 0) {
                    const row = qtyInput.closest('tr');
                    const priceCell = row.children[2]; // عمود السعر
                    const price = parseFloat(priceCell.textContent) || 0;
                    
                    count++;
                    totalQty += qty;
                    totalAmount += qty * price;
                }
            }
        }
    });
    
    document.getElementById('returnCount').textContent = count;
    document.getElementById('returnTotalQty').textContent = totalQty;
    document.getElementById('returnAmount').textContent = totalAmount.toFixed(2) + ' ريال';
}
// ===== تفعيل/تعطيل حقل الكمية =====
function toggleReturnItem(itemId) {
    const checkbox = document.getElementById(`returnItem_${itemId}`);
    const qtyInput = document.getElementById(`returnQty_${itemId}`);
    
    qtyInput.disabled = !checkbox.checked;
    updateReturnSummary();
}

// ===== تحديث ملخص الإرجاع =====
function updateReturnSummary() {
    const checkboxes = document.querySelectorAll('input[id^="returnItem_"]');
    let count = 0;
    let totalQty = 0;
    let totalAmount = 0;
    
    checkboxes.forEach(checkbox => {
        if (checkbox.checked) {
            const id = checkbox.id.replace('returnItem_', '');
            const qty = parseInt(document.getElementById(`returnQty_${id}`).value) || 0;
            const priceCell = document.getElementById(`returnQty_${id}`).closest('tr').children[2];
            const price = parseFloat(priceCell.textContent) || 0;
            
            count++;
            totalQty += qty;
            totalAmount += qty * price;
        }
    });
    
    document.getElementById('returnCount').textContent = count;
    document.getElementById('returnTotalQty').textContent = totalQty;
    document.getElementById('returnAmount').textContent = totalAmount.toFixed(2) + ' ريال';
}

// ===== تنفيذ الإرجاع =====
// ===== تنفيذ الإرجاع - نسخة مبسطة للاختبار =====
// ===== تنفيذ الإرجاع الحقيقي =====
// ===== تنفيذ الإرجاع =====
// ===== تنفيذ الإرجاع بدون نافذة تأكيد =====
function submitReturn(saleId, invoiceNumber, customerId) {
    console.log('🔍 بدء الإرجاع:', {saleId, invoiceNumber, customerId});
    
    // جمع البيانات من النموذج
    const returnType = document.getElementById('returnType').value;
    const items = [];
    
    const checkboxes = document.querySelectorAll('input[id^="returnItem_"]');
    let hasSelected = false;
    let totalRefund = 0;
    let validationErrors = [];
    
    checkboxes.forEach(checkbox => {
        if (checkbox.checked) {
            const id = checkbox.id.replace('returnItem_', '');
            const qtyInput = document.getElementById(`returnQty_${id}`);
            
            if (!qtyInput || qtyInput.disabled) return;
            
            const qty = parseInt(qtyInput.value) || 0;
            const maxQty = parseInt(qtyInput.getAttribute('data-max') || qtyInput.max) || 0;
            
            if (qty < 0) {
                validationErrors.push('الكمية يجب أن تكون 0 أو أكثر');
                return;
            }
            
            if (qty > maxQty) {
                validationErrors.push(`الكمية المطلوبة (${qty}) أكبر من المتاح للإرجاع (${maxQty})`);
                return;
            }
            
            if (qty === 0) return;
            
            hasSelected = true;
            
            const row = qtyInput.closest('tr');
            const priceCell = row.children[2];
            const price = parseFloat(priceCell.textContent) || 0;
            
            const productCell = row.children[0];
            const productName = productCell.innerText.split('\n')[0].trim();
            
            const shelfCode = qtyInput.getAttribute('data-shelf') || '';
            
            const subtotal = qty * price;
            totalRefund += subtotal;
            
            items.push({
                sale_item_id: parseInt(id),
                product_id: 0,
                product_name: productName,
                shelf_code: shelfCode,
                quantity: qty,
                price: price,
                selected: true
            });
        }
    });
    
    if (validationErrors.length > 0) {
        showAlert('error', validationErrors.join('\n'));
        return;
    }
    
    if (!hasSelected) {
        showAlert('error', '❌ الرجاء اختيار منتجات للإرجاع');
        return;
    }
    
    if (totalRefund <= 0) {
        showAlert('error', '❌ المبلغ المسترد يجب أن يكون أكبر من صفر');
        return;
    }
    
    // ===== تم إزالة confirm نهائياً =====
    // الإرجاع يتم مباشرة بدون طلب تأكيد
    
    const data = {
        sale_id: saleId,
        invoice_number: invoiceNumber,
        customer_id: customerId,
        refund_method: returnType,
        reason: 'إرجاع منتجات',
        items: items
    };
    
    console.log('📤 إرسال بيانات الإرجاع:', data);
    
    showLoading(true, 'جاري معالجة الإرجاع...');
    
    fetch(BASE_URL + '/return/process-return', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(data)
    })
    .then(response => {
        console.log('📥 استجابة الخادم:', response.status);
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        return response.text().then(text => {
            console.log('📄 نص الاستجابة:', text.substring(0, 200));
            try {
                return JSON.parse(text);
            } catch (e) {
                console.error('❌ استجابة غير JSON:', text);
                throw new Error('الخادم أرجع استجابة غير صالحة');
            }
        });
    })
    .then(result => {
        showLoading(false);
        
        if (result.success) {
            showAlert('success', `✅ تم الإرجاع بنجاح - رقم الإرجاع: ${result.return_number}`);
            
            // تحديث الفاتورة في الواجهة إذا كانت مفتوحة
            if (result.updated_items) {
                updateReturnedItemsInUI(result.updated_items);
            }
            
            closeReturnWindow();
            
            // تحديث الصفحة بعد ثانيتين
            setTimeout(() => {
                location.reload();
            }, 2000);
        } else {
            showAlert('error', result.message || '❌ فشل الإرجاع');
        }
    })
    .catch(error => {
        showLoading(false);
        console.error('❌ Return error:', error);
        showAlert('error', 'حدث خطأ في الاتصال بالخادم: ' + error.message);
    });
}

// ===== تحديث العناصر في الواجهة بعد الإرجاع =====
function updateReturnedItemsInUI(updatedItems) {
    updatedItems.forEach(item => {
        const qtyInput = document.getElementById(`returnQty_${item.sale_item_id}`);
        const checkbox = document.getElementById(`returnItem_${item.sale_item_id}`);
        
        if (qtyInput) {
            // تحديث الحد الأقصى
            qtyInput.max = item.available_for_return;
            qtyInput.setAttribute('data-max', item.available_for_return);
            
            // تعطيل إذا لم يتبق كمية
            if (item.available_for_return <= 0) {
                qtyInput.disabled = true;
                qtyInput.value = 0;
                if (checkbox) checkbox.disabled = true;
            } else {
                qtyInput.value = 1;
            }
        }
    });
    
    // تحديث الملخص
    updateReturnSummary();
}

function closeReturnWindow() {
    document.getElementById('returnModal').classList.remove('active');
}






function calculateReturnSummary() {
    const checkboxes = document.querySelectorAll('input[id^="returnItem_"]');
    let count = 0;
    let totalQty = 0;
    let totalAmount = 0;
    
    checkboxes.forEach(checkbox => {
        if (checkbox.checked) {
            const id = checkbox.id.replace('returnItem_', '');
            const qty = parseInt(document.getElementById(`returnQty_${id}`).value) || 0;
            const price = parseFloat(document.querySelector(`#returnQty_${id}`).closest('tr').children[2].textContent) || 0;
            
            count++;
            totalQty += qty;
            totalAmount += qty * price;
        }
    });
    
    document.getElementById('returnCount').textContent = count;
    document.getElementById('returnTotalQty').textContent = totalQty;
    document.getElementById('returnAmount').textContent = totalAmount.toFixed(2) + ' ريال';
}
// ===== التحقق من الكميات قبل عرض نافذة التأكيد =====

// ===== نافذة التحذير (عند وجود مشاكل في الكميات) =====
function showWarningModal(saleData, problems) {
    let problemsHtml = '';
    problems.forEach(p => {
        problemsHtml += `
            <div style="background: #ffebee; padding: 10px; margin-bottom: 8px; border-radius: 6px; border-right: 4px solid #f44336;">
                <div style="display: flex; justify-content: space-between;">
                    <span style="font-weight: bold;">${p.name}</span>
                    <span style="color: #f44336;">⚠️ ${p.status}</span>
                </div>
                <div style="display: flex; justify-content: space-between; margin-top: 5px; font-size: 13px;">
                    <span>المطلوب: ${p.requested}</span>
                    <span>المتوفر: ${p.available}</span>
                </div>
            </div>
        `;
    });

    const modal = document.createElement('div');
    modal.className = 'modal';
    modal.style.display = 'flex';
    modal.style.zIndex = '10001';
    
    modal.innerHTML = `
        <div style="background: white; width: 90%; max-width: 500px; border-radius: 12px; overflow: hidden; box-shadow: 0 10px 40px rgba(0,0,0,0.2);">
            <div style="background: linear-gradient(135deg, #f44336, #d32f2f); color: white; padding: 20px; text-align: center;">
                <span style="font-size: 40px; display: block; margin-bottom: 10px;">⚠️</span>
                <h3 style="margin: 0; font-size: 20px;">تحذير: مشكلة في الكميات</h3>
            </div>
            
            <div style="padding: 20px;">
                <p style="margin-bottom: 15px;">بعض المنتجات لا تتوفر بالكمية المطلوبة:</p>
                
                <div style="max-height: 300px; overflow-y: auto; margin-bottom: 20px;">
                    ${problemsHtml}
                </div>
                
                <p style="background: #fff3e0; padding: 10px; border-radius: 6px; font-size: 14px; margin-bottom: 20px;">
                    ⚠️ هل تريد متابعة البيع مع توفر الكميات الموجودة فقط؟
                </p>
                
                <div style="display: flex; gap: 10px;">
                    <button id="forceSaleBtn" style="flex: 2; background: linear-gradient(135deg, #ff9800, #f57c00); color: white; border: none; padding: 15px; border-radius: 8px; font-size: 16px; font-weight: bold; cursor: pointer;">
                        ⚡ نعم، بيع المتوفر
                    </button>
                    <button id="cancelSaleBtn" style="flex: 1; background: #f5f5f5; color: #666; border: 1px solid #ddd; padding: 15px; border-radius: 8px; font-size: 16px; cursor: pointer;">
                        ❌ إلغاء
                    </button>
                </div>
            </div>
        </div>
    `;
    
    document.body.appendChild(modal);
    
    document.getElementById('forceSaleBtn').onclick = function() {
        document.body.removeChild(modal);
        // تعديل الكميات في السلة لتتناسب مع المتوفر
        const updatedCart = cart.map(item => {
            const problem = problems.find(p => p.name === item.name);
            if (problem) {
                item.quantity = problem.available; // تعديل الكمية إلى المتوفر
            }
            return item;
        });
        
        // تحديث السلة بالكميات الجديدة
        cart = updatedCart;
        updateCart();
        
        // عرض نافذة التأكيد بالكميات المعدلة
        showConfirmationModal(saleData);
    };
    
    document.getElementById('cancelSaleBtn').onclick = function() {
        document.body.removeChild(modal);
    };
    
    modal.addEventListener('click', function(e) {
        if (e.target === modal) {
            document.body.removeChild(modal);
        }
    });
}

// ===== نافذة التأكيد العادية =====
function showConfirmationModal(saleData) {
    const total = saleData.total_amount;
    const paid = saleData.paid_amount;
    
    const modal = document.createElement('div');
    modal.className = 'modal';
    modal.style.display = 'flex';
    modal.style.zIndex = '10001';
    
    modal.innerHTML = `
        <div style="background: white; width: 90%; max-width: 450px; border-radius: 12px; overflow: hidden; box-shadow: 0 10px 40px rgba(0,0,0,0.2);">
            <div style="background: linear-gradient(135deg, #4CAF50, #388E3C); color: white; padding: 20px; text-align: center;">
                <span style="font-size: 40px; display: block; margin-bottom: 10px;">💰</span>
                <h3 style="margin: 0; font-size: 20px;">تأكيد عملية البيع</h3>
            </div>
            
            <div style="padding: 25px;">
                <div style="background: #f5f5f5; padding: 15px; border-radius: 8px; margin-bottom: 20px;">
                    <p style="margin: 5px 0; display: flex; justify-content: space-between;">
                        <span>إجمالي الفاتورة:</span>
                        <span style="font-weight: bold; color: #2e7d32;">${total.toFixed(2)} ريال</span>
                    </p>
                    <p style="margin: 5px 0; display: flex; justify-content: space-between;">
                        <span>المبلغ المدفوع:</span>
                        <span style="font-weight: bold;">${paid.toFixed(2)} ريال</span>
                    </p>
                    <p style="margin: 5px 0; display: flex; justify-content: space-between;">
                        <span>عدد الأصناف:</span>
                        <span style="font-weight: bold;">${saleData.items.length}</span>
                    </p>
                </div>
                
                <div style="display: flex; gap: 10px;">
                    <button id="confirmSaleBtn" style="flex: 2; background: linear-gradient(135deg, #4CAF50, #388E3C); color: white; border: none; padding: 15px; border-radius: 8px; font-size: 16px; font-weight: bold; cursor: pointer;">
                        ✅ تأكيد البيع
                    </button>
                    <button id="cancelSaleBtn" style="flex: 1; background: #f5f5f5; color: #666; border: 1px solid #ddd; padding: 15px; border-radius: 8px; font-size: 16px; cursor: pointer;">
                        ❌ إلغاء
                    </button>
                </div>
            </div>
        </div>
    `;
    
    document.body.appendChild(modal);
    
    document.getElementById('confirmSaleBtn').onclick = function() {
        document.body.removeChild(modal);
        executeSale(saleData);
    };
    
    document.getElementById('cancelSaleBtn').onclick = function() {
        document.body.removeChild(modal);
    };
    
    modal.addEventListener('click', function(e) {
        if (e.target === modal) {
            document.body.removeChild(modal);
        }
    });
}

// ===== معالجة البيع =====
function processSale(type) {
    // التحقق من السلة
    if (cart.length === 0) {
        showAlert('error', '❌ السلة فارغة');
        return;
    }
    
    console.log('🔍 بدء عملية البيع');
    
    const total = parseFloat(document.getElementById('cartTotal').textContent) || 0;
    const paid = parseFloat(document.getElementById('paidAmount').value) || 0;
    
    if (type === 'cash' && paid < total) {
        showAlert('error', '❌ المبلغ المدفوع أقل من الإجمالي');
        return;
    }
    
    // تجهيز بيانات البيع
    const saleData = {
        items: cart.map(item => ({
            product_id: item.product_id,
            shelf_id: item.shelf_id,
            main_inventory_id: item.main_inventory_id,
            batch_number: item.batch_number,
            expiry_date: item.expiry_date,
            quantity: item.quantity,
            price: item.price,
            cost: item.cost || 0
        })),
        total_amount: total,
        paid_amount: paid,
        sale_type: type,
        customer_id: document.getElementById('customerSelect').value || null,
        discount: 0
    };
    
    showLoading(true, 'جاري معالجة البيع...');
    
    fetch(BASE_URL + '/pos/process-sale', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify(saleData)
    })
    .then(response => {
        if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
        return response.text().then(text => {
            try {
                return JSON.parse(text);
            } catch (e) {
                console.error('❌ استجابة غير JSON:', text.substring(0, 200));
                throw new Error('الخادم أرجع استجابة غير صالحة');
            }
        });
    })
    .then(data => {
        showLoading(false);
        
        if (data.success) {
            showAlert('success', '✅ تمت عملية البيع بنجاح');
            
            if (data.print && data.print.success && data.auto_open) {
                printInvoiceDirect(data.print.file_path);
            }
            
            clearCart();
            document.getElementById('paidAmount').value = 0;
            calculateRemaining();
        } else {
            showAlert('error', data.message || '❌ فشلت عملية البيع');
        }
    })
    .catch(error => {
        showLoading(false);
        console.error('❌ Process sale error:', error);
        showAlert('error', 'حدث خطأ في الاتصال بالخادم');
    });
}

// ============================================
// اختصارات لوحة المفاتيح
// ============================================
document.addEventListener('keydown', function(e) {
    // Ctrl + S للتركيز على حقل البحث
    if (e.ctrlKey && e.key === 's') {
        e.preventDefault();
        document.getElementById('productSearch').focus();
    }
    
    // Ctrl + A للتركيز على حقل الباركود
    if (e.ctrlKey && e.key === 'a') {
        e.preventDefault();
        document.getElementById('barcodeInput').focus();
    }
    
    // F2 - بيع نقدي
    if (e.key === 'F2') {
        e.preventDefault();
        if (!document.getElementById('cashSaleBtn').disabled) {
            processSale('cash');
        }
    }
    
    // F3 - بيع آجل
    if (e.key === 'F3') {
        e.preventDefault();
        if (!document.getElementById('creditSaleBtn').disabled) {
            processSale('credit');
        }
    }
    
    // Ctrl+R - إرجاع
    if (e.ctrlKey && e.key === 'r') {
        e.preventDefault();
        openReturnWindow();
    }
    
    // Delete - حذف المنتج المحدد
    if (e.key === 'Delete' && selectedRowId) {
        e.preventDefault();
        removeSelectedItem();
    }
    
    // الأسهم للتنقل في نتائج البحث
    if (document.getElementById('searchResults').classList.contains('active')) {
        const items = document.querySelectorAll('.search-result-item');
        let currentIndex = -1;
        
        items.forEach((item, index) => {
            if (item.classList.contains('selected')) {
                currentIndex = index;
                item.classList.remove('selected');
            }
        });
        
        if (e.key === 'ArrowDown') {
            e.preventDefault();
            currentIndex = (currentIndex + 1) % items.length;
            items[currentIndex].classList.add('selected');
            items[currentIndex].scrollIntoView({ block: 'nearest' });
        } else if (e.key === 'ArrowUp') {
            e.preventDefault();
            currentIndex = (currentIndex - 1 + items.length) % items.length;
            items[currentIndex].classList.add('selected');
            items[currentIndex].scrollIntoView({ block: 'nearest' });
        } else if (e.key === 'Enter' && currentIndex !== -1) {
            e.preventDefault();
            items[currentIndex].click();
        }
    }
});

// ============================================
// التهيئة عند تحميل الصفحة
// ============================================
document.addEventListener('DOMContentLoaded', function() {
    // تركيز على حقل البحث
    document.getElementById('productSearch').focus();
    
    // إضافة مستمعين للأحداث لحقول الإدخال
    document.getElementById('paidAmount').addEventListener('input', calculateRemaining);
    document.getElementById('customerSelect').addEventListener('change', updateCustomerInfo);
    
    // منع إرسال النموذج عند الضغط على Enter
    document.querySelectorAll('input').forEach(input => {
        input.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                e.preventDefault();
            }
        });
    });
});

// ===== طباعة الفاتورة باستخدام رابط التحميل =====
function printInvoiceDirect(filePath) {
    // استخراج اسم الملف من المسار
    const fileName = filePath.split('\\').pop();
    
    // إنشاء رابط التحميل
    const downloadUrl = BASE_URL + '/pos/download-invoice?file=' + encodeURIComponent(fileName);
    
    // جلب محتوى الملف عبر الرابط
    fetch(downloadUrl)
        .then(response => response.text())
        .then(html => {
            // إنشاء نافذة جديدة
            const printWindow = window.open('', '_blank', 'width=800,height=600');
            
            if (!printWindow) {
                showAlert('error', '❌ تم منع النوافذ المنبثقة. الرجاء السماح بها');
                return;
            }
            
            // كتابة المحتوى
            printWindow.document.write(html);
            printWindow.document.close();
            
            // طباعة وإغلاق
            printWindow.onload = function() {
                printWindow.print();
                setTimeout(() => printWindow.close(), 1000);
            };
        })
        .catch(error => {
            console.error('Error:', error);
            showAlert('error', '❌ فشل تحميل الفاتورة');
        });
}
</script>

</body>
</html>

<?php
$content = ob_get_clean();
require BASE_PATH . 'views/layouts/main.php';
?>

<?php 
    include_once 'views/Usermessage.php';
    include_once 'views/Casio.php'; 
?>