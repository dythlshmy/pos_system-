<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $title ?></title>
    <link rel="stylesheet" href="<?= asset('css/style.css') ?>">

    <!-- ===== أولاً: ملفات الحماية والإصلاح (مرة واحدة فقط) ===== -->
    <script src="<?= BASE_URL ?>/assets/js/security.js?v=<?= time() ?>"></script>
    <script src="<?= BASE_URL ?>/assets/js/fix-false.js?v=<?= time() ?>"></script>
    <script src="<?= asset('js/silent-core.js')?>"></script>

    <!-- ===== تحسين الأداء ومنع تضارب الجلسات ===== -->
    <script>
    // منع التخزين المؤقت للطلبات AJAX
    const abortControllers = new Map();
    
    // إلغاء جميع الطلبات النشطة
    function abortAllPendingRequests() {
        for (const [url, controller] of abortControllers) {
            controller.abort();
            abortControllers.delete(url);
        }
    }
    
    // دالة fetch محسنة مع إمكانية الإلغاء
    window.smartFetch = function(url, options = {}) {
        // إلغاء أي طلب سابق لنفس الـ URL
        if (abortControllers.has(url)) {
            abortControllers.get(url).abort();
            abortControllers.delete(url);
        }
        
        const controller = new AbortController();
        abortControllers.set(url, controller);
        
        const fetchOptions = {
            ...options,
            signal: controller.signal,
            headers: {
                ...options.headers,
                'X-Requested-With': 'XMLHttpRequest'
            }
        };
        
        return fetch(url, fetchOptions)
            .then(response => {
                abortControllers.delete(url);
                return response;
            })
            .catch(error => {
                abortControllers.delete(url);
                if (error.name === 'AbortError') {
                    console.log('Request aborted:', url);
                    return null;
                }
                throw error;
            });
    };
    </script>
</head>

<body>
    <?php require BASE_PATH . 'views/partials/top_nav.php'; ?>
    
    <div class="main-container">
        <div class="content-area">
            <?= $content ?? '' ?>
        </div>
    </div>

    <!-- ===== الملفات المساعدة (مرة واحدة فقط، تم إزالة التكرار) ===== -->
    <script src="<?= asset('js/main.js') ?>"></script>
    
    <!-- ===== نظام التحقق الذكي من الترخيص والنسخ الاحتياطي (محسن) ===== -->
    <script>
    (function() {
        "use strict";
        
        // متغيرات التحكم
        let licenseCheckInterval = null;
        let backupCheckInterval = null;
        let isPageVisible = true;
        let lastLicenseCheck = 0;
        let lastBackupCheck = 0;
        
        // الفواصل الزمنية (محسنة لتقليل الضغط)
        const LICENSE_CHECK_INTERVAL = 30 * 60 * 1000; // 30 دقيقة
        const BACKUP_CHECK_INTERVAL = 12 * 60 * 60 * 1000; // 12 ساعة (بدلاً من 5 دقائق)
        const MIN_CHECK_INTERVAL = 60 * 1000; // دقيقة واحدة كحد أدنى بين الفحوصات
        
        // التحقق من الترخيص (مع التخزين المؤقت)
        function checkLicenseStatus() {
            const now = Date.now();
            
            // منع الفحص المتكرر جداً
            if (now - lastLicenseCheck < MIN_CHECK_INTERVAL) {
                return;
            }
            lastLicenseCheck = now;
            
            // التحقق فقط إذا كانت الصفحة مرئية وليست صفحة الترخيص
            if (!isPageVisible || window.location.href.includes('/license')) {
                return;
            }
            
            smartFetch('<?= BASE_URL ?>/license/status')
                .then(response => response ? response.json() : null)
                .then(data => {
                    if (data && data.status !== 'active') {
                        // تخزين الصفحة الحالية للعودة بعد التفعيل
                        sessionStorage.setItem('redirect_after_license', window.location.href);
                        showLicenseAlert(data);
                    }
                })
                .catch(error => {
                    // تجاهل أخطاء الإلغاء
                    if (error && error.name !== 'AbortError') {
                        console.warn('License check error:', error);
                    }
                });
        }
        
        // عرض تنبيه الترخيص
        function showLicenseAlert(data) {
            // تجنب إنشاء أكثر من تنبيه
            if (document.querySelector('.license-alert')) return;
            
            const alertDiv = document.createElement('div');
            alertDiv.className = 'license-alert';
            alertDiv.style.cssText = `
                position: fixed;
                top: 20px;
                left: 50%;
                transform: translateX(-50%);
                background: #f8d7da;
                color: #721c24;
                padding: 15px 30px;
                border-radius: 5px;
                border: 2px solid #f5c6cb;
                z-index: 9999;
                box-shadow: 0 4px 15px rgba(0,0,0,0.2);
                direction: rtl;
                text-align: center;
                font-weight: bold;
            `;
            
            alertDiv.innerHTML = `
                ⚠️ ${data.message}<br>
                <small>بصمة الجهاز: ${data.fingerprint || 'غير متوفرة'}</small><br>
                <button onclick="window.location.href='<?= BASE_URL ?>/license'" 
                        style="margin-top:10px; padding:5px 20px; background:#dc3545; color:white; border:none; border-radius:3px; cursor:pointer;">
                    الذهاب لصفحة التفعيل
                </button>
            `;
            
            document.body.appendChild(alertDiv);
            
            // إخفاء التنبيه بعد 10 ثوان
            setTimeout(() => {
                if (alertDiv && alertDiv.parentNode) {
                    alertDiv.style.display = 'none';
                    setTimeout(() => alertDiv.remove(), 1000);
                }
            }, 10000);
        }
        
        // فحص النسخ الاحتياطي (مع تخزين مؤقت)
        function checkAutoBackup() {
            const now = Date.now();
            
            // منع الفحص المتكرر جداً
            if (now - lastBackupCheck < MIN_CHECK_INTERVAL) {
                return;
            }
            lastBackupCheck = now;
            
            // التحقق فقط إذا كانت الصفحة مرئية وليست صفحات خاصة
            if (!isPageVisible || 
                window.location.href.includes('/license') || 
                window.location.href.includes('/login')) {
                return;
            }
            
            smartFetch('<?= BASE_URL ?>/settings/auto-backup')
                .then(response => response ? response.json() : null)
                .then(data => {
                    if (data && data.success) {
                        console.log('Auto Backup:', data.message);
                    } else if (data && data.message && 
                              !data.message.includes('لم يحن وقت') &&
                              !data.message.includes('لهذا اليوم مسبقاً') &&
                              !data.message.includes('غير مفعل')) {
                        console.log('Auto Backup Status:', data.message);
                    }
                })
                .catch(error => {
                    if (error && error.name !== 'AbortError') {
                        console.warn('Auto Backup Error:', error);
                    }
                });
        }
        
        // مراقبة رؤية الصفحة (لتقليل الطلبات الخلفية)
        function handleVisibilityChange() {
            isPageVisible = !document.hidden;
            
            if (isPageVisible) {
                // عند عودة المستخدم للصفحة، تحقق من الترخيص فوراً
                setTimeout(checkLicenseStatus, 100);
            } else {
                // عند خروج المستخدم من الصفحة، ألغِ أي طلبات معلقة
                if (typeof abortAllPendingRequests === 'function') {
                    abortAllPendingRequests();
                }
            }
        }
        
        // بدء المؤقتات
        function startIntervals() {
            // فحص الترخيص عند التحميل
            setTimeout(checkLicenseStatus, 500);
            
            // مؤقت فحص الترخيص (30 دقيقة)
            if (licenseCheckInterval) clearInterval(licenseCheckInterval);
            licenseCheckInterval = setInterval(checkLicenseStatus, LICENSE_CHECK_INTERVAL);
            
            // مؤقت فحص النسخ الاحتياطي (12 ساعة)
            if (backupCheckInterval) clearInterval(backupCheckInterval);
            backupCheckInterval = setInterval(checkAutoBackup, BACKUP_CHECK_INTERVAL);
        }
        
        // إيقاف المؤقتات
        function stopIntervals() {
            if (licenseCheckInterval) {
                clearInterval(licenseCheckInterval);
                licenseCheckInterval = null;
            }
            if (backupCheckInterval) {
                clearInterval(backupCheckInterval);
                backupCheckInterval = null;
            }
        }
        
        // إعادة تشغيل المؤقتات عند تغيير الصفحة (للـ SPA)
        function restartIntervals() {
            stopIntervals();
            startIntervals();
        }
        
        // مراقبة تغييرات الـ URL للصفحات التي لا تعيد التحميل (SPA)
        let lastUrl = location.href;
        function checkUrlChange() {
            if (location.href !== lastUrl) {
                lastUrl = location.href;
                restartIntervals();
            }
        }
        
        // إضافة مستمعي الأحداث
        document.addEventListener('visibilitychange', handleVisibilityChange);
        
        // مراقبة تغييرات URL (للتنقل الداخلي)
        setInterval(checkUrlChange, 1000);
        
        // مراقبة التنقل باستخدام History API
        const originalPushState = history.pushState;
        const originalReplaceState = history.replaceState;
        
        history.pushState = function() {
            originalPushState.apply(this, arguments);
            checkUrlChange();
        };
        
        history.replaceState = function() {
            originalReplaceState.apply(this, arguments);
            checkUrlChange();
        };
        
        window.addEventListener('popstate', checkUrlChange);
        
        // بدء النظام عند تحميل الصفحة
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', startIntervals);
        } else {
            startIntervals();
        }
        
        // تنظيف عند إغلاق الصفحة
        window.addEventListener('beforeunload', function() {
            stopIntervals();
            if (typeof abortAllPendingRequests === 'function') {
                abortAllPendingRequests();
            }
        });
        
        // تصدير دوال للاستخدام الخارجي
        window.LicenseManager = {
            checkNow: checkLicenseStatus,
            restart: restartIntervals
        };
    })();
    </script>
    
    <!-- تم إزالة التحميل المكرر للملفات (كان هناك silent-core.js مكرر 3 مرات و main.js مكرر) -->
</body>
</html>


<?php 
    include_once 'views/Shortcut_manage.php';
    include_once 'views/Usermessage.php';
    include_once 'views/Casio.php'; 
?>