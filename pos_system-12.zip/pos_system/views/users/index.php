<?php
ob_start();

// منع الوصول المباشر
if (!defined('BASE_PATH')) {
    exit('Access Denied');
}

// التأكد من وجود المتغيرات
$users = isset($users) ? $users : [];
$current_user = isset($current_user) ? $current_user : [];
?>

<!-- ===== CSS المدمج لواجهة إدارة المستخدمين ===== -->
<style>
/* ============================================
   واجهة إدارة المستخدمين - تصميم سطح المكتب المتقدم
   ============================================ */

/* ===== إعادة تعيين القالب الرئيسي ===== */
.main-container, .content-area {
    margin: 0 !important;
    padding: 0 !important;
    width: 100% !important;
    height: 100% !important;
    overflow: hidden !important;
    background: transparent !important;
}

/* ===== منع تحديد النص خارج الحقول ===== */
* {
    user-select: none;
    -webkit-user-select: none;
    -moz-user-select: none;
    -ms-user-select: none;
}

/* السماح بالتحديد فقط في الحقول */
input, textarea, select, [contenteditable="true"] {
    user-select: text !important;
    -webkit-user-select: text !important;
    -moz-user-select: text !important;
    -ms-user-select: text !important;
}

/* ===== إخفاء أيقونات كلمة المرور في المتصفح ===== */
input::-ms-reveal,
input::-ms-clear {
    display: none;
}

/* منع تغيير لون الخلفية من المتصفح */
input:-webkit-autofill,
input:-webkit-autofill:hover,
input:-webkit-autofill:focus,
input:-webkit-autofill:active {
    -webkit-box-shadow: 0 0 0 30px white inset !important;
    -webkit-text-fill-color: var(--neutral-800) !important;
    caret-color: var(--neutral-800) !important;
    transition: background-color 5000s ease-in-out 0s;
}

/* إخفاء أيقونة العين في المتصفحات */
input[type="password"]::-webkit-credentials-auto-fill-button,
input[type="password"]::-webkit-caps-lock-indicator,
input[type="password"]::-webkit-strong-password-visualizer {
    display: none !important;
    visibility: hidden !important;
    pointer-events: none !important;
}

/* ===== منع الطباعة ===== */
@media print {
    body { display: none !important; }
}

/* ===== منع السحب والإفلات ===== */
img, a, [draggable] {
    -webkit-user-drag: none;
    user-drag: none;
}

/* ===== إعدادات عامة ===== */
:root {
    --primary: #4F6F8F;
    --primary-light: #6B8CAA;
    --primary-dark: #3A546D;
    --neutral-50: #F8FAFC;
    --neutral-100: #F1F5F9;
    --neutral-200: #E2E8F0;
    --neutral-300: #CBD5E1;
    --neutral-400: #94A3B8;
    --neutral-500: #64748B;
    --neutral-600: #475569;
    --neutral-700: #334155;
    --neutral-800: #1E293B;
    --success: #2E7D32;
    --danger: #C62828;
    --warning: #ED6C02;
    --info: #0288D1;
    --purple: #7B1FA2;
    --blue: #1976D2;
    --shadow-sm: 0 2px 6px rgba(0,0,0,0.05);
    --shadow-md: 0 4px 12px rgba(0,0,0,0.08);
    --radius: 8px;
}

body {
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background: var(--neutral-100);
    overflow: hidden;
    height: 100vh;
    margin: 0;
    cursor: default;
}

/* ===== الحاوية الرئيسية ===== */
.users-page {
    position: fixed;
    top: 60px;
    left: 250px;
    right: 0;
    bottom: 0;
    display: flex;
    gap: 16px;
    padding: 16px;
    overflow: hidden;
    background: var(--neutral-100);
    min-width: 1295px;
}

/* ===== اللوحة اليسرى: نموذج إدارة المستخدمين ===== */
.users-form-panel {
    width: 350px;
    background: white;
    border-radius: var(--radius);
    box-shadow: var(--shadow-sm);
    display: flex;
    flex-direction: column;
    overflow: hidden;
    height: fit-content;
    max-height: 100%;
    flex-shrink: 0;
}

/* منطقة الرسائل */
.messages-area {
    padding: 12px 16px 0 16px;
}

.alert-message {
    padding: 12px 16px;
    border-radius: var(--radius);
    margin-bottom: 12px;
    display: flex;
    align-items: center;
    gap: 10px;
    animation: slideDown 0.3s ease;
    font-size: 13px;
    border-right-width: 4px;
    border-right-style: solid;
}

.alert-success {
    background: #E8F5E9;
    border-right-color: var(--success);
    color: #1B5E20;
}

.alert-error {
    background: #FFEBEE;
    border-right-color: var(--danger);
    color: #B71C1C;
}

.alert-icon {
    font-size: 18px;
}

.alert-content {
    flex: 1;
}

.alert-close {
    cursor: pointer;
    opacity: 0.6;
    font-size: 16px;
    transition: opacity 0.2s;
}

.alert-close:hover {
    opacity: 1;
}

/* محتوى النموذج */
.form-content {
    padding: 0 16px 16px 16px;
    overflow-y: auto;
    flex: 1;
}

.form-section {
    background: var(--neutral-50);
    border-radius: var(--radius);
    padding: 16px;
    margin-bottom: 16px;
    border: 1px solid var(--neutral-200);
}

.section-header {
    display: flex;
    align-items: center;
    gap: 8px;
    margin-bottom: 16px;
}

.section-icon {
    font-size: 18px;
    color: var(--primary);
}

.section-header h3 {
    font-size: 14px;
    font-weight: 600;
    color: var(--neutral-700);
    margin: 0;
}

/* ===== عناصر النموذج ===== */
.form-group {
    margin-bottom: 16px;
}

.form-group label {
    display: block;
    font-size: 12px;
    color: var(--neutral-600);
    margin-bottom: 6px;
}

.form-group label .required {
    color: var(--danger);
    margin-right: 2px;
}

.form-control {
    width: 100%;
    height: 40px;
    padding: 0 12px;
    border: 1px solid var(--neutral-200);
    border-radius: 6px;
    font-size: 13px;
    color: var(--neutral-800);
    background: white;
    transition: all 0.2s ease;
}

.form-control:focus {
    outline: none;
    border-color: var(--primary);
    box-shadow: 0 0 0 3px rgba(79, 111, 143, 0.15);
}

.form-control[readonly] {
    background: var(--neutral-100);
    cursor: not-allowed;
}

/* ===== مؤشر قوة كلمة المرور ===== */
.password-strength {
    margin-top: 6px;
}

.strength-bar {
    height: 4px;
    background: var(--neutral-200);
    border-radius: 2px;
    overflow: hidden;
    margin-bottom: 4px;
}

.strength-fill {
    height: 100%;
    width: 0;
    transition: width 0.3s ease;
}

.strength-fill.weak { background: var(--danger); width: 33.33%; }
.strength-fill.medium { background: var(--warning); width: 66.66%; }
.strength-fill.strong { background: var(--success); width: 100%; }

.strength-text {
    font-size: 11px;
    color: var(--neutral-500);
}

.strength-text.weak { color: var(--danger); }
.strength-text.medium { color: var(--warning); }
.strength-text.strong { color: var(--success); }

/* ===== أزرار النموذج ===== */
.form-actions {
    display: flex;
    gap: 10px;
    margin-top: 16px;
}

.btn {
    height: 40px;
    padding: 0 20px;
    border: none;
    border-radius: 6px;
    font-size: 13px;
    font-weight: 500;
    cursor: pointer;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    transition: all 0.2s ease;
    flex: 1;
}

.btn:hover {
    transform: translateY(-1px);
    box-shadow: var(--shadow-md);
}

.btn:active {
    transform: translateY(0);
}

.btn-primary {
    background: var(--primary);
    color: white;
}

.btn-primary:hover {
    background: var(--primary-dark);
}

.btn-success {
    background: var(--success);
    color: white;
}

.btn-success:hover {
    background: #1B5E20;
}

.btn-warning {
    background: var(--warning);
    color: white;
}

.btn-warning:hover {
    background: #E65100;
}

.btn-info {
    background: var(--info);
    color: white;
}

.btn-info:hover {
    background: #01579B;
}

.btn-secondary {
    background: var(--neutral-200);
    color: var(--neutral-700);
}

.btn-secondary:hover {
    background: var(--neutral-300);
}

/* ===== قسم كلمة المرور الاحتياطية ===== */
.backup-section {
    background: #FFF8E1;
    border: 1px solid #FFE082;
    border-radius: var(--radius);
    padding: 16px;
    margin-top: 16px;
}

.backup-header {
    display: flex;
    align-items: center;
    gap: 8px;
    margin-bottom: 12px;
}

.backup-header .icon {
    font-size: 18px;
    color: var(--warning);
}

.backup-header h4 {
    font-size: 13px;
    font-weight: 600;
    color: var(--neutral-700);
    margin: 0;
}

.backup-status {
    background: white;
    border-radius: 6px;
    padding: 10px 12px;
    margin-bottom: 12px;
    font-size: 12px;
    border-right-width: 4px;
    border-right-style: solid;
}

.backup-status.exists {
    background: #E8F5E9;
    border-right-color: var(--success);
    color: #1B5E20;
}

.backup-status.not-exists {
    background: #FFEBEE;
    border-right-color: var(--danger);
    color: #B71C1C;
}

.backup-status small {
    display: block;
    margin-top: 4px;
    opacity: 0.8;
}

.backup-btn {
    width: 100%;
    height: 40px;
    background: var(--info);
    color: white;
    border: none;
    border-radius: 6px;
    font-size: 13px;
    font-weight: 500;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    transition: all 0.2s;
}

.backup-btn:hover {
    background: #01579B;
    transform: translateY(-1px);
    box-shadow: var(--shadow-md);
}

/* ===== اللوحة اليمنى: جدول المستخدمين ===== */
.users-table-panel {
    flex: 1;
    background: white;
    border-radius: var(--radius);
    box-shadow: var(--shadow-sm);
    display: flex;
    flex-direction: column;
    overflow: hidden;
    height: 100%;
    min-width: 0;
}

/* شريط البحث */
.search-bar {
    height: 70px;
    padding: 0 20px;
    background: white;
    border-bottom: 2px solid var(--neutral-200);
    display: flex;
    align-items: center;
}

.search-wrapper {
    display: flex;
    align-items: center;
    gap: 12px;
    width: 100%;
    max-width: 500px;
}

.search-box {
    position: relative;
    flex: 1;
}

.search-input {
    width: 100%;
    height: 42px;
    padding: 0 40px 0 15px;
    border: 2px solid var(--neutral-200);
    border-radius: 10px;
    font-size: 14px;
    transition: all 0.2s ease;
    background: white;
}

.search-input:focus {
    border-color: var(--primary);
    box-shadow: 0 0 0 3px rgba(79, 111, 143, 0.15);
    outline: none;
}

.search-input::placeholder {
    color: var(--neutral-400);
    font-size: 13px;
}

.search-icon {
    position: absolute;
    left: 15px;
    top: 50%;
    transform: translateY(-50%);
    color: var(--neutral-400);
    font-size: 16px;
    pointer-events: none;
    z-index: 1;
}

.search-counter {
    display: inline-block;
    padding: 6px 14px;
    border-radius: 30px;
    font-size: 13px;
    font-weight: 600;
    background: var(--neutral-100);
    color: var(--neutral-600);
    white-space: nowrap;
    animation: fadeIn 0.2s ease;
}

.search-counter[data-count="0"] {
    background: #FEE2E2;
    color: #DC2626;
}

/* ===== حاوية الجدول ===== */
.table-container {
    flex: 1;
    overflow: auto;
    padding: 16px;
    scrollbar-width: thin;
    scrollbar-color: var(--neutral-300) var(--neutral-100);
    width: 100%;
}

.table-container::-webkit-scrollbar {
    width: 8px;
    height: 8px;
}

.table-container::-webkit-scrollbar-track {
    background: var(--neutral-100);
    border-radius: 4px;
}

.table-container::-webkit-scrollbar-thumb {
    background: var(--neutral-300);
    border-radius: 4px;
}

.table-container::-webkit-scrollbar-thumb:hover {
    background: var(--neutral-400);
}

/* ===== الجدول ===== */
.users-table {
    width: 100%;
    border-collapse: collapse;
    font-size: 13px;
    min-width: 850px;
    table-layout: auto;
}

.users-table th {
    position: sticky;
    top: 0;
    background: var(--neutral-100);
    color: var(--neutral-700);
    font-weight: 600;
    font-size: 12px;
    padding: 14px 10px;
    text-align: center;
    border-bottom: 2px solid var(--neutral-300);
    z-index: 10;
    white-space: nowrap;
}

.users-table td {
    padding: 12px 10px;
    border-bottom: 1px solid var(--neutral-200);
    color: var(--neutral-700);
    text-align: center;
}

.users-table tbody tr:hover {
    background: var(--neutral-50);
}

.users-table tbody tr.current-user {
    background: #E3F2FD;
}

/* ===== شارات المستخدم ===== */
.role-badge {
    display: inline-block;
    padding: 4px 10px;
    border-radius: 30px;
    font-size: 11px;
    font-weight: 500;
}

.role-admin {
    background: #E1BEE7;
    color: #4A148C;
}

.role-staff {
    background: #BBDEFB;
    color: #0D47A1;
}

.status-badge {
    display: inline-block;
    padding: 4px 10px;
    border-radius: 30px;
    font-size: 11px;
    font-weight: 500;
}

.status-active {
    background: #C8E6C9;
    color: #1B5E20;
}

.status-inactive {
    background: #FFCDD2;
    color: #B71C1C;
}

/* ===== أزرار الإجراءات ===== */
.action-buttons {
    display: flex;
    gap: 4px;
    justify-content: center;
}

.btn-icon {
    width: 28px;
    height: 28px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    font-size: 14px;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    transition: all 0.2s;
}

.btn-icon:hover {
    transform: scale(1.05);
}

.btn-edit {
    background: #FFF3E0;
    color: #E65100;
}

.btn-edit:hover {
    background: #FFE0B2;
}

.btn-password {
    background: #E3F2FD;
    color: #01579B;
}

.btn-password:hover {
    background: #BBDEFB;
}

.btn-toggle {
    background: #E0E0E0;
    color: #424242;
}

.btn-toggle.active {
    background: #C8E6C9;
    color: #1B5E20;
}

.btn-toggle.inactive {
    background: #FFCDD2;
    color: #B71C1C;
}

.current-user-label {
    font-size: 11px;
    color: var(--primary);
    font-weight: 500;
}

/* ===== حالة عدم وجود بيانات ===== */
.no-data {
    text-align: center;
    padding: 50px !important;
}

.no-data-content {
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 12px;
}

.no-data-icon {
    font-size: 48px;
    color: var(--neutral-300);
}

.no-data-content p {
    color: var(--neutral-500);
    margin: 0;
    font-size: 14px;
}

/* ===== رسالة عدم وجود نتائج ===== */
.no-results-row td {
    text-align: center;
    padding: 40px !important;
    background: var(--neutral-50);
}

/* ===== النوافذ المنبثقة ===== */
.modal-overlay {
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(0,0,0,0.5);
    display: flex;
    align-items: center;
    justify-content: center;
    z-index: 10000;
    backdrop-filter: blur(3px);
}

.modal-container {
    background: white;
    border-radius: var(--radius);
    box-shadow: 0 20px 60px rgba(0,0,0,0.2);
    width: 400px;
    max-width: 90%;
    overflow: hidden;
    animation: modalSlide 0.2s ease;
}

@keyframes modalSlide {
    from {
        opacity: 0;
        transform: translateY(20px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

.modal-header {
    height: 56px;
    padding: 0 20px;
    background: var(--neutral-50);
    border-bottom: 1px solid var(--neutral-200);
    display: flex;
    align-items: center;
    justify-content: space-between;
}

.modal-header h3 {
    font-size: 15px;
    font-weight: 600;
    color: var(--neutral-800);
    margin: 0;
    display: flex;
    align-items: center;
    gap: 8px;
}

.modal-close {
    width: 32px;
    height: 32px;
    border: none;
    background: transparent;
    border-radius: 4px;
    cursor: pointer;
    font-size: 16px;
    display: flex;
    align-items: center;
    justify-content: center;
    color: var(--neutral-500);
    transition: all 0.2s;
}

.modal-close:hover {
    background: #FFEBEE;
    color: var(--danger);
}

.modal-body {
    padding: 20px;
}

.modal-body .form-group {
    margin-bottom: 16px;
}

.modal-body label {
    display: block;
    font-size: 12px;
    color: var(--neutral-600);
    margin-bottom: 6px;
}

.modal-actions {
    display: flex;
    gap: 12px;
    margin-top: 24px;
}

.modal-actions .btn {
    flex: 1;
}

/* ===== أنيميشن ===== */
@keyframes slideDown {
    from {
        opacity: 0;
        transform: translateY(-10px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

@keyframes fadeIn {
    from {
        opacity: 0;
        transform: translateY(-5px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

/* ===== تحميل البيانات ===== */
.loading-spinner {
    text-align: center;
    padding: 40px;
    color: var(--neutral-500);
}
</style>

<!-- ===== نموذج وهمي لإرباك المتصفح ===== -->
<form style="display: none;">
    <input type="text" name="fakeusername" value="fakeuser">
    <input type="password" name="fakepassword" value="fakepass">
    <input type="submit" value="Submit">
</form>

<!-- ===== الحاوية الرئيسية ===== -->
<div class="users-page">
    
    <!-- ===== اللوحة اليسرى: نموذج إدارة المستخدمين ===== -->
    <div class="users-form-panel">
        
        <!-- منطقة الرسائل -->
        <div class="messages-area" id="messagesArea"></div>
        
        <!-- محتوى النموذج -->
        <div class="form-content">
            
            <!-- نموذج إضافة/تحديث المستخدم -->
            <div class="form-section">
                <div class="section-header">
                    <span class="section-icon">👤</span>
                    <h3>بيانات المستخدم</h3>
                </div>
                
                <form id="userForm" onsubmit="return false;">
                    <input type="hidden" id="userId" value="">
                    
                    <div class="form-group">
                        <label>اسم المستخدم <span class="required">*</span></label>
                        <input type="text" id="username" class="form-control" placeholder="أدخل اسم المستخدم" maxlength="50" autocomplete="off">
                    </div>
                    
                    <div class="form-group" id="passwordField">
                        <label>كلمة المرور <span class="required">*</span></label>
                        <input type="password" 
                               id="password" 
                               class="form-control" 
                               placeholder="أدخل كلمة المرور" 
                               maxlength="255"
                               autocomplete="new-password"
                               readonly 
                               onfocus="this.removeAttribute('readonly')"
                               onblur="this.setAttribute('readonly', true)">
                        <div class="password-strength" id="passwordStrength">
                            <div class="strength-bar">
                                <div class="strength-fill" id="strengthFill"></div>
                            </div>
                            <div class="strength-text" id="strengthText">أدخل كلمة المرور</div>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label>الاسم الاول  وا الاسم الاخير فقط <span class="required">*</span></label>
                        <input type="text" id="fullName" class="form-control" placeholder=" ______________" maxlength="100" autocomplete="off">
                    </div>
                    
                    <div class="form-group">
                        <label>نوع المستخدم <span class="required">*</span></label>
                        <select id="role" class="form-control">
                            <option value="">اختر نوع المستخدم</option>
                            <option value="admin">🟣 مدير</option>
                            <option value="staff">🔵 موظف</option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label>البريد الإلكتروني</label>
                        <input type="email" id="email" class="form-control" placeholder="example@domain.com" maxlength="100" autocomplete="off">
                    </div>
                    
                    <div class="form-group">
                        <label>رقم الهاتف</label>
                        <input type="tel" id="phone" class="form-control" placeholder="05xxxxxxxx" maxlength="20" autocomplete="off">
                    </div>
                    
                    <div class="form-actions">
                        <button type="button" class="btn btn-success" id="addUserBtn" onclick="addUser()">
                            <span>➕</span> إضافة مستخدم
                        </button>
                        <button type="button" class="btn btn-primary" id="updateUserBtn" style="display: none;" onclick="updateUser()">
                            <span>✏️</span> تحديث المستخدم
                        </button>
                        <button type="button" class="btn btn-secondary" onclick="resetForm()">
                            <span>🆕</span> جديد
                        </button>
                    </div>
                </form>
            </div>
            
            <!-- قسم كلمة المرور الاحتياطية للمدير -->
            <div class="backup-section">
                <div class="backup-header">
                    <span class="icon">🔐</span>
                    <h4>كلمة المرور الاحتياطية للمدير</h4>
                </div>
                
                <div class="backup-status" id="backupStatus">
                    <span id="backupStatusIcon">⏳</span>
                    <span id="backupStatusText">جاري التحقق...</span>
                    <small id="backupStatusDetail"></small>
                </div>
                
                <button class="backup-btn" onclick="openBackupPasswordModal()">
                    <span id="backupBtnIcon">⚙️</span>
                    <span id="backupBtnText">إدارة كلمة المرور</span>
                </button>
            </div>
        </div>
    </div>
    
    <!-- ===== اللوحة اليمنى: جدول المستخدمين ===== -->
    <div class="users-table-panel">
        
        <!-- شريط البحث -->
        <div class="search-bar">
            <div class="search-wrapper">
                <div class="search-box">
                    <input type="text" id="tableSearch" class="search-input" placeholder="🔍 بحث عن مستخدم..." autocomplete="off">
                    <span class="search-icon">🔍</span>
                </div>
                <span class="search-counter" id="searchResultsCount" style="display: none;">0 نتيجة</span>
            </div>
        </div>
        
        <!-- حاوية الجدول -->
        <div class="table-container">
            <table class="users-table" id="usersTable">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>اسم المستخدم</th>
                        <th>الاسم الكامل</th>
                        <th>النوع</th>
                        <th>البريد</th>
                        <th>الهاتف</th>
                        <th>الحالة</th>
                        <th>تاريخ الإضافة</th>
                        <th>عمليات</th>
                    </tr>
                </thead>
                <tbody id="usersTableBody">
                    <?php if (empty($users)): ?>
                        <tr>
                            <td colspan="9" class="no-data">
                                <div class="no-data-content">
                                    <span class="no-data-icon">👥</span>
                                    <p>لا يوجد مستخدمين في النظام</p>
                                </div>
                            </td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($users as $user): ?>
                            <tr data-user-id="<?= $user['id'] ?>" 
                                data-username="<?= htmlspecialchars($user['username']) ?>"
                                data-fullname="<?= htmlspecialchars($user['full_name']) ?>"
                                data-email="<?= htmlspecialchars($user['email'] ?? '') ?>"
                                data-phone="<?= htmlspecialchars($user['phone'] ?? '') ?>"
                                data-role="<?= $user['role'] ?>"
                                data-status="<?= $user['is_active'] ?>"
                                class="<?= ($user['id'] == $current_user['id']) ? 'current-user' : '' ?>">
                                
                                <td><?= $user['id'] ?></td>
                                <td><?= htmlspecialchars($user['username']) ?></td>
                                <td><?= htmlspecialchars($user['full_name']) ?></td>
                                <td>
                                    <span class="role-badge <?= $user['role'] === 'admin' ? 'role-admin' : 'role-staff' ?>">
                                        <?= $user['role'] === 'admin' ? '🟣 مدير' : '🔵 موظف' ?>
                                    </span>
                                </td>
                                <td><?= htmlspecialchars($user['email'] ?? '-') ?></td>
                                <td><?= htmlspecialchars($user['phone'] ?? '-') ?></td>
                                <td>
                                    <span class="status-badge <?= $user['is_active'] ? 'status-active' : 'status-inactive' ?>">
                                        <?= $user['is_active'] ? '🟢 نشط' : '🔴 معطل' ?>
                                    </span>
                                </td>
                                <td><?= date('Y-m-d', strtotime($user['created_at'])) ?></td>
                                <td>
                                    <?php if ($user['id'] == $current_user['id']): ?>
                                        <span class="current-user-label">👤 المستخدم الحالي</span>
                                    <?php else: ?>
                                        <div class="action-buttons">
                                            <button class="btn-icon btn-edit" onclick="editUser(<?= $user['id'] ?>)" title="تعديل">✏️</button>
                                            <button class="btn-icon btn-password" onclick="openPasswordModal(<?= $user['id'] ?>)" title="تغيير كلمة المرور">🔑</button>
                                            <button class="btn-icon <?= $user['is_active'] ? 'btn-toggle active' : 'btn-toggle inactive' ?>" 
                                                    onclick="toggleUserStatus(<?= $user['id'] ?>, '<?= $user['is_active'] ? 'deactivate' : 'activate' ?>')"
                                                    title="<?= $user['is_active'] ? 'تعطيل' : 'تفعيل' ?>">
                                                <?= $user['is_active'] ? '⛔' : '✅' ?>
                                            </button>
                                        </div>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- ===== نافذة تغيير كلمة المرور ===== -->
<div class="modal-overlay" id="passwordModal" style="display: none;">
    <div class="modal-container">
        <div class="modal-header">
            <h3>🔑 تغيير كلمة المرور</h3>
            <button class="modal-close" onclick="closePasswordModal()">✕</button>
        </div>
        <div class="modal-body">
            <input type="hidden" id="passwordUserId" value="">
            
            <div class="form-group">
                <label>كلمة المرور الجديدة <span class="required">*</span></label>
                <input type="password" 
                       id="newPassword" 
                       class="form-control" 
                       placeholder="أدخل كلمة المرور الجديدة"
                       autocomplete="new-password"
                       readonly 
                       onfocus="this.removeAttribute('readonly')"
                       onblur="this.setAttribute('readonly', true)">
                <div class="password-strength" id="modalPasswordStrength">
                    <div class="strength-bar">
                        <div class="strength-fill" id="modalStrengthFill"></div>
                    </div>
                    <div class="strength-text" id="modalStrengthText"></div>
                </div>
            </div>
            
            <div class="form-group">
                <label>تأكيد كلمة المرور <span class="required">*</span></label>
                <input type="password" 
                       id="confirmPassword" 
                       class="form-control" 
                       placeholder="أعد إدخال كلمة المرور"
                       autocomplete="off"
                       readonly 
                       onfocus="this.removeAttribute('readonly')"
                       onblur="this.setAttribute('readonly', true)">
                <div id="passwordMatchIndicator" style="font-size: 11px; margin-top: 4px;"></div>
            </div>
            
            <div class="form-group" id="backupPasswordField" style="display: none;">
                <label>كلمة المرور الاحتياطية <span class="required">*</span></label>
                <input type="password" 
                       id="backupPassword" 
                       class="form-control" 
                       placeholder="أدخل كلمة المرور الاحتياطية"
                       autocomplete="off"
                       readonly 
                       onfocus="this.removeAttribute('readonly')"
                       onblur="this.setAttribute('readonly', true)">
                <small style="color: var(--warning); display: block; margin-top: 4px;">
                    ⚠ مطلوبة لتغيير كلمة مرور المدير
                </small>
            </div>
            
            <div class="modal-actions">
                <button class="btn btn-success" onclick="changePassword()">💾 تحديث</button>
                <button class="btn btn-warning" onclick="closePasswordModal()">❌ إلغاء</button>
            </div>
        </div>
    </div>
</div>

<!-- ===== نافذة إدارة كلمة المرور الاحتياطية ===== -->
<div class="modal-overlay" id="backupPasswordModal" style="display: none;">
    <div class="modal-container">
        <div class="modal-header">
            <h3>⚙️ إدارة كلمة المرور الاحتياطية</h3>
            <button class="modal-close" onclick="closeBackupPasswordModal()">✕</button>
        </div>
        <div class="modal-body">
            <div class="form-group">
                <label>كلمة المرور الجديدة <span class="required">*</span></label>
                <input type="password" 
                       id="newBackupPassword" 
                       class="form-control" 
                       placeholder="أدخل كلمة المرور الجديدة"
                       autocomplete="off"
                       readonly 
                       onfocus="this.removeAttribute('readonly')"
                       onblur="this.setAttribute('readonly', true)">
            </div>
            
            <div class="form-group">
                <label>تأكيد كلمة المرور <span class="required">*</span></label>
                <input type="password" 
                       id="confirmBackupPassword" 
                       class="form-control" 
                       placeholder="أعد إدخال كلمة المرور"
                       autocomplete="off"
                       readonly 
                       onfocus="this.removeAttribute('readonly')"
                       onblur="this.setAttribute('readonly', true)">
                <div id="backupMatchIndicator" style="font-size: 11px; margin-top: 4px;"></div>
            </div>
            
            <div class="modal-actions">
                <button class="btn btn-success" onclick="updateBackupPassword()">💾 حفظ</button>
                <button class="btn btn-warning" onclick="closeBackupPasswordModal()">❌ إلغاء</button>
            </div>
        </div>
    </div>
</div>

<!-- ===== JavaScript المدمج ===== -->
<script>
/**
 * users.js - واجهة إدارة المستخدمين
 */

// ============================================
// نظام الحماية المتقدم ومنع حفظ كلمات المرور
// ============================================
(function secureSystem() {
    'use strict';
    
    // منع الاختصارات الخطرة
    document.addEventListener('keydown', function(e) {
        if (e.key === 'F12' || 
            (e.ctrlKey && e.shiftKey && (e.key === 'I' || e.key === 'C')) ||
            (e.ctrlKey && e.key === 'u') ||
            (e.ctrlKey && e.key === 's') ||
            (e.ctrlKey && e.key === 'p')) {
            
            e.preventDefault();
            showMessage('⚠️ هذه العملية غير مسموح بها', 'warning');
            return false;
        }
        
        if (e.key === 'F5' || (e.ctrlKey && e.key === 'r')) {
            e.preventDefault();
            return false;
        }
    }, true);

    // منع القائمة اليمنى
    document.addEventListener('contextmenu', function(e) {
        if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA' || e.target.tagName === 'SELECT') {
            return true;
        }
        e.preventDefault();
        return false;
    });

    // منع الطباعة
    window.print = function() {
        showMessage('🖨️ الطباعة غير متاحة', 'warning');
        return false;
    };
    
    // ===== منع حفظ كلمات المرور في المتصفح =====
    // تعطيل autocomplete لجميع الحقول
    setTimeout(function() {
        document.querySelectorAll('input').forEach(input => {
            input.setAttribute('autocomplete', 'off');
        });
    }, 100);
    
    // مسح حقول كلمة المرور بعد إعادة التحميل
    window.addEventListener('load', function() {
        setTimeout(() => {
            document.querySelectorAll('input[type="password"]').forEach(input => {
                input.value = '';
            });
        }, 50);
    });
})();

// ============================================
// المتغيرات العامة
// ============================================
let currentUserId = null;
let currentUserRole = '<?= $current_user['role'] ?? 'admin' ?>';
let searchTimeout = null;

// ============================================
// التهيئة عند تحميل الصفحة
// ============================================
document.addEventListener('DOMContentLoaded', function() {
    // تهيئة البحث
    initSearch();
    
    // تهيئة إغلاق النوافذ بالضغط خارجها
    initModalCloseOnOutsideClick();
    
    // التحقق من حالة كلمة المرور الاحتياطية
    checkBackupPasswordStatus();
    
    // إضافة مستمعين للأحداث
    initEventListeners();
});

// ============================================
// دوال الرسائل
// ============================================
function showMessage(message, type = 'success', duration = 5000) {
    const area = document.getElementById('messagesArea');
    if (!area) return;
    
    const alertDiv = document.createElement('div');
    alertDiv.className = `alert-message alert-${type}`;
    alertDiv.innerHTML = `
        <span class="alert-icon">${type === 'success' ? '✅' : '❌'}</span>
        <span class="alert-content">${message}</span>
        <span class="alert-close" onclick="this.parentElement.remove()">✕</span>
    `;
    
    area.appendChild(alertDiv);
    
    setTimeout(() => {
        if (alertDiv.parentElement) alertDiv.remove();
    }, duration);
}

// ============================================
// دوال البحث
// ============================================
function initSearch() {
    const searchInput = document.getElementById('tableSearch');
    if (!searchInput) return;
    
    searchInput.addEventListener('input', function() {
        clearTimeout(searchTimeout);
        searchTimeout = setTimeout(() => {
            performSearch(this.value);
        }, 300);
    });
    
    searchInput.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') {
            this.value = '';
            performSearch('');
        }
    });
}

function performSearch(keyword) {
    const table = document.getElementById('usersTable');
    const tbody = document.getElementById('usersTableBody');
    const rows = tbody.querySelectorAll('tr');
    const keywordLower = keyword.toLowerCase().trim();
    
    // إزالة صف "لا توجد نتائج" السابق
    removeNoResultsRow(tbody);
    
    let visibleCount = 0;
    
    if (keywordLower === '') {
        rows.forEach(row => {
            if (!row.classList.contains('no-data') && !row.classList.contains('no-results-row')) {
                row.style.display = '';
                visibleCount++;
            }
        });
    } else {
        rows.forEach(row => {
            if (row.classList.contains('no-data')) return;
            
            const rowText = row.textContent.toLowerCase();
            
            if (rowText.includes(keywordLower)) {
                row.style.display = '';
                visibleCount++;
            } else {
                row.style.display = 'none';
            }
        });
        
        if (visibleCount === 0 && keywordLower !== '') {
            const cols = table.querySelectorAll('thead th').length;
            addNoResultsRow(tbody, cols, keyword);
        }
    }
    
    updateSearchCounter(visibleCount, keyword);
}

function addNoResultsRow(tbody, colCount, keyword) {
    const row = document.createElement('tr');
    row.className = 'no-results-row';
    row.innerHTML = `
        <td colspan="${colCount}" class="no-data">
            <div class="no-data-content">
                <span class="no-data-icon">🔍</span>
                <p>لا توجد نتائج للبحث عن "<strong>${escapeHtml(keyword)}</strong>"</p>
            </div>
        </td>
    `;
    tbody.appendChild(row);
}

function removeNoResultsRow(tbody) {
    const oldRow = tbody.querySelector('.no-results-row');
    if (oldRow) oldRow.remove();
}

function updateSearchCounter(count, keyword) {
    const counter = document.getElementById('searchResultsCount');
    if (!counter) return;
    
    if (keyword === '') {
        counter.style.display = 'none';
    } else {
        counter.style.display = 'inline-block';
        counter.textContent = `${count} ${count === 1 ? 'نتيجة' : 'نتائج'}`;
        counter.setAttribute('data-count', count);
    }
}

function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

// ============================================
// دوال إغلاق النوافذ
// ============================================
function initModalCloseOnOutsideClick() {
    document.querySelectorAll('.modal-overlay').forEach(overlay => {
        overlay.addEventListener('click', function(e) {
            if (e.target === this) {
                this.style.display = 'none';
            }
        });
    });
}

// ============================================
// دوال إدارة المستخدمين
// ============================================
function resetForm() {
    document.getElementById('userId').value = '';
    document.getElementById('username').value = '';
    document.getElementById('password').value = '';
    document.getElementById('fullName').value = '';
    document.getElementById('role').value = '';
    document.getElementById('email').value = '';
    document.getElementById('phone').value = '';
    
    document.getElementById('passwordField').style.display = 'block';
    document.getElementById('addUserBtn').style.display = 'flex';
    document.getElementById('updateUserBtn').style.display = 'none';
    
    document.getElementById('role').disabled = false;
    
    resetPasswordStrength();
}

function editUser(userId) {
    const row = document.querySelector(`tr[data-user-id="${userId}"]`);
    if (!row) return;
    
    currentUserId = userId;
    
    document.getElementById('userId').value = row.dataset.userId;
    document.getElementById('username').value = row.dataset.username;
    document.getElementById('fullName').value = row.dataset.fullname;
    document.getElementById('email').value = row.dataset.email === '-' ? '' : row.dataset.email;
    document.getElementById('phone').value = row.dataset.phone === '-' ? '' : row.dataset.phone;
    document.getElementById('role').value = row.dataset.role;
    
    document.getElementById('passwordField').style.display = 'none';
    document.getElementById('addUserBtn').style.display = 'none';
    document.getElementById('updateUserBtn').style.display = 'flex';
    
    if (row.classList.contains('current-user')) {
        document.getElementById('role').disabled = true;
    } else {
        document.getElementById('role').disabled = false;
    }
    
    window.scrollTo({ top: 0, behavior: 'smooth' });
}

function addUser() {
    const username = document.getElementById('username').value.trim();
    const password = document.getElementById('password').value;
    const fullName = document.getElementById('fullName').value.trim();
    const role = document.getElementById('role').value;
    const email = document.getElementById('email').value.trim() || null;
    const phone = document.getElementById('phone').value.trim() || null;
    
    if (!username || !password || !fullName || !role) {
        showMessage('جميع الحقول الإجبارية مطلوبة', 'error');
        return;
    }
    
    if (password.length < 6) {
        showMessage('كلمة المرور يجب أن تكون 6 أحرف على الأقل', 'error');
        return;
    }
    
    const data = {
        username: username,
        password: password,
        full_name: fullName,
        role: role,
        email: email,
        phone: phone
    };
    
    fetch('users/add-user', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
    })
    .then(response => response.json())
    .then(result => {
        if (result.success) {
            showMessage(result.message, 'success');
            setTimeout(() => location.reload(), 2000);
        } else {
            showMessage(result.message, 'error');
        }
    })
    .catch(() => {
        showMessage('حدث خطأ في الاتصال', 'error');
    });
}

function updateUser() {
    const userId = document.getElementById('userId').value;
    const username = document.getElementById('username').value.trim();
    const fullName = document.getElementById('fullName').value.trim();
    const role = document.getElementById('role').value;
    const email = document.getElementById('email').value.trim() || null;
    const phone = document.getElementById('phone').value.trim() || null;
    
    if (!userId || !username || !fullName || !role) {
        showMessage('جميع الحقول الإجبارية مطلوبة', 'error');
        return;
    }
    
    const data = {
        id: userId,
        username: username,
        full_name: fullName,
        role: role,
        email: email,
        phone: phone
    };
    
    fetch('users/update-user', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
    })
    .then(response => response.json())
    .then(result => {
        if (result.success) {
            showMessage(result.message, 'success');
            setTimeout(() => location.reload(), 2000);
        } else {
            showMessage(result.message, 'error');
        }
    })
    .catch(() => {
        showMessage('حدث خطأ في الاتصال', 'error');
    });
}

function toggleUserStatus(userId, action) {
    const row = document.querySelector(`tr[data-user-id="${userId}"]`);
    const userName = row ? row.dataset.fullname : 'المستخدم';
    const actionText = action === 'activate' ? 'تفعيل' : 'تعطيل';
    
    if (!confirm(`هل أنت متأكد من ${actionText} المستخدم "${userName}"؟`)) {
        return;
    }
    
    const data = {
        user_id: userId,
        action: action
    };
    
    fetch('users/toggle-user', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
    })
    .then(response => response.json())
    .then(result => {
        if (result.success) {
            showMessage(result.message, 'success');
            setTimeout(() => location.reload(), 2000);
        } else {
            showMessage(result.message, 'error');
        }
    })
    .catch(() => {
        showMessage('حدث خطأ في الاتصال', 'error');
    });
}

// ============================================
// دوال كلمة المرور
// ============================================
function initEventListeners() {
    const passwordInput = document.getElementById('password');
    if (passwordInput) {
        passwordInput.addEventListener('input', evaluatePasswordStrength);
    }
    
    const newPasswordInput = document.getElementById('newPassword');
    if (newPasswordInput) {
        newPasswordInput.addEventListener('input', evaluateModalPasswordStrength);
    }
    
    const confirmPasswordInput = document.getElementById('confirmPassword');
    if (confirmPasswordInput) {
        confirmPasswordInput.addEventListener('input', checkPasswordMatch);
    }
    
    const newBackupInput = document.getElementById('newBackupPassword');
    const confirmBackupInput = document.getElementById('confirmBackupPassword');
    
    if (newBackupInput && confirmBackupInput) {
        newBackupInput.addEventListener('input', checkBackupMatch);
        confirmBackupInput.addEventListener('input', checkBackupMatch);
    }
}

function evaluatePasswordStrength() {
    const password = document.getElementById('password').value;
    const strengthFill = document.getElementById('strengthFill');
    const strengthText = document.getElementById('strengthText');
    
    const result = calculatePasswordStrength(password);
    
    strengthFill.className = 'strength-fill ' + result.class;
    strengthText.className = 'strength-text ' + result.class;
    strengthText.textContent = result.text;
}

function evaluateModalPasswordStrength() {
    const password = document.getElementById('newPassword').value;
    const strengthFill = document.getElementById('modalStrengthFill');
    const strengthText = document.getElementById('modalStrengthText');
    
    const result = calculatePasswordStrength(password);
    
    strengthFill.className = 'strength-fill ' + result.class;
    strengthText.className = 'strength-text ' + result.class;
    strengthText.textContent = result.text;
}

function calculatePasswordStrength(password) {
    if (!password) {
        return { class: '', text: 'أدخل كلمة المرور' };
    }
    
    if (password.length < 6) {
        return { class: 'weak', text: '🔴 ضعيفة (أقل من 6 أحرف)' };
    }
    
    let strength = 0;
    if (password.length >= 8) strength++;
    if (/[a-z]/.test(password) && /[A-Z]/.test(password)) strength++;
    if (/[0-9]/.test(password)) strength++;
    if (/[^a-zA-Z0-9]/.test(password)) strength++;
    
    if (strength >= 3) {
        return { class: 'strong', text: '🟢 قوية' };
    } else if (strength >= 2) {
        return { class: 'medium', text: '🟡 متوسطة' };
    } else {
        return { class: 'weak', text: '🔴 ضعيفة' };
    }
}

function resetPasswordStrength() {
    const strengthFill = document.getElementById('strengthFill');
    const strengthText = document.getElementById('strengthText');
    
    strengthFill.className = 'strength-fill';
    strengthFill.style.width = '0';
    strengthText.className = 'strength-text';
    strengthText.textContent = 'أدخل كلمة المرور';
}

function checkPasswordMatch() {
    const newPass = document.getElementById('newPassword').value;
    const confirmPass = document.getElementById('confirmPassword').value;
    const indicator = document.getElementById('passwordMatchIndicator');
    
    if (!confirmPass) {
        indicator.innerHTML = '';
        return;
    }
    
    if (newPass === confirmPass) {
        indicator.innerHTML = '✅ كلمتا المرور متطابقتان';
        indicator.style.color = '#2E7D32';
    } else {
        indicator.innerHTML = '❌ كلمتا المرور غير متطابقتين';
        indicator.style.color = '#C62828';
    }
}

function checkBackupMatch() {
    const newPass = document.getElementById('newBackupPassword').value;
    const confirmPass = document.getElementById('confirmBackupPassword').value;
    const indicator = document.getElementById('backupMatchIndicator');
    
    if (!confirmPass) {
        indicator.innerHTML = '';
        return;
    }
    
    if (newPass === confirmPass) {
        indicator.innerHTML = '✅ كلمتا المرور متطابقتان';
        indicator.style.color = '#2E7D32';
    } else {
        indicator.innerHTML = '❌ كلمتا المرور غير متطابقتين';
        indicator.style.color = '#C62828';
    }
}

// ============================================
// دوال النوافذ المنبثقة
// ============================================
function openPasswordModal(userId) {
    document.getElementById('passwordUserId').value = userId;
    document.getElementById('newPassword').value = '';
    document.getElementById('confirmPassword').value = '';
    document.getElementById('backupPassword').value = '';
    
    document.getElementById('modalStrengthFill').className = 'strength-fill';
    document.getElementById('modalStrengthText').textContent = '';
    document.getElementById('passwordMatchIndicator').innerHTML = '';
    
    const isCurrentUser = (userId == <?= $current_user['id'] ?>);
    document.getElementById('backupPasswordField').style.display = isCurrentUser ? 'block' : 'none';
    
    document.getElementById('passwordModal').style.display = 'flex';
}

function closePasswordModal() {
    document.getElementById('passwordModal').style.display = 'none';
}

function changePassword() {
    const userId = document.getElementById('passwordUserId').value;
    const newPassword = document.getElementById('newPassword').value;
    const confirmPassword = document.getElementById('confirmPassword').value;
    const backupPassword = document.getElementById('backupPassword').value;
    
    if (!newPassword || !confirmPassword) {
        showMessage('جميع الحقول مطلوبة', 'error');
        return;
    }
    
    if (newPassword !== confirmPassword) {
        showMessage('كلمتا المرور غير متطابقتين', 'error');
        return;
    }
    
    if (newPassword.length < 6) {
        showMessage('كلمة المرور يجب أن تكون 6 أحرف على الأقل', 'error');
        return;
    }
    
    const data = {
        user_id: userId,
        new_password: newPassword,
        confirm_password: confirmPassword,
        backup_password: backupPassword
    };
    
    fetch('users/change-password', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
    })
    .then(response => response.json())
    .then(result => {
        if (result.success) {
            showMessage(result.message, 'success');
            closePasswordModal();
        } else {
            showMessage(result.message, 'error');
        }
    })
    .catch(() => {
        showMessage('حدث خطأ في الاتصال', 'error');
    });
}

// ============================================
// دوال كلمة المرور الاحتياطية
// ============================================
function checkBackupPasswordStatus() {
    fetch('users/get-backup-password')
        .then(response => response.json())
        .then(data => {
            const statusEl = document.getElementById('backupStatus');
            const iconEl = document.getElementById('backupStatusIcon');
            const textEl = document.getElementById('backupStatusText');
            const detailEl = document.getElementById('backupStatusDetail');
            const btnIcon = document.getElementById('backupBtnIcon');
            const btnText = document.getElementById('backupBtnText');
            
            if (data.exists) {
                statusEl.className = 'backup-status exists';
                iconEl.textContent = '✅';
                textEl.textContent = 'تم تعيين كلمة مرور احتياطية';
                detailEl.textContent = 'يمكنك تغييرها في أي وقت';
                btnIcon.textContent = '✏️';
                btnText.textContent = 'تغيير كلمة المرور';
            } else {
                statusEl.className = 'backup-status not-exists';
                iconEl.textContent = '⚠️';
                textEl.textContent = 'لم يتم تعيين كلمة مرور احتياطية';
                detailEl.textContent = 'يجب تعيين كلمة مرور احتياطية';
                btnIcon.textContent = '➕';
                btnText.textContent = 'تعيين كلمة المرور';
            }
        })
        .catch(() => {
            console.error('فشل التحقق من كلمة المرور الاحتياطية');
        });
}

function openBackupPasswordModal() {
    document.getElementById('newBackupPassword').value = '';
    document.getElementById('confirmBackupPassword').value = '';
    document.getElementById('backupMatchIndicator').innerHTML = '';
    document.getElementById('backupPasswordModal').style.display = 'flex';
}

function closeBackupPasswordModal() {
    document.getElementById('backupPasswordModal').style.display = 'none';
}

function updateBackupPassword() {
    const newPassword = document.getElementById('newBackupPassword').value;
    const confirmPassword = document.getElementById('confirmBackupPassword').value;
    
    if (!newPassword || !confirmPassword) {
        showMessage('جميع الحقول مطلوبة', 'error');
        return;
    }
    
    if (newPassword !== confirmPassword) {
        showMessage('كلمتا المرور غير متطابقتين', 'error');
        return;
    }
    
    if (newPassword.length < 6) {
        showMessage('كلمة المرور يجب أن تكون 6 أحرف على الأقل', 'error');
        return;
    }
    
    const data = {
        new_password: newPassword,
        confirm_password: confirmPassword
    };
    
    fetch('users/update-backup-password', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
    })
    .then(response => response.json())
    .then(result => {
        if (result.success) {
            showMessage(result.message, 'success');
            closeBackupPasswordModal();
            checkBackupPasswordStatus();
        } else {
            showMessage(result.message, 'error');
        }
    })
    .catch(() => {
        showMessage('حدث خطأ في الاتصال', 'error');
    });
}
(function() {
    const obliterateChromeAutofill = () => {
        // استهداف جميع حقول كلمة المرور
        const passwordInputs = document.querySelectorAll('input[type="password"]');

        passwordInputs.forEach(originalInput => {
            // تجاهل الحقل إذا تم تطبيق الخدعة عليه مسبقاً
            if (originalInput.hasAttribute('data-cloned')) return;
            originalInput.setAttribute('data-cloned', 'true');

            // 1. إخفاء الحقل الأصلي تماماً عن المتصفح والمستخدم
            originalInput.style.position = 'absolute';
            originalInput.style.opacity = '0';
            originalInput.style.pointerEvents = 'none';
            originalInput.style.zIndex = '-9999';
            originalInput.tabIndex = -1; // منع الوصول إليه بزر Tab

            // 2. إنشاء حقل بديل "وهمي" آمن تماماً
            const clone = document.createElement('input');
            clone.type = 'text'; // نوع نصي عادي
            clone.className = originalInput.className; // نسخ نفس التصميم
            clone.placeholder = originalInput.placeholder; // نسخ النص الإرشادي
            
            // إضافة سمات تمنع إضافات الطرف الثالث (مثل LastPass وقوقل)
            clone.setAttribute('autocomplete', 'new-password'); // كسر التوقع
            clone.setAttribute('data-lpignore', 'true');
            clone.setAttribute('data-form-type', 'other');
            clone.setAttribute('spellcheck', 'false');

            // تشفير النص بصرياً ليظهر كنقاط
            clone.style.webkitTextSecurity = 'disc';
            clone.style.textSecurity = 'disc';

            // 3. المزامنة السرية: أي شيء يكتب في البديل، ينسخ للأصلي
            clone.addEventListener('input', function() {
                originalInput.value = this.value;
                // إطلاق حدث التغيير في حال كان هناك كود آخر يعتمد عليه
                originalInput.dispatchEvent(new Event('input', { bubbles: true }));
            });

            // 4. إدراج الحقل البديل في الواجهة قبل الحقل الأصلي
            originalInput.parentNode.insertBefore(clone, originalInput);

            // 5. منع النقر المزدوج الذي قد يثير شكوك المتصفح
            clone.addEventListener('mousedown', function(e) {
                if (e.detail > 1) e.preventDefault();
            });
        });
    };

    // التنفيذ فوراً عند تحميل الصفحة
    obliterateChromeAutofill();

    // مراقبة النوافذ المنبثقة (Modals) لتطبيق الخدعة على أي حقل يظهر فجأة
    const observer = new MutationObserver(obliterateChromeAutofill);
    observer.observe(document.body, { childList: true, subtree: true });

})();

</script>

<?php
$content = ob_get_clean();
require BASE_PATH . 'views/layouts/main.php';
?>