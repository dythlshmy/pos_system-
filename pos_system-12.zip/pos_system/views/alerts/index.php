<?php
ob_start();
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $title ?? 'التنبيهات' ?></title>
    <link rel="stylesheet" href="<?= asset('css/style.css') ?>">
    <style>
        .alerts-page {
            padding: 20px;
            height: calc(100vh - 60px);
            overflow: hidden;
            display: flex;
            flex-direction: column;
        }

        .stats-grid {
            display: grid;
            grid-template-columns: repeat(5, 1fr);
            gap: 15px;
            margin-bottom: 20px;
        }

        .stat-card {
            background: white;
            border-radius: 10px;
            padding: 15px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            text-align: center;
            cursor: pointer;
            transition: transform 0.3s;
        }

        .stat-card:hover {
            transform: translateY(-5px);
        }

        .stat-card .number {
            font-size: 28px;
            font-weight: bold;
        }

        .stat-card .label {
            font-size: 12px;
            color: #666;
            margin-top: 5px;
        }

        .stat-card.total { background: #e3f2fd; color: #1976d2; }
        .stat-card.expiry { background: #fff3e0; color: #ed6c02; }
        .stat-card.expired { background: #ffebee; color: #c62828; }
        .stat-card.low { background: #e8f5e8; color: #2e7d32; }
        .stat-card.unread { background: #e8eaf6; color: #1a237e; }

        .action-bar {
            background: white;
            border-radius: 10px;
            padding: 15px;
            margin-bottom: 20px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
        }

        .btn {
            height: 40px;
            padding: 0 20px;
            border: none;
            border-radius: 6px;
            font-size: 14px;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }

        .btn-primary { background: #1976d2; color: white; }
        .btn-success { background: #2e7d32; color: white; }
        .btn-danger { background: #c62828; color: white; }
        .btn-info { background: #0288d1; color: white; }

        .alerts-container {
            flex: 1;
            overflow-y: auto;
            padding: 10px;
        }

        .alert-card {
            background: white;
            border-radius: 10px;
            padding: 15px;
            margin-bottom: 10px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            display: flex;
            align-items: center;
            gap: 15px;
            border-right: 4px solid;
            transition: all 0.3s;
        }

        .alert-card.unread {
            background: #f5f5f5;
        }

        .alert-card.expiry { border-right-color: #ed6c02; }
        .alert-card.expired { border-right-color: #c62828; }
        .alert-card.low { border-right-color: #2e7d32; }

        .alert-icon {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 20px;
        }

        .alert-icon.expiry { background: #fff3e0; }
        .alert-icon.expired { background: #ffebee; }
        .alert-icon.low { background: #e8f5e8; }

        .alert-content {
            flex: 1;
        }

        .alert-message {
            font-size: 14px;
            font-weight: 500;
            margin-bottom: 5px;
        }

        .alert-time {
            font-size: 11px;
            color: #999;
        }

        .alert-actions {
            display: flex;
            gap: 5px;
        }

        .alert-btn {
            width: 32px;
            height: 32px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 14px;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: all 0.3s;
        }

        .alert-btn:hover {
            transform: scale(1.1);
        }

        .btn-read { background: #e3f2fd; color: #1976d2; }
        .btn-delete { background: #ffebee; color: #c62828; }

        .empty-state {
            text-align: center;
            padding: 60px;
            background: white;
            border-radius: 10px;
        }

        .empty-state .icon {
            font-size: 60px;
            margin-bottom: 20px;
            opacity: 0.5;
        }

        .tabs {
            display: flex;
            gap: 10px;
            margin-bottom: 15px;
        }

        .tab {
            padding: 8px 16px;
            border: 1px solid #e0e0e0;
            border-radius: 20px;
            cursor: pointer;
            font-size: 13px;
            transition: all 0.3s;
        }

        .tab.active {
            background: #1a237e;
            color: white;
            border-color: #1a237e;
        }
    </style>
</head>
<body>
<!-- نظام الحماية -->
<script src="<?= BASE_URL ?>/assets/js/security.js?v=<?= time() ?>"></script>
    <div class="alerts-page">
        <!-- إحصائيات -->
        <div class="stats-grid">
            <div class="stat-card total" onclick="filterAlerts('all')">
                <div class="number"><?= $stats['total'] ?? 0 ?></div>
                <div class="label">إجمالي التنبيهات</div>
            </div>
            <div class="stat-card expiry" onclick="filterAlerts('expiry')">
                <div class="number"><?= $stats['expiry_count'] ?? 0 ?></div>
                <div class="label">قريب الانتهاء</div>
            </div>
            <div class="stat-card expired" onclick="filterAlerts('expired')">
                <div class="number"><?= $stats['expired_count'] ?? 0 ?></div>
                <div class="label">منتهي الصلاحية</div>
            </div>
            <div class="stat-card low" onclick="filterAlerts('low')">
                <div class="number"><?= $stats['low_stock_count'] ?? 0 ?></div>
                <div class="label">مخزون منخفض</div>
            </div>
            <div class="stat-card unread" onclick="filterAlerts('unread')">
                <div class="number"><?= $stats['unread_count'] ?? 0 ?></div>
                <div class="label">غير مقروء</div>
            </div>
        </div>

        <!-- شريط الإجراءات -->
        <div class="action-bar">
            <button class="btn btn-primary" onclick="markAllAsRead()">
                <span>✅</span> تحديد الكل كمقروء
            </button>
            <button class="btn btn-info" onclick="refreshAlerts()">
                <span>🔄</span> تحديث التنبيهات
            </button>
                            <div class="action-buttons" style="margin-top: 8px;">
                    <button class="btn btn-back" onclick="goBack()">
                        <span>🔙</span> عودة
                    </button>
                </div>
        </div>

        <!-- التبويبات -->
        <div class="tabs">
            <div class="tab active" data-filter="all" onclick="filterAlerts('all')">الكل</div>
            <div class="tab" data-filter="expiry" onclick="filterAlerts('expiry')">قريب الانتهاء</div>
            <div class="tab" data-filter="expired" onclick="filterAlerts('expired')">منتهي</div>
            <div class="tab" data-filter="low" onclick="filterAlerts('low')">مخزون منخفض</div>
            <div class="tab" data-filter="unread" onclick="filterAlerts('unread')">غير مقروء</div>
        </div>

        <!-- قائمة التنبيهات -->
        <div class="alerts-container" id="alertsContainer">
            <?php if (empty($alerts)): ?>
                <div class="empty-state">
                    <div class="icon">🔔</div>
                    <h3>لا توجد تنبيهات</h3>
                    <p>كل شيء على ما يرام</p>
                </div>
            <?php else: ?>
                <?php foreach ($alerts as $alert): ?>
                    <div class="alert-card <?= $alert['type'] ?> <?= !$alert['is_read'] ? 'unread' : '' ?>" 
                         data-id="<?= $alert['id'] ?>" data-type="<?= $alert['type'] ?>">
                        <div class="alert-icon <?= $alert['type'] ?>">
                            <?php
                            if ($alert['type'] == 'expired') echo '🔴';
                            elseif ($alert['type'] == 'expiry') echo '🟡';
                            elseif ($alert['type'] == 'stock_low') echo '🟢';
                            else echo '🔵';
                            ?>
                        </div>
                        <div class="alert-content">
                            <div class="alert-message"><?= htmlspecialchars($alert['message']) ?></div>
                            <div class="alert-time"><?= date('Y-m-d H:i', strtotime($alert['created_at'])) ?></div>
                        </div>
                        <div class="alert-actions">
                            <?php if (!$alert['is_read']): ?>
                                <button class="alert-btn btn-read" onclick="markAsRead(<?= $alert['id'] ?>)" title="تحديد كمقروء">
                                    ✅
                                </button>
                            <?php endif; ?>
                            <button class="alert-btn btn-delete" onclick="deleteAlert(<?= $alert['id'] ?>)" title="حذف">
                                🗑️
                            </button>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>

    <script>
        let currentFilter = 'all';

                                
        // دوال التنقل
        function goBack() {
            window.history.back();
        }

        // تصفية التنبيهات
        function filterAlerts(filter) {
            currentFilter = filter;
            
            // تحديث التبويبات
            document.querySelectorAll('.tab').forEach(tab => {
                tab.classList.remove('active');
                if (tab.dataset.filter === filter) {
                    tab.classList.add('active');
                }
            });

            // تصفية البطاقات
            document.querySelectorAll('.alert-card').forEach(card => {
                if (filter === 'all') {
                    card.style.display = 'flex';
                } else if (filter === 'unread') {
                    card.style.display = card.classList.contains('unread') ? 'flex' : 'none';
                } else {
                    card.style.display = card.dataset.type === filter ? 'flex' : 'none';
                }
            });
        }

        // تحديد تنبيه كمقروء
        function markAsRead(id) {
            fetch('<?= BASE_URL ?>/alerts/mark-read', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: `id=${id}`
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    const card = document.querySelector(`.alert-card[data-id="${id}"]`);
                    card.classList.remove('unread');
                    card.querySelector('.btn-read')?.remove();
                    updateStats();
                }
            });
        }

        // تحديد الكل كمقروء
        function markAllAsRead() {
            fetch('<?= BASE_URL ?>/alerts/mark-all-read', {
                method: 'POST'
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    document.querySelectorAll('.alert-card').forEach(card => {
                        card.classList.remove('unread');
                        card.querySelector('.btn-read')?.remove();
                    });
                    updateStats();
                }
            });
        }

        // حذف تنبيه
        function deleteAlert(id) {
            if (!confirm('هل أنت متأكد من حذف هذا التنبيه؟')) return;

            fetch('<?= BASE_URL ?>/alerts/delete', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: `id=${id}`
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    document.querySelector(`.alert-card[data-id="${id}"]`).remove();
                    updateStats();
                    
                    if (document.querySelectorAll('.alert-card').length === 0) {
                        location.reload();
                    }
                }
            });
        }

        // تحديث التنبيهات
        function refreshAlerts() {
            fetch('<?= BASE_URL ?>/alerts/refresh', {
                method: 'POST'
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    location.reload();
                }
            });
        }

        // تحديث الإحصائيات
        function updateStats() {
            fetch('<?= BASE_URL ?>/alerts/get-unread')
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        document.querySelector('.stat-card.unread .number').textContent = data.count;
                    }
                });
        }

        // التحقق من التنبيهات كل دقيقة
        setInterval(() => {
            refreshAlerts();
        }, 60000);
    </script>
</body>
</html>

<?php
$content = ob_get_clean();
require BASE_PATH . 'views/layouts/main.php';
?>