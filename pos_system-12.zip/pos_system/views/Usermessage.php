<?php
$u_name = Auth::name() ?? 'المستخدم';
$u_role = Auth::role(); 
$role_text = ($u_role === 'admin') ? 'مدير النظام' : 'موظف';
// ألوان الرتبة (ذهبي للمدير، سماوي للموظف)
$role_color = ($u_role === 'admin') ? '#D4AF37' : '#0096FF';
?>

<style>
    :root {
        /* تدرج اللؤلؤ القزحي (أبيض + سماوي فاتح + لافندر ناعم) */
        --pearl-bg: linear-gradient(135deg, #ffffff 0%, #f0f4ff 50%, #f3e5f5 100%);
        --pearl-border: linear-gradient(45deg, #00f7ff, #e1bee7, #00f7ff);
        --text-main: #1a202c;
    }

    .user-cloud-container {
        position: fixed;
        left: 20px;
        top: 75px; 
        width: 320px;
        z-index: 100000;
        display: none;
        perspective: 1200px;
    }

    /* هيكل السحابة اللؤلؤية */
    .magic-cloud {
        background: var(--pearl-bg);
        backdrop-filter: blur(15px);
        -webkit-backdrop-filter: blur(15px);
        
        /* شكل سحابة عصري (حواف غير متناظرة) */
        border-radius: 40px 100px 40px 100px; 
        padding: 25px;
        position: relative;
        
        /* الإطار المضيء والبريق */
        border: 2px solid rgba(255, 255, 255, 0.8);
        box-shadow: 
            0 15px 35px rgba(0, 0, 0, 0.1),            /* ظل العمق */
            0 0 25px rgba(0, 247, 255, 0.2),           /* بريق خارجي سماوي */
            inset 0 0 20px rgba(255, 255, 255, 0.6),   /* لمعان لؤلؤي داخلي */
            0 0 10px rgba(225, 190, 245, 0.3);         /* لمسة لافندر مشعة */
            
        animation: cloudFloat 4s infinite ease-in-out;
        transition: all 0.5s ease;
        direction: rtl;
    }

    /* إضافة لمعان "قزحي" متحرك على السطح */
    .magic-cloud::before {
        content: '';
        position: absolute;
        inset: 0;
        border-radius: inherit;
        background: linear-gradient(105deg, transparent 30%, rgba(255,255,255,0.4) 45%, rgba(0,247,255,0.1) 50%, transparent 70%);
        background-size: 200% 100%;
        animation: iridescentMove 6s linear infinite;
        pointer-events: none;
    }

    @keyframes iridescentMove {
        0% { background-position: 200% 0; }
        100% { background-position: -200% 0; }
    }

    @keyframes cloudAppear {
        0% { opacity: 0; transform: scale(0.6) translateY(-40px) rotate(-5deg); filter: blur(15px); }
        100% { opacity: 1; transform: scale(1) translateY(0) rotate(0deg); filter: blur(0); }
    }

    @keyframes cloudFloat {
        0%, 100% { transform: translateY(0) rotate(0.5deg); }
        50% { transform: translateY(10px) rotate(-0.5deg); }
    }

    /* الأيقونة المضيئة ببريق قزحي */
    .avatar-wrapper {
        width: 60px;
        height: 60px;
        background: white;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 28px;
        box-shadow: 0 0 15px rgba(0, 247, 255, 0.4);
        border: 2px solid var(--pearl-border);
        position: relative;
        z-index: 2;
    }

    .role-badge {
        display: inline-block;
        padding: 3px 12px;
        background: rgba(0, 0, 0, 0.05);
        border: 1px solid <?= $role_color ?>55;
        color: <?= $role_color ?>;
        border-radius: 12px;
        font-size: 11px;
        font-weight: 800;
        margin-top: 4px;
        text-transform: uppercase;
        letter-spacing: 0.5px;
    }

    .user-name {
        margin: 0;
        color: var(--text-main);
        font-size: 18px;
        font-weight: 900;
        text-shadow: 0 2px 4px rgba(0,0,0,0.05);
    }

    .timer-container {
        margin-top: 18px;
        background: rgba(255, 255, 255, 0.5);
        border-radius: 25px;
        padding: 15px;
        border: 1px solid rgba(0,0,0,0.03);
        box-shadow: inset 0 2px 10px rgba(0,0,0,0.02);
        text-align: center;
        position: relative;
    }

    #live-counter {
        font-family: 'Courier New', monospace;
        font-size: 26px;
        font-weight: 900;
        color: #2d3748;
        letter-spacing: 2px;
        display: block;
        margin-top: 5px;
    }

    /* بريق العداد */
    .pulse-dot {
        width: 8px;
        height: 8px;
        background: #00ff88;
        border-radius: 50%;
        display: inline-block;
        margin-left: 8px;
        box-shadow: 0 0 10px #00ff88;
        animation: dotPulse 1.5s infinite;
    }

    @keyframes dotPulse {
        0% { transform: scale(1); opacity: 1; }
        50% { transform: scale(1.4); opacity: 0.4; }
        100% { transform: scale(1); opacity: 1; }
    }
</style>

<div id="cloudBox" class="user-cloud-container">
    <div class="magic-cloud">
        <div style="display: flex; align-items: center; gap: 15px; position: relative; z-index: 2;">
            <div class="avatar-wrapper">👤</div>
            <div class="user-info">
                <p style="margin:0; font-size: 10px; color: #718096; font-weight: bold;">الهوية الرقمية</p>
                <h4 class="user-name"><?= htmlspecialchars($u_name) ?></h4>
                <div class="role-badge">✨ <?= $role_text ?></div>
            </div>
        </div>

        <div class="timer-container">
            <div style="display: flex; align-items: center; justify-content: center;">
                <span class="pulse-dot"></span>
                <span style="font-size: 11px; color: #4a5568; font-weight: 700;">مدة النشاط الآن</span>
            </div>
            <div id="live-counter">00:00:00</div>
        </div>
        
        
    </div>
</div>

<script>
(function() {
    const btn = document.getElementById('cloud-toggle-btn');
    const cloud = document.getElementById('cloudBox');
    const counter = document.getElementById('live-counter');
    
    // إدارة الوقت المستمر
    let sessionStart = localStorage.getItem('user_cloud_start');
    if (!sessionStart) {
        sessionStart = Date.now();
        localStorage.setItem('user_cloud_start', sessionStart);
    }

    function updateTime() {
        const diff = Math.floor((Date.now() - sessionStart) / 1000);
        const h = Math.floor(diff / 3600).toString().padStart(2, '0');
        const m = Math.floor((diff % 3600) / 60).toString().padStart(2, '0');
        const s = (diff % 60).toString().padStart(2, '0');
        counter.innerText = `${h}:${m}:${s}`;
    }

    setInterval(updateTime, 1000);
    updateTime();

    // التحكم في الظهور الخرافي
    btn.onclick = function(e) {
        e.stopPropagation();
        if (getComputedStyle(cloud).display === 'none') {
            cloud.style.display = 'block';
            cloud.style.animation = 'cloudAppear 0.6s cubic-bezier(0.175, 0.885, 0.32, 1.275) forwards';
        } else {
            cloud.style.animation = 'cloudAppear 0.4s reverse forwards';
            setTimeout(() => { cloud.style.display = 'none'; }, 400);
        }
    };

    // إغلاق عند النقر في الخارج
    document.addEventListener('click', (e) => {
        if (!cloud.contains(e.target) && e.target !== btn) {
            cloud.style.display = 'none';
        }
    });
})();
</script>
