<?php
/**
 * product_analytics.php
 * واجهة تحليلات المنتج - تصميم كثيف (Dense UI)
 * يشمل: سجل المنتج (بتصميم جديد)، تفاصيل الدفعات، الجرد الفعلي، سجل الجرد
 */

// منع الوصول المباشر
if (!defined('BASE_PATH')) {
    exit('Access Denied');
}
?>

<!-- ===== CSS الخاص بواجهة تحليلات المنتج ===== -->
<style>
/* ============================================
   التصميم العام للنافذة المنبثقة
   ============================================ */

/* ============================================
   التصميم العام للنافذة المنبثقة - الحفاظ على التصميم السابق
   ============================================ */

/* ===== المتغيرات العامة ===== */
:root {
    --primary: #2563eb;
    --primary-dark: #1d4ed8;
    --primary-light: #60a5fa;
    --primary-soft: #dbeafe;
    --secondary: #64748b;
    --secondary-dark: #475569;
    --success: #10b981;
    --success-dark: #059669;
    --success-soft: #d1fae5;
    --danger: #ef4444;
    --danger-dark: #dc2626;
    --danger-soft: #fee2e2;
    --warning: #f59e0b;
    --warning-dark: #d97706;
    --warning-soft: #fef3c7;
    --info: #3b82f6;
    --info-dark: #2563eb;
    --info-soft: #dbeafe;
    --neutral-50: #f9fafb;
    --neutral-100: #f3f4f6;
    --neutral-200: #e5e7eb;
    --neutral-300: #d1d5db;
    --neutral-400: #9ca3af;
    --neutral-500: #6b7280;
    --neutral-600: #4b5563;
    --neutral-700: #374151;
    --neutral-800: #1f2937;
    --neutral-900: #111827;
    --shadow-xs: 0 1px 2px 0 rgb(0 0 0 / 0.05);
    --shadow-sm: 0 1px 3px 0 rgb(0 0 0 / 0.1), 0 1px 2px -1px rgb(0 0 0 / 0.1);
    --shadow-md: 0 4px 6px -1px rgb(0 0 0 / 0.1), 0 2px 4px -2px rgb(0 0 0 / 0.1);
    --shadow-lg: 0 10px 15px -3px rgb(0 0 0 / 0.1), 0 4px 6px -4px rgb(0 0 0 / 0.1);
    --shadow-xl: 0 20px 25px -5px rgb(0 0 0 / 0.1), 0 8px 10px -6px rgb(0 0 0 / 0.1);
    --radius-sm: 6px;
    --radius-md: 8px;
    --radius-lg: 12px;
    --radius-xl: 16px;
    --radius-2xl: 20px;
    --transition-fast: 0.15s ease;
    --transition-normal: 0.2s ease;
    --transition-slow: 0.3s ease;
}

/* ===== الطبقة الخلفية (Overlay) ===== */
.modal-overlay {
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(0, 0, 0, 0.5);
    backdrop-filter: blur(4px);
    display: flex;
    align-items: center;
    justify-content: center;
    z-index: 99999;
    animation: fadeIn 0.2s ease;
}

@keyframes fadeIn {
    from { opacity: 0; backdrop-filter: blur(0px); }
    to { opacity: 1; backdrop-filter: blur(4px); }
}

/* ===== النافذة الرئيسية ===== */
.product-analytics-window {
    width: 95%;
    max-width: 1400px;
    height: 90vh;
    background: var(--neutral-50);
    border-radius: var(--radius-xl);
    box-shadow: var(--shadow-xl);
    display: flex;
    flex-direction: column;
    overflow: hidden;
    animation: windowSlideIn 0.25s cubic-bezier(0.16, 1, 0.3, 1);
}

@keyframes windowSlideIn {
    from { opacity: 0; transform: scale(0.95) translateY(10px); }
    to { opacity: 1; transform: scale(1) translateY(0); }
}

/* ===== رأس النافذة (Header) ===== */
.window-header {
    height: 64px;
    background: linear-gradient(135deg, var(--primary), var(--primary-dark));
    color: white;
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 0 24px;
    flex-shrink: 0;
    box-shadow: var(--shadow-sm);
}

.product-info-header {
    display: flex;
    align-items: center;
    gap: 16px;
}

.product-icon {
    width: 40px;
    height: 40px;
    background: rgba(255, 255, 255, 0.2);
    border-radius: var(--radius-lg);
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 24px;
}

.product-details h2 {
    font-size: 18px;
    font-weight: 600;
    margin: 0 0 4px 0;
    letter-spacing: -0.3px;
}

.product-details .barcode {
    font-size: 12px;
    opacity: 0.8;
    display: flex;
    align-items: center;
    gap: 6px;
}

.window-controls {
    display: flex;
    gap: 8px;
}

.window-controls button {
    width: 36px;
    height: 36px;
    border: none;
    background: rgba(255, 255, 255, 0.1);
    color: white;
    border-radius: var(--radius-sm);
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 16px;
    transition: all var(--transition-fast);
}

.window-controls button:hover {
    background: rgba(255, 255, 255, 0.2);
    transform: scale(1.05);
}

.window-controls button.close-btn:hover {
    background: var(--danger);
}

/* ===== شريط التبويبات (Tabs) ===== */
.window-tabs {
    height: 52px;
    background: white;
    border-bottom: 1px solid var(--neutral-200);
    display: flex;
    align-items: center;
    padding: 0 20px;
    gap: 4px;
    flex-shrink: 0;
    overflow-x: auto;
    scrollbar-width: none;
}

.window-tabs::-webkit-scrollbar {
    display: none;
}

.tab-item {
    height: 44px;
    padding: 0 20px;
    border: none;
    background: transparent;
    border-radius: var(--radius-md) var(--radius-md) 0 0;
    font-size: 14px;
    font-weight: 500;
    color: var(--neutral-600);
    cursor: pointer;
    display: inline-flex;
    align-items: center;
    gap: 8px;
    transition: all var(--transition-fast);
    white-space: nowrap;
}

.tab-item:hover {
    color: var(--primary);
    background: var(--primary-soft);
}

.tab-item.active {
    color: var(--primary);
    background: white;
    box-shadow: 0 -2px 0 var(--primary) inset;
}

/* ===== منطقة المحتوى الرئيسية ===== */
.window-content {
    flex: 1;
    overflow-y: auto;
    padding: 20px;
    background: var(--neutral-50);
}

.window-content::-webkit-scrollbar {
    width: 8px;
    height: 8px;
}

.window-content::-webkit-scrollbar-track {
    background: var(--neutral-100);
    border-radius: 4px;
}

.window-content::-webkit-scrollbar-thumb {
    background: var(--neutral-300);
    border-radius: 4px;
}

.window-content::-webkit-scrollbar-thumb:hover {
    background: var(--neutral-400);
}

/* ===== التبويبات ===== */
.tab-pane {
    display: none;
    animation: fadeInUp 0.3s ease;
}

.tab-pane.active {
    display: block;
}

@keyframes fadeInUp {
    from { opacity: 0; transform: translateY(10px); }
    to { opacity: 1; transform: translateY(0); }
}

/* ============================================
   تصميم سجل المنتج الجديد (Dense UI)
   ============================================ */

/* القسم العلوي - معلومات المنتج */
.product-header-compact {
    background: white;
    border-radius: var(--radius-lg);
    margin-bottom: 16px;
    overflow: hidden;
    border: 1px solid var(--neutral-200);
    box-shadow: var(--shadow-sm);
}

.product-info-row {
    background: var(--neutral-50);
    padding: 12px 16px;
    display: flex;
    gap: 20px;
    font-size: 13px;
    border-bottom: 1px solid var(--neutral-200);
}

.product-name {
    font-weight: 700;
    color: var(--primary);
}

.product-barcode {
    font-family: monospace;
    color: var(--neutral-600);
}

.product-category {
    color: var(--neutral-500);
}

/* صفوف الدفعات المختصرة */
.batches-mini-row {
    padding: 10px 16px;
    display: flex;
    flex-wrap: wrap;
    gap: 10px;
    background: white;
}

.batch-mini-card {
    background: var(--neutral-50);
    border: 1px solid var(--neutral-200);
    border-radius: var(--radius-md);
    padding: 8px 12px;
    cursor: pointer;
    transition: all 0.2s;
    min-width: 280px;
}

.batch-mini-card:hover {
    background: var(--primary-soft);
    border-color: var(--primary-light);
    transform: translateY(-1px);
    box-shadow: var(--shadow-sm);
}

.batch-mini-header {
    display: flex;
    gap: 15px;
    font-size: 12px;
    font-weight: 600;
    margin-bottom: 6px;
}

.batch-mini-number {
    color: var(--primary);
}

.batch-mini-stats {
    display: flex;
    gap: 12px;
    font-size: 11px;
    color: var(--neutral-600);
}

.batch-mini-stats span {
    font-weight: 600;
    color: var(--neutral-800);
}

.batch-expanded-details {
    margin-top: 10px;
    padding-top: 10px;
    border-top: 1px solid var(--neutral-200);
    font-size: 12px;
    display: none;
}

.batch-expanded-details.show {
    display: block;
    animation: fadeIn 0.2s ease;
}

.batch-detail-row {
    display: flex;
    gap: 15px;
    margin-bottom: 8px;
    flex-wrap: wrap;
}

.batch-detail-item {
    background: white;
    padding: 6px 12px;
    border-radius: var(--radius-md);
    border: 1px solid var(--neutral-200);
}

/* شريط الفلاتر */
.filter-bar-compact {
    background: white;
    border-radius: var(--radius-lg);
    padding: 10px 16px;
    margin-bottom: 16px;
    display: flex;
    align-items: center;
    gap: 12px;
    flex-wrap: wrap;
    border: 1px solid var(--neutral-200);
    box-shadow: var(--shadow-sm);
}

.filter-btn {
    background: transparent;
    border: 1px solid var(--neutral-300);
    padding: 6px 16px;
    border-radius: 20px;
    font-size: 12px;
    font-weight: 500;
    cursor: pointer;
    transition: all 0.2s;
}

.filter-btn:hover {
    background: var(--neutral-100);
    border-color: var(--neutral-400);
}

.filter-btn.active {
    background: var(--primary);
    border-color: var(--primary);
    color: white;
}

.custom-date-inputs {
    display: flex;
    align-items: center;
    gap: 8px;
}

.date-input {
    padding: 6px 10px;
    border: 1px solid var(--neutral-300);
    border-radius: var(--radius-md);
    font-size: 12px;
    background: white;
}

.date-input:focus {
    outline: none;
    border-color: var(--primary);
    box-shadow: 0 0 0 2px var(--primary-soft);
}

/* القسم الرئيسي (نصفين) */
.main-split-section {
    display: flex;
    gap: 16px;
    margin-bottom: 16px;
    height: 380px;
}

.left-panel, .right-panel {
    flex: 1;
    background: white;
    border-radius: var(--radius-lg);
    display: flex;
    flex-direction: column;
    overflow: hidden;
    border: 1px solid var(--neutral-200);
    box-shadow: var(--shadow-sm);
}

.panel-header {
    background: var(--neutral-100);
    padding: 12px 16px;
    font-weight: 600;
    font-size: 13px;
    border-bottom: 1px solid var(--neutral-200);
    color: var(--neutral-700);
}

.panel-scroll {
    flex: 1;
    overflow-y: auto;
}

.panel-scroll::-webkit-scrollbar {
    width: 6px;
}

.panel-scroll::-webkit-scrollbar-track {
    background: var(--neutral-100);
}

.panel-scroll::-webkit-scrollbar-thumb {
    background: var(--neutral-300);
    border-radius: 3px;
}

/* صفوف المدخلات والمتبقي */
.entry-row, .remaining-row {
    display: flex;
    align-items: center;
    padding: 10px 12px;
    border-bottom: 1px solid var(--neutral-100);
    cursor: pointer;
    transition: background 0.15s;
    font-size: 12px;
    gap: 8px;
}

.entry-row:hover, .remaining-row:hover {
    background: var(--neutral-50);
}

.entry-row.expanded, .remaining-row.expanded {
    background: var(--primary-soft);
}

.entry-col-batch, .remaining-col-batch {
    flex: 0.8;
    font-weight: 600;
    color: var(--primary);
}

.entry-col-date, .remaining-col-date {
    flex: 0.8;
    color: var(--neutral-500);
}

.entry-col-quantity {
    flex: 0.6;
}

.entry-col-cost, .entry-col-price {
    flex: 0.8;
}

.entry-col-remaining {
    flex: 0.6;
    font-weight: 600;
}

.remaining-col-units {
    flex: 0.6;
    font-weight: 600;
}

.remaining-col-value {
    flex: 1;
}

/* التفاصيل الموسعة */
.expanded-details {
    padding: 12px 16px;
    background: var(--neutral-50);
    border-top: 1px solid var(--neutral-200);
    font-size: 12px;
}

.details-grid {
    display: flex;
    flex-wrap: wrap;
    gap: 12px;
    margin-bottom: 10px;
}

.detail-box {
    background: white;
    padding: 8px 12px;
    border-radius: var(--radius-md);
    border: 1px solid var(--neutral-200);
    min-width: 140px;
}

.detail-label {
    font-size: 10px;
    color: var(--neutral-500);
    margin-bottom: 4px;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

.detail-value {
    font-weight: 600;
    color: var(--neutral-800);
    font-size: 14px;
}

.batch-sales-row {
    display: flex;
    gap: 12px;
    margin: 12px 0;
}

.batch-sales-cash, .batch-sales-credit {
    flex: 1;
    background: white;
    padding: 10px;
    border-radius: var(--radius-md);
    border: 1px solid var(--neutral-200);
}

.warning-text {
    color: var(--warning);
    font-weight: 600;
}

/* قسم تحليل المبيعات */
.sales-analysis-section {
    background: white;
    border-radius: var(--radius-lg);
    overflow: hidden;
    max-height: 280px;
    display: flex;
    flex-direction: column;
    border: 1px solid var(--neutral-200);
    box-shadow: var(--shadow-sm);
}

.sales-header {
    display: flex;
    background: var(--neutral-100);
    padding: 10px 16px;
    font-size: 12px;
    font-weight: 600;
    border-bottom: 1px solid var(--neutral-200);
    color: var(--neutral-700);
}

.sales-header-item {
    flex: 1;
    text-align: center;
}

.sales-scroll {
    flex: 1;
    overflow-y: auto;
}

.sales-scroll::-webkit-scrollbar {
    width: 6px;
}

.sales-scroll::-webkit-scrollbar-track {
    background: var(--neutral-100);
}

.sales-scroll::-webkit-scrollbar-thumb {
    background: var(--neutral-300);
    border-radius: 3px;
}

.sales-row {
    display: flex;
    padding: 8px 16px;
    border-bottom: 1px solid var(--neutral-100);
    cursor: pointer;
    font-size: 12px;
    transition: background 0.15s;
}

.sales-row:hover {
    background: var(--neutral-50);
}

.sales-row.expanded {
    background: var(--primary-soft);
}

.sales-col {
    flex: 1;
    text-align: center;
}

.sales-expanded {
    padding: 12px 16px;
    background: var(--neutral-50);
    border-top: 1px solid var(--neutral-200);
    display: none;
}

.sales-expanded.show {
    display: block;
    animation: fadeIn 0.2s ease;
}

/* حالة التحميل */
.loading-placeholder {
    text-align: center;
    padding: 40px;
    color: var(--neutral-400);
    font-size: 13px;
}

/* ============================================
   أنماط التبويبات الأخرى (الحفاظ على التصميم السابق)
   ============================================ */

/* ===== البطاقات العامة ===== */
.info-card {
    background: white;
    border-radius: var(--radius-lg);
    box-shadow: var(--shadow-sm);
    overflow: hidden;
    margin-bottom: 20px;
    transition: all var(--transition-normal);
}

.info-card:hover {
    box-shadow: var(--shadow-md);
}

.info-card-header {
    background: var(--neutral-50);
    padding: 14px 20px;
    border-bottom: 1px solid var(--neutral-200);
    display: flex;
    align-items: center;
    gap: 10px;
}

.info-card-header h3 {
    margin: 0;
    font-size: 15px;
    font-weight: 600;
    color: var(--neutral-800);
}

.info-card-icon {
    width: 32px;
    height: 32px;
    background: var(--primary-soft);
    border-radius: var(--radius-md);
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 16px;
    color: var(--primary);
}

.info-card-content {
    padding: 16px 20px;
}

/* ===== شبكة الإحصائيات ===== */
.stats-grid-compact {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 16px;
    margin-bottom: 20px;
}

.compact-stat-card {
    background: white;
    border: 1px solid var(--neutral-200);
    border-radius: var(--radius-lg);
    padding: 16px;
    text-align: center;
    transition: all var(--transition-fast);
}

.compact-stat-card:hover {
    transform: translateY(-2px);
    box-shadow: var(--shadow-md);
    border-color: var(--neutral-300);
}

.compact-stat-value {
    font-size: 28px;
    font-weight: 700;
    color: var(--primary);
    line-height: 1.2;
    margin-bottom: 6px;
}

.compact-stat-label {
    font-size: 12px;
    color: var(--neutral-600);
    margin-bottom: 4px;
    font-weight: 500;
}

.compact-stat-detail {
    font-size: 10px;
    color: var(--neutral-400);
}

/* ===== جداول البيانات ===== */
.data-grid {
    width: 100%;
    border-collapse: collapse;
    font-size: 13px;
}

.data-grid th {
    text-align: center;
    padding: 12px 12px;
    background: var(--neutral-100);
    color: var(--neutral-700);
    font-weight: 600;
    font-size: 12px;
    border-bottom: 2px solid var(--neutral-300);
}

.data-grid td {
    padding: 10px 12px;
    border-bottom: 1px solid var(--neutral-200);
    color: var(--neutral-700);
    text-align: center;
}

.data-grid tbody tr:hover {
    background: var(--neutral-50);
}

/* ===== حالة عدم وجود بيانات ===== */
.no-data-block {
    text-align: center;
    padding: 40px 20px;
    background: white;
    border-radius: var(--radius-lg);
}

.no-data-icon {
    font-size: 48px;
    color: var(--neutral-300);
    margin-bottom: 12px;
}

.no-data-text {
    color: var(--neutral-500);
    font-size: 14px;
}

/* ===== شارات الحالة ===== */
.status-badge {
    display: inline-block;
    padding: 4px 12px;
    border-radius: 30px;
    font-size: 11px;
    font-weight: 600;
}

.status-good {
    background: var(--success-soft);
    color: var(--success-dark);
}

.status-warning {
    background: var(--warning-soft);
    color: var(--warning-dark);
}

.status-expired {
    background: var(--danger-soft);
    color: var(--danger-dark);
}

/* ===== أنماط الدفعات ===== */
.batches-section {
    background: white;
    border-radius: var(--radius-lg);
    padding: 0;
}

.batches-list {
    display: flex;
    flex-direction: column;
    gap: 12px;
}

.batch-card {
    border: 1px solid var(--neutral-200);
    border-radius: var(--radius-lg);
    overflow: hidden;
    transition: all var(--transition-fast);
}

.batch-card:hover {
    box-shadow: var(--shadow-md);
}

.batch-header {
    background: var(--neutral-50);
    padding: 14px 18px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    cursor: pointer;
}

.batch-header-left {
    display: flex;
    align-items: center;
    gap: 20px;
    flex-wrap: wrap;
}

.batch-number {
    font-weight: 700;
    color: var(--primary);
    font-size: 13px;
    background: var(--primary-soft);
    padding: 4px 12px;
    border-radius: 20px;
}

.batch-info {
    display: flex;
    gap: 20px;
    flex-wrap: wrap;
}

.batch-info-item {
    display: flex;
    flex-direction: column;
    gap: 2px;
}

.batch-info-label {
    font-size: 10px;
    color: var(--neutral-500);
}

.batch-info-value {
    font-size: 13px;
    font-weight: 600;
    color: var(--neutral-800);
}

.batch-status {
    padding: 4px 12px;
    border-radius: 20px;
    font-size: 11px;
    font-weight: 600;
}

.batch-details {
    padding: 16px;
    background: white;
    border-top: 1px solid var(--neutral-200);
    display: none;
}

.batch-details.expanded {
    display: block;
    animation: fadeIn 0.3s ease;
}

/* ===== نماذج الجرد ===== */
.inventory-section {
    background: white;
    border-radius: var(--radius-lg);
    padding: 20px;
}

.summary-block {
    background: var(--neutral-50);
    border-radius: var(--radius-lg);
    padding: 16px;
    margin-bottom: 20px;
}

.block-title {
    font-size: 14px;
    font-weight: 600;
    color: var(--neutral-700);
    margin-bottom: 12px;
    display: flex;
    align-items: center;
    gap: 8px;
}

.inventory-summary {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 16px;
    margin-bottom: 20px;
}

.inventory-input-area {
    background: var(--neutral-100);
    border-radius: var(--radius-lg);
    padding: 20px;
}

.actual-input {
    display: flex;
    align-items: center;
    gap: 16px;
    margin-bottom: 16px;
}

.actual-input label {
    font-size: 14px;
    font-weight: 600;
    color: var(--neutral-700);
    min-width: 140px;
}

.actual-input input {
    flex: 1;
    height: 44px;
    border: 2px solid var(--neutral-200);
    border-radius: var(--radius-md);
    padding: 0 14px;
    font-size: 16px;
    font-weight: 600;
    transition: all var(--transition-fast);
}

.actual-input input:focus {
    outline: none;
    border-color: var(--primary);
    box-shadow: 0 0 0 3px var(--primary-soft);
}

.difference-display {
    background: white;
    padding: 16px;
    border-radius: var(--radius-lg);
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 12px;
}

.difference-label {
    font-size: 14px;
    font-weight: 600;
    color: var(--neutral-700);
}

.difference-value {
    font-size: 28px;
    font-weight: 700;
}

.diff-positive { color: var(--success); }
.diff-negative { color: var(--danger); }
.diff-zero { color: var(--neutral-500); }

.financial-impact {
    background: var(--neutral-100);
    padding: 12px;
    border-radius: var(--radius-md);
    margin-bottom: 16px;
    font-size: 13px;
    text-align: center;
}

.action-buttons-group {
    display: flex;
    gap: 12px;
    margin-top: 20px;
}

/* ===== أزرار ===== */
.btn-sm {
    height: 36px;
    padding: 0 16px;
    border: none;
    border-radius: var(--radius-md);
    font-size: 13px;
    font-weight: 500;
    cursor: pointer;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 6px;
    transition: all var(--transition-fast);
}

.btn-sm:hover {
    transform: translateY(-1px);
    box-shadow: var(--shadow-md);
}

.btn-primary-sm {
    background: var(--primary);
    color: white;
}

.btn-primary-sm:hover {
    background: var(--primary-dark);
}

.btn-success-sm {
    background: var(--success);
    color: white;
}

.btn-success-sm:hover {
    background: var(--success-dark);
}

.btn {
    height: 38px;
    padding: 0 18px;
    border: none;
    border-radius: var(--radius-md);
    font-size: 13px;
    font-weight: 500;
    cursor: pointer;
    display: inline-flex;
    align-items: center;
    gap: 6px;
    transition: all var(--transition-fast);
}

.btn-primary {
    background: var(--primary);
    color: white;
}

.btn-primary:hover {
    background: var(--primary-dark);
}

/* ===== سجل الجرد ===== */
.audit-section {
    background: white;
    border-radius: var(--radius-lg);
    padding: 20px;
}

.audit-stats {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 16px;
    margin-bottom: 24px;
}

.audit-card {
    background: var(--neutral-50);
    border: 1px solid var(--neutral-200);
    border-radius: var(--radius-lg);
    padding: 16px;
    text-align: center;
    transition: all var(--transition-fast);
}

.audit-card:hover {
    transform: translateY(-2px);
    box-shadow: var(--shadow-sm);
}

.audit-percentage {
    font-size: 28px;
    font-weight: 700;
    color: var(--primary);
    margin-bottom: 6px;
}

/* ===== جدول المعلومات ===== */
.info-table {
    width: 100%;
    border-collapse: collapse;
}

.info-table tr {
    border-bottom: 1px solid var(--neutral-100);
}

.info-table tr:last-child {
    border-bottom: none;
}

.info-table td {
    padding: 10px 12px;
}

.info-table td:first-child {
    font-weight: 600;
    color: var(--neutral-700);
    width: 140px;
    background: var(--neutral-50);
}

.info-table td:last-child {
    color: var(--neutral-800);
}

/* ===== حالة ملء الشاشة ===== */
.product-analytics-window.fullscreen {
    width: 100vw;
    height: 100vh;
    max-width: none;
    border-radius: 0;
}

/* ===== أنماط نصية ===== */
.text-success { color: var(--success); font-weight: 600; }
.text-danger { color: var(--danger); font-weight: 600; }
.text-warning { color: var(--warning); font-weight: 600; }

/* ===== استجابة للشاشات الصغيرة ===== */
@media (max-width: 1024px) {
    .stats-grid-compact {
        grid-template-columns: repeat(2, 1fr);
    }
    .main-split-section {
        flex-direction: column;
        height: auto;
    }
    .left-panel, .right-panel {
        min-height: 280px;
    }
    .inventory-summary {
        grid-template-columns: 1fr;
    }
    .audit-stats {
        grid-template-columns: repeat(2, 1fr);
    }
}

@media (max-width: 768px) {
    .window-tabs {
        overflow-x: auto;
        padding: 0 12px;
    }
    .tab-item {
        padding: 0 14px;
        font-size: 12px;
    }
    .stats-grid-compact {
        grid-template-columns: 1fr;
    }
    .actual-input {
        flex-direction: column;
        align-items: stretch;
    }
    .actual-input label {
        min-width: auto;
    }
    .batch-header-left {
        flex-direction: column;
        align-items: flex-start;
        gap: 8px;
    }
    .batch-info {
        flex-wrap: wrap;
    }
}

@media (max-width: 480px) {
    .window-header {
        padding: 0 16px;
    }
    .product-info-header {
        gap: 10px;
    }
    .product-details h2 {
        font-size: 14px;
    }
    .filter-bar-compact {
        flex-direction: column;
        align-items: stretch;
    }
    .custom-date-inputs {
        justify-content: space-between;
    }
}
</style>

<!-- ===== نافذة تحليلات المنتج الرئيسية ===== -->
<div class="modal-overlay" id="productAnalyticsModal" style="display: none;">
    <div class="product-analytics-window" id="analyticsWindow">
        
        <!-- ===== رأس النافذة ===== -->
        <div class="window-header">
            <div class="product-info-header">
                <span class="product-icon">📦</span>
                <div class="product-details">
                    <h2 id="modalProductName">جاري تحميل المنتج...</h2>
                    <div class="barcode">
                        <span>🔖</span>
                        <span id="modalProductBarcode">---</span>
                    </div>
                </div>
            </div>
            <div class="window-controls">
                <button onclick="toggleFullscreen()" title="ملء الشاشة">⛶</button>
                <button class="close-btn" onclick="closeProductAnalytics()" title="إغلاق">✕</button>
            </div>
        </div>

        <!-- ===== شريط التبويبات ===== -->
        <div class="window-tabs">
            <button class="tab-item active" onclick="switchTab(1)" id="tab1">
                <span class="tab-icon">📋</span>
                <span>سجل المنتج</span>
            </button>
            <button class="tab-item" onclick="switchTab(2)" id="tab2">
                <span class="tab-icon">📦</span>
                <span>تفاصيل الدفعات</span>
            </button>
            <button class="tab-item" onclick="switchTab(3)" id="tab3">
                <span class="tab-icon">🔍</span>
                <span>الجرد الفعلي</span>
            </button>
            <button class="tab-item" onclick="switchTab(4)" id="tab4">
                <span class="tab-icon">📋</span>
                <span>سجل الجرد</span>
            </button>
        </div>

        <!-- ===== منطقة المحتوى ===== -->
        <div class="window-content" id="windowContent">
            
            <!-- تبويب 1: سجل المنتج (التصميم الجديد) -->
            <div class="tab-pane active" id="tabPane1">
                
                <!-- معلومات المنتج + صفوف الدفعات المختصرة -->
                <div class="product-header-compact">
                    <div class="product-info-row">
                        <span class="product-name" id="productNameDisplay">---</span>
                        <span class="product-barcode" id="productBarcodeDisplay">---</span>
                        <span class="product-category" id="productCategoryDisplay">---</span>
                    </div>
                    <div class="batches-mini-row" id="batchesMiniRow">
                        <div class="batch-mini-loading">جاري تحميل الدفعات...</div>
                    </div>
                </div>

                <!-- شريط الفلاتر -->
                <div class="filter-bar-compact">
                    <button class="filter-btn" data-period="daily">اليوم</button>
                    <button class="filter-btn" data-period="weekly">أسبوع</button>
                    <button class="filter-btn" data-period="monthly">شهر</button>
                    <button class="filter-btn" data-period="custom">مخصص</button>
                    <div class="custom-date-inputs" style="display: none;">
                        <input type="date" id="filterDateFrom" class="date-input">
                        <span>→</span>
                        <input type="date" id="filterDateTo" class="date-input">
                    </div>
                </div>

                <!-- القسم الرئيسي (نصفين) -->
                <div class="main-split-section">
                    
                    <!-- القسم الأيسر: المدخلات (الدفعات) -->
                    <div class="left-panel">
                        <div class="panel-header">📦 المدخلات</div>
                        <div class="panel-scroll" id="entriesList">
                            <div class="loading-placeholder">جاري تحميل الدفعات...</div>
                        </div>
                    </div>
                    
                    <!-- القسم الأيمن: المتبقي FIFO -->
                    <div class="right-panel">
                        <div class="panel-header">📊 المتبقي (FIFO)</div>
                        <div class="panel-scroll" id="remainingList">
                            <div class="loading-placeholder">جاري تحميل المخزون المتبقي...</div>
                        </div>
                    </div>
                </div>

                <!-- تحليل المبيعات -->
            
            </div>

            <!-- تبويب 2: تفاصيل الدفعات -->
            <div class="tab-pane" id="tabPane2">
                <div class="stats-grid-compact" id="batchesStatsCards">
                    <div class="compact-stat-card">
                        <div class="compact-stat-value" id="totalBatches">0</div>
                        <div class="compact-stat-label">إجمالي الدفعات</div>
                    </div>
                    <div class="compact-stat-card">
                        <div class="compact-stat-value" id="totalCartonsRemaining">0</div>
                        <div class="compact-stat-label">الكراتين المتبقية</div>
                    </div>
                    <div class="compact-stat-card">
                        <div class="compact-stat-value" id="totalUnitsRemaining">0</div>
                        <div class="compact-stat-label">القطع المتبقية</div>
                    </div>
                    <div class="compact-stat-card">
                        <div class="compact-stat-value" id="batchesValue">0</div>
                        <div class="compact-stat-label">قيمة المخزون</div>
                    </div>
                </div>
                <div class="batches-list" id="batchesList">
                    <div class="no-data-block"><div class="no-data-icon">📦</div><div class="no-data-text">جاري تحميل البيانات...</div></div>
                </div>
            </div>

            <!-- تبويب 3: الجرد الفعلي -->
            <div class="tab-pane" id="tabPane3">
                <div class="inventory-section">
                    <input type="hidden" id="currentInventoryProductId">
                    
                    <div class="summary-block">
                        <div class="block-title"><span>📦</span> المخزون في المخزن الرئيسي</div>
                        <table class="data-grid">
                            <thead><tr><th>رقم الدفعة</th><th>الكراتين</th><th>قطع/كرتون</th><th>إجمالي القطع</th><th>سعر التكلفة</th><th>سعر البيع</th><th>القيمة</th></tr></thead>
                            <tbody id="mainInventoryBody"><tr><td colspan="7" class="no-data">جاري التحميل...</td></tr></tbody>
                        </table>
                    </div>

                    <div class="summary-block">
                        <div class="block-title"><span>🏪</span> المخزون على الرفوف</div>
                        <table class="data-grid">
                            <thead><tr><th>كود الرف</th><th>القطع المتبقية</th><th>سعر البيع</th><th>القيمة</th><th>تاريخ النقل</th></tr></thead>
                            <tbody id="shelfInventoryBody"><tr><td colspan="5" class="no-data">جاري التحميل...</td></tr></tbody>
                        </table>
                    </div>

                    <div class="inventory-summary">
                        <div class="summary-block">
                            <div class="block-title"><span>📊</span> الكمية المتوقعة الكلية</div>
                            <div style="font-size:20px;font-weight:700;color:var(--primary);" id="expectedTotal">0 كرتون | 0 قطعة</div>
                            <div id="expectedBreakdown" style="display:none;"></div>
                        </div>
                        <div class="summary-block">
                            <div class="block-title"><span>💰</span> قيمة المخزون المتوقعة</div>
                            <div style="font-size:24px;font-weight:700;color:var(--primary);" id="expectedValue">0</div>
                            <div id="expectedValueBreakdown">تكلفة: 0 | بيع: 0</div>
                        </div>
                    </div>

                    <div class="inventory-input-area">
                        <div class="actual-input" style="align-items: flex-start;">
                            <div style="flex: 1; margin-left: 10px;">
                                <label style="display:block; margin-bottom:5px;">كمية المخزون (بالكرتون):</label>
                                <input type="number" id="actualQuantityCartons" min="0" step="0.01" placeholder="أدخل كراتين المخزون..." style="width:100%; height:44px; border:2px solid var(--neutral-200); border-radius:var(--radius-md); padding:0 14px; font-size:16px; font-weight:600;">
                            </div>
                            <div style="flex: 1;">
                                <label style="display:block; margin-bottom:5px;">كمية الرفوف (بالقطع):</label>
                                <input type="number" id="actualQuantityPieces" min="0" step="1" placeholder="أدخل قطع الرفوف..." style="width:100%; height:44px; border:2px solid var(--neutral-200); border-radius:var(--radius-md); padding:0 14px; font-size:16px; font-weight:600;">
                            </div>
                        </div>
                        <div class="difference-display" style="flex-direction: column; align-items: flex-start; gap: 10px;">
                            <div style="display: flex; justify-content: space-between; width: 100%;">
                                <span class="difference-label">الكمية الفعلية المدخلة:</span>
                                <span class="difference-value" id="actualTotalDisplay" style="color: var(--primary); font-size: 20px;">0 كرتون | 0 قطعة</span>
                            </div>
                            <div style="display: flex; justify-content: space-between; width: 100%; border-top: 1px solid var(--neutral-200); padding-top: 10px;">
                                <span class="difference-label">الفرق (بالقطع):</span>
                                <span class="difference-value" id="differenceDisplay">0</span>
                            </div>
                        </div>
                        <div class="financial-impact" id="financialImpact">القيمة المالية للفرق: 0 ريال</div>
                        
                        <div>
                            <label style="font-weight:600; font-size:12px;">سبب الفرق:</label>
                            <select id="differenceReasonSelect" class="form-control" style="width:100%; margin-top:5px; margin-bottom:8px;">
                                <option value="">-- اختر سبباً --</option>
                                <option value="تلف">تلف أو انتهاء صلاحية</option>
                                <option value="فقدان">سرقة أو فقدان</option>
                                <option value="خطأ مبيعات">خطأ في تسجيل المبيعات</option>
                                <option value="خطأ وارد">خطأ في تسجيل الدفعات الواردة</option>
                                <option value="إرجاع غير مسجل">إرجاع غير مسجل</option>
                                <option value="أخرى">سبب آخر</option>
                            </select>
                            <textarea id="differenceReason" class="form-control" rows="2" placeholder="تفاصيل إضافية..."></textarea>
                        </div>

                        <div id="lastAuditInfo" style="background:var(--neutral-100);padding:12px;border-radius:8px;margin-top:12px;">
                            <div style="font-weight:600; font-size:12px;">آخر جرد:</div>
                            <div>لم يتم إجراء جرد سابق</div>
                        </div>

                        <div class="action-buttons-group">
                            <button class="btn-sm btn-success-sm" onclick="savePhysicalInventory()"><span>💾</span> حفظ الجرد</button>
                            <button class="btn-sm btn-primary-sm" onclick="refreshInventoryData()"><span>🔄</span> تحديث</button>
                        </div>
                    </div>
                </div>
            </div>

            <!-- تبويب 4: سجل الجرد -->
            <div class="tab-pane" id="tabPane4">
                <div class="audit-section">
                    <div class="audit-stats" id="auditStats"></div>
                    <div class="audit-history" id="auditHistory">
                        <div class="no-data-block"><div class="no-data-icon">📋</div><div class="no-data-text">لا يوجد سجل جرد لهذا المنتج</div></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
// ============================================
// المتغيرات العامة
// ============================================
let currentProductId = null;
let currentTab = 1;
let isFullscreen = false;
let inventoryData = null;

// متغيرات تبويب سجل المنتج
let currentFilterPeriod = 'daily';
let currentFilterFrom = null;
let currentFilterTo = null;
let openEntryId = null;
let openRemainingId = null;
let openSalesPrice = null;

// ============================================
// دوال مساعدة
// ============================================
function formatMoney(amount) {
    if (amount === undefined || amount === null || isNaN(amount)) {
        return '0.00';
    }
    return parseFloat(amount).toFixed(2);
}

function showSystemMessage(message) {
    alert(message);
}

function escapeHtml(text) {
    if (!text) return '';
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

function calculatePeriodDates(period) {
    const today = new Date();
    let from = new Date();
    let to = new Date();
    
    switch(period) {
        case 'daily':
            from = today;
            to = today;
            break;
        case 'weekly':
            from.setDate(today.getDate() - 7);
            break;
        case 'monthly':
            from.setMonth(today.getMonth() - 1);
            break;
    }
    return {
        from: from.toISOString().split('T')[0],
        to: to.toISOString().split('T')[0]
    };
}

function isNearExpiry(expiryDate) {
    if (!expiryDate) return false;
    const today = new Date();
    const expiry = new Date(expiryDate);
    const diffDays = Math.ceil((expiry - today) / (1000 * 60 * 60 * 24));
    return diffDays <= 30 && diffDays >= 0;
}

function getExpiryStatus(expiryDate) {
    if (!expiryDate) return { class: 'status-good', text: 'بدون تاريخ', days: null };
    const today = new Date();
    const expiry = new Date(expiryDate);
    const diffDays = Math.ceil((expiry - today) / (1000 * 60 * 60 * 24));
    if (diffDays < 0) return { class: 'status-expired', text: 'منتهي', days: null };
    if (diffDays <= 30) return { class: 'status-warning', text: 'قريب الانتهاء', days: diffDays };
    return { class: 'status-good', text: 'ساري', days: diffDays };
}

// ============================================
// دالة تحميل تحليل المبيعات (المفقودة)
// ============================================
function loadSalesAnalysisData() {
    if (!currentProductId) return;

    const container = document.getElementById('salesAnalysisList');
    if (!container) {
        console.log('عنصر salesAnalysisList غير موجود');
        return;
    }

    container.innerHTML = '<div class="loading-placeholder">جاري تحميل تحليل المبيعات...</div>';

    let url = BASE_URL + '/reports/product-sales-analysis?product_id=' + currentProductId;

    if (currentFilterPeriod !== 'all' && currentFilterPeriod !== 'custom') {
        const dates = calculatePeriodDates(currentFilterPeriod);
        if (dates.from && dates.to) {
            url += '&from=' + dates.from + '&to=' + dates.to;
        }
    } else if (currentFilterPeriod === 'custom' && currentFilterFrom && currentFilterTo) {
        url += '&from=' + currentFilterFrom + '&to=' + currentFilterTo;
    }

    fetch(url)
        .then(response => response.json())
        .then(data => {
            if (data.success && data.data && data.data.by_price) {
                renderSalesAnalysis(data.data.by_price);
            } else if (data.success && data.data && data.data.stats) {
                container.innerHTML = '<div class="loading-placeholder">لا توجد مبيعات في هذه الفترة</div>';
            } else {
                container.innerHTML = '<div class="loading-placeholder">لا توجد بيانات مبيعات</div>';
            }
        })
        .catch(error => {
            console.error('خطأ:', error);
            container.innerHTML = '<div class="loading-placeholder">حدث خطأ في تحميل البيانات</div>';
        });
}

// ============================================
// تبويب 1: سجل المنتج
// ============================================

function loadProductFullHistory() {
    if (!currentProductId) return;
    loadProductBasicInfo();
    loadBatchesMini();
    loadEntriesData();
    loadRemainingData();
    loadSalesAnalysisData();
}

function loadProductBasicInfo() {
    const row = document.querySelector(`tr[data-product-id="${currentProductId}"]`);
    if (row) {
        const nameEl = document.getElementById('productNameDisplay');
        const barcodeEl = document.getElementById('productBarcodeDisplay');
        const categoryEl = document.getElementById('productCategoryDisplay');
        if (nameEl) nameEl.textContent = row.cells[1]?.textContent || '---';
        if (barcodeEl) barcodeEl.textContent = row.cells[2]?.textContent || '---';
        if (categoryEl) categoryEl.textContent = row.cells[3]?.textContent || 'غير مصنف';
    }
}

function loadBatchesMini() {
    const container = document.getElementById('batchesMiniRow');
    if (!container) return;
    container.innerHTML = '<div class="batch-mini-loading">جاري تحميل الدفعات...</div>';
    
    fetch(BASE_URL + '/reports/product-batches?product_id=' + currentProductId)
        .then(r => r.json())
        .then(data => {
            if (data.success && data.data && data.data.length > 0) {
                renderBatchesMini(data.data);
            } else {
                container.innerHTML = '<div class="batch-mini-loading">لا توجد دفعات</div>';
            }
        })
        .catch(() => {
            container.innerHTML = '<div class="batch-mini-loading">خطأ في التحميل</div>';
        });
}

function renderBatchesMini(batches) {
    const container = document.getElementById('batchesMiniRow');
    let html = '';
    
    batches.forEach(batch => {
        const cashTotal = parseFloat(batch.cash_total) || 0;
        const creditTotal = parseFloat(batch.credit_total) || 0;
        const cashQty = parseInt(batch.cash_quantity) || 0;
        const creditQty = parseInt(batch.credit_quantity) || 0;
        const cartonsRemaining = parseInt(batch.cartons_remaining) || 0;
        const cartonsQuantity = parseInt(batch.cartons_quantity) || 0;
        
        html += `
            <div class="batch-mini-card" id="batch_mini_${batch.id}" onclick="showBatchMiniDetails(${batch.id})">
                <div class="batch-mini-header">
                    <span class="batch-mini-number">${escapeHtml(batch.batch_number)}</span>
                    <span>مدخلات: ${cartonsQuantity} كرتون</span>
                </div>
                <div class="batch-mini-stats">
                    <span>💰 نقدي: ${cashQty} قطعة (${formatMoney(cashTotal)})</span>
                    <span>📅 آجل: ${creditQty} قطعة (${formatMoney(creditTotal)})</span>
                    <span>📦 متبقي: ${cartonsRemaining}/${cartonsQuantity}</span>
                </div>
                <div class="batch-expanded-details" id="batch_mini_details_${batch.id}"></div>
            </div>
        `;
    });
    container.innerHTML = html;
}

function showBatchMiniDetails(batchId) {
    const detailsDiv = document.getElementById(`batch_mini_details_${batchId}`);
    if (!detailsDiv) return;
    
    if (detailsDiv.classList.contains('show')) {
        detailsDiv.classList.remove('show');
        return;
    }
    
    document.querySelectorAll('.batch-expanded-details').forEach(el => el.classList.remove('show'));
    detailsDiv.classList.add('show');
    detailsDiv.innerHTML = '<div class="loading-placeholder">جاري تحميل التفاصيل...</div>';
    
    fetch(BASE_URL + '/reports/batch-sales?batch_id=' + batchId)
        .then(r => r.json())
        .then(response => {
            if (response.success && response.data) {
                const sales = response.data;
                let cashQty = 0, creditQty = 0, cashTotal = 0, creditTotal = 0, totalProfit = 0;
                
                sales.forEach(sale => {
                    const quantity = parseInt(sale.quantity) || 0;
                    const subtotal = parseFloat(sale.subtotal) || 0;
                    const profit = parseFloat(sale.profit) || 0;
                    
                    if (sale.sale_type === 'cash') {
                        cashQty += quantity;
                        cashTotal += subtotal;
                    } else if (sale.sale_type === 'credit') {
                        creditQty += quantity;
                        creditTotal += subtotal;
                    }
                    totalProfit += profit;
                });
                
                const totalRevenue = cashTotal + creditTotal;
                
                detailsDiv.innerHTML = `
                    <div class="batch-detail-row">
                        <div class="batch-detail-item">💰 مبيعات نقدي: ${cashQty} قطعة (${formatMoney(cashTotal)})</div>
                        <div class="batch-detail-item">📅 مبيعات آجل: ${creditQty} قطعة (${formatMoney(creditTotal)})</div>
                    </div>
                    <div class="batch-detail-row">
                        <div class="batch-detail-item">📊 إجمالي البيع: ${formatMoney(totalRevenue)}</div>
                        <div class="batch-detail-item">💹 إجمالي الربح: ${formatMoney(totalProfit)}</div>
                    </div>
                `;
            } else {
                detailsDiv.innerHTML = '<div class="batch-detail-row">لا توجد مبيعات لهذه الدفعة</div>';
            }
        })
        .catch(error => {
            console.error('خطأ:', error);
            detailsDiv.innerHTML = '<div class="batch-detail-row">❌ حدث خطأ في تحميل البيانات</div>';
        });
    
    fetch(BASE_URL + '/reports/product-batches?product_id=' + currentProductId)
        .then(r => r.json())
        .then(response => {
            if (response.success && response.data) {
                const batch = response.data.find(b => b.id == batchId);
                if (batch) {
                    const expiryStatus = getExpiryStatus(batch.expiry_date);
                    const profitMargin = batch.profit_margin || 0;
                    const totalProfit = batch.total_profit || 0;
                    
                    const existingHtml = detailsDiv.innerHTML;
                    detailsDiv.innerHTML = `
                        <div class="batch-detail-row">
                            <div class="batch-detail-item">💰 سعر الشراء: ${formatMoney(batch.cost_price_unit)}</div>
                            <div class="batch-detail-item">🏷️ سعر البيع: ${formatMoney(batch.selling_price_unit)}</div>
                            <div class="batch-detail-item">📊 هامش الربح: ${profitMargin}%</div>
                        </div>
                        <div class="batch-detail-row">
                            <div class="batch-detail-item">📅 تاريخ الانتهاء: ${batch.expiry_date || '---'}</div>
                            <div class="batch-detail-item ${expiryStatus.class === 'status-warning' ? 'warning-text' : ''}">${expiryStatus.text}</div>
                            <div class="batch-detail-item">💹 إجمالي الربح المحقق: ${formatMoney(totalProfit)}</div>
                        </div>
                        ${existingHtml}
                    `;
                }
            }
        });
}

function loadEntriesData() {
    const container = document.getElementById('entriesList');
    if (!container) return;
    container.innerHTML = '<div class="loading-placeholder">جاري تحميل الدفعات...</div>';
    
    fetch(BASE_URL + '/reports/product-batches?product_id=' + currentProductId)
        .then(r => r.json())
        .then(data => {
            if (data.success && data.data && data.data.length > 0) {
                renderEntries(data.data);
            } else {
                container.innerHTML = '<div class="loading-placeholder">لا توجد دفعات</div>';
            }
        })
        .catch(() => {
            container.innerHTML = '<div class="loading-placeholder">حدث خطأ</div>';
        });
}

function renderEntries(batches) {
    const container = document.getElementById('entriesList');
    if (!container) return;
    
    let totalSoldQtyOverall = 0;
    let totalSalesAmountOverall = 0;
    let html = '';
    
    batches.forEach(batch => {
        const cartonsQuantity = parseInt(batch.cartons_quantity) || 0;
        const cartonsRemaining = parseInt(batch.cartons_remaining) || 0;
        const soldCartons = cartonsQuantity - cartonsRemaining;
        const unitsPerCarton = parseInt(batch.units_per_carton) || 1;
        const soldUnits = soldCartons * unitsPerCarton;
        const sellingPriceUnit = parseFloat(batch.selling_price_unit) || 0;
        const totalSales = soldUnits * sellingPriceUnit;
        
        totalSoldQtyOverall += soldUnits;
        totalSalesAmountOverall += totalSales;
        
        const isExpanded = (openEntryId === batch.id);
        const costPerCarton = parseFloat(batch.cost_price_carton) || 0;
        const sellingPrice = parseFloat(batch.selling_price_unit) || 0;
        const totalProfit = parseFloat(batch.total_profit) || 0;
        
        html += `
            <div class="entry-card ${isExpanded ? 'expanded' : ''}" onclick="toggleEntryDetails(${batch.id})" style="background: white; border: 1px solid var(--neutral-200); border-radius: var(--radius-md); margin-bottom: 12px; cursor: pointer; transition: all 0.2s;">
                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 12px; padding: 12px;">
                    <div>
                        <div style="font-size: 10px; color: var(--neutral-500); margin-bottom: 4px;">📦 رقم الدفعة</div>
                        <div style="font-weight: 600; color: var(--primary);">${escapeHtml(batch.batch_number)}</div>
                    </div>
                    <div>
                        <div style="font-size: 10px; color: var(--neutral-500); margin-bottom: 4px;">📅 تاريخ الإدخال</div>
                        <div style="font-weight: 500;">${batch.entry_date}</div>
                    </div>
                    <div>
                        <div style="font-size: 10px; color: var(--neutral-500); margin-bottom: 4px;">📦 عدد الكراتين</div>
                        <div style="font-weight: 500;">${cartonsQuantity} كرتون</div>
                    </div>
                    <div>
                        <div style="font-size: 10px; color: var(--neutral-500); margin-bottom: 4px;">💰 سعر الكرتون</div>
                        <div style="font-weight: 500;">${formatMoney(costPerCarton)} ريال</div>
                    </div>
                    <div>
                        <div style="font-size: 10px; color: var(--neutral-500); margin-bottom: 4px;">🏷️ سعر القطعة</div>
                        <div style="font-weight: 500;">${formatMoney(sellingPrice)} ريال</div>
                    </div>
                    <div>
                        <div style="font-size: 10px; color: var(--neutral-500); margin-bottom: 4px;">📊 الكراتين المتبقية</div>
                        <div style="font-weight: 500;">${cartonsRemaining} كرتون</div>
                    </div>
                    <div>
                        <div style="font-size: 10px; color: var(--neutral-500); margin-bottom: 4px;">💹 إجمالي الربح</div>
                        <div style="font-weight: 600; color: ${totalProfit >= 0 ? 'green' : 'red'}">${formatMoney(totalProfit)} ريال</div>
                    </div>
                    <div>
                        <div style="font-size: 10px; color: var(--neutral-500); margin-bottom: 4px;">📈 الكمية المباعة</div>
                        <div style="font-weight: 600; color: var(--primary);">${soldUnits} قطعة</div>
                    </div>
                    <div>
                        <div style="font-size: 10px; color: var(--neutral-500); margin-bottom: 4px;">💰 إجمالي المبيعات</div>
                        <div style="font-weight: 600; color: var(--success);">${formatMoney(totalSales)} ريال</div>
                    </div>
                </div>
                <div class="expanded-details" id="entry_details_${batch.id}" style="display: ${isExpanded ? 'block' : 'none'}; border-top: 1px solid var(--neutral-200); background: var(--neutral-50); padding: 12px;">
                    <div class="loading-placeholder">جاري تحميل التفاصيل...</div>
                </div>
            </div>
        `;
    });
    
    container.innerHTML = html;
    
    // تحديث الإجماليات في الرأس
    const totalSoldQtySpan = document.getElementById('totalSoldQty');
    const totalSalesAmountSpan = document.getElementById('totalSalesAmount');
    if (totalSoldQtySpan) totalSoldQtySpan.textContent = totalSoldQtyOverall;
    if (totalSalesAmountSpan) totalSalesAmountSpan.textContent = formatMoney(totalSalesAmountOverall);
    
    if (openEntryId) {
        loadEntryDetails(openEntryId);
    }
}
function toggleEntryDetails(batchId) {
    if (openEntryId === batchId) {
        openEntryId = null;
        const detailsDiv = document.getElementById(`entry_details_${batchId}`);
        const rowDiv = document.querySelector(`.entry-row[onclick*="toggleEntryDetails(${batchId})"]`);
        if (detailsDiv) detailsDiv.style.display = 'none';
        if (rowDiv) rowDiv.classList.remove('expanded');
    } else {
        if (openEntryId) {
            const oldDetails = document.getElementById(`entry_details_${openEntryId}`);
            const oldRow = document.querySelector(`.entry-row[onclick*="toggleEntryDetails(${openEntryId})"]`);
            if (oldDetails) oldDetails.style.display = 'none';
            if (oldRow) oldRow.classList.remove('expanded');
        }
        openEntryId = batchId;
        const newDetails = document.getElementById(`entry_details_${batchId}`);
        const newRow = document.querySelector(`.entry-row[onclick*="toggleEntryDetails(${batchId})"]`);
        if (newDetails) newDetails.style.display = 'block';
        if (newRow) newRow.classList.add('expanded');
        loadEntryDetails(batchId);
    }
}

function loadEntryDetails(batchId) {
    const container = document.getElementById(`entry_details_${batchId}`);
    if (!container) return;
    
    Promise.all([
        fetch(BASE_URL + '/reports/batch-sales?batch_id=' + batchId).then(r => r.json()),
        fetch(BASE_URL + '/reports/product-batches?product_id=' + currentProductId).then(r => r.json())
    ]).then(([salesData, batchData]) => {
        const batch = batchData.data?.find(b => b.id == batchId);
        if (!batch) return;
        
        let cashQty = 0, creditQty = 0, cashTotal = 0, creditTotal = 0, totalProfit = 0;
        
        if (salesData.success && salesData.data && salesData.data.length > 0) {
            salesData.data.forEach(sale => {
                const quantity = parseInt(sale.quantity) || 0;
                const subtotal = parseFloat(sale.subtotal) || 0;
                const profit = parseFloat(sale.profit) || 0;
                
                if (sale.sale_type === 'cash') {
                    cashQty += quantity;
                    cashTotal += subtotal;
                } else if (sale.sale_type === 'credit') {
                    creditQty += quantity;
                    creditTotal += subtotal;
                }
                totalProfit += profit;
            });
        }
        
        const totalRevenue = cashTotal + creditTotal;
        const totalQuantity = cashQty + creditQty;
        const avgCostPerUnit = parseFloat(batch.cost_price_unit) || 0;
        const totalCost = totalQuantity * avgCostPerUnit;
        const profit = totalRevenue - totalCost;
        
        container.innerHTML = `
            <div class="details-grid">
                <div class="detail-box">
                    <div class="detail-label">عدد الكراتين</div>
                    <div class="detail-value">${batch.cartons_quantity}</div>
                </div>
                <div class="detail-box">
                    <div class="detail-label">سعر الكرتون</div>
                    <div class="detail-value">${formatMoney(batch.cost_price_carton)}</div>
                </div>
                <div class="detail-box">
                    <div class="detail-label">تاريخ الانتهاء</div>
                    <div class="detail-value ${isNearExpiry(batch.expiry_date) ? 'warning-text' : ''}">${batch.expiry_date || '---'}</div>
                </div>
            </div>
            <div class="batch-sales-row">
                <div class="batch-sales-cash">
                    <strong>💰 نقدي</strong><br>
                    الكمية: ${cashQty} قطعة<br>
                    الإجمالي: ${formatMoney(cashTotal)}
                </div>
                <div class="batch-sales-credit">
                    <strong>📅 آجل</strong><br>
                    الكمية: ${creditQty} قطعة<br>
                    الإجمالي: ${formatMoney(creditTotal)}
                </div>
            </div>
            <div class="details-grid" style="margin-top: 10px;">
                <div class="detail-box">
                    <div class="detail-label">إجمالي التكلفة</div>
                    <div class="detail-value">${formatMoney(totalCost)}</div>
                </div>
                <div class="detail-box">
                    <div class="detail-label">إجمالي البيع</div>
                    <div class="detail-value">${formatMoney(totalRevenue)}</div>
                </div>
                <div class="detail-box">
                    <div class="detail-label">الربح</div>
                    <div class="detail-value ${profit >= 0 ? 'text-success' : 'text-danger'}">${formatMoney(profit)}</div>
                </div>
            </div>
        `;
    }).catch(error => {
        console.error('خطأ:', error);
        container.innerHTML = '<div class="loading-placeholder">حدث خطأ في تحميل التفاصيل</div>';
    });
}

function loadRemainingData() {
    const container = document.getElementById('remainingList');
    if (!container) return;
    container.innerHTML = '<div class="loading-placeholder">جاري تحميل المخزون المتبقي...</div>';
    
    fetch(BASE_URL + '/reports/product-batches?product_id=' + currentProductId)
        .then(r => r.json())
        .then(data => {
            if (data.success && data.data && data.data.length > 0) {
                const remaining = data.data.filter(b => b.cartons_remaining > 0);
                renderRemaining(remaining);
            } else {
                container.innerHTML = '<div class="loading-placeholder">لا يوجد مخزون متبقي</div>';
            }
        });
}

function renderRemaining(batches) {
    const container = document.getElementById('remainingList');
    if (!container) return;
    
    let totalRemainingUnitsAll = 0;
    let totalRemainingValueAll = 0;
    let html = '';
    
    batches.forEach(batch => {
        const cartonsRemaining = parseInt(batch.cartons_remaining) || 0;
        const unitsPerCarton = parseInt(batch.units_per_carton) || 1;
        const totalUnits = cartonsRemaining * unitsPerCarton;
        const costPerUnit = parseFloat(batch.cost_price_unit) || 0;
        const totalValue = totalUnits * costPerUnit;
        const sellingPrice = parseFloat(batch.selling_price_unit) || 0;
        
        totalRemainingUnitsAll += totalUnits;
        totalRemainingValueAll += totalValue;
        
        const isExpanded = (openRemainingId === batch.id);
        
        html += `
            <div class="remaining-card ${isExpanded ? 'expanded' : ''}" onclick="toggleRemainingDetails(${batch.id})" style="background: white; border: 1px solid var(--neutral-200); border-radius: var(--radius-md); margin-bottom: 12px; cursor: pointer; transition: all 0.2s;">
                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 12px; padding: 12px;">
                    <div>
                        <div style="font-size: 10px; color: var(--neutral-500); margin-bottom: 4px;">📦 رقم الدفعة</div>
                        <div style="font-weight: 600; color: var(--primary);">${escapeHtml(batch.batch_number)}</div>
                    </div>
                    <div>
                        <div style="font-size: 10px; color: var(--neutral-500); margin-bottom: 4px;">📅 تاريخ الإدخال</div>
                        <div style="font-weight: 500;">${batch.entry_date}</div>
                    </div>
                    <div>
                        <div style="font-size: 10px; color: var(--neutral-500); margin-bottom: 4px;">📦 الكراتين المتبقية</div>
                        <div style="font-weight: 500;">${cartonsRemaining} كرتون</div>
                    </div>
                    <div>
                        <div style="font-size: 10px; color: var(--neutral-500); margin-bottom: 4px;">🔢 القطع المتبقية</div>
                        <div style="font-weight: 600; color: var(--success);">${totalUnits} قطعة</div>
                    </div>
                    <div>
                        <div style="font-size: 10px; color: var(--neutral-500); margin-bottom: 4px;">💰 قيمة المخزون</div>
                        <div style="font-weight: 600; color: var(--primary);">${formatMoney(totalValue)} ريال</div>
                    </div>
                    <div>
                        <div style="font-size: 10px; color: var(--neutral-500); margin-bottom: 4px;">🏷️ سعر البيع</div>
                        <div style="font-weight: 500;">${formatMoney(sellingPrice)} ريال/قطعة</div>
                    </div>
                </div>
                <div class="expanded-details" id="remaining_details_${batch.id}" style="display: ${isExpanded ? 'block' : 'none'}; border-top: 1px solid var(--neutral-200); background: var(--neutral-50); padding: 12px;">
                    <div class="loading-placeholder">جاري تحميل التفاصيل...</div>
                </div>
            </div>
        `;
    });
    
    container.innerHTML = html;
    
    // تحديث الإجماليات في الرأس
    const totalRemainingUnitsSpan = document.getElementById('totalRemainingUnits');
    const totalRemainingValueSpan = document.getElementById('totalRemainingValue');
    if (totalRemainingUnitsSpan) totalRemainingUnitsSpan.textContent = totalRemainingUnitsAll;
    if (totalRemainingValueSpan) totalRemainingValueSpan.textContent = formatMoney(totalRemainingValueAll);
    
    if (openRemainingId) {
        loadRemainingDetails(openRemainingId);
    }
}

function toggleRemainingDetails(batchId) {
    if (openRemainingId === batchId) {
        openRemainingId = null;
        const detailsDiv = document.getElementById(`remaining_details_${batchId}`);
        const rowDiv = document.querySelector(`.remaining-row[onclick*="toggleRemainingDetails(${batchId})"]`);
        if (detailsDiv) detailsDiv.style.display = 'none';
        if (rowDiv) rowDiv.classList.remove('expanded');
    } else {
        if (openRemainingId) {
            const oldDetails = document.getElementById(`remaining_details_${openRemainingId}`);
            const oldRow = document.querySelector(`.remaining-row[onclick*="toggleRemainingDetails(${openRemainingId})"]`);
            if (oldDetails) oldDetails.style.display = 'none';
            if (oldRow) oldRow.classList.remove('expanded');
        }
        openRemainingId = batchId;
        const newDetails = document.getElementById(`remaining_details_${batchId}`);
        const newRow = document.querySelector(`.remaining-row[onclick*="toggleRemainingDetails(${batchId})"]`);
        if (newDetails) newDetails.style.display = 'block';
        if (newRow) newRow.classList.add('expanded');
        loadRemainingDetails(batchId);
    }
}

function loadRemainingDetails(batchId) {
    const container = document.getElementById(`remaining_details_${batchId}`);
    if (!container) return;
    
    fetch(BASE_URL + '/reports/product-batches?product_id=' + currentProductId)
        .then(r => r.json())
        .then(data => {
            const batch = data.data?.find(b => b.id == batchId);
            if (!batch) return;
            
            const expiryStatus = getExpiryStatus(batch.expiry_date);
            container.innerHTML = `
                <div class="details-grid">
                    <div class="detail-box">
                        <div class="detail-label">سعر القطعة</div>
                        <div class="detail-value">${formatMoney(batch.selling_price_unit)}</div>
                    </div>
                    <div class="detail-box">
                        <div class="detail-label">سعر الشراء</div>
                        <div class="detail-value">${formatMoney(batch.cost_price_unit)}</div>
                    </div>
                    <div class="detail-box">
                        <div class="detail-label">تاريخ الانتهاء</div>
                        <div class="detail-value ${expiryStatus.class === 'status-warning' ? 'warning-text' : ''}">${batch.expiry_date || '---'}</div>
                    </div>
                </div>
                <div class="detail-box" style="margin-top: 8px;">
                    <div class="detail-label">حالة المخزون</div>
                    <div class="detail-value ${expiryStatus.class === 'status-warning' ? 'warning-text' : ''}">
                        ${expiryStatus.text}
                        ${expiryStatus.days ? ` (${expiryStatus.days} يوم متبقي)` : ''}
                    </div>
                </div>
            `;
        });
}

function renderSalesAnalysis(byPrice) {
    const container = document.getElementById('salesAnalysisList');
    if (!container) return;
    
    if (!byPrice || byPrice.length === 0) {
        container.innerHTML = '<div class="loading-placeholder">لا توجد مبيعات</div>';
        return;
    }
    
    let html = '<div class="sales-header"><div class="sales-header-item">سعر البيع</div><div class="sales-header-item">الكمية</div><div class="sales-header-item">الإجمالي</div><div class="sales-header-item">نقدي</div><div class="sales-header-item">آجل</div><div class="sales-header-item">الربح</div></div><div class="sales-scroll">';
    
    for (let i = 0; i < byPrice.length; i++) {
        const item = byPrice[i];
        const priceValue = parseFloat(item.price_unit) || 0;
        const totalQuantity = parseInt(item.total_quantity) || 0;
        const totalAmount = parseFloat(item.total_amount) || 0;
        const totalProfit = parseFloat(item.total_profit) || 0;
        const cashQuantity = parseFloat(item.cash_quantity) || 0;
        const creditQuantity = parseFloat(item.credit_quantity) || 0;
        const cashAmount = cashQuantity * priceValue;
        const creditAmount = creditQuantity * priceValue;
        
        html += `
            <div class="sales-row" onclick="toggleSalesDetails(${priceValue})">
                <div class="sales-col">${formatMoney(priceValue)}</div>
                <div class="sales-col">${totalQuantity}</div>
                <div class="sales-col">${formatMoney(totalAmount)}</div>
                <div class="sales-col">${formatMoney(cashAmount)}</div>
                <div class="sales-col">${formatMoney(creditAmount)}</div>
                <div class="sales-col" style="color: ${totalProfit >= 0 ? 'green' : 'red'}">${formatMoney(totalProfit)}</div>
            </div>
            <div class="sales-expanded" id="sales_details_${priceValue}" style="display: none">
                <div class="loading-placeholder">جاري تحميل التفاصيل...</div>
            </div>
        `;
    }
    html += '</div>';
    container.innerHTML = html;
}

function toggleSalesDetails(price) {
    const priceKey = parseFloat(price);
    if (isNaN(priceKey)) return;
    
    if (openSalesPrice === priceKey) {
        openSalesPrice = null;
        const detailsDiv = document.getElementById(`sales_details_${priceKey}`);
        const rowDiv = document.querySelector(`.sales-row[onclick*="toggleSalesDetails(${priceKey})"]`);
        if (detailsDiv) detailsDiv.style.display = 'none';
        if (rowDiv) rowDiv.classList.remove('expanded');
    } else {
        if (openSalesPrice) {
            const oldDetails = document.getElementById(`sales_details_${openSalesPrice}`);
            const oldRow = document.querySelector(`.sales-row[onclick*="toggleSalesDetails(${openSalesPrice})"]`);
            if (oldDetails) oldDetails.style.display = 'none';
            if (oldRow) oldRow.classList.remove('expanded');
        }
        openSalesPrice = priceKey;
        const newDetails = document.getElementById(`sales_details_${priceKey}`);
        const newRow = document.querySelector(`.sales-row[onclick*="toggleSalesDetails(${priceKey})"]`);
        if (newDetails) newDetails.style.display = 'block';
        if (newRow) newRow.classList.add('expanded');
        loadSalesDetails(priceKey);
    }
}

function loadSalesDetails(price) {
    const container = document.getElementById(`sales_details_${price}`);
    if (!container) return;
    
    let url = BASE_URL + '/reports/product-sales-analysis?product_id=' + currentProductId;
    if (currentFilterPeriod !== 'all' && currentFilterPeriod !== 'custom') {
        const dates = calculatePeriodDates(currentFilterPeriod);
        if (dates.from && dates.to) {
            url += '&from=' + dates.from + '&to=' + dates.to;
        }
    }
    if (currentFilterPeriod === 'custom' && currentFilterFrom && currentFilterTo) {
        url += '&from=' + currentFilterFrom + '&to=' + currentFilterTo;
    }
    
    fetch(url)
        .then(r => r.json())
        .then(data => {
            if (data.success && data.data && data.data.details) {
                const details = data.data.details || [];
                const salesAtPrice = details.filter(s => parseFloat(s.selling_price) == parseFloat(price));
                const cashSales = salesAtPrice.filter(s => s.sale_type === 'cash');
                const creditSales = salesAtPrice.filter(s => s.sale_type === 'credit');
                
                const totalQuantity = salesAtPrice.reduce((sum, s) => sum + (parseInt(s.quantity) || 0), 0);
                const totalRevenue = salesAtPrice.reduce((sum, s) => sum + (parseFloat(s.subtotal) || 0), 0);
                const totalProfit = salesAtPrice.reduce((sum, s) => sum + (parseFloat(s.profit) || 0), 0);
                
                container.innerHTML = `
                    <div class="details-grid">
                        <div class="detail-box">
                            <div class="detail-label">💰 المبيعات النقدية</div>
                            <div class="detail-value">${cashSales.length} عملية</div>
                            <div class="detail-label" style="margin-top: 8px;">العملاء:</div>
                            <div style="font-size: 11px; max-height: 80px; overflow-y: auto;">
                                ${cashSales.map(s => s.customer_name || 'عميل نقدي').join('<br>') || '---'}
                            </div>
                        </div>
                        <div class="detail-box">
                            <div class="detail-label">📅 المبيعات الآجلة</div>
                            <div class="detail-value">${creditSales.length} عملية</div>
                            <div class="detail-label" style="margin-top: 8px;">العملاء:</div>
                            <div style="font-size: 11px; max-height: 80px; overflow-y: auto;">
                                ${creditSales.map(s => s.customer_name || '---').join('<br>') || '---'}
                            </div>
                        </div>
                    </div>
                    <div class="details-grid" style="margin-top: 8px;">
                        <div class="detail-box">
                            <div class="detail-label">إجمالي القطع المباعة</div>
                            <div class="detail-value">${totalQuantity}</div>
                        </div>
                        <div class="detail-box">
                            <div class="detail-label">إجمالي الإيرادات</div>
                            <div class="detail-value">${formatMoney(totalRevenue)}</div>
                        </div>
                        <div class="detail-box">
                            <div class="detail-label">إجمالي الربح</div>
                            <div class="detail-value" style="color: ${totalProfit >= 0 ? 'green' : 'red'}">${formatMoney(totalProfit)}</div>
                        </div>
                    </div>
                `;
            } else {
                container.innerHTML = '<div class="loading-placeholder">لا توجد تفاصيل</div>';
            }
        })
        .catch((error) => {
            console.error('خطأ:', error);
            container.innerHTML = '<div class="loading-placeholder">خطأ في التحميل</div>';
        });
}

function initFilters() {
    const filterBtns = document.querySelectorAll('.filter-btn');
    const customDatesDiv = document.querySelector('.custom-date-inputs');
    const dateFrom = document.getElementById('filterDateFrom');
    const dateTo = document.getElementById('filterDateTo');
    
    if (!filterBtns.length) return;
    
    filterBtns.forEach(btn => {
        btn.addEventListener('click', function() {
            filterBtns.forEach(b => b.classList.remove('active'));
            this.classList.add('active');
            
            const period = this.dataset.period;
            currentFilterPeriod = period;
            
            if (period === 'custom') {
                if (customDatesDiv) customDatesDiv.style.display = 'flex';
                if (dateFrom && dateTo && dateFrom.value && dateTo.value) {
                    currentFilterFrom = dateFrom.value;
                    currentFilterTo = dateTo.value;
                    refreshDataAfterFilter();
                }
            } else {
                if (customDatesDiv) customDatesDiv.style.display = 'none';
                currentFilterFrom = null;
                currentFilterTo = null;
                refreshDataAfterFilter();
            }
        });
    });
    
    if (dateFrom && dateTo) {
        dateFrom.addEventListener('change', function() {
            if (currentFilterPeriod === 'custom' && this.value && dateTo.value) {
                currentFilterFrom = this.value;
                currentFilterTo = dateTo.value;
                refreshDataAfterFilter();
            }
        });
        dateTo.addEventListener('change', function() {
            if (currentFilterPeriod === 'custom' && dateFrom.value && this.value) {
                currentFilterFrom = dateFrom.value;
                currentFilterTo = this.value;
                refreshDataAfterFilter();
            }
        });
    }
}

function refreshDataAfterFilter() {
    loadEntriesData();
    loadRemainingData();
    loadSalesAnalysisData();
}

// ============================================
// تبويب 2: تفاصيل الدفعات
// ============================================
function loadBatchesData() {
    const container = document.getElementById('batchesList');
    if (!container) return;
    container.innerHTML = '<div class="no-data-block"><div class="no-data-icon">📦</div><div class="no-data-text">جاري تحميل الدفعات...</div></div>';
    
    fetch(BASE_URL + '/reports/product-batches?product_id=' + currentProductId)
        .then(r => r.json())
        .then(data => {
            if (data.success && data.data && data.data.length > 0) {
                renderBatches(data.data);
                updateBatchesStats(data.data);
            } else {
                container.innerHTML = '<div class="no-data-block"><div class="no-data-icon">📦</div><div class="no-data-text">لا توجد دفعات لهذا المنتج</div></div>';
            }
        })
        .catch(() => {
            container.innerHTML = '<div class="no-data-block"><div class="no-data-icon">❌</div><div class="no-data-text">حدث خطأ</div></div>';
        });
}

function updateBatchesStats(batches) {
    let totalCartons = 0, totalUnits = 0, totalValue = 0;
    batches.forEach(b => {
        totalCartons += b.cartons_remaining || 0;
        totalUnits += (b.cartons_remaining || 0) * (b.units_per_carton || 1);
        totalValue += (b.cartons_remaining || 0) * (b.cost_price_carton || 0);
    });
    const totalBatches = document.getElementById('totalBatches');
    const totalCartonsEl = document.getElementById('totalCartonsRemaining');
    const totalUnitsEl = document.getElementById('totalUnitsRemaining');
    const batchesValueEl = document.getElementById('batchesValue');
    if (totalBatches) totalBatches.textContent = batches.length;
    if (totalCartonsEl) totalCartonsEl.textContent = totalCartons;
    if (totalUnitsEl) totalUnitsEl.textContent = totalUnits;
    if (batchesValueEl) batchesValueEl.textContent = formatMoney(totalValue);
}

function renderBatches(batches) {
    const container = document.getElementById('batchesList');
    let html = '<div class="batches-list">';
    batches.forEach(batch => {
        const totalUnits = (batch.cartons_remaining || 0) * (batch.units_per_carton || 1);
        const expiryStatus = getExpiryStatus(batch.expiry_date);
        html += `<div class="batch-card">
            <div class="batch-header" onclick="toggleBatchDetails(${batch.id})">
                <div class="batch-header-left">
                    <span class="batch-number">${batch.batch_number || '---'}</span>
                    <div class="batch-info">
                        <div class="batch-info-item"><span class="batch-info-label">الكراتين</span><span class="batch-info-value">${batch.cartons_remaining || 0} / ${batch.cartons_quantity || 0}</span></div>
                        <div class="batch-info-item"><span class="batch-info-label">القطع</span><span class="batch-info-value">${totalUnits}</span></div>
                        <div class="batch-info-item"><span class="batch-info-label">سعر الشراء</span><span class="batch-info-value">${formatMoney(batch.cost_price_carton || 0)} /كرتون</span></div>
                        <div class="batch-info-item"><span class="batch-info-label">سعر البيع</span><span class="batch-info-value">${formatMoney(batch.selling_price_unit || 0)} /قطعة</span></div>
                    </div>
                </div>
                <div><span class="batch-status ${expiryStatus.class}">${expiryStatus.text}</span><span style="margin-left:10px;">▼</span></div>
            </div>
            <div class="batch-details" id="batchDetails_${batch.id}">
                <div style="padding:15px;"><h4>تفاصيل المبيعات</h4><table class="data-grid"><thead><tr><th>التاريخ</th><th>الكمية</th><th>سعر البيع</th><th>الإجمالي</th><th>النوع</th></tr></thead><tbody id="batchSales_${batch.id}"><tr><td colspan="5" class="no-data">جاري التحميل...</td></tr></tbody></table></div>
            </div>
        </div>`;
    });
    html += '</div>';
    container.innerHTML = html;
    if (batches.length > 0) loadBatchSales(batches[0].id);
}

function toggleBatchDetails(batchId) {
    const details = document.getElementById('batchDetails_' + batchId);
    if (!details) return;
    const isExpanded = details.classList.contains('expanded');
    document.querySelectorAll('.batch-details').forEach(el => el.classList.remove('expanded'));
    if (!isExpanded) {
        details.classList.add('expanded');
        loadBatchSales(batchId);
    }
}

function loadBatchSales(batchId) {
    const container = document.getElementById('batchSales_' + batchId);
    if (!container) return;
    fetch(BASE_URL + '/reports/batch-sales?batch_id=' + batchId)
        .then(r => r.json())
        .then(data => {
            if (data.success && data.data && data.data.length > 0) {
                let html = '';
                data.data.forEach(sale => {
                    const typeClass = sale.sale_type === 'cash' ? 'status-good' : 'status-warning';
                    const typeText = sale.sale_type === 'cash' ? 'نقدي' : 'آجل';
                    html += `<tr><td>${sale.sale_date}</td><td>${sale.quantity}</td><td>${formatMoney(sale.price_unit)}</td><td>${formatMoney(sale.subtotal)}</td><td><span class="status-badge ${typeClass}">${typeText}</span></td></tr>`;
                });
                container.innerHTML = html;
            } else {
                container.innerHTML = '<tr><td colspan="5" class="no-data">لا توجد مبيعات</td></tr>';
            }
        })
        .catch(() => {
            container.innerHTML = '<tr><td colspan="5" class="no-data">خطأ</td></tr>';
        });
}

// ============================================
// تبويب 3: الجرد الفعلي
// ============================================
function loadInventoryData() {
    if (!currentProductId) return;
    const productIdInput = document.getElementById('currentInventoryProductId');
    if (productIdInput) productIdInput.value = currentProductId;
    
    fetch(BASE_URL + '/reports/product-inventory-details?product_id=' + currentProductId)
        .then(r => r.json())
        .then(data => {
            if (data.success) {
                inventoryData = data.data;
                renderMainInventory(data.data.main_inventory);
                renderShelfInventory(data.data.shelf_inventory);
                updateInventorySummary(data.data);
                setupInventoryInput(data.data);
                loadLastAuditInfo();
            }
        })
        .catch(e => console.error);
}

function renderMainInventory(items) {
    const tbody = document.getElementById('mainInventoryBody');
    if (!tbody) return;
    if (!items || items.length === 0) {
        tbody.innerHTML = '<tr><td colspan="7" class="no-data">لا توجد دفعات</td></tr>';
        return;
    }
    let html = '';
    items.forEach(item => {
        const totalUnits = item.cartons_remaining * (item.units_per_carton || 1);
        const value = totalUnits * (item.cost_price_unit || 0);
        html += `创业
            <td class="text-center">${item.batch_number || '---'}</td>
            <td class="text-center">${item.cartons_remaining}</td>
            <td class="text-center">${item.units_per_carton || 1}</td>
            <td class="text-center">${totalUnits}</td>
            <td class="text-center">${formatMoney(item.cost_price_unit || 0)}</td>
            <td class="text-center">${formatMoney(item.selling_price_unit || 0)}</td>
            <td class="text-center">${formatMoney(value)}</td>
        </tr>`;
    });
    tbody.innerHTML = html;
}

function renderShelfInventory(items) {
    const tbody = document.getElementById('shelfInventoryBody');
    if (!tbody) return;
    if (!items || items.length === 0) {
        tbody.innerHTML = '<tr><td colspan="5" class="no-data">لا توجد أرفف</td></tr>';
        return;
    }
    let html = '';
    items.forEach(item => {
        const value = item.units_remaining * (item.selling_price_unit || 0);
        html += `<tr>
            <td class="text-center">${item.shelf_code || '---'}</td>
            <td class="text-center">${item.units_remaining}</td>
            <td class="text-center">${formatMoney(item.selling_price_unit || 0)}</td>
            <td class="text-center">${formatMoney(value)}</td>
            <td class="text-center">${item.added_at || '---'}</td>
        </tr>`;
    });
    tbody.innerHTML = html;
}

function updateInventorySummary(data) {
    const mainTotal = data.main_total || 0;
    const mainCartons = data.main_cartons_total || 0;
    const shelfTotal = data.shelf_total || 0;
    const expectedTotal = mainTotal + shelfTotal;
    const costValue = data.cost_value || 0;
    const saleValue = data.sale_value || 0;
    const expectedTotalEl = document.getElementById('expectedTotal');
    const expectedBreakdownEl = document.getElementById('expectedBreakdown');
    const expectedValueEl = document.getElementById('expectedValue');
    const expectedValueBreakdownEl = document.getElementById('expectedValueBreakdown');
    if (expectedTotalEl) expectedTotalEl.textContent = `${mainCartons} كرتون | ${shelfTotal} قطعة`;
    if (expectedBreakdownEl) expectedBreakdownEl.textContent = `الكلي بالقطع: ${expectedTotal} قطعة`;
    if (expectedValueEl) expectedValueEl.textContent = formatMoney(saleValue);
    if (expectedValueBreakdownEl) expectedValueBreakdownEl.textContent = `تكلفة: ${formatMoney(costValue)} | بيع: ${formatMoney(saleValue)}`;
}

function setupInventoryInput(data) {
    const actualCartonsInput = document.getElementById('actualQuantityCartons');
    const actualPiecesInput = document.getElementById('actualQuantityPieces');
    if (!actualCartonsInput || !actualPiecesInput) return;
    
    const expectedTotal = (data.main_total || 0) + (data.shelf_total || 0);
    const avgCost = data.avg_cost || 0;
    const unitsPerCarton = data.product ? (data.product.units_per_carton || 1) : 1;
    
    function calcDifference() {
        const currentCartonsInput = document.getElementById('actualQuantityCartons');
        const currentPiecesInput = document.getElementById('actualQuantityPieces');
        
        const actualCartons = parseFloat(currentCartonsInput.value) || 0;
        const actualPieces = parseInt(currentPiecesInput.value) || 0;
        
        const actualTotalDisplay = document.getElementById('actualTotalDisplay');
        if (actualTotalDisplay) {
            actualTotalDisplay.textContent = `${actualCartons} كرتون | ${actualPieces} قطعة`;
        }
        
        const actualTotalPieces = Math.floor(actualCartons * unitsPerCarton) + actualPieces;
        const diff = actualTotalPieces - expectedTotal;
        const diffDisplay = document.getElementById('differenceDisplay');
        if (diffDisplay) {
            diffDisplay.textContent = diff > 0 ? '+' + diff : diff;
            diffDisplay.className = 'difference-value ' + (diff > 0 ? 'diff-positive' : (diff < 0 ? 'diff-negative' : 'diff-zero'));
        }
        const financialImpact = document.getElementById('financialImpact');
        if (financialImpact) financialImpact.innerHTML = `القيمة المالية للفرق: ${formatMoney(diff * avgCost)} ريال`;
    }
    
    const newCartonsInput = actualCartonsInput.cloneNode(true);
    actualCartonsInput.parentNode.replaceChild(newCartonsInput, actualCartonsInput);
    
    const newPiecesInput = actualPiecesInput.cloneNode(true);
    actualPiecesInput.parentNode.replaceChild(newPiecesInput, actualPiecesInput);
    
    newCartonsInput.addEventListener('input', calcDifference);
    newPiecesInput.addEventListener('input', calcDifference);
    
    // لتحديث أسرع أثناء الكتابة
    newCartonsInput.addEventListener('keyup', calcDifference);
    newPiecesInput.addEventListener('keyup', calcDifference);
    
    calcDifference();
}

function loadLastAuditInfo() {
    const container = document.getElementById('lastAuditInfo');
    if (!container) return;
    fetch(BASE_URL + '/reports/last-audit?product_id=' + currentProductId)
        .then(r => r.json())
        .then(data => {
            if (data.success && data.data) {
                const audit = data.data;
                const diffClass = audit.difference > 0 ? 'diff-positive' : (audit.difference < 0 ? 'diff-negative' : 'diff-zero');
                
                const unitsPerCarton = inventoryData?.product?.units_per_carton || 1;
                function formatQty(qty) {
                    const absQty = Math.abs(qty);
                    const cartons = Math.floor(absQty / unitsPerCarton);
                    const pieces = absQty % unitsPerCarton;
                    return `${cartons} كرتون | ${pieces} قطعة`;
                }
                const diffFormatted = audit.difference > 0 ? '+' + formatQty(audit.difference) : (audit.difference < 0 ? '-' + formatQty(audit.difference) : formatQty(0));
                
                container.innerHTML = `<div style="font-weight:600;">آخر جرد:</div><div style="margin-top:5px; font-size:13px;"><span>التاريخ: ${audit.audit_date}</span> | <span class="${diffClass}" style="font-weight:600;">الفرق: ${diffFormatted}</span> | <span>السبب: ${audit.reason || '---'}</span></div>`;
            }
        })
        .catch(() => {});
}

function savePhysicalInventory() {
    const productId = document.getElementById('currentInventoryProductId')?.value;
    const actualCartonsInput = document.getElementById('actualQuantityCartons')?.value;
    const actualPiecesInput = document.getElementById('actualQuantityPieces')?.value;
    
    const reasonSelect = document.getElementById('differenceReasonSelect')?.value;
    const reasonText = document.getElementById('differenceReason')?.value;
    
    if (!productId || (actualCartonsInput === '' && actualPiecesInput === '')) {
        alert('الرجاء إدخال الكمية بصورة صحيحة');
        return;
    }
    
    const actualCartons = parseFloat(actualCartonsInput) || 0;
    const actualPieces = parseInt(actualPiecesInput) || 0;
    if (actualCartons < 0 || actualPieces < 0) {
        alert('الكمية لا يمكن أن تكون سالبة');
        return;
    }
    
    const unitsPerCarton = inventoryData?.product?.units_per_carton || 1;
    const actualQty = Math.floor(actualCartons * unitsPerCarton) + actualPieces;
    
    const expectedTotal = (inventoryData?.main_total || 0) + (inventoryData?.shelf_total || 0);
    const difference = actualQty - expectedTotal;
    const data = {
        product_id: productId,
        actual_quantity: actualQty,
        expected_quantity: expectedTotal,
        difference: difference,
        reason: (reasonSelect || '') + (reasonText ? ' - ' + reasonText : '')
    };
    const saveBtn = document.querySelector('#tabPane3 .btn-success-sm');
    if (!saveBtn) return;
    const originalText = saveBtn.innerHTML;
    saveBtn.innerHTML = '⏳ جاري الحفظ...';
    saveBtn.disabled = true;
    fetch(BASE_URL + '/reports/save-physical-inventory', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
    })
        .then(r => r.json())
        .then(result => {
            if (result.success) {
                alert('✅ تم حفظ الجرد بنجاح');
                loadInventoryData();
                loadAuditHistory();
                const cartonsInput = document.getElementById('actualQuantityCartons');
                const piecesInput = document.getElementById('actualQuantityPieces');
                const reasonSelectEl = document.getElementById('differenceReasonSelect');
                const reasonTextEl = document.getElementById('differenceReason');
                if (cartonsInput) cartonsInput.value = '';
                if (piecesInput) piecesInput.value = '';
                if (reasonSelectEl) reasonSelectEl.value = '';
                if (reasonTextEl) reasonTextEl.value = '';
            } else {
                alert('❌ ' + (result.message || 'فشل حفظ الجرد'));
            }
        })
        .catch(e => {
            alert('حدث خطأ في الاتصال');
        })
        .finally(() => {
            saveBtn.innerHTML = originalText;
            saveBtn.disabled = false;
        });
}

function refreshInventoryData() {
    loadInventoryData();
}

// ============================================
// تبويب 4: سجل الجرد
// ============================================
function loadAuditHistory() {
    if (!currentProductId) return;
    const container = document.getElementById('auditHistory');
    if (!container) return;
    fetch(BASE_URL + '/reports/product-audit-history?product_id=' + currentProductId)
        .then(r => r.json())
        .then(data => {
            if (data.success && data.data && data.data.length > 0) {
                renderAuditHistory(data.data);
                updateAuditStats(data.stats);
            } else {
                container.innerHTML = '<div class="no-data-block"><div class="no-data-icon">📋</div><div class="no-data-text">لا يوجد سجل جرد لهذا المنتج</div></div>';
            }
        })
        .catch(() => {
            container.innerHTML = '<div class="no-data-block"><div class="no-data-icon">❌</div><div class="no-data-text">حدث خطأ</div></div>';
        });
}

function renderAuditHistory(audits) {
    const container = document.getElementById('auditHistory');
    if (!container) return;
    let html = '';
    
    const unitsPerCarton = inventoryData?.product?.units_per_carton || 1;
    function formatQty(qty) {
        const absQty = Math.abs(qty);
        const cartons = Math.floor(absQty / unitsPerCarton);
        const pieces = absQty % unitsPerCarton;
        return `${cartons} كرتون | ${pieces} قطعة`;
    }
    
    audits.forEach(audit => {
        const diffClass = audit.difference > 0 ? 'diff-positive' : (audit.difference < 0 ? 'diff-negative' : 'diff-zero');
        const statusText = audit.difference > 0 ? 'زيادة' : (audit.difference < 0 ? 'عجز' : 'مطابق');
        const applyStatus = audit.status === 'applied' ? '<span class="status-badge status-good" style="margin-right:5px;">مُطبق فعلياً</span>' : '<span class="status-badge status-warning" style="margin-right:5px;">مسودة - لم يُطبق</span>';
        
        const expectedTxt = formatQty(audit.expected_qty);
        const actualTxt = formatQty(audit.actual_qty);
        const diffFormatted = audit.difference > 0 ? '+' + formatQty(audit.difference) : (audit.difference < 0 ? '-' + formatQty(audit.difference) : formatQty(0));
        
        // أزرار التحكم
        let actionButtons = '';
        if (audit.status !== 'applied') {
            actionButtons = `
                <div style="margin-top:15px; padding-top:15px; border-top:1px solid var(--neutral-200); display:flex; gap:10px; justify-content:flex-end;">
                    <button type="button" class="btn-sm btn-primary-sm" onclick="editAudit(${audit.id}, ${audit.actual_qty}, '${escapeHtml(audit.reason || '')}')">✏️ تعديل</button>
                    <button type="button" class="btn-sm btn-danger-sm" onclick="deleteAudit(${audit.id})">🗑️ حذف</button>
                    <button type="button" class="btn-sm btn-success-sm" onclick="applyAuditToDB(${audit.id})">✅ تطبيق الجرد الفعلي</button>
                </div>
            `;
        }

        html += `<div style="background:white;border:1px solid var(--neutral-200);border-radius:8px;padding:15px;margin-bottom:15px;">
            <div style="display:flex;justify-content:space-between;margin-bottom:10px;">
                <span>📅 ${audit.audit_date} ${applyStatus}</span>
                <span>بواسطة: ${audit.user_name || 'المدير'}</span>
            </div>
            <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:10px;">
                <div><span style="font-size:11px;color:var(--neutral-500);">المتوقعة</span><div style="font-weight:600;font-size:13px;color:var(--primary);">${expectedTxt}</div></div>
                <div><span style="font-size:11px;color:var(--neutral-500);">الفعلية</span><div style="font-weight:600;font-size:13px;color:var(--primary);">${actualTxt}</div></div>
                <div><span style="font-size:11px;color:var(--neutral-500);">الفرق</span><div class="${diffClass}" style="font-weight:600;font-size:13px;">${diffFormatted}</div></div>
                <div><span style="font-size:11px;color:var(--neutral-500);">طبيعة الفرق</span><div style="margin-top:2px;"><span class="status-badge ${audit.difference > 0 ? 'status-good' : (audit.difference < 0 ? 'status-expired' : 'status-warning')}">${statusText}</span></div></div>
            </div>${audit.reason ? `<div style="margin-top:10px;padding-top:10px;border-top:1px dashed var(--neutral-200);">السبب: ${audit.reason}</div>` : ''}
            ${actionButtons}
        </div>`;
    });
    container.innerHTML = html;
}

function updateAuditStats(stats) {
    if (!stats) return;
    const container = document.getElementById('auditStats');
    if (!container) return;
    const total = stats.total_count || 0;
    const accuracy = total > 0 ? ((stats.matched_count / total) * 100).toFixed(1) : 0;
    container.innerHTML = `
        <div class="audit-card"><div class="audit-percentage">${total}</div><div class="stat-label">إجمالي الجردات</div></div>
        <div class="audit-card"><div class="audit-percentage">${accuracy}%</div><div class="stat-label">دقة الجرد</div></div>
        <div class="audit-card"><div class="audit-percentage">${stats.deficit_count || 0}</div><div class="stat-label">مرات العجز</div></div>
        <div class="audit-card"><div class="audit-percentage">${stats.surplus_count || 0}</div><div class="stat-label">مرات الزيادة</div></div>
    `;
}

function editAudit(auditId, currentActualQty, currentReason) {
    showEditAuditModal(auditId, currentActualQty, currentReason);
}

function showEditAuditModal(auditId, currentActualQty, currentReason) {
    const modalId = 'editAuditModal_' + Date.now();
    const modal = document.createElement('div');
    modal.id = modalId;
    modal.className = 'modal-overlay';
    modal.style.zIndex = '99999';
    modal.innerHTML = `
        <div class="modal-window" style="max-width: 400px; background: white; padding: 20px; border-radius: 8px;">
            <h3 style="margin-top:0;">✏️ تعديل الكمية الفعلية</h3>
            <div style="margin-bottom: 15px;">
                <label>الكمية الفعلية (أدخل إجمالي القطع كعدد صحيح):</label>
                <input type="number" id="audit_actual_qty_${modalId}" value="${currentActualQty}" class="form-control" style="width:100%; margin-top:5px; padding:8px;">
            </div>
            <div style="margin-bottom: 15px;">
                <label>سبب الفرق (إن وجد):</label>
                <input type="text" id="audit_reason_${modalId}" value="${currentReason || ''}" class="form-control" style="width:100%; margin-top:5px; padding:8px;">
            </div>
            <div style="display:flex; gap:10px; justify-content:flex-end;">
                <button type="button" class="btn btn-secondary" onclick="document.getElementById('${modalId}').remove()">إلغاء</button>
                <button type="button" class="btn btn-primary" onclick="submitEditAudit(${auditId}, '${modalId}')">حفظ التعديلات</button>
            </div>
        </div>
    `;
    document.body.appendChild(modal);
}

function submitEditAudit(auditId, modalId) {
    const newQtyStr = document.getElementById('audit_actual_qty_' + modalId).value;
    const newReason = document.getElementById('audit_reason_' + modalId).value;
    const newActualQty = parseInt(newQtyStr);
    
    if (isNaN(newActualQty) || newActualQty < 0) {
        showCustomAlert("تأكد من إدخال كمية صحيحة.");
        return;
    }
    
    document.getElementById(modalId).remove();
    
    fetch(BASE_URL + '/reports/edit-inventory-audit', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ audit_id: auditId, actual_qty: newActualQty, reason: newReason })
    })
    .then(r => r.json())
    .then(data => {
        if (data.success) {
            showCustomAlert('تم تعديل سجل الجرد بنجاح');
            loadAuditHistory();
        } else {
            showCustomAlert('خطأ: ' + (data.message || 'غير معروف'));
        }
    })
    .catch(e => showCustomAlert('حدث خطأ بالاتصال'));
}

function deleteAudit(auditId) {
    showCustomConfirm("هل أنت متأكد من حذف هذا الجرد المسجل؟ لا يمكن التراجع عن ذلك!", () => {
        fetch(BASE_URL + '/reports/delete-inventory-audit', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ audit_id: auditId })
        })
        .then(r => r.json())
        .then(data => {
            if (data.success) {
                showCustomAlert('تم حذف سجل الجرد بنجاح');
                loadAuditHistory();
            } else {
                showCustomAlert('خطأ: ' + (data.message || 'غير معروف'));
            }
        })
        .catch(e => showCustomAlert('حدث خطأ بالاتصال'));
    });
}

function applyAuditToDB(auditId) {
    showCustomConfirm("تحذير! سيؤدي القيام بذلك إلى إضافة/خصم المخزون (بالرف والمخزن) بشكل فعلي استناداً إلى الكميات المسجلة بهذا الجرد.\\nهل أنت متأكد من رغبتك في تطبيق الجرد الفعلي؟", () => {
        fetch(BASE_URL + '/reports/apply-inventory-audit', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ audit_id: auditId })
        })
        .then(r => r.json())
        .then(data => {
            if (data.success) {
                showCustomAlert('تم تطبيق الجرد الفعلي بنجاح وتم تحديث أرصدة المخزون.');
                loadInventoryData();
                loadAuditHistory();
                loadBatchesData(); // لتحديث تفاصيل الدفعات
            } else {
                showCustomAlert('خطأ أثناء التطبيق: ' + (data.message || 'غير معروف'));
            }
        })
        .catch(e => showCustomAlert('حدث خطأ بالاتصال'));
    });
}

function showCustomConfirm(message, onConfirm) {
    const modalId = 'confirmAuditModal_' + Date.now();
    const modal = document.createElement('div');
    modal.id = modalId;
    modal.className = 'modal-overlay';
    modal.style.zIndex = '99999';
    modal.innerHTML = `
        <div class="modal-window" style="max-width: 400px; background: white; padding: 20px; border-radius: 8px; text-align:center;">
            <h3 style="margin-top:0; color: #d9534f;">⚠️ تأكيد العملية</h3>
            <p style="margin-bottom: 20px;">${message.replace(/\\n/g, '<br>')}</p>
            <div style="display:flex; gap:10px; justify-content:center;">
                <button type="button" class="btn btn-secondary" onclick="document.getElementById('${modalId}').remove()">إلغاء</button>
                <button type="button" class="btn btn-danger" id="btnConfirm_${modalId}">نعم، متأكد</button>
            </div>
        </div>
    `;
    document.body.appendChild(modal);
    
    document.getElementById('btnConfirm_' + modalId).onclick = function() {
        document.getElementById(modalId).remove();
        onConfirm();
    };
}

function showCustomAlert(message) {
    const modalId = 'alertAuditModal_' + Date.now();
    const modal = document.createElement('div');
    modal.id = modalId;
    modal.className = 'modal-overlay';
    modal.style.zIndex = '99999';
    modal.innerHTML = `
        <div class="modal-window" style="max-width: 400px; background: white; padding: 20px; border-radius: 8px; text-align:center;">
            <h3 style="margin-top:0; color: #0275d8;">ℹ️ إشعار</h3>
            <p style="margin-bottom: 20px;">${message}</p>
            <div style="display:flex; justify-content:center;">
                <button type="button" class="btn btn-primary" onclick="document.getElementById('${modalId}').remove()">موافق</button>
            </div>
        </div>
    `;
    document.body.appendChild(modal);
}

// ============================================
// دوال إدارة التبويبات والنافذة
// ============================================
function switchTab(tabNumber) {
    document.querySelectorAll('.tab-item').forEach(tab => tab.classList.remove('active'));
    const activeTab = document.getElementById('tab' + tabNumber);
    if (activeTab) activeTab.classList.add('active');
    
    document.querySelectorAll('.tab-pane').forEach(pane => pane.classList.remove('active'));
    const activePane = document.getElementById('tabPane' + tabNumber);
    if (activePane) activePane.classList.add('active');
    
    currentTab = tabNumber;
    loadTabData(tabNumber);
}

function loadTabData(tabNumber) {
    if (!currentProductId) return;
    switch(tabNumber) {
        case 1:
            loadProductFullHistory();
            break;
        case 2:
            loadBatchesData();
            break;
        case 3:
            loadInventoryData();
            break;
        case 4:
            loadAuditHistory();
            break;
    }
}

function showProductHistory(productId) {
    currentProductId = productId;
    const row = document.querySelector(`tr[data-product-id="${productId}"]`);
    if (row) {
        const nameEl = document.getElementById('modalProductName');
        const barcodeEl = document.getElementById('modalProductBarcode');
        if (nameEl) nameEl.textContent = row.cells[1]?.textContent || 'المنتج';
        if (barcodeEl) barcodeEl.textContent = row.cells[2]?.textContent || '---';
    }
    const modal = document.getElementById('productAnalyticsModal');
    if (modal) modal.style.display = 'flex';
    loadProductFullHistory();
    if (currentTab !== 1) switchTab(1);
}

function closeProductAnalytics() {
    const modal = document.getElementById('productAnalyticsModal');
    if (modal) modal.style.display = 'none';
    currentProductId = null;
    currentTab = 1;
    document.querySelectorAll('.tab-item').forEach(tab => tab.classList.remove('active'));
    const firstTab = document.getElementById('tab1');
    if (firstTab) firstTab.classList.add('active');
    document.querySelectorAll('.tab-pane').forEach(pane => pane.classList.remove('active'));
    const firstPane = document.getElementById('tabPane1');
    if (firstPane) firstPane.classList.add('active');
}

function toggleFullscreen() {
    const windowEl = document.getElementById('analyticsWindow');
    if (windowEl) windowEl.classList.toggle('fullscreen');
}

// ============================================
// التهيئة
// ============================================
document.addEventListener('DOMContentLoaded', function() {
    const modal = document.getElementById('productAnalyticsModal');
    if (modal) {
        modal.addEventListener('click', function(e) {
            if (e.target === this) closeProductAnalytics();
        });
    }
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') {
            const modalEl = document.getElementById('productAnalyticsModal');
            if (modalEl && modalEl.style.display === 'flex') closeProductAnalytics();
        }
    });
    initFilters();
    console.log('✅ تم تهيئة واجهة تحليلات المنتج');
});

</script>

<?php 
    // تأكد من كتابة المسار الصحيح للملف
    include_once 'views/Casio.php'; 
?>