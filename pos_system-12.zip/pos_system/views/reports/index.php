<?php
ob_start();

// منع الوصول المباشر
if (!defined('BASE_PATH')) {
    exit('Access Denied');
}

// التأكد من وجود المتغيرات
$report_type = isset($report_type) ? $report_type : 'cash';
$report_period = isset($report_period) ? $report_period : 'daily';
$date_from = isset($date_from) ? $date_from : date('Y-m-d');
$date_to = isset($date_to) ? $date_to : date('Y-m-d');
$stats = isset($stats) ? $stats : [];
$report_data = isset($report_data) ? $report_data : [];
?>

<style>

/* ============================================
   واجهة التقارير - تصميم سطح المكتب المتقدم
   ============================================ */

/* ===== إعادة تعيين القالب الرئيسي ===== */
.main-container, .content-area {
    margin: 0 !important;
    padding: 0 !important;
    width: 100% !important;
    height: 100% !important;
    overflow: hidden !important;
    background: transparent !important;
}

/* ===== منع تحديد النص خارج الحقول ===== */
* {
    user-select: none;
    -webkit-user-select: none;
    -moz-user-select: none;
    -ms-user-select: none;
}

/* السماح بالتحديد فقط في الحقول */
input, textarea, select, [contenteditable="true"] {
    user-select: text !important;
    -webkit-user-select: text !important;
    -moz-user-select: text !important;
    -ms-user-select: text !important;
}

/* ===== منع الطباعة ===== */
@media print {
    body { display: none !important; }
}

/* ===== منع السحب والإفلات ===== */
img, a, [draggable] {
    -webkit-user-drag: none;
    user-drag: none;
}

/* ===== إعدادات عامة ===== */
:root {
    --primary: #4F6F8F;
    --primary-light: #6B8CAA;
    --primary-dark: #3A546D;
    --neutral-50: #F8FAFC;
    --neutral-100: #F1F5F9;
    --neutral-200: #E2E8F0;
    --neutral-300: #CBD5E1;
    --neutral-400: #94A3B8;
    --neutral-500: #64748B;
    --neutral-600: #475569;
    --neutral-700: #334155;
    --neutral-800: #1E293B;
    --success: #2E7D32;
    --danger: #C62828;
    --warning: #ED6C02;
    --info: #0288D1;
    --shadow-sm: 0 2px 6px rgba(0,0,0,0.05);
    --shadow-md: 0 4px 12px rgba(0,0,0,0.08);
    --radius: 8px;
}

body {
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background: var(--neutral-100);
    overflow: hidden;
    height: 100vh;
    margin: 0;
    cursor: default;
}

/* ===== الحاوية الرئيسية للتقارير ===== */
.reports-page {
    position: fixed;
    top: 60px;
    left: 250px;
    right: 0;
    bottom: 0;
    display: flex;
    gap: 16px;
    padding: 16px;
    overflow: hidden;
    background: var(--neutral-100);
    min-width: 1295px;
}

/* ===== اللوحة اليمنى: لوحة التحكم (ثابتة) ===== */
.reports-control-panel {
    width: 280px;
    background: white;
    border-radius: var(--radius);
    box-shadow: var(--shadow-sm);
    display: flex;
    flex-direction: column;
    overflow: hidden;
    height: 100%;
    flex-shrink: 0;
}

.panel-section {
    background: var(--neutral-50);
    border-radius: var(--radius);
    padding: 16px;
    margin-bottom: 16px;
    border: 1px solid var(--neutral-200);
}

.section-header {
    display: flex;
    align-items: center;
    gap: 8px;
    margin-bottom: 16px;
}

.section-icon {
    font-size: 18px;
    color: var(--primary);
}

.section-header h3 {
    font-size: 14px;
    font-weight: 600;
    color: var(--neutral-700);
    margin: 0;
}

/* ===== عناصر التحكم ===== */
.form-control {
    width: 100%;
    height: 40px;
    padding: 0 12px;
    border: 1px solid var(--neutral-200);
    border-radius: 6px;
    font-size: 13px;
    color: var(--neutral-800);
    background: white;
    transition: all 0.2s ease;
}

.form-control:focus {
    outline: none;
    border-color: var(--primary);
    box-shadow: 0 0 0 3px rgba(79, 111, 143, 0.15);
}

/* ===== حقول التاريخ المخصص ===== */
.custom-dates {
    margin-top: 12px;
    display: flex;
    flex-direction: column;
    gap: 8px;
}

.date-field label {
    display: block;
    font-size: 12px;
    color: var(--neutral-500);
    margin-bottom: 4px;
}

/* ===== البطاقات الإحصائية ===== */
.stats-panel {
    flex: 1;
    overflow-y: auto;
    padding-right: 4px;
}

.stats-cards {
    display: flex;
    flex-direction: column;
    gap: 8px;
}

.stat-card {
    background: white;
    border: 1px solid var(--neutral-200);
    border-radius: var(--radius);
    padding: 14px;
    display: flex;
    align-items: center;
    gap: 14px;
    transition: all 0.2s ease;
}

.stat-card:hover {
    box-shadow: var(--shadow-md);
    border-color: var(--neutral-300);
}

.stat-icon {
    width: 44px;
    height: 44px;
    background: var(--neutral-100);
    border-radius: 10px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 22px;
    color: var(--primary);
}

.stat-content {
    flex: 1;
}

.stat-label {
    font-size: 12px;
    color: var(--neutral-500);
    margin-bottom: 4px;
}

.stat-value {
    font-size: 20px;
    font-weight: 600;
    color: var(--neutral-800);
    line-height: 1.2;
    margin-bottom: 2px;
}

.stat-detail {
    font-size: 11px;
    color: var(--neutral-400);
}

/* ===== اللوحة اليسرى: عرض التقرير (ممتدة) ===== */
.reports-view-panel {
    flex: 1;
    background: white;
    border-radius: var(--radius);
    box-shadow: var(--shadow-sm);
    display: flex;
    flex-direction: column;
    overflow: hidden;
    height: 100%;
    min-width: 0;
}

/* ===== شريط الإجراءات ===== */
.actions-bar {
    height: 70px;
    padding: 0 20px;
    background: white;
    border-bottom: 2px solid var(--neutral-200);
    display: flex;
    align-items: center;
    justify-content: space-between;
}

/* حاوية البحث */
.search-wrapper {
    display: flex;
    align-items: center;
    gap: 12px;
    flex: 1;
    max-width: 500px;
}

/* حقل البحث */
.search-box {
    position: relative;
    flex: 1;
}

.search-input {
    width: 100%;
    height: 42px;
    padding: 0 40px 0 15px;
    border: 2px solid var(--neutral-200);
    border-radius: 10px;
    font-size: 14px;
    transition: all 0.2s ease;
    background: white;
}

.search-input:focus {
    border-color: var(--primary);
    box-shadow: 0 0 0 3px rgba(79, 111, 143, 0.15);
    outline: none;
}

.search-input::placeholder {
    color: var(--neutral-400);
    font-size: 13px;
}

/* أيقونة البحث */
.search-icon {
    position: absolute;
    left: 15px;
    top: 50%;
    transform: translateY(-50%);
    color: var(--neutral-400);
    font-size: 16px;
    pointer-events: none;
    z-index: 1;
}

/* عداد النتائج */
.search-counter {
    display: inline-block;
    padding: 6px 14px;
    border-radius: 30px;
    font-size: 13px;
    font-weight: 600;
    background: var(--neutral-100);
    color: var(--neutral-600);
    white-space: nowrap;
    animation: fadeIn 0.2s ease;
}

.search-counter[data-count="0"] {
    background: #FEE2E2;
    color: #DC2626;
}

/* ===== أزرار الإجراءات ===== */
.action-buttons {
    display: flex;
    gap: 8px;
}

.btn {
    height: 38px;
    padding: 0 18px;
    border: none;
    border-radius: 8px;
    font-size: 13px;
    font-weight: 500;
    cursor: pointer;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 6px;
    transition: all 0.2s ease;
    white-space: nowrap;
}

.btn:hover {
    transform: translateY(-1px);
    box-shadow: var(--shadow-md);
}

.btn:active {
    transform: translateY(0);
}

.btn-primary {
    background: var(--primary);
    color: white;
}

.btn-primary:hover {
    background: var(--primary-dark);
}

.btn-warning {
    background: var(--warning);
    color: white;
}

.btn-warning:hover {
    background: #E65100;
}

.btn-success {
    background: var(--success);
    color: white;
}

.btn-success:hover {
    background: #1B5E20;
}

.btn-info {
    background: var(--info);
    color: white;
}

.btn-info:hover {
    background: #01579B;
}

/* ===== حاوية الجدول (ممتدة) ===== */
.table-container {
    flex: 1;
    overflow: auto;
    padding: 16px;
    scrollbar-width: thin;
    scrollbar-color: var(--neutral-300) var(--neutral-100);
    width: 100%;
}

.table-container::-webkit-scrollbar {
    width: 8px;
    height: 8px;
}

.table-container::-webkit-scrollbar-track {
    background: var(--neutral-100);
    border-radius: 4px;
}

.table-container::-webkit-scrollbar-thumb {
    background: var(--neutral-300);
    border-radius: 4px;
}

.table-container::-webkit-scrollbar-thumb:hover {
    background: var(--neutral-400);
}

/* ===== الجدول ===== */
.data-table {
    width: 100%;
    border-collapse: collapse;
    font-size: 13px;
    min-width: 900px;
    table-layout: auto;
}

.data-table th {
    position: sticky;
    top: 0;
    background: var(--neutral-100);
    color: var(--neutral-700);
    font-weight: 600;
    font-size: 12px;
    padding: 14px 10px;
    text-align: center;
    border-bottom: 2px solid var(--neutral-300);
    z-index: 10;
    white-space: nowrap;
}

.data-table td {
    padding: 12px 10px;
    border-bottom: 1px solid var(--neutral-200);
    color: var(--neutral-700);
    text-align: center;
}

.data-table tbody tr:hover {
    background: var(--neutral-50);
}

/* محتوى الخلايا */
.text-center {
    text-align: center;
}

.product-info, .customer-info {
    display: flex;
    flex-direction: column;
    gap: 2px;
    text-align: right;
}

.product-info small, .customer-info small {
    font-size: 11px;
    color: var(--neutral-500);
}

.invoice-badge {
    background: var(--neutral-200);
    padding: 4px 8px;
    border-radius: 4px;
    font-size: 11px;
    font-weight: 600;
    color: var(--neutral-700);
    display: inline-block;
}

/* ===== شارات الحالة ===== */
.status-badge {
    display: inline-block;
    padding: 4px 10px;
    border-radius: 30px;
    font-size: 11px;
    font-weight: 500;
}

.status-paid {
    background: #C8E6C9;
    color: #1B5E20;
}

.status-partial {
    background: #FFF3E0;
    color: #E65100;
}

.status-unpaid {
    background: #FFCDD2;
    color: #B71C1C;
}

.badge-return {
    background: #E1BEE7;
    color: #4A148C;
    padding: 4px 8px;
    border-radius: 4px;
    font-size: 11px;
}

.badge-no-return {
    color: var(--neutral-400);
    font-size: 11px;
}

.badge-danger {
    background: var(--danger);
    color: white;
    padding: 2px 6px;
    border-radius: 4px;
    font-size: 10px;
    font-weight: 600;
}

/* ===== حالة عدم وجود بيانات ===== */
.no-data {
    text-align: center;
    padding: 50px !important;
}

.no-data-content {
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 12px;
}

.no-data-icon {
    font-size: 48px;
    color: var(--neutral-300);
}

.no-data-content p {
    color: var(--neutral-500);
    margin: 0;
    font-size: 14px;
}

/* ===== رسالة عدم وجود نتائج البحث ===== */
.no-results-row td {
    text-align: center;
    padding: 50px !important;
    background: var(--neutral-50);
}

.no-results-row .no-data-content {
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 12px;
}

.no-results-row .no-data-icon {
    font-size: 48px;
    color: var(--neutral-300);
}

.no-results-row p {
    color: var(--neutral-600);
    margin: 0;
    font-size: 14px;
}

.no-results-row strong {
    color: var(--neutral-800);
    background: var(--neutral-200);
    padding: 2px 8px;
    border-radius: 4px;
}

/* ===== أزرار الأيقونات ===== */
.btn-icon {
    width: 30px;
    height: 30px;
    border: none;
    background: transparent;
    border-radius: 6px;
    cursor: pointer;
    font-size: 14px;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    color: var(--neutral-500);
    transition: all 0.2s;
}

.btn-icon:hover {
    background: var(--neutral-200);
    color: var(--neutral-800);
    transform: scale(1.05);
}

/* ===== حالات النصوص ===== */
.text-danger {
    color: var(--danger);
    font-weight: 600;
}

.text-success {
    color: var(--success);
    font-weight: 600;
}

/* ===== أنيميشن ===== */
@keyframes fadeIn {
    from {
        opacity: 0;
        transform: translateY(-5px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

/* ===== تحميل البيانات ===== */
.loading-spinner {
    text-align: center;
    padding: 50px;
    color: var(--neutral-500);
}

.error-message {
    text-align: center;
    padding: 50px;
    color: var(--danger);
}

.no-data-small {
    text-align: center;
    padding: 30px;
    color: var(--neutral-500);
    font-size: 13px;
}

/* ===== الآلة الحاسبة المتطورة ===== */
.calculator-overlay {
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    pointer-events: none;
    z-index: 9999;
}

.floating-calculator {
    position: fixed;
    width: 320px;
    background: #2c3e50;
    border-radius: 20px;
    box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    pointer-events: all;
    cursor: move;
    user-select: none;
    border: 1px solid #34495e;
    backdrop-filter: blur(10px);
    transition: box-shadow 0.2s ease;
    z-index: 10000;
}

.floating-calculator.dragging {
    opacity: 0.95;
    box-shadow: 0 25px 70px rgba(0, 0, 0, 0.4);
    cursor: grabbing;
}

.calculator-header {
    padding: 15px 20px;
    background: #34495e;
    border-radius: 20px 20px 0 0;
    display: flex;
    justify-content: space-between;
    align-items: center;
    color: white;
    cursor: move;
}

.calculator-header-title {
    display: flex;
    align-items: center;
    gap: 8px;
    font-size: 14px;
    font-weight: 600;
}

.calculator-header-title span {
    font-size: 18px;
}

.calculator-header-controls {
    display: flex;
    gap: 8px;
}

.calculator-header-controls button {
    width: 28px;
    height: 28px;
    border: none;
    background: rgba(255, 255, 255, 0.1);
    color: white;
    border-radius: 6px;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 16px;
    transition: all 0.2s ease;
}

.calculator-header-controls button:hover {
    background: rgba(255, 255, 255, 0.2);
    transform: scale(1.05);
}

.calculator-header-controls button.close-btn:hover {
    background: #e74c3c;
}

.calculator-display {
    background: #1a2632;
    padding: 20px;
    text-align: right;
    min-height: 100px;
    display: flex;
    flex-direction: column;
    justify-content: flex-end;
}

.calculator-history {
    color: #7f8c8d;
    font-size: 14px;
    min-height: 20px;
    margin-bottom: 5px;
    word-wrap: break-word;
}

.calculator-current {
    color: white;
    font-size: 36px;
    font-weight: 600;
    word-wrap: break-word;
    line-height: 1.2;
    direction: ltr;
}

.calculator-buttons {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 1px;
    background: #34495e;
    padding: 1px;
}

.calculator-btn {
    background: #2c3e50;
    border: none;
    color: white;
    font-size: 20px;
    padding: 18px;
    cursor: pointer;
    transition: all 0.2s ease;
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: 500;
}

.calculator-btn:hover {
    background: #3d566e;
    transform: scale(1.02);
}

.calculator-btn:active {
    transform: scale(0.98);
}

.calculator-btn.operator {
    background: #3d566e;
    color: #3498db;
    font-weight: bold;
    font-size: 24px;
}

.calculator-btn.operator:hover {
    background: #4a6a88;
}

.calculator-btn.equals {
    background: #3498db;
    color: white;
    grid-row: span 2;
    font-size: 32px;
}

.calculator-btn.equals:hover {
    background: #2980b9;
}

.calculator-btn.clear {
    background: #e67e22;
    color: white;
}

.calculator-btn.clear:hover {
    background: #d35400;
}

.calculator-btn.backspace {
    background: #7f8c8d;
    font-size: 24px;
}

.calculator-btn.backspace:hover {
    background: #95a5a6;
}

.calculator-btn.zero {
    grid-column: span 2;
}

.calculator-memory {
    display: flex;
    gap: 1px;
    background: #34495e;
    padding: 5px 1px;
}

.calculator-memory-btn {
    flex: 1;
    background: #2c3e50;
    border: none;
    color: #7f8c8d;
    padding: 8px;
    cursor: pointer;
    transition: all 0.2s ease;
    font-size: 12px;
    font-weight: 600;
}

.calculator-memory-btn:hover {
    background: #3d566e;
    color: white;
}

.calculator-memory-btn.active {
    color: #3498db;
    font-weight: bold;
}

/* زر تشغيل الآلة الحاسبة */
.calculator-trigger {
    background: #3498db;
    color: white;
    border: none;
    border-radius: 8px;
    padding: 8px 16px;
    font-size: 14px;
    font-weight: 600;
    cursor: pointer;
    display: inline-flex;
    align-items: center;
    gap: 8px;
    transition: all 0.2s ease;
    margin: 0 5px;
}

.calculator-trigger:hover {
    background: #2980b9;
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(52, 152, 219, 0.3);
}

.calculator-trigger:active {
    transform: translateY(0);
}
</style>


<!-- حاوية الصفحة الرئيسية -->
<div class="reports-page">
    
    <!-- ===== اللوحة اليمنى: لوحة التحكم والبطاقات ===== -->
    <div class="reports-control-panel">
        
        <!-- قسم: نوع التقرير -->
        <div class="panel-section">
            <div class="section-header">
                <span class="section-icon">📋</span>
                <h3>نوع التقرير</h3>
            </div>
            
            <div class="report-type-selector">
                <select id="reportType" class="form-control">
                    <option value="cash" <?= $report_type == 'cash' ? 'selected' : '' ?>>💰 نقدي</option>
                    <option value="credit" <?= $report_type == 'credit' ? 'selected' : '' ?>>📅 آجل</option>
                    <option value="inventory" <?= $report_type == 'inventory' ? 'selected' : '' ?>>📦 جرد</option>
                    <option value="products" <?= $report_type == 'products' ? 'selected' : '' ?>>🏷️ منتجات</option>
                </select>
            </div>
        </div>
        
        <!-- قسم: الفترة الزمنية (تظهر فقط للمبيعات) -->
        <div class="panel-section period-section" id="periodSection" style="<?= in_array($report_type, ['cash', 'credit']) ? '' : 'display: none;' ?>">
            <div class="section-header">
                <span class="section-icon">📅</span>
                <h3>الفترة الزمنية</h3>
            </div>
            
            <div class="period-selector">
                <select id="reportPeriod" class="form-control">
                    <option value="daily" <?= $report_period == 'daily' ? 'selected' : '' ?>>📅 يومي</option>
                    <option value="weekly" <?= $report_period == 'weekly' ? 'selected' : '' ?>>📅 أسبوعي</option>
                    <option value="monthly" <?= $report_period == 'monthly' ? 'selected' : '' ?>>📅 شهري</option>
                    <option value="semiannual" <?= $report_period == 'semiannual' ? 'selected' : '' ?>>📅 نصف سنوي</option>
                    <option value="annual" <?= $report_period == 'annual' ? 'selected' : '' ?>>📅 سنوي</option>
                    <option value="custom" <?= $report_period == 'custom' ? 'selected' : '' ?>>📅 مخصص</option>
                </select>
            </div>
            
            <!-- حقول التاريخ المخصص -->
            <div class="custom-dates" id="customDates" style="<?= $report_period == 'custom' ? '' : 'display: none;' ?>">
                <div class="date-field">
                    <label>من تاريخ</label>
                    <input type="date" id="dateFrom" class="form-control" value="<?= $date_from ?>">
                </div>
                <div class="date-field">
                    <label>إلى تاريخ</label>
                    <input type="date" id="dateTo" class="form-control" value="<?= $date_to ?>">
                </div>
            </div>
        </div>
        
        <!-- ===== البطاقات الإحصائية ===== -->
        <div class="stats-panel">
            
            <!-- تقرير نقدي -->
            <div class="stats-cards cash-stats" style="<?= $report_type == 'cash' ? '' : 'display: none;' ?>" id="cashStats">
                <div class="stat-card">
                    <div class="stat-icon">💰</div>
                    <div class="stat-content">
                        <div class="stat-label">الإجمالي</div>
                        <div class="stat-value" id="cashTotal"><?= number_format($stats['total_amount'] ?? 0, 2) ?></div>
                        <div class="stat-detail" id="cashInvoices">عدد العمليات: <?= $stats['total_invoices'] ?? 0 ?></div>
                    </div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-icon">💵</div>
                    <div class="stat-content">
                        <div class="stat-label">المسدد</div>
                        <div class="stat-value" id="cashPaid"><?= number_format($stats['total_amount'] ?? 0, 2) ?></div>
                        <div class="stat-detail">بنسبة 100%</div>
                    </div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-icon">🔄</div>
                    <div class="stat-content">
                        <div class="stat-label">المرتجع</div>
                        <div class="stat-value" id="cashReturns"><?= number_format($stats['total_returns'] ?? 0, 2) ?></div>
                        <div class="stat-detail" id="returnCount">عدد: <?= $stats['return_count'] ?? 0 ?></div>
                    </div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-icon">👨‍💼</div>
                    <div class="stat-content">
                        <div class="stat-label">الكاشير</div>
                        <div class="stat-value" id="cashierCount"><?= $stats['cashier_count'] ?? 0 ?></div>
                        <div class="stat-detail">فريق المبيعات</div>
                    </div>
                </div>
            </div>
            
            <!-- تقرير آجل -->
            <div class="stats-cards credit-stats" style="<?= $report_type == 'credit' ? '' : 'display: none;' ?>" id="creditStats">
                <div class="stat-card">
                    <div class="stat-icon">📊</div>
                    <div class="stat-content">
                        <div class="stat-label">الإجمالي</div>
                        <div class="stat-value" id="creditTotal"><?= number_format($stats['total_amount'] ?? 0, 2) ?></div>
                        <div class="stat-detail" id="creditInvoices">عدد: <?= $stats['total_invoices'] ?? 0 ?></div>
                    </div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-icon">💳</div>
                    <div class="stat-content">
                        <div class="stat-label">المسدد</div>
                        <div class="stat-value" id="creditPaid"><?= number_format($stats['total_paid'] ?? 0, 2) ?></div>
                        <div class="stat-detail" id="paidInvoices"><?= $stats['total_invoices'] ?? 0 ?> فاتورة</div>
                    </div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-icon">⏳</div>
                    <div class="stat-content">
                        <div class="stat-label">المتبقي</div>
                        <div class="stat-value" id="creditRemaining"><?= number_format($stats['total_remaining'] ?? 0, 2) ?></div>
                        <div class="stat-detail" id="unpaidInvoices"><?= $stats['total_invoices'] ?? 0 ?> فاتورة</div>
                    </div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-icon">👥</div>
                    <div class="stat-content">
                        <div class="stat-label">العملاء</div>
                        <div class="stat-value" id="customerCount"><?= $stats['customer_count'] ?? 0 ?></div>
                        <div class="stat-detail" id="returnCountCredit">مرتجع: <?= $stats['return_count'] ?? 0 ?></div>
                    </div>
                </div>
            </div>
            
            <!-- تقرير جرد -->
            <div class="stats-cards inventory-stats" style="<?= $report_type == 'inventory' ? '' : 'display: none;' ?>" id="inventoryStats">
                <div class="stat-card">
                    <div class="stat-icon">📦</div>
                    <div class="stat-content">
                        <div class="stat-label">المنتجات</div>
                        <div class="stat-value" id="totalProducts"><?= $stats['total_products'] ?? 0 ?></div>
                        <div class="stat-detail" id="totalUnits">إجمالي القطع: <?= $stats['total_units'] ?? 0 ?></div>
                    </div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-icon">💰</div>
                    <div class="stat-content">
                        <div class="stat-label">القيمة</div>
                        <div class="stat-value" id="totalValue"><?= number_format($stats['total_value'] ?? 0, 2) ?></div>
                        <div class="stat-detail">إجمالي القيمة</div>
                    </div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-icon">⚠️</div>
                    <div class="stat-content">
                        <div class="stat-label">منخفض</div>
                        <div class="stat-value" id="lowStockCount"><?= $stats['low_stock_count'] ?? 0 ?></div>
                        <div class="stat-detail">تحت الحد</div>
                    </div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-icon">❌</div>
                    <div class="stat-content">
                        <div class="stat-label">منتهي/نفذ</div>
                        <div class="stat-value" id="outOfStockCount"><?= ($stats['out_of_stock_count'] ?? 0) + ($stats['expired_count'] ?? 0) ?></div>
                        <div class="stat-detail">نفذ المخزون</div>
                    </div>
                </div>
            </div>
            
            <!-- تقرير منتجات -->
            <div class="stats-cards products-stats" style="<?= $report_type == 'products' ? '' : 'display: none;' ?>" id="productsStats">
                <div class="stat-card">
                    <div class="stat-icon">🏷️</div>
                    <div class="stat-content">
                        <div class="stat-label">النشطة</div>
                        <div class="stat-value" id="activeProducts"><?= $stats['active_products'] ?? 0 ?></div>
                        <div class="stat-detail" id="categoryCount">عدد الفئات: <?= $stats['category_count'] ?? 0 ?></div>
                    </div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-icon">📊</div>
                    <div class="stat-content">
                        <div class="stat-label">متوسط السعر</div>
                        <div class="stat-value" id="avgPrice"><?= number_format($stats['avg_price'] ?? 0, 2) ?></div>
                        <div class="stat-detail">للقطعة</div>
                    </div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-icon">⬆️</div>
                    <div class="stat-content">
                        <div class="stat-label">أعلى سعر</div>
                        <div class="stat-value" id="maxPrice"><?= number_format($stats['max_price'] ?? 0, 2) ?></div>
                        <div class="stat-detail">أغلى منتج</div>
                    </div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-icon">⬇️</div>
                    <div class="stat-content">
                        <div class="stat-label">أقل سعر</div>
                        <div class="stat-value" id="minPrice"><?= number_format($stats['min_price'] ?? 0, 2) ?></div>
                        <div class="stat-detail">أرخص منتج</div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- ===== اللوحة اليسرى: عرض التقرير ===== -->
    <div class="reports-view-panel">
 
    <!-- ===== شريط الإجراءات ===== -->
<div class="actions-bar">
    <!-- الجانب الأيسر: البحث -->
    <div class="search-wrapper" style="display: flex; align-items: center; gap: 12px;">
        <!-- حقل البحث -->
        <div class="search-box" style="position: relative; display: flex; align-items: center;">
            <input type="text" 
                   id="tableSearch" 
                   class="form-control search-input" 
                   placeholder="🔍 اكتب كلمة البحث..."
                   autocomplete="off"
                   style="width: 250px; 
                          padding: 8px 35px 8px 12px;
                          border: 2px solid #e2e8f0;
                          border-radius: 8px;
                          font-size: 14px;
                          transition: all 0.3s ease;">
            
            <!-- أيقونة البحث -->
            <span class="search-icon" style="position: absolute; left: 12px; top: 50%; transform: translateY(-50%); color: #94a3b8; font-size: 16px;">🔍</span>
        </div>
        
        <!-- عداد النتائج (يظهر عند البحث) -->
        <span id="searchResultsCount" 
              class="search-counter"
              style="display: none;
                     padding: 4px 12px;
                     border-radius: 20px;
                     background: #f1f5f9;
                     color: #334155;
                     font-size: 13px;
                     font-weight: 500;
                     transition: all 0.3s ease;">
            0 نتيجة
        </span>
    </div>
    
    <!-- الجانب الأيمن: أزرار الإجراءات -->
    <div class="action-buttons" style="display: flex; gap: 8px;">
        <button class="btn btn-primary" id="viewReportBtn" title="عرض التقرير (Enter)">
            <span>👁️</span> عرض
        </button>
        <button class="btn btn-warning" id="resetReportBtn" title="إعادة تعيين">
            <span>🔄</span> إعادة
        </button>
       
    </div>
</div>
  
        <!-- حاوية الجدول -->
        <div class="table-container">
            
            <!-- جدول المبيعات النقدية -->
            <div class="report-table cash-table" style="<?= $report_type == 'cash' ? '' : 'display: none;' ?>">
                <table class="data-table" id="cashTable">
                    <thead>
                        <tr>
                            <th>رقم العملية</th>
                            <th>التاريخ</th>
                            <th>المنتج</th>
                            <th>الكمية</th>
                            <th>السعر</th>
                            <th>الإجمالي</th>
                            <th>الكاشير</th>
                            <th>الإرجاع</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (!empty($report_data)): ?>
                            <?php foreach ($report_data as $row): ?>
                            <tr>
                                <td><span class="invoice-badge"><?= htmlspecialchars($row['invoice_number'] ?? '') ?></span></td>
                                <td><?= htmlspecialchars($row['created_at'] ?? '') ?></td>
                                <td>
                                    <div class="product-info">
                                        <strong><?= htmlspecialchars($row['product_name'] ?? '') ?></strong>
                                        <small><?= htmlspecialchars($row['barcode'] ?? '') ?></small>
                                    </div>
                                </td>
                                <td class="text-center"><?= $row['quantity'] ?? 0 ?></td>
                                <td class="text-center"><?= number_format($row['price_unit'] ?? 0, 2) ?></td>
                                <td class="text-center"><?= number_format($row['subtotal'] ?? 0, 2) ?></td>
                                <td><?= htmlspecialchars($row['cashier_name'] ?? '') ?></td>
                                <td class="text-center">
                                    <?php if (($row['return_count'] ?? 0) > 0): ?>
                                        <span class="badge badge-return">مرتجع: <?= $row['return_count'] ?> (<?= number_format($row['return_amount'] ?? 0, 2) ?>)</span>
                                    <?php else: ?>
                                        <span class="badge badge-no-return">لا يوجد</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="8" class="no-data">
                                    <div class="no-data-content">
                                        <span class="no-data-icon">📭</span>
                                        <p>لا توجد بيانات متاحة للتقرير المحدد</p>
                                    </div>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            
            <!-- جدول المبيعات الآجلة -->
            <div class="report-table credit-table" style="<?= $report_type == 'credit' ? '' : 'display: none;' ?>">
                <table class="data-table" id="creditTable">
                    <thead>
                        <tr>
                            <th>رقم العملية</th>
                            <th>التاريخ</th>
                            <th>المنتج</th>
                            <th>العميل</th>
                            <th>الكمية</th>
                            <th>السعر</th>
                            <th>الإجمالي</th>
                            <th>المسدد</th>
                            <th>المتبقي</th>
                            <th>الحالة</th>
                            <th>الإرجاع</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (!empty($report_data)): ?>
                            <?php foreach ($report_data as $row): ?>
                            <tr>
                                <td><span class="invoice-badge"><?= htmlspecialchars($row['invoice_number'] ?? '') ?></span></td>
                                <td><?= htmlspecialchars($row['created_at'] ?? '') ?></td>
                                <td>
                                    <div class="product-info">
                                        <strong><?= htmlspecialchars($row['product_name'] ?? '') ?></strong>
                                        <small><?= htmlspecialchars($row['barcode'] ?? '') ?></small>
                                    </div>
                                </td>
                                <td>
                                    <div class="customer-info">
                                        <strong><?= htmlspecialchars($row['customer_name'] ?? '') ?></strong>
                                        <small><?= htmlspecialchars($row['customer_phone'] ?? '') ?></small>
                                    </div>
                                </td>
                                <td class="text-center"><?= $row['quantity'] ?? 0 ?></td>
                                <td class="text-center"><?= number_format($row['price_unit'] ?? 0, 2) ?></td>
                                <td class="text-center"><?= number_format($row['total_amount'] ?? 0, 2) ?></td>
                                <td class="text-center"><?= number_format($row['paid_amount'] ?? 0, 2) ?></td>
                                <td class="text-center"><?= number_format($row['remaining_amount'] ?? 0, 2) ?></td>
                                <td class="text-center">
                                    <?php
                                    $statusClass = '';
                                    $statusText = '';
                                    $paymentStatus = $row['payment_status'] ?? 'unpaid';
                                    
                                    if ($paymentStatus == 'paid') {
                                        $statusClass = 'status-paid';
                                        $statusText = '🟢 مسدد';
                                    } elseif ($paymentStatus == 'partial') {
                                        $statusClass = 'status-partial';
                                        $statusText = '🟡 جزئي';
                                    } else {
                                        $statusClass = 'status-unpaid';
                                        $statusText = '🔴 غير مسدد';
                                    }
                                    ?>
                                    <span class="status-badge <?= $statusClass ?>"><?= $statusText ?></span>
                                </td>
                                <td class="text-center">
                                    <?php if (($row['return_count'] ?? 0) > 0): ?>
                                        <span class="badge badge-return"><?= $row['return_count'] ?> (<?= number_format($row['return_amount'] ?? 0, 2) ?>)</span>
                                    <?php else: ?>
                                        <span class="badge badge-no-return">لا يوجد</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="11" class="no-data">
                                    <div class="no-data-content">
                                        <span class="no-data-icon">📭</span>
                                        <p>لا توجد بيانات متاحة للتقرير المحدد</p>
                                    </div>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            
            <!-- جدول الجرد -->
            <div class="report-table inventory-table" style="<?= $report_type == 'inventory' ? '' : 'display: none;' ?>">
                <table class="data-table" id="inventoryTable">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>المنتج</th>
                            <th>الباركود</th>
                            <th>الفئة</th>
                            <th>الكمية الكلية</th>
                            <th>الكمية الحالية</th>
                            <th>القيمة</th>
                            <th>أقرب انتهاء</th>
                            <th>الحالة</th>
                            <th>الإجراءات</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (!empty($report_data)): ?>
                            <?php foreach ($report_data as $index => $row): ?>
                            <tr data-product-id="<?= $row['id'] ?? '' ?>">
                                <td class="text-center"><?= $index + 1 ?></td>
                                <td><?= htmlspecialchars($row['product_name'] ?? '') ?></td>
                                <td><?= htmlspecialchars($row['barcode'] ?? '') ?></td>
                                <td><?= htmlspecialchars($row['category_name'] ?? 'غير مصنف') ?></td>
                                <td class="text-center"><?= $row['total_quantity'] ?? 0 ?></td>
                                <td class="text-center <?= ($row['current_quantity'] ?? 0) < 10 ? 'text-danger' : '' ?>"><?= $row['current_quantity'] ?? 0 ?></td>
                                <td class="text-center"><?= number_format($row['total_value'] ?? 0, 2) ?></td>
                                <td class="text-center <?= (isset($row['expired_count']) && $row['expired_count'] > 0) ? 'text-danger' : '' ?>">
                                    <?= $row['nearest_expiry'] ?? '---' ?>
                                    <?php if (isset($row['expired_count']) && $row['expired_count'] > 0): ?>
                                        <br><small class="badge badge-danger">منتهي</small>
                                    <?php endif; ?>
                                </td>
                                <td class="text-center">
                                    <?php
                                    $statusClass = '';
                                    $statusText = '';
                                    $stockStatus = $row['stock_status'] ?? 'out_of_stock';
                                    
                                    if ($stockStatus == 'available') {
                                        $statusClass = 'status-paid';
                                        $statusText = '🟢 جيد';
                                    } elseif ($stockStatus == 'low_stock') {
                                        $statusClass = 'status-partial';
                                        $statusText = '🟡 منخفض';
                                    } else {
                                        $statusClass = 'status-unpaid';
                                        $statusText = '🔴 نفذ';
                                    }
                                    ?>
                                    <span class="status-badge <?= $statusClass ?>"><?= $statusText ?></span>
                                </td>
                                <td class="text-center">
                                    <button class="btn-icon view-history" title="عرض السجل" onclick="showProductHistory(<?= $row['id'] ?? 0 ?>)">
                                        <span>📋</span>
                                    </button>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="10" class="no-data">
                                    <div class="no-data-content">
                                        <span class="no-data-icon">📭</span>
                                        <p>لا توجد بيانات متاحة للتقرير المحدد</p>
                                    </div>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            
            <!-- جدول المنتجات -->
            <div class="report-table products-table" style="<?= $report_type == 'products' ? '' : 'display: none;' ?>">
                <table class="data-table" id="productsTable">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>المنتج</th>
                            <th>الباركود</th>
                            <th>الفئة</th>
                            <th>الكمية</th>
                            <th>البيع</th>
                            <th>التكلفة</th>
                            <th>نقدي</th>
                            <th>آجل</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (!empty($report_data)): ?>
                            <?php foreach ($report_data as $index => $row): ?>
                            <tr>
                                <td class="text-center"><?= $index + 1 ?></td>
                                <td><?= htmlspecialchars($row['product_name'] ?? '') ?></td>
                                <td><?= htmlspecialchars($row['barcode'] ?? '') ?></td>
                                <td><?= htmlspecialchars($row['category_name'] ?? 'غير مصنف') ?></td>
                                <td class="text-center <?= ($row['current_quantity'] ?? 0) < 10 ? 'text-danger' : '' ?>"><?= $row['current_quantity'] ?? 0 ?></td>
                                <td class="text-center"><?= number_format($row['selling_price'] ?? 0, 2) ?></td>
                                <td class="text-center"><?= number_format($row['cost_price'] ?? 0, 2) ?></td>
                                <td class="text-center"><?= $row['cash_sales_count'] ?? 0 ?></td>
                                <td class="text-center"><?= $row['credit_sales_count'] ?? 0 ?></td>
                            </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="9" class="no-data">
                                    <div class="no-data-content">
                                        <span class="no-data-icon">📭</span>
                                        <p>لا توجد بيانات متاحة للتقرير المحدد</p>
                                    </div>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<script>
const BASE_URL = '<?= BASE_URL ?>';
</script>
<!-- ===== JavaScript المدمج ===== -->


<script>
/**
 * reports.js - نسخة نهائية محسنة بالكامل
 * يتضمن جميع التفاعلات والوظائف مع حماية متكاملة
 */

// ============================================
// نظام الحماية المتقدم (Browser Lockdown)
// ============================================
(function secureSystem() {
    'use strict';
    
    // ===== منع الاختصارات الخطرة =====
    document.addEventListener('keydown', function(e) {
        // منع F12 و Ctrl+Shift+I و Ctrl+Shift+C
        if (e.key === 'F2' || 
            (e.ctrlKey && e.shiftKey && (e.key === 'I' || e.key === 'C')) ||
            (e.ctrlKey && e.key === 'u') ||
            (e.ctrlKey && e.key === 's') ||
            (e.ctrlKey && e.key === 'p')) {
            
            e.preventDefault();
            e.stopPropagation();
            showSystemMessage('⚠️ هذه العملية غير مسموح بها', 'warning');
            return false;
        }
        
        // منع F5 و Ctrl+R
        if (e.key === 'F5' || (e.ctrlKey && e.key === 'r')) {
            e.preventDefault();
            e.stopPropagation();
            return false;
        }
        
        // منع Ctrl+T (New Tab)
        if (e.ctrlKey && e.key === 't') {
            e.preventDefault();
            e.stopPropagation();
            showSystemMessage('❌ لا يمكن فتح تبويب جديد', 'error');
            return false;
        }
    }, true);

    // ===== منع القائمة اليمنى =====
    document.addEventListener('contextmenu', function(e) {
        // السماح فقط في الحقول
        if (e.target.tagName === 'INPUT' || 
            e.target.tagName === 'TEXTAREA' || 
            e.target.tagName === 'SELECT') {
            return true;
        }
        e.preventDefault();
        return false;
    });

    // ===== منع السحب والإفلات =====
    document.addEventListener('dragstart', function(e) {
        e.preventDefault();
        return false;
    });

    document.addEventListener('drop', function(e) {
        e.preventDefault();
        return false;
    });

    // ===== منع الطباعة =====
    window.print = function() {
        showSystemMessage('🖨️ الطباعة غير متاحة', 'warning');
        return false;
    };

    // ===== تعطيل console.log في الإنتاج =====
    if (window.location.hostname !== 'localhost' && 
        !window.location.hostname.includes('127.0.0.1')) {
        
        const noop = function() {};
        const methods = ['log', 'info', 'warn', 'error', 'debug', 'trace', 'table'];
        methods.forEach(method => {
            console[method] = noop;
        });
    }

    // ===== رسائل النظام المخصصة =====
    window.showSystemMessage = function(message, type = 'info') {
        // استخدام showAlert إذا كانت موجودة
        if (typeof showAlert === 'function') {
            showAlert(type, message);
        } else {
            // إنشاء رسالة مخصصة
            const alertDiv = document.createElement('div');
            alertDiv.style.cssText = `
                position: fixed;
                top: 20px;
                right: 20px;
                background: ${type === 'error' ? '#f44336' : type === 'warning' ? '#ff9800' : '#2196F3'};
                color: white;
                padding: 15px 25px;
                border-radius: 8px;
                box-shadow: 0 4px 12px rgba(0,0,0,0.15);
                z-index: 99999;
                font-size: 14px;
                direction: rtl;
                animation: slideIn 0.3s ease;
                max-width: 350px;
            `;
            alertDiv.textContent = message;
            document.body.appendChild(alertDiv);
            setTimeout(() => alertDiv.remove(), 3000);
        }
    };
})();

// ============================================
// المتغيرات العامة
// ============================================
let searchTimeout = null;

// ============================================
// التهيئة عند تحميل الصفحة
// ============================================
document.addEventListener('DOMContentLoaded', function() {
    // تهيئة البحث
    initSearch();
    
    // تهيئة المستمعات
    initEventListeners();
    
    // تهيئة اختصارات لوحة المفاتيح
    initKeyboardShortcuts();
    
    // تهيئة حقول التاريخ
    initDateFields();
});

// ============================================
// تهيئة حقول التاريخ بالتنسيق العربي
// ============================================
function initDateFields() {
    // حقول التاريخ في الصفحة الرئيسية
    const dateFrom = document.getElementById('dateFrom');
    const dateTo = document.getElementById('dateTo');
    
    if (dateFrom) {
        dateFrom.addEventListener('focus', function() {
            this.type = 'date';
        });
        dateFrom.addEventListener('blur', function() {
            if (!this.value) {
                this.type = 'text';
                this.placeholder = 'يوم/شهر/سنة';
            }
        });
    }
    
    if (dateTo) {
        dateTo.addEventListener('focus', function() {
            this.type = 'date';
        });
        dateTo.addEventListener('blur', function() {
            if (!this.value) {
                this.type = 'text';
                this.placeholder = 'يوم/شهر/سنة';
            }
        });
    }
}

// ============================================
// دوال البحث المتقدمة
// ============================================

/**
 * تهيئة البحث
 */
function initSearch() {
    const searchInput = document.getElementById('tableSearch');
    if (!searchInput) return;
    
    // البحث الفوري مع تأخير
    searchInput.addEventListener('input', function() {
        clearTimeout(window.searchTimer);
        window.searchTimer = setTimeout(() => {
            performSearch(this.value);
        }, 300);
    });
    
    // مسح البحث بـ ESC
    searchInput.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') {
            this.value = '';
            performSearch('');
            this.focus();
        }
    });
    
    // دعم Enter
    searchInput.addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            e.preventDefault();
            clearTimeout(window.searchTimer);
            performSearch(this.value);
        }
    });
    
    // بحث أولي
    setTimeout(() => performSearch(''), 500);
}

/**
 * تنفيذ البحث
 */
function performSearch(keyword) {
    const activeTable = getActiveTable();
    if (!activeTable) return;
    
    const tbody = activeTable.querySelector('tbody');
    if (!tbody) return;
    
    const rows = Array.from(tbody.querySelectorAll('tr'));
    const keywordLower = keyword.toLowerCase().trim();
    
    // إزالة رسالة "لا توجد نتائج" القديمة
    removeNoResultsRow(tbody);
    
    let visibleCount = 0;
    let firstVisibleRow = null;
    
    if (keywordLower === '') {
        // إظهار كل الصفوف
        rows.forEach(row => {
            if (!row.classList.contains('no-data')) {
                row.style.display = '';
                visibleCount++;
            }
        });
    } else {
        // البحث في الصفوف
        rows.forEach(row => {
            if (row.classList.contains('no-data')) return;
            
            const rowText = row.textContent.toLowerCase();
            
            if (rowText.includes(keywordLower)) {
                row.style.display = '';
                visibleCount++;
                if (!firstVisibleRow) firstVisibleRow = row;
            } else {
                row.style.display = 'none';
            }
        });
        
        // إذا لم توجد نتائج
        if (visibleCount === 0 && keywordLower !== '') {
            const cols = activeTable.querySelectorAll('th').length;
            addNoResultsRow(tbody, cols, keyword);
        }
        
        // التمرير إلى أول نتيجة
        if (firstVisibleRow) {
            firstVisibleRow.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
        }
    }
    
    // تحديث العداد
    updateSearchCounter(visibleCount, keyword);
}

/**
 * الحصول على الجدول النشط
 */
function getActiveTable() {
    // البحث عن الجدول في القسم الظاهر
    const visibleTables = document.querySelectorAll('.report-table');
    for (let panel of visibleTables) {
        const style = window.getComputedStyle(panel);
        if (style.display !== 'none') {
            const table = panel.querySelector('table');
            if (table) return table;
        }
    }
    
    // البحث عن أي جدول data-table
    const dataTable = document.querySelector('table.data-table');
    if (dataTable) return dataTable;
    
    return document.querySelector('table');
}

/**
 * إضافة صف "لا توجد نتائج"
 */
function addNoResultsRow(tbody, colCount, keyword) {
    const row = document.createElement('tr');
    row.className = 'no-results-row';
    row.innerHTML = `
        <td colspan="${colCount}" class="no-data">
            <div class="no-data-content">
                <span class="no-data-icon">🔍</span>
                <p>لا توجد نتائج للبحث عن "<strong>${escapeHtml(keyword)}</strong>"</p>
            </div>
        </td>
    `;
    tbody.appendChild(row);
}

/**
 * إزالة صف "لا توجد نتائج"
 */
function removeNoResultsRow(tbody) {
    const oldRow = tbody.querySelector('.no-results-row');
    if (oldRow) oldRow.remove();
}

/**
 * تحديث عداد النتائج
 */
function updateSearchCounter(count, keyword) {
    let counter = document.getElementById('searchResultsCount');
    
    if (!counter) {
        counter = document.createElement('span');
        counter.id = 'searchResultsCount';
        counter.className = 'search-counter';
        
        const searchWrapper = document.querySelector('.search-wrapper');
        if (searchWrapper) {
            searchWrapper.appendChild(counter);
        }
    }
    
    if (keyword === '') {
        counter.style.display = 'none';
    } else {
        counter.style.display = 'inline-block';
        counter.textContent = `${count} ${count === 1 ? 'نتيجة' : 'نتائج'}`;
        counter.setAttribute('data-count', count);
    }
}

/**
 * إعادة تعيين البحث
 */
function resetSearch() {
    const searchInput = document.getElementById('tableSearch');
    if (searchInput) {
        searchInput.value = '';
        performSearch('');
    }
}

/**
 * هروب النصوص الآمن
 */
function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

// ============================================
// تهيئة المستمعات
// ============================================
function initEventListeners() {
    
    // تغيير نوع التقرير
    const reportType = document.getElementById('reportType');
    if (reportType) {
        reportType.addEventListener('change', function() {
            togglePeriodSection(this.value);
            toggleStatsCards(this.value);
            toggleReportTables(this.value);
            updateUrlParams();
        });
    }
    
    // تغيير الفترة الزمنية
    const reportPeriod = document.getElementById('reportPeriod');
    if (reportPeriod) {
        reportPeriod.addEventListener('change', function() {
            toggleCustomDates(this.value);
            if (this.value !== 'custom') {
                updateUrlParams();
            }
        });
    }
    
    // أزرار التاريخ المخصص
    const dateFrom = document.getElementById('dateFrom');
    const dateTo = document.getElementById('dateTo');
    
    if (dateFrom) {
        dateFrom.addEventListener('change', function() {
            if (document.getElementById('reportPeriod').value === 'custom') {
                updateUrlParams();
            }
        });
    }
    
    if (dateTo) {
        dateTo.addEventListener('change', function() {
            if (document.getElementById('reportPeriod').value === 'custom') {
                updateUrlParams();
            }
        });
    }
    
    // زر عرض التقرير
    const viewBtn = document.getElementById('viewReportBtn');
    if (viewBtn) {
        viewBtn.addEventListener('click', function() {
            updateUrlParams();
        });
    }
    
    // زر إعادة تعيين
    const resetBtn = document.getElementById('resetReportBtn');
    if (resetBtn) {
        resetBtn.addEventListener('click', function() {
            resetReport();
        });
    }
}

// ============================================
// اختصارات لوحة المفاتيح
// ============================================
function initKeyboardShortcuts() {
    document.addEventListener('keydown', function(e) {
        
        // Ctrl + 1-4: تغيير نوع التقرير
        if (e.ctrlKey && !isNaN(parseInt(e.key))) {
            e.preventDefault();
            const num = parseInt(e.key);
            const select = document.getElementById('reportType');
            
            if (select) {
                switch(num) {
                    case 1: select.value = 'cash'; break;
                    case 2: select.value = 'credit'; break;
                    case 3: select.value = 'inventory'; break;
                    case 4: select.value = 'products'; break;
                    default: return;
                }
                select.dispatchEvent(new Event('change'));
            }
        }
        
        // Ctrl + Shift: إعادة تعيين
        if (e.ctrlKey && e.shiftKey) {
            e.preventDefault();
            resetReport();
        }
        
        // Enter في أي حقل تحكم: عرض التقرير
        if (e.key === 'Enter') {
            const target = e.target;
            if (target.tagName === 'INPUT' || target.tagName === 'SELECT') {
                e.preventDefault();
                updateUrlParams();
            }
        }
    });
}

// ============================================
// دوال التحكم في الواجهة
// ============================================

function togglePeriodSection(type) {
    const periodSection = document.getElementById('periodSection');
    if (!periodSection) return;
    periodSection.style.display = (type === 'cash' || type === 'credit') ? 'block' : 'none';
}

function toggleCustomDates(period) {
    const customDates = document.getElementById('customDates');
    if (!customDates) return;
    customDates.style.display = period === 'custom' ? 'block' : 'none';
}

function toggleStatsCards(type) {
    document.querySelectorAll('.stats-cards').forEach(el => {
        el.style.display = 'none';
    });
    const target = document.getElementById(type + 'Stats');
    if (target) target.style.display = 'block';
}

function toggleReportTables(type) {
    document.querySelectorAll('.report-table').forEach(el => {
        el.style.display = 'none';
    });
    const target = document.querySelector('.' + type + '-table');
    if (target) target.style.display = 'block';
    resetSearch();
}

function updateUrlParams() {
    const type = document.getElementById('reportType').value;
    const period = document.getElementById('reportPeriod').value;
    
    let url = `?type=${type}&period=${period}`;
    
    if (period === 'custom') {
        const from = document.getElementById('dateFrom').value;
        const to = document.getElementById('dateTo').value;
        url += `&from=${from}&to=${to}`;
    }
    
    window.location.href = window.location.pathname + url;
}

function resetReport() {
    window.location.href = window.location.pathname;
}

function exportToExcel() {
    const type = document.getElementById('reportType').value;
    const period = document.getElementById('reportPeriod').value;
    
    let url = `reports/export?type=${type}&period=${period}`;
    
    if (period === 'custom') {
        const from = document.getElementById('dateFrom').value;
        const to = document.getElementById('dateTo').value;
        url += `&from=${from}&to=${to}`;
    }
    
    window.open(url, '_blank');
}

function printReport() {
    const type = document.getElementById('reportType').value;
    const period = document.getElementById('reportPeriod').value;
    
    let url = `reports/print?type=${type}&period=${period}`;
    
    if (period === 'custom') {
        const from = document.getElementById('dateFrom').value;
        const to = document.getElementById('dateTo').value;
        url += `&from=${from}&to=${to}`;
    }
    
    window.open(url, '_blank');
}

</script>
<?php require BASE_PATH . 'views/reports/product_analytics.php'; ?>

<?php
$content = ob_get_clean();
require BASE_PATH . 'views/layouts/main.php';
?>


