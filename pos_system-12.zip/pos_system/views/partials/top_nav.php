<?php
$currentPage = basename($_SERVER['REQUEST_URI']);
$role = Auth::role();
$userName = Auth::name() ?? '';
?>
<nav class="top-nav">
    <div class="nav-right">
        <a href="<?= BASE_URL ?>/dashboard" class="nav-link <?= $currentPage == 'dashboard' ? 'active' : '' ?>">
            🏠 الرئيسية
        </a>
        
        <?php if ($role === 'admin'): ?>
            <a href="<?= BASE_URL ?>/inventory" class="nav-link <?= $currentPage == 'inventory' ? 'active' : '' ?>">
                🏭 المخزن الرئيسي
            </a>
            <a href="<?= BASE_URL ?>/shelf" class="nav-link <?= $currentPage == 'shelf' ? 'active' : '' ?>">
                🛒 رف البيع
            </a>
        <?php endif; ?>
        
        <a href="<?= BASE_URL ?>/pos" class="nav-link <?= $currentPage == 'pos' ? 'active' : '' ?>">
            💰 نقطة البيع
        </a>
        <a href="<?= BASE_URL ?>/customers" class="nav-link <?= $currentPage == 'customers' ? 'active' : '' ?>">
            👥 العملاء
        </a>
        
        <?php if ($role === 'admin'): ?>
            <a href="<?= BASE_URL ?>/reports" class="nav-link <?= $currentPage == 'reports' ? 'active' : '' ?>">
                📊 التقارير
            </a>
            <a href="<?= BASE_URL ?>/users" class="nav-link <?= $currentPage == 'users' ? 'active' : '' ?>">
                👨‍💼 المستخدمين
            </a>
            <a href="<?= BASE_URL ?>/settings" class="nav-link <?= $currentPage == 'settings' ? 'active' : '' ?>">
                ⚙️ الإعدادات
            </a>
        <?php endif; ?>
        
       
       
    </div>
    
<div class="nav-left" style="display: flex; align-items: center; gap: 15px;">
    
    <!-- زر التحكم بإدارة الاختصارات -->
    <button id="shortcut-manager-btn" 
            onclick="if(window.ShortcutEngine) window.ShortcutEngine.toggleModal();"
            style="
                background: linear-gradient(135deg, #1e3c72, #2a5298); 
                border: 1px solid rgba(255, 255, 255, 0.2); 
                border-radius: 12px; 
                width: 45px; 
                height: 45px; 
                display: flex; 
                align-items: center; 
                justify-content: center; 
                cursor: pointer; 
                font-size: 22px; 
                transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1); 
                box-shadow: 0 4px 10px rgba(0,0,0,0.15);
                outline: none;
                color: #fff;
            "
            onmouseover="this.style.transform='translateY(-3px)'; this.style.boxShadow='0 8px 15px rgba(30,60,114,0.3)';" 
            onmouseout="this.style.transform='translateY(0)'; this.style.boxShadow='0 4px 10px rgba(0,0,0,0.15)';"
            title="إدارة اختصارات النظام">
        ⌨️
    </button>

    <button id="cloud-toggle-btn" 
            style="
                background: linear-gradient(135deg, #ffffff, #f0f7ff); 
                border: 1px solid rgba(0, 210, 255, 0.2); 
                border-radius: 12px; 
                width: 45px; 
                height: 45px; 
                display: flex; 
                align-items: center; 
                justify-content: center; 
                cursor: pointer; 
                font-size: 22px; 
                transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1); 
                box-shadow: 0 4px 10px rgba(0,0,0,0.05);
                outline: none;
                position: relative;
                overflow: hidden;
            "
            onmouseover="this.style.transform='translateY(-3px)'; this.style.boxShadow='0 8px 15px rgba(0,188,212,0.2)';" 
            onmouseout="this.style.transform='translateY(0)'; this.style.boxShadow='0 4px 10px rgba(0,0,0,0.05)';"
            title="بيانات المستخدم">
        
        <span style="filter: drop-shadow(0 2px 4px rgba(0,0,0,0.1));">👤</span>
        
        <div style="position: absolute; top: 0; left: -100%; width: 50%; height: 100%; background: linear-gradient(90deg, transparent, rgba(255,255,255,0.8), transparent); transition: 0.5s; pointer-events: none;" id="btn-shine"></div>
    </button>


    <div class="nav-left">
       
        <a href="<?= BASE_URL ?>/logout" class="nav-link logout">🚪 خروج</a>
    </div>
</div>

<script>
    // إضافة تأثير اللمعان عند التحويم بالماوس
    const btn = document.getElementById('cloud-toggle-btn');
    const shine = document.getElementById('btn-shine');
    btn.onmouseenter = () => { shine.style.left = '100%'; shine.style.transition = '0.6s'; };
    btn.onmouseleave = () => { shine.style.left = '-100%'; shine.style.transition = '0s'; };
</script>

<?php include_once 'views/Usermessage.php'; ?>

</nav>
 

<?php 
    // تأكد من كتابة المسار الصحيح للملف
    include_once 'views/Casio.php'; 
?>