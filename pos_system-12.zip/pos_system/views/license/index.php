<!DOCTYPE html>
<html dir="rtl" lang="ar">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>تفعيل الترخيص - <?php echo APP_NAME; ?></title>
    <style>
        * { margin:0; padding:0; box-sizing:border-box; }
        body {
            font-family: 'Tajawal', sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        .license-card {
            max-width: 600px;
            width: 100%;
            background: white;
            border-radius: 15px;
            padding: 40px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
            animation: fadeIn 0.5s ease;
        }
        @keyframes fadeIn {
            from { opacity:0; transform:translateY(-20px); }
            to { opacity:1; transform:translateY(0); }
        }
        h1 { text-align:center; margin-bottom:30px; color:#333; }
        .status-box {
            padding:15px; border-radius:8px; margin-bottom:25px; text-align:center;
        }
        .status-no_license {
            background:#fff3cd; color:#856404; border:2px solid #ffeeba;
        }
        .status-expired {
            background:#f8d7da; color:#721c24; border:2px solid #f5c6cb;
        }
        .fingerprint-section {
            background:#f8f9fa; border-radius:10px; padding:20px; margin:20px 0;
            border:2px dashed #dee2e6; text-align:center;
        }
        .fingerprint-box {
            background:white; padding:15px; border-radius:8px; border:1px solid #dee2e6;
            direction:ltr; text-align:left; font-family:monospace; font-size:14px;
            margin:10px 0; word-break:break-all; display:flex; justify-content:space-between;
            align-items:center;
        }
        .btn-copy {
            background:#007bff; color:white; border:none; padding:8px 20px;
            border-radius:5px; cursor:pointer; white-space:nowrap;
        }
        .instruction {
            color:#666; font-size:14px; margin:15px 0; padding:12px;
            background:#e7f3ff; border-radius:5px; border-right:3px solid #007bff;
        }
        .input-group input {
            width:100%; padding:15px; font-size:16px; border:2px solid #ddd;
            border-radius:8px; margin:10px 0; direction:ltr; text-align:left;
            font-family:monospace;
        }
        .btn-activate {
            width:100%; background:linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color:white; border:none; padding:15px; font-size:18px; border-radius:8px;
            cursor:pointer; transition:all 0.3s;
        }
        .btn-activate:hover { transform:translateY(-2px); box-shadow:0 10px 30px rgba(102,126,234,0.4); }
        .btn-activate:disabled { opacity:0.6; cursor:not-allowed; }
        .message-box {
            margin-top:20px; padding:15px; border-radius:5px; text-align:center;
            display:none;
        }
        .message-success { background:#d4edda; color:#155724; border:2px solid #c3e6cb; }
        .message-error { background:#f8d7da; color:#721c24; border:2px solid #f5c6cb; }
    </style>
</head>
<body>
    <div class="license-card">
        <h1>🔐 تفعيل نظام الكاشير</h1>
        
        <div class="status-box status-<?php echo $data['status']['status']; ?>">
            <strong><?php echo $data['status']['message']; ?></strong>
            <?php if (isset($data['status']['expiry_date'])): ?>
                <br><small>تاريخ الانتهاء: <?php echo $data['status']['expiry_date']; ?></small>
            <?php endif; ?>
        </div>
        
        <div class="fingerprint-section">
            <div class="fingerprint-label">📱 بصمة هذا الجهاز:</div>
            <div class="fingerprint-box">
                <code id="fingerprint"><?php echo $data['fingerprint']; ?></code>
                <button class="btn-copy" onclick="copyFingerprint()">نسخ</button>
            </div>
            <div class="instruction">
                أرسل هذه البصمة للمطور للحصول على مفتاح التفعيل
            </div>
        </div>
        
        <div class="input-group">
            <input type="text" id="license_key" placeholder="أدخل مفتاح الترخيص">
        </div>
        
        <button class="btn-activate" id="activateBtn" onclick="activateLicense()">
            تفعيل النظام
        </button>
        
        <div id="messageBox" class="message-box"></div>
    </div>
    
    <script>
    function copyFingerprint() {
        const fingerprint = document.getElementById('fingerprint').innerText;
        navigator.clipboard.writeText(fingerprint).then(() => {
            alert('✅ تم نسخ البصمة');
        });
    }
    
    function activateLicense() {
        const licenseKey = document.getElementById('license_key').value.trim();
        const activateBtn = document.getElementById('activateBtn');
        const messageBox = document.getElementById('messageBox');
        
        if (!licenseKey) {
            alert('الرجاء إدخال مفتاح الترخيص');
            return;
        }
        
        activateBtn.disabled = true;
        activateBtn.innerHTML = 'جاري التفعيل...';
        messageBox.style.display = 'none';
        
        const formData = new FormData();
        formData.append('license_key', licenseKey);
        
        fetch('<?php echo BASE_URL; ?>/license/activate', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            messageBox.style.display = 'block';
            
            if (data.success) {
                messageBox.className = 'message-box message-success';
                messageBox.innerHTML = '✅ ' + data.message + '<br>جاري تحويلك إلى صفحة تسجيل الدخول...';
                
                setTimeout(() => {
                    window.location.href = '<?php echo BASE_URL; ?>/login';
                }, 2000);
            } else {
                messageBox.className = 'message-box message-error';
                messageBox.innerHTML = '❌ ' + data.message;
                activateBtn.disabled = false;
                activateBtn.innerHTML = 'تفعيل النظام';
            }
        })
        .catch(error => {
            messageBox.style.display = 'block';
            messageBox.className = 'message-box message-error';
            messageBox.innerHTML = '❌ حدث خطأ في الاتصال';
            activateBtn.disabled = false;
            activateBtn.innerHTML = 'تفعيل النظام';
        });
    }
    </script>
</body>
</html>