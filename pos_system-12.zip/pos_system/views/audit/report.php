<?php
ob_start();
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $title ?? 'تقرير الجرد' ?></title>
    <link rel="stylesheet" href="<?= asset('css/style.css') ?>">
    <style>
        /* ===== المتغيرات العامة ===== */
        :root {
            --primary: #1a237e;
            --primary-light: #283593;
            --accent: #1976d2;
            --success: #2e7d32;
            --danger: #c62828;
            --warning: #ed6c02;
            --info: #0288d1;
            --gray-100: #f5f5f5;
            --gray-200: #e0e0e0;
            --gray-300: #bdbdbd;
            --gray-600: #757575;
            --gray-800: #424242;
            --shadow: 0 1px 3px rgba(0,0,0,0.05);
            --shadow-sm: 0 1px 2px rgba(0,0,0,0.03);
        }

        /* إزالة الهوامش والحشو الافتراضي */
        body {
            margin: 0;
            padding: 0;
            background: var(--gray-100);
            font-family: system-ui, -apple-system, 'Segoe UI', Roboto, 'Helvetica Neue', sans-serif;
        }

        /* ===== تخطيط الصفحة الرئيسي - ثابت ===== */
        .audit-report-page {
            height: calc(100vh - 60px);
            display: flex;
            gap: 12px;
            padding: 12px;
            overflow: hidden;
            background: var(--gray-100);
        }

        /* ===== اللوحة اليمنى - 30% ثابتة ===== */
        .right-panel {
            width: 30%;
            min-width: 280px;
            background: white;
            border-radius: 10px;
            box-shadow: var(--shadow);
            display: flex;
            flex-direction: column;
            overflow: hidden;
            height: 100%;
        }

        .panel-header {
            padding: 12px 15px;
            background: linear-gradient(135deg, var(--primary), var(--primary-light));
            color: white;
            border-bottom: 1px solid rgba(255,255,255,0.1);
            flex-shrink: 0;
        }

        .panel-header h2 {
            font-size: 15px;
            font-weight: 600;
            margin: 0;
            display: flex;
            align-items: center;
            gap: 6px;
        }

        .panel-header .subtitle {
            font-size: 10px;
            opacity: 0.8;
            margin-top: 3px;
        }

        /* ===== حاوية البطاقات مع شريط تمرير رأسي ===== */
        .cards-scroll-container {
            flex: 1;
            overflow-y: auto;
            padding: 12px;
            display: flex;
            flex-direction: column;
            gap: 8px;
            scrollbar-width: thin;
            scrollbar-color: var(--accent) var(--gray-200);
        }

        .cards-scroll-container::-webkit-scrollbar {
            width: 4px;
        }

        .cards-scroll-container::-webkit-scrollbar-track {
            background: var(--gray-200);
            border-radius: 2px;
        }

        .cards-scroll-container::-webkit-scrollbar-thumb {
            background: var(--accent);
            border-radius: 2px;
        }

        /* ===== بطاقات المعلومات - مصغرة ===== */
        .info-card {
            background: white;
            border: 1px solid var(--gray-200);
            border-radius: 8px;
            padding: 10px 12px;
            display: flex;
            align-items: center;
            gap: 10px;
            transition: all 0.2s;
            box-shadow: var(--shadow-sm);
        }

        .info-card:hover {
            transform: translateX(-3px);
            border-color: var(--accent);
        }

        .info-icon {
            width: 36px;
            height: 36px;
            border-radius: 8px;
            background: var(--gray-100);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 18px;
            flex-shrink: 0;
        }

        .info-card.id .info-icon { background: #e3f2fd; color: var(--primary); }
        .info-card.date .info-icon { background: #fff3e0; color: var(--warning); }
        .info-card.user .info-icon { background: #e8f5e8; color: var(--success); }
        .info-card.status .info-icon { background: #e8eaf6; color: var(--info); }

        .info-content {
            flex: 1;
            min-width: 0;
        }

        .info-label {
            font-size: 10px;
            color: var(--gray-600);
            margin-bottom: 2px;
            letter-spacing: 0.2px;
        }

        .info-value {
            font-size: 14px;
            font-weight: 600;
            color: var(--gray-800);
            line-height: 1.2;
        }

        /* ===== بطاقة الملخص السريع - مصغرة ===== */
        .quick-summary-card {
            background: linear-gradient(135deg, var(--accent), #1565c0);
            color: white;
            border-radius: 8px;
            padding: 12px;
            margin-top: 4px;
        }

        .quick-summary-title {
            font-size: 12px;
            font-weight: 600;
            margin-bottom: 10px;
            display: flex;
            align-items: center;
            gap: 6px;
            opacity: 0.95;
        }

        .summary-grid {
            display: flex;
            flex-direction: column;
            gap: 6px;
        }

        .summary-row {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 4px 0;
            border-bottom: 1px solid rgba(255,255,255,0.1);
            font-size: 11px;
        }

        .summary-row:last-child { border-bottom: none; }

        .summary-label {
            opacity: 0.9;
            display: flex;
            align-items: center;
            gap: 4px;
        }

        .summary-value {
            font-size: 12px;
            font-weight: 600;
        }

        .summary-value.loss { color: #ff8a80; }
        .summary-value.gain { color: #b9f6ca; }
        .summary-value.highlight {
            font-size: 13px;
            background: rgba(255,255,255,0.2);
            padding: 2px 8px;
            border-radius: 12px;
        }

        /* ===== اللوحة اليسرى - 70% ثابتة ===== */
        .left-panel {
            width: 70%;
            background: white;
            border-radius: 10px;
            box-shadow: var(--shadow);
            display: flex;
            flex-direction: column;
            overflow: hidden;
            height: 100%;
        }

        .left-panel-header {
            padding: 10px 15px;
            background: var(--gray-100);
            border-bottom: 1px solid var(--gray-200);
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-shrink: 0;
        }

        .left-panel-header h3 {
            font-size: 14px;
            font-weight: 600;
            color: var(--primary);
            margin: 0;
            display: flex;
            align-items: center;
            gap: 6px;
        }

        .left-panel-header .badge {
            background: var(--gray-200);
            padding: 3px 8px;
            border-radius: 16px;
            font-size: 10px;
            color: var(--gray-600);
            font-weight: 500;
        }

        /* ===== حاوية الجدول مع شريط تمرير رأسي فقط ===== */
        .table-container {
            flex: 1;
            overflow-y: auto;
            overflow-x: hidden;
            padding: 0 12px 12px 12px;
            scrollbar-width: thin;
            scrollbar-color: var(--accent) var(--gray-200);
        }

        .table-container::-webkit-scrollbar {
            width: 4px;
        }

        .table-container::-webkit-scrollbar-track {
            background: var(--gray-200);
            border-radius: 2px;
        }

        .table-container::-webkit-scrollbar-thumb {
            background: var(--accent);
            border-radius: 2px;
        }

        /* ===== جدول تفاصيل المنتجات - مصغر ===== */
        .audit-details-table {
            width: 100%;
            border-collapse: collapse;
            font-size: 11px;
        }

        .audit-details-table th {
            background: var(--gray-100);
            padding: 8px 4px;
            font-weight: 600;
            color: var(--gray-800);
            border-bottom: 2px solid var(--gray-200);
            position: sticky;
            top: 0;
            z-index: 10;
            text-align: center;
            font-size: 10px;
            white-space: nowrap;
        }

        .audit-details-table td {
            padding: 6px 4px;
            border-bottom: 1px solid var(--gray-200);
            text-align: center;
            white-space: nowrap;
        }

        .audit-details-table tbody tr:hover {
            background: var(--gray-100);
        }

        .product-name-cell {
            font-weight: 500;
            text-align: right;
            white-space: nowrap;
            max-width: 150px;
            overflow: hidden;
            text-overflow: ellipsis;
        }

        .product-barcode-cell {
            color: #666;
            font-size: 9px;
        }

        .diff-positive {
            color: var(--success);
            font-weight: 600;
        }

        .diff-negative {
            color: var(--danger);
            font-weight: 600;
        }

        .status-badge {
            display: inline-block;
            padding: 3px 6px;
            border-radius: 12px;
            font-size: 9px;
            font-weight: 500;
            white-space: nowrap;
        }

        .status-loss {
            background: #ffebee;
            color: #c62828;
        }

        .status-gain {
            background: #e8f5e8;
            color: #2e7d32;
        }

        .status-match {
            background: var(--gray-200);
            color: var(--gray-600);
        }

        /* ===== شريط الإجراءات السفلية - مصغر ===== */
        .action-bar {
            padding: 10px 15px;
            background: var(--gray-100);
            border-top: 1px solid var(--gray-200);
            display: flex;
            gap: 8px;
            justify-content: flex-end;
            flex-shrink: 0;
        }

        .btn {
            padding: 6px 12px;
            border: none;
            border-radius: 6px;
            font-size: 11px;
            font-weight: 500;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 4px;
            transition: all 0.2s;
        }

        .btn-primary {
            background: var(--accent);
            color: white;
        }

        .btn-primary:hover {
            background: #1565c0;
        }

        .btn-success {
            background: var(--success);
            color: white;
        }

        .btn-success:hover {
            background: #1b5e20;
        }

        .btn-outline {
            background: white;
            border: 1px solid var(--gray-200);
            color: var(--gray-600);
        }

        .btn-outline:hover {
            background: var(--gray-100);
        }

        /* ===== تجاوب ===== */
        @media (max-width: 1200px) {
            .audit-report-page {
                flex-direction: column;
            }
            
            .right-panel, .left-panel {
                width: 100%;
                min-width: auto;
            }
            
            .right-panel {
                max-height: 300px;
            }
        }
    </style>
</head>
<body>
    
    <?php
    // حساب الإحصائيات - بنفس المتغيرات المستخدمة في الملف الأصلي
    $stats = $stats ?? [];
    $items = $items ?? [];
    $audit = $audit ?? [];
    
    // إحصائيات إضافية للعرض في البطاقات
    $totalItems = $stats['total_items'] ?? count($items);
    $totalExpected = 0;
    $totalActual = 0;
    $lossCount = $stats['deficit_count'] ?? 0;
    $gainCount = $stats['surplus_count'] ?? 0;
    $matchCount = $stats['match_count'] ?? 0;
    
    // حساب المجاميع إذا لم تكن موجودة في $stats
    foreach ($items as $item) {
        $totalExpected += $item['expected_qty'] ?? 0;
        $totalActual += $item['actual_qty'] ?? 0;
    }
    ?>

    <div class="audit-report-page">
        <!-- ===== اللوحة اليمنى - 30% مع شريط تمرير ===== -->
        <div class="right-panel">
            <div class="panel-header">
                <h2>
                    <span>📊</span>
                    تقرير الجرد #<?= $audit['id'] ?? 'N/A' ?>
                </h2>
                <div class="subtitle">تفاصيل الجرد</div>
            </div>
            
            <div class="cards-scroll-container">
                <!-- بطاقة رقم الجرد -->
                <div class="info-card id">
                    <div class="info-icon">📋</div>
                    <div class="info-content">
                        <div class="info-label">رقم الجرد</div>
                        <div class="info-value">#<?= $audit['id'] ?? 'N/A' ?></div>
                    </div>
                </div>
                
                <!-- بطاقة تاريخ الجرد -->
                <div class="info-card date">
                    <div class="info-icon">📅</div>
                    <div class="info-content">
                        <div class="info-label">التاريخ</div>
                        <div class="info-value"><?= isset($audit['audit_date']) ? date('Y-m-d H:i', strtotime($audit['audit_date'])) : date('Y-m-d') ?></div>
                    </div>
                </div>
                
                <!-- بطاقة المسؤول -->
                <div class="info-card user">
                    <div class="info-icon">👤</div>
                    <div class="info-content">
                        <div class="info-label">المسؤول</div>
                        <div class="info-value"><?= htmlspecialchars($audit['user_name'] ?? 'غير معروف') ?></div>
                    </div>
                </div>
                
                <!-- بطاقة حالة الجرد -->
                <div class="info-card status">
                    <div class="info-icon">⚡</div>
                    <div class="info-content">
                        <div class="info-label">الحالة</div>
                        <div class="info-value">
                            <?php if (($audit['status'] ?? '') == 'completed'): ?>
                                <span style="color: var(--success);">✅ مكتمل</span>
                            <?php else: ?>
                                <span style="color: var(--warning);">⏳ قيد التنفيذ</span>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

                <!-- بطاقة إجمالي المنتجات -->
                <div class="info-card" style="border-right: 3px solid var(--info);">
                    <div class="info-icon" style="background: #e1f5fe; color: var(--info);">📦</div>
                    <div class="info-content">
                        <div class="info-label">إجمالي المنتجات</div>
                        <div class="info-value"><?= $totalItems ?></div>
                    </div>
                </div>

                <!-- بطاقة إجمالي الفروقات -->
                <div class="info-card" style="border-right: 3px solid var(--warning);">
                    <div class="info-icon" style="background: #fff3e0; color: var(--warning);">📊</div>
                    <div class="info-content">
                        <div class="info-label">إجمالي الفروقات</div>
                        <div class="info-value"><?= number_format($stats['total_discrepancy'] ?? 0, 0) ?> وحدة</div>
                    </div>
                </div>

                <!-- بطاقة الملخص السريع -->
                <div class="quick-summary-card">
                    <div class="quick-summary-title">
                        <span>📈</span> ملخص الفروقات
                    </div>
                    
                    <div class="summary-grid">
                        <div class="summary-row">
                            <span class="summary-label">📊 النظري:</span>
                            <span class="summary-value"><?= number_format($totalExpected) ?></span>
                        </div>
                        
                        <div class="summary-row">
                            <span class="summary-label">📝 الفعلي:</span>
                            <span class="summary-value"><?= number_format($totalActual) ?></span>
                        </div>
                        
                        <div class="summary-row">
                            <span class="summary-label">✅ مطابق:</span>
                            <span class="summary-value"><?= $matchCount ?></span>
                        </div>
                        
                        <div class="summary-row">
                            <span class="summary-label">🔴 عجز:</span>
                            <span class="summary-value loss"><?= $lossCount ?></span>
                        </div>
                        
                        <div class="summary-row">
                            <span class="summary-label">🟢 زيادة:</span>
                            <span class="summary-value gain"><?= $gainCount ?></span>
                        </div>
                        
                        <div class="summary-row" style="margin-top: 4px; border-top: 1px solid rgba(255,255,255,0.2);">
                            <span class="summary-label">💰 صافي الفرق:</span>
                            <span class="summary-value highlight"><?= number_format(($stats['total_surplus'] ?? 0) - ($stats['total_deficit'] ?? 0), 0) ?> وحدة</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- ===== اللوحة اليسرى - 70% مع شريط تمرير رأسي للجدول ===== -->
        <div class="left-panel">
            <div class="left-panel-header">
                <h3>
                    <span>📋</span>
                    تفاصيل المنتجات
                </h3>
                <span class="badge"><?= $totalItems ?></span>
            </div>
            
            <!-- حاوية الجدول مع شريط تمرير رأسي فقط -->
            <div class="table-container">
                <table class="audit-details-table">
                    <thead>
                        <tr>
                            <th style="width: 30px;">#</th>
                            <th style="text-align: right;">المنتج</th>
                            <th>الباركود</th>
                            <th>النظري</th>
                            <th>الفعلي</th>
                            <th>الفرق</th>
                            <th>الحالة</th>
                            <th>السبب</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($items)): ?>
                            <tr>
                                <td colspan="8" style="text-align: center; padding: 30px; color: #666;">
                                    لا توجد عناصر في هذا الجرد
                                </td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($items as $index => $item): ?>
                                <?php
                                $difference = ($item['actual_qty'] ?? 0) - ($item['expected_qty'] ?? 0);
                                ?>
                                <tr>
                                    <td><?= $index + 1 ?></td>
                                    <td class="product-name-cell" title="<?= htmlspecialchars($item['product_name'] ?? '') ?>">
                                        <?= htmlspecialchars($item['product_name'] ?? '') ?>
                                    </td>
                                    <td class="product-barcode-cell"><?= htmlspecialchars($item['barcode'] ?? '') ?></td>
                                    <td><?= number_format($item['expected_qty'] ?? 0) ?></td>
                                    <td><?= number_format($item['actual_qty'] ?? 0) ?></td>
                                    <td class="<?= $difference < 0 ? 'diff-negative' : ($difference > 0 ? 'diff-positive' : '') ?>">
                                        <?= $difference > 0 ? '+' : '' ?><?= $difference ?>
                                    </td>
                                    <td>
                                        <?php if ($difference < 0): ?>
                                            <span class="status-badge status-loss">🔴 عجز</span>
                                        <?php elseif ($difference > 0): ?>
                                            <span class="status-badge status-gain">🟢 زيادة</span>
                                        <?php else: ?>
                                            <span class="status-badge status-match">⚪ مطابق</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><?= htmlspecialchars($item['reason'] ?? '-') ?></td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <!-- شريط الإجراءات السفلية -->
            <div class="action-bar">
                <button class="btn btn-primary" onclick="window.print()">
                    <span>🖨️</span> طباعة
                </button>
              
                <button class="btn btn-outline" onclick="window.location.href='<?= BASE_URL ?>/audit'">
                    <span>↩️</span> عودة
                </button>
            </div>
        </div>
    </div>
    <!-- نظام الحماية -->
<script src="<?= BASE_URL ?>/assets/js/security.js?v=<?= time() ?>"></script>
</body>
</html>

<?php
$content = ob_get_clean();
require BASE_PATH . 'views/layouts/main.php';
?>