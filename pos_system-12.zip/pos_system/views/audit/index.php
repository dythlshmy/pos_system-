<?php
ob_start();
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $title ?? 'جرد المخزون' ?></title>
    <link rel="stylesheet" href="<?= asset('css/style.css') ?>">
    <style>
        /* ============================================
           ملف CSS الخاص بواجهة الجرد
           تصميم: البطاقات رأسياً على اليمين، الجدول على اليسار
           ============================================ */

        /* ===== المتغيرات العامة ===== */
        :root {
            --primary: #1a237e;
            --primary-light: #283593;
            --accent: #1976d2;
            --success: #2e7d32;
            --danger: #c62828;
            --warning: #ed6c02;
            --info: #0288d1;
            --gray-100: #f5f5f5;
            --gray-200: #e0e0e0;
            --gray-300: #bdbdbd;
            --gray-600: #757575;
            --gray-800: #424242;
            --shadow: 0 2px 4px rgba(0,0,0,0.1);
            --shadow-lg: 0 4px 12px rgba(0,0,0,0.15);
        }

        /* ===== تخطيط الصفحة الرئيسي ===== */
        .audit-page {
            height: calc(100vh - 60px);
            display: flex;
            gap: 15px;
            padding: 15px;
            overflow: hidden;
            background: var(--gray-100);
        }

        /* ===== اللوحة اليمنى - 30% ===== */
        .right-panel {
            width: 30%;
            min-width: 280px;
            background: white;
            border-radius: 12px;
            box-shadow: var(--shadow);
            display: flex;
            flex-direction: column;
            overflow: hidden;
        }

        /* ===== رأس اللوحة اليمنى ===== */
        .panel-header {
            padding: 15px;
            background: linear-gradient(135deg, var(--primary), var(--primary-light));
            color: white;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }

        .panel-header h2 {
            font-size: 16px;
            font-weight: 600;
            margin: 0;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .panel-header h2 i {
            font-size: 18px;
        }

        .panel-header .subtitle {
            font-size: 11px;
            opacity: 0.8;
            margin-top: 5px;
        }

        /* ===== البطاقات - مرتبة رأسياً ===== */
        .cards-container {
            flex: 1;
            padding: 15px;
            display: flex;
            flex-direction: column;
            gap: 12px;
            overflow-y: auto;
        }

        /* بطاقة إحصائية واحدة */
        .stat-card {
            background: white;
            border: 1px solid var(--gray-200);
            border-radius: 10px;
            padding: 15px;
            display: flex;
            align-items: center;
            gap: 15px;
            transition: all 0.3s;
            box-shadow: 0 1px 3px rgba(0,0,0,0.05);
        }

        .stat-card:hover {
            transform: translateX(-5px);
            box-shadow: var(--shadow);
            border-color: var(--accent);
        }

        /* أيقونة البطاقة */
        .stat-icon {
            width: 48px;
            height: 48px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
        }

        /* ألوان الأيقونات حسب نوع البطاقة */
        .stat-card.total .stat-icon {
            background: #e3f2fd;
            color: var(--primary);
        }

        .stat-card.completed .stat-icon {
            background: #e8f5e8;
            color: var(--success);
        }

        .stat-card.pending .stat-icon {
            background: #fff3e0;
            color: var(--warning);
        }

        .stat-card.discrepancy .stat-icon {
            background: #ffebee;
            color: var(--danger);
        }

        /* محتوى البطاقة */
        .stat-content {
            flex: 1;
        }

        .stat-label {
            font-size: 12px;
            color: var(--gray-600);
            margin-bottom: 4px;
        }

        .stat-number {
            font-size: 20px;
            font-weight: bold;
            color: var(--gray-800);
            line-height: 1.2;
        }

        .stat-sub {
            font-size: 10px;
            color: #999;
            margin-top: 2px;
        }

        /* ===== زر بدء جرد جديد ===== */
        .start-audit-btn {
            background: linear-gradient(135deg, var(--accent), #1565c0);
            color: white;
            border: none;
            border-radius: 8px;
            padding: 14px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            transition: all 0.3s;
            box-shadow: 0 2px 8px rgba(25,118,210,0.3);
            margin-top: 10px;
        }

        .start-audit-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(25,118,210,0.4);
        }

        .start-audit-btn:active {
            transform: translateY(0);
        }

        .start-audit-btn i {
            font-size: 16px;
        }

        /* ===== اللوحة اليسرى - 70% ===== */
        .left-panel {
            width: 70%;
            background: white;
            border-radius: 12px;
            box-shadow: var(--shadow);
            display: flex;
            flex-direction: column;
            overflow: hidden;
        }

        /* ===== شريط عنوان اللوحة اليسرى ===== */
        .left-panel-header {
            padding: 15px 20px;
            background: var(--gray-100);
            border-bottom: 1px solid var(--gray-200);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .left-panel-header h3 {
            font-size: 15px;
            font-weight: 600;
            color: var(--primary);
            margin: 0;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .left-panel-header .badge {
            background: var(--gray-200);
            padding: 4px 8px;
            border-radius: 20px;
            font-size: 11px;
            color: var(--gray-600);
        }

        /* ===== حاوية الجدول ===== */
        .table-container {
            flex: 1;
            overflow: auto;
            padding: 0 20px 20px 20px;
        }

        /* ===== جدول الجردات السابقة ===== */
        .audits-table {
            width: 100%;
            border-collapse: collapse;
            font-size: 13px;
        }

        .audits-table th {
            background: var(--gray-100);
            padding: 12px 10px;
            font-weight: 600;
            color: var(--gray-800);
            border-bottom: 2px solid var(--gray-200);
            position: sticky;
            top: 0;
            z-index: 10;
            text-align: center;
            font-size: 12px;
        }

        .audits-table td {
            padding: 12px 10px;
            border-bottom: 1px solid var(--gray-200);
            text-align: center;
        }

        .audits-table tbody tr:hover {
            background: var(--gray-100);
        }

        /* شارات الحالة */
        .status-badge {
            display: inline-block;
            padding: 4px 8px;
            border-radius: 20px;
            font-size: 11px;
            font-weight: 500;
        }

        .status-badge.completed {
            background: #e8f5e8;
            color: #2e7d32;
        }

        .status-badge.pending {
            background: #fff3e0;
            color: #e65100;
        }

        /* أزرار الإجراءات */
        .action-btn {
            background: none;
            border: 1px solid var(--gray-200);
            border-radius: 4px;
            padding: 6px 10px;
            font-size: 11px;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            gap: 4px;
            transition: all 0.3s;
            color: var(--gray-600);
        }

        .action-btn:hover {
            background: var(--info);
            border-color: var(--info);
            color: white;
        }

        /* ===== نافذة الجرد المنبثقة ===== */
        .modal {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0,0,0,0.5);
            display: none;
            align-items: center;
            justify-content: center;
            z-index: 10000;
        }

        .modal.active {
            display: flex;
        }

        .modal-content {
            background: white;
            border-radius: 12px;
            width: 95%;
            max-width: 1200px;
            max-height: 90vh;
            display: flex;
            flex-direction: column;
            box-shadow: var(--shadow-lg);
        }

        .modal-header {
            padding: 15px 20px;
            background: var(--primary);
            color: white;
            border-radius: 12px 12px 0 0;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .modal-header h3 {
            font-size: 16px;
            margin: 0;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .modal-close {
            background: rgba(255,255,255,0.2);
            border: none;
            color: white;
            width: 30px;
            height: 30px;
            border-radius: 50%;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: all 0.3s;
        }

        .modal-close:hover {
            background: rgba(255,255,255,0.3);
            transform: rotate(90deg);
        }

        .modal-body {
            padding: 20px;
            overflow-y: auto;
            flex: 1;
        }

        /* ===== شريط التقدم ===== */
        .progress-container {
            margin-bottom: 20px;
        }

        .progress-stats {
            display: flex;
            justify-content: space-between;
            font-size: 12px;
            color: var(--gray-600);
            margin-bottom: 5px;
        }

        .progress-bar {
            background: var(--gray-200);
            height: 6px;
            border-radius: 3px;
            overflow: hidden;
        }

        .progress-fill {
            background: var(--success);
            height: 100%;
            width: 0%;
            transition: width 0.3s;
        }

        /* ===== جدول الجرد ===== */
        .audit-table-container {
            overflow-x: auto;
            margin: 20px 0;
            border: 1px solid var(--gray-200);
            border-radius: 8px;
        }

        .audit-table {
            width: 100%;
            border-collapse: collapse;
            min-width: 1000px;
            font-size: 12px;
        }

        .audit-table th {
            background: var(--gray-100);
            padding: 10px;
            font-weight: 600;
            color: var(--gray-800);
            border-bottom: 2px solid var(--gray-200);
            text-align: center;
            font-size: 11px;
        }

        .audit-table td {
            padding: 8px 10px;
            border-bottom: 1px solid var(--gray-200);
            vertical-align: middle;
        }

        /* معلومات المنتج */
        .product-info {
            display: flex;
            flex-direction: column;
            gap: 2px;
        }

        .product-name {
            font-weight: 600;
            font-size: 12px;
        }

        .product-barcode {
            font-size: 10px;
            color: #999;
        }

        /* حقول الإدخال */
        .actual-input {
            width: 70px;
            padding: 5px;
            border: 1px solid var(--gray-200);
            border-radius: 4px;
            text-align: center;
            font-size: 12px;
        }

        .actual-input:focus {
            outline: none;
            border-color: var(--accent);
            box-shadow: 0 0 0 2px rgba(25,118,210,0.1);
        }

        .reason-input {
            width: 120px;
            padding: 5px;
            border: 1px solid var(--gray-200);
            border-radius: 4px;
            font-size: 11px;
        }

        /* الفرق */
        .difference {
            font-weight: 600;
            font-size: 12px;
            text-align: center;
        }

        .diff-positive {
            color: var(--success);
        }

        .diff-negative {
            color: var(--danger);
        }

        .diff-zero {
            color: #999;
        }

        /* شارات الحالة في الجدول */
        .item-status {
            padding: 3px 6px;
            border-radius: 12px;
            font-size: 10px;
            font-weight: 500;
            display: inline-block;
        }

        .status-pending {
            background: #fff3e0;
            color: #e65100;
        }

        .status-done {
            background: #e8f5e8;
            color: #2e7d32;
        }

        /* ===== ملخص الجرد ===== */
        .summary-cards {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 10px;
            margin: 20px 0;
        }

        .summary-card {
            background: var(--gray-100);
            border-radius: 8px;
            padding: 12px;
            text-align: center;
        }

        .summary-card .label {
            font-size: 11px;
            color: #666;
            margin-bottom: 5px;
        }

        .summary-card .value {
            font-size: 18px;
            font-weight: bold;
            color: var(--gray-800);
        }

        .summary-card .unit {
            font-size: 10px;
            color: #999;
        }

        /* ===== أزرار الإجراءات في النافذة ===== */
        .modal-actions {
            display: flex;
            gap: 10px;
            justify-content: flex-end;
            margin-top: 20px;
        }

        .btn {
            padding: 8px 16px;
            border: none;
            border-radius: 6px;
            font-size: 12px;
            font-weight: 500;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 6px;
            transition: all 0.3s;
        }

        .btn-sm {
            padding: 5px 10px;
            font-size: 11px;
        }

        .btn-primary {
            background: var(--accent);
            color: white;
        }

        .btn-primary:hover {
            background: #1565c0;
        }

        .btn-success {
            background: var(--success);
            color: white;
        }

        .btn-success:hover {
            background: #1b5e20;
        }

        .btn-danger {
            background: var(--danger);
            color: white;
        }

        .btn-danger:hover {
            background: #b71c1c;
        }

        .btn-outline {
            background: white;
            border: 1px solid var(--gray-200);
            color: var(--gray-600);
        }

        .btn-outline:hover {
            background: var(--gray-100);
        }

        /* ===== تجاوب للشاشات الصغيرة ===== */
        @media (max-width: 1200px) {
            .audit-page {
                flex-direction: column;
            }
            
            .right-panel {
                width: 100%;
                min-width: auto;
            }
            
            .left-panel {
                width: 100%;
            }
            
            .cards-container {
                flex-direction: row;
                flex-wrap: wrap;
            }
            
            .stat-card {
                flex: 1;
                min-width: 200px;
            }
        }

        @media (max-width: 768px) {
            .cards-container {
                flex-direction: column;
            }
            
            .summary-cards {
                grid-template-columns: repeat(2, 1fr);
            }
        }
    </style>
</head>
<body>
<!-- نظام الحماية -->
<script src="<?= BASE_URL ?>/assets/js/security.js?v=<?= time() ?>"></script>
    <div class="audit-page">
        <!-- ===== اللوحة اليمنى - 30% ===== -->
        <div class="right-panel">
            <div class="panel-header">
                <h2>
                    <i>📊</i>
                    لوحة الجرد
                </h2>
                <div class="subtitle">إحصائيات وأدوات الجرد</div>
            </div>
            
            <div class="cards-container">
                                <div class="action-buttons" style="margin-top: 8px;">
                    <button class="btn btn-back" onclick="goBack()">
                        <span>🔙</span> عودة
                    </button>
                </div>
                <!-- بطاقة إجمالي الجردات -->
                <div class="stat-card total">
                    <div class="stat-icon">📋</div>
                    <div class="stat-content">
                        <div class="stat-label">إجمالي الجردات</div>
                        <div class="stat-number"><?= $stats['total_audits'] ?? 0 ?></div>
                        <div class="stat-sub">جميع الجردات</div>
                    </div>
                </div>
                
                <!-- بطاقة المكتملة -->
                <div class="stat-card completed">
                    <div class="stat-icon">✅</div>
                    <div class="stat-content">
                        <div class="stat-label">مكتملة</div>
                        <div class="stat-number"><?= $stats['completed_audits'] ?? 0 ?></div>
                        <div class="stat-sub">تمت بنجاح</div>
                    </div>
                </div>
                
                <!-- بطاقة قيد التنفيذ -->
                <div class="stat-card pending">
                    <div class="stat-icon">⏳</div>
                    <div class="stat-content">
                        <div class="stat-label">قيد التنفيذ</div>
                        <div class="stat-number"><?= $stats['pending_audits'] ?? 0 ?></div>
                        <div class="stat-sub">جارية الآن</div>
                    </div>
                </div>
                
                <!-- بطاقة قيمة الفروقات -->
                <div class="stat-card discrepancy">
                    <div class="stat-icon">💰</div>
                    <div class="stat-content">
                        <div class="stat-label">قيمة الفروقات</div>
                        <div class="stat-number"><?= number_format($stats['total_discrepancy'] ?? 0, 2) ?> ₪</div>
                        <div class="stat-sub">عجز/زيادة</div>
                    </div>
                </div>
                
                <!-- زر بدء جرد جديد -->
                <button class="start-audit-btn" onclick="startNewAudit()">
                    <i>➕</i>
                    بدء جرد جديد
                </button>
            </div>
        </div>
        
        <!-- ===== اللوحة اليسرى - 70% ===== -->
        <div class="left-panel">
            <div class="left-panel-header">
                <h3>
                    <i>📜</i>
                    سجل الجردات السابقة
                </h3>
                <span class="badge">آخر 30 يوم</span>
            </div>
            
            <div class="table-container">
                <table class="audits-table">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>📅 التاريخ</th>
                            <th>👤 المسؤول</th>
                            <th>⚡ الحالة</th>
                            <th>💰 الفروقات</th>
                            <th>⚙️ إجراءات</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($audits)): ?>
                            <tr>
                                <td colspan="6" style="text-align: center; padding: 40px;">
                                    <span style="font-size: 48px; display: block; margin-bottom: 10px;">📭</span>
                                    <p style="color: #666;">لا توجد جردات سابقة</p>
                                    <p style="font-size: 12px; color: #999;">اضغط "بدء جرد جديد" للبدء</p>
                                </td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($audits as $index => $audit): ?>
                                <tr>
                                    <td><?= $index + 1 ?></td>
                                    <td><?= date('Y-m-d H:i', strtotime($audit['audit_date'])) ?></td>
                                    <td><?= htmlspecialchars($audit['user_name'] ?? 'غير معروف') ?></td>
                                    <td>
                                        <span class="status-badge <?= $audit['status'] ?>">
                                            <?= $audit['status'] == 'completed' ? '✅ مكتمل' : '⏳ قيد التنفيذ' ?>
                                        </span>
                                    </td>
                                    <td style="color: <?= ($audit['total_discrepancy'] ?? 0) > 0 ? 'var(--danger)' : 'var(--success)' ?>; font-weight: bold;">
                                        <?= number_format($audit['total_discrepancy'] ?? 0, 2) ?> ₪
                                    </td>
                                    <td>
                                        <button class="action-btn" onclick="viewReport(<?= $audit['id'] ?>)">
                                            <i>📊</i>
                                            تقرير
                                        </button>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- ===== نافذة الجرد الجديد ===== -->
    <div class="modal" id="auditModal">
        <div class="modal-content">
            <div class="modal-header">
                <h3>
                    <i>📦</i>
                    جرد جديد - أدخل الكميات الفعلية
                </h3>
                <button class="modal-close" onclick="closeAuditModal()">✕</button>
            </div>
            
            <div class="modal-body">
                <!-- شريط التقدم -->
                <div class="progress-container">
                    <div class="progress-stats">
                        <span>📊 تم جرد <span id="completedCount">0</span> من <span id="totalCount">0</span> منتج</span>
                        <span id="progressPercentage">0%</span>
                    </div>
                    <div class="progress-bar">
                        <div class="progress-fill" id="progressFill" style="width: 0%;"></div>
                    </div>
                </div>

                <!-- جدول الجرد -->
                <div class="audit-table-container">
                    <table class="audit-table">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>📦 المنتج</th>
                                <th>🏢 المستودع</th>
                                <th>🛒 الرف</th>
                                <th>🖥️ الإجمالي النظري</th>
                                <th>📝 الفعلي</th>
                                <th>📊 الفرق</th>
                                <th>🔍 السبب</th>
                                <th>✅ الحالة</th>
                            </tr>
                        </thead>
                        <tbody id="auditProductsBody">
                            <!-- سيتم تعبئتها بالجافاسكريبت -->
                        </tbody>
                    </table>
                </div>

                <!-- ملخص الجرد -->
                <div class="summary-cards">
                    <div class="summary-card">
                        <div class="label">✅ تم الجرد</div>
                        <div class="value" id="summaryDone">0</div>
                    </div>
                    <div class="summary-card">
                        <div class="label">🔴 عجز</div>
                        <div class="value" style="color: var(--danger);" id="summaryLoss">0</div>
                    </div>
                    <div class="summary-card">
                        <div class="label">🟢 زيادة</div>
                        <div class="value" style="color: var(--success);" id="summaryGain">0</div>
                    </div>
                    <div class="summary-card">
                        <div class="label">💰 إجمالي الفروقات</div>
                        <div class="value" id="summaryTotal">0</div>
                    </div>
                </div>

                <!-- أزرار الإجراءات -->
                <div class="modal-actions">
                    <button class="btn btn-success" onclick="completeAudit()" id="completeAuditBtn">
                        ✅ إنهاء الجرد وحفظ النتائج
                    </button>
                    <button class="btn btn-primary" onclick="saveAuditProgress()" id="saveProgressBtn">
                        💾 حفظ التقدم
                    </button>
                    <button class="btn btn-outline" onclick="closeAuditModal()">
                        ❌ إلغاء
                    </button>
                </div>
            </div>
        </div>
    </div>

    <script>
        const BASE_URL = '<?= BASE_URL ?>';
        let currentAuditId = null;
        let auditProducts = [];

        // ===== بدء جرد جديد =====
        function startNewAudit() {
            fetch(BASE_URL + '/audit/start', { 
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                }
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    currentAuditId = data.audit_id;
                    loadProductsForAudit();
                    document.getElementById('auditModal').classList.add('active');
                } else {
                    alert('خطأ: ' + data.message);
                }
            })
            .catch(error => {
                alert('حدث خطأ في الاتصال');
                console.error(error);
            });
        }

        // ===== تحميل المنتجات للجرد =====
        function loadProductsForAudit() {
            fetch(BASE_URL + '/audit/get-products')
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        auditProducts = data.data;
                        displayAuditProducts();
                    } else {
                        alert('خطأ في تحميل المنتجات');
                    }
                });
        }

        // ===== عرض المنتجات في جدول الجرد =====
        function displayAuditProducts() {
            const tbody = document.getElementById('auditProductsBody');
            const totalCount = document.getElementById('totalCount');
            totalCount.textContent = auditProducts.length;

            let html = '';
            auditProducts.forEach((product, index) => {
                html += `
                    <tr id="product-row-${product.id}" data-id="${product.id}">
                        <td>${index + 1}</td>
                        <td>
                            <div class="product-info">
                                <span class="product-name">${product.name}</span>
                                <span class="product-barcode">${product.barcode}</span>
                            </div>
                        </td>
                        <td><span class="badge" style="background:#e3f2fd; color:#1a237e; padding:3px 8px; border-radius:12px; font-weight:bold;">${product.main_qty}</span></td>
                        <td><span class="badge" style="background:#fff3e0; color:#e65100; padding:3px 8px; border-radius:12px; font-weight:bold;">${product.shelf_qty}</span></td>
                        <td class="expected-qty" id="expected-${product.id}" style="font-weight:bold;">${product.expected_qty}</td>
                        <td>
                            <input type="number" class="actual-input" id="actual-${product.id}" 
                                   value="${product.actual_qty}" min="0" 
                                   onchange="updateProductAudit(${product.id})">
                        </td>
                        <td class="difference" id="diff-${product.id}">0</td>
                        <td>
                            <input type="text" class="reason-input" id="reason-${product.id}" 
                                   placeholder="سبب الفرق..." onchange="updateProductAudit(${product.id})">
                        </td>
                        <td>
                            <span class="item-status status-pending" id="status-${product.id}">
                                ⏳ قيد الانتظار
                            </span>
                        </td>
                    </tr>
                `;
            });
            
            tbody.innerHTML = html;
            updateAllDifferences();
            updateProgress();
        }

        // ===== تحديث بيانات منتج في الجرد =====
        function updateProductAudit(productId) {
            const expected = parseInt(document.getElementById(`expected-${productId}`).textContent);
            const actual = parseInt(document.getElementById(`actual-${productId}`).value) || 0;
            const reason = document.getElementById(`reason-${productId}`).value;
            
            const diff = actual - expected;
            const diffElement = document.getElementById(`diff-${productId}`);
            diffElement.textContent = diff;
            
            // تلوين الفرق
            if (diff < 0) {
                diffElement.className = 'difference diff-negative';
            } else if (diff > 0) {
                diffElement.className = 'difference diff-positive';
            } else {
                diffElement.className = 'difference diff-zero';
            }
            
            // تحديث الحالة
            const statusElement = document.getElementById(`status-${productId}`);
            if (actual === expected) {
                statusElement.className = 'item-status status-done';
                statusElement.innerHTML = '✅ مطابق';
            } else if (diff < 0) {
                statusElement.className = 'item-status status-pending';
                statusElement.innerHTML = '🔴 عجز';
            } else {
                statusElement.className = 'item-status status-pending';
                statusElement.innerHTML = '🟢 زيادة';
            }
            
            // حفظ التغيير تلقائياً
            saveAuditItem(productId, expected, actual, reason);
            
            // تحديث الملخص
            updateAuditSummary();
            updateProgress();
        }

        // ===== حفظ عنصر جرد =====
        function saveAuditItem(productId, expected, actual, reason) {
            const formData = new URLSearchParams({
                audit_id: currentAuditId,
                product_id: productId,
                expected_qty: expected,
                actual_qty: actual,
                reason: reason
            });

            fetch(BASE_URL + '/audit/save-item', {
                method: 'POST',
                headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (!data.success) {
                    console.error('فشل في حفظ المنتج:', data.message);
                }
            })
            .catch(error => console.error('Error saving:', error));
        }

        // ===== تحديث جميع الفروقات =====
        function updateAllDifferences() {
            auditProducts.forEach(product => {
                const expected = parseInt(document.getElementById(`expected-${product.id}`).textContent);
                const actual = parseInt(document.getElementById(`actual-${product.id}`).value) || 0;
                const diff = actual - expected;
                const diffElement = document.getElementById(`diff-${product.id}`);
                diffElement.textContent = diff;
                
                if (diff < 0) {
                    diffElement.className = 'difference diff-negative';
                } else if (diff > 0) {
                    diffElement.className = 'difference diff-positive';
                } else {
                    diffElement.className = 'difference diff-zero';
                }
            });
        }

        // ===== تحديث ملخص الجرد =====
        function updateAuditSummary() {
            let done = 0;
            let loss = 0;
            let gain = 0;
            let totalDiff = 0;
            
            auditProducts.forEach(product => {
                const actual = parseInt(document.getElementById(`actual-${product.id}`).value) || 0;
                const expected = parseInt(document.getElementById(`expected-${product.id}`).textContent);
                const diff = actual - expected;
                
                if (diff === 0) {
                    done++;
                } else if (diff < 0) {
                    loss++;
                } else {
                    gain++;
                }
                
                totalDiff += Math.abs(diff);
            });
            
            document.getElementById('summaryDone').textContent = done;
            document.getElementById('summaryLoss').textContent = loss;
            document.getElementById('summaryGain').textContent = gain;
            document.getElementById('summaryTotal').textContent = totalDiff;
        }

        // ===== تحديث شريط التقدم =====
        function updateProgress() {
            let completed = 0;
            
            auditProducts.forEach(product => {
                // يعتبر مكتملاً إذا تم إدخال كمية فعلية
                if (document.getElementById(`actual-${product.id}`).value !== '') {
                    completed++;
                }
            });
            
            const total = auditProducts.length;
            const percentage = total > 0 ? Math.round((completed / total) * 100) : 0;
            
            document.getElementById('completedCount').textContent = completed;
            document.getElementById('progressPercentage').textContent = percentage + '%';
            document.getElementById('progressFill').style.width = percentage + '%';
        }

        // ===== حفظ تقدم الجرد =====
        function saveAuditProgress() {
            alert('تم حفظ التقدم بنجاح');
        }

        // ===== إنهاء الجرد =====
        function completeAudit() {
            if (!confirm('هل أنت متأكد من إنهاء الجرد؟\nلن تتمكن من التعديل بعد الإنهاء.')) {
                return;
            }
            
            const formData = new URLSearchParams({
                audit_id: currentAuditId
            });

            fetch(BASE_URL + '/audit/complete', {
                method: 'POST',
                headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert('✅ تم إنهاء الجرد بنجاح');
                    closeAuditModal();
                    location.reload();
                } else {
                    alert('خطأ: ' + data.message);
                }
            })
            .catch(error => {
                alert('حدث خطأ في الاتصال');
                console.error(error);
            });
        }

        // ===== عرض تقرير جرد سابق =====
        function viewReport(auditId) {
            window.location.href = BASE_URL + '/audit/report/' + auditId;
        }

        // ===== إغلاق نافذة الجرد =====
        function closeAuditModal() {
            document.getElementById('auditModal').classList.remove('active');
            currentAuditId = null;

        }
        
        // دوال التنقل
        function goBack() {
            window.history.back();
        }

    </script>
</body>
</html>

<?php
$content = ob_get_clean();
require BASE_PATH . 'views/layouts/main.php';
?>