<style>
       :root {
        --casio-bg: linear-gradient(135deg, rgba(10, 25, 47, 0.98), rgba(0, 47, 108, 0.95));
        --casio-blue: #00d2ff;
        --casio-accent: #3a7bd5;
        --casio-text: #ffffff;
        --glow: 0 0 15px rgba(0, 210, 255, 0.5);
    }
    /* 1. الزر العائم - يظهر عند تشغيل الصفحة ولا يفتح الآلة تلقائياً */
 #casio-master-wrapper {
        display: none;
        position: fixed;
        top: 50%; left: 50%;
        transform: translate(-50%, -50%);
        width: 280px;
        min-width: 250px;
        height: 580px;
        min-height: 500px;
        background: var(--casio-bg);
        backdrop-filter: blur(25px);
        border-radius: 20px;
        padding: 18px;
        box-shadow: 0 50px 100px rgba(0,0,0,0.9), var(--glow);
        z-index: 2147483647; /* القيمة القصوى للمتصفح */
        border: 1px solid rgba(255,255,255,0.15);
        flex-direction: column;
        overflow: hidden;
        user-select: none;
        transition: box-shadow 0.3s ease;
    }

    /* الزر العائم - مطور */
    #casio-launcher-btn {
        position: fixed; top: 80px; right: 30px;
        width: 68px; height: 68px;
        background: radial-gradient(circle, var(--casio-blue), var(--casio-accent));
        border-radius: 50%;
        cursor: move;
        display: flex; align-items: center; justify-content: center;
        box-shadow: 0 10px 30px rgba(0, 210, 255, 0.5);
        z-index: 2147483646;
        color: white; font-size: 32px; border: 2px solid #fff;
        transition: transform 0.2s, box-shadow 0.2s;
    }
    #casio-launcher-btn:hover { transform: scale(1.05); box-shadow: 0 0 20px var(--casio-blue); }


    /* شاشة الآلة - بيضاء ناصعة */
    .casio-lcd {
        background: #ffffff;
        border-radius: 12px;
        padding: 15px;
        margin-bottom: 15px;
        text-align: right;
        border: 4px solid #002f6c;
        box-shadow: inset 0 5px 15px rgba(0,0,0,0.2);
    }
    #casio-expr { font-size: 14px; color: #555; height: 20px; font-family: monospace; }
    #casio-val { font-size: 34px; font-weight: bold; color: #000; word-wrap: break-word; }

    /* شبكة الأزرار */
    .casio-btns-grid {
        display: grid;
        grid-template-columns: repeat(5, 1fr);
        gap: 8px;
        flex: 1;
    }

    .casio-btn {
        border: none;
        border-radius: 10px;
        font-weight: bold;
        cursor: pointer;
        font-size: 13px;
        transition: all 0.1s ease;
        box-shadow: 0 4px 0 rgba(0,0,0,0.2);
        display: flex;
        align-items: center;
        justify-content: center;
        color: white;
    }
    .casio-btn:active { transform: translateY(3px); box-shadow: none; }

    /* تصنيفات الأزرار */
    .btn-financial { background: #fb8500; } /* برتقالي للمالي */
    .btn-scientific { background: #023047; } /* كحلي للعلمي */
    .btn-numeric   { background: #ffffff; color: #000; font-size: 20px; } /* أبيض للأرقام */
    .btn-operator  { background: #219ebc; } /* سماوي للعمليات */
    .btn-danger    { background: #d00000; } /* أحمر للحذف */
    .btn-success   { background: #38b000; grid-column: span 2; font-size: 24px; } /* أخضر لليساوي */

    /* نافذة السجل المنبثقة داخل الآلة */
    #casio-history-panel {
        display: none;
        position: absolute;
        top: 0; left: 0; width: 100%; height: 100%;
        background: rgba(255,255,255,0.98);
        z-index: 100001;
        padding: 20px;
        border-radius: 25px;
        color: #000;
    }

    /* مقبض التكبير في الزاوية */
    .resizer {
        position: absolute;
        right: 0; bottom: 0; width: 20px; height: 20px;
        cursor: nwse-resize;
        background: linear-gradient(135deg, transparent 50%, rgba(0,0,0,0.2) 50%);
    }
</style>

<div id="casio-launcher-btn" title="انقر للفتح | اسحب للتحريك">🖩</div>

<div id="casio-master-wrapper">
    <div id="casio-drag-handle" style="cursor:move; padding: 5px; color:#fff; display:flex; justify-content:space-between; font-size:12px; font-weight:bold;">
        <span>CASIO BUSINESS PRO</span>
        <span onclick="toggleCasioDisplay()" style="cursor:pointer; font-size:18px;">✕</span>
    </div>

    <div class="casio-lcd">
        <div id="casio-expr">READY</div>
        <div id="casio-val">0</div>
    </div>

    <div class="casio-btns-grid">
        <button class="casio-btn btn-financial" onclick="runFin('NPV')">NPV</button>
        <button class="casio-btn btn-financial" onclick="runFin('IRR')">IRR</button>
        <button class="casio-btn btn-financial" onclick="runFin('PV')">PV</button>
        <button class="casio-btn btn-financial" onclick="runFin('FV')">FV</button>
        <button class="casio-btn btn-financial" onclick="runFin('PMT')">PMT</button>

        <button class="casio-btn btn-financial" onclick="runFin('TAX+')">TAX+</button>
        <button class="casio-btn btn-financial" onclick="runFin('TAX-')">TAX-</button>
        <button class="casio-btn btn-financial" onclick="runFin('COST')">COST</button>
        <button class="casio-btn btn-financial" onclick="runFin('SELL')">SELL</button>
        <button class="casio-btn btn-financial" onclick="runFin('MAR')">MAR</button>

        <button class="casio-btn btn-scientific" onclick="runSci('sin')">sin</button>
        <button class="casio-btn btn-scientific" onclick="runSci('cos')">cos</button>
        <button class="casio-btn btn-scientific" onclick="runSci('tan')">tan</button>
        <button class="casio-btn btn-scientific" onclick="runSci('log')">log</button>
        <button class="casio-btn btn-scientific" onclick="runSci('pow')">xʸ</button>

        <button class="casio-btn btn-danger" onclick="fullClear()">AC</button>
        <button class="casio-btn btn-operator" onclick="backspace()">DEL</button>
        <button class="casio-btn btn-operator" onclick="addChar('GT')">GT</button>
        <button class="casio-btn btn-scientific" onclick="toggleHistoryPanel()">📜</button>
        <button class="casio-btn btn-operator" onclick="addChar('/')">÷</button>

        <button class="casio-btn btn-numeric" onclick="addChar('7')">7</button>
        <button class="casio-btn btn-numeric" onclick="addChar('8')">8</button>
        <button class="casio-btn btn-numeric" onclick="addChar('9')">9</button>
        <button class="casio-btn btn-operator" onclick="addChar('*')">×</button>
        <button class="casio-btn btn-scientific" onclick="runSci('sqrt')">√</button>

        <button class="casio-btn btn-numeric" onclick="addChar('4')">4</button>
        <button class="casio-btn btn-numeric" onclick="addChar('5')">5</button>
        <button class="casio-btn btn-numeric" onclick="addChar('6')">6</button>
        <button class="casio-btn btn-operator" onclick="addChar('-')">-</button>
        <button class="casio-btn btn-scientific" onclick="addChar('(')">(</button>

        <button class="casio-btn btn-numeric" onclick="addChar('1')">1</button>
        <button class="casio-btn btn-numeric" onclick="addChar('2')">2</button>
        <button class="casio-btn btn-numeric" onclick="addChar('3')">3</button>
        <button class="casio-btn btn-operator" onclick="addChar('+')">+</button>
        <button class="casio-btn btn-scientific" onclick="addChar(')')">)</button>

        <button class="casio-btn btn-numeric" onclick="addChar('0')">0</button>
        <button class="casio-btn btn-numeric" onclick="addChar('.')">.</button>
        <button class="casio-btn btn-success" onclick="calculateResult()">=</button>
        <button class="casio-btn btn-operator" onclick="addChar('%')">%</button>
    </div>

    <div id="casio-history-panel">
        <h3 style="border-bottom: 2px solid #002f6c; padding-bottom: 10px;">سجل العمليات الحسابية</h3>
        <div id="history-list" style="height: 400px; overflow-y: auto; margin-bottom: 20px; font-family: monospace; font-size: 16px;"></div>
        <button class="casio-btn btn-danger" style="width:100%; height:50px;" onclick="toggleHistoryPanel()">إغلاق السجل</button>
    </div>

    <div class="resizer"></div>
</div>

<script>
    let currentInput = '0';
    let gTotal = 0;
    let operationLogs = [];

    // --- 1. التحكم في الفتح والإغلاق ---
    function toggleCasioDisplay() {
        const win = document.getElementById("casio-master-wrapper");
        win.style.display = (win.style.display === "flex") ? "none" : "flex";
    }

    // --- 2. إدارة السحب والتحريك (بدون فتح تلقائي) ---
    function enableDragging(element, handle) {
        let x = 0, y = 0, xOld = 0, yOld = 0;
        let isMoving = false;

        handle.onmousedown = (e) => {
            isMoving = false;
            e.preventDefault();
            xOld = e.clientX; yOld = e.clientY;
            document.onmouseup = () => {
                document.onmouseup = null;
                document.onmousemove = null;
                if (!isMoving && handle.id === "casio-launcher-btn") toggleCasioDisplay();
            };
            document.onmousemove = (e) => {
                isMoving = true;
                x = xOld - e.clientX; y = yOld - e.clientY;
                xOld = e.clientX; yOld = e.clientY;
                element.style.top = (element.offsetTop - y) + "px";
                element.style.left = (element.offsetLeft - x) + "px";
                element.style.bottom = "auto"; element.style.right = "auto";
            };
        };
    }
    enableDragging(document.getElementById("casio-launcher-btn"), document.getElementById("casio-launcher-btn"));
    enableDragging(document.getElementById("casio-master-wrapper"), document.getElementById("casio-drag-handle"));

    // --- 3. منطق الحسابات ---
    const valDisp = document.getElementById("casio-val");
    const exprDisp = document.getElementById("casio-expr");

    function addChar(c) {
    if (c === 'GT') { 
        currentInput = gTotal.toString(); 
    } else {
        if (currentInput === '0' && c !== '.' && c !== '%') {
            currentInput = c;
        } else {
            // منع تكرار علامة النسبة المئوية بشكل متتالي
            if (c === '%' && currentInput.endsWith('%')) return;
            currentInput += c;
        }
    }
    valDisp.innerText = currentInput;
}


    function fullClear() { currentInput = '0'; valDisp.innerText = '0'; exprDisp.innerText = 'READY'; }
    function backspace() { currentInput = currentInput.slice(0, -1) || '0'; valDisp.innerText = currentInput; }

function calculateResult() {
    try {
        let expression = currentInput.replace(/×/g, '*').replace(/÷/g, '/');

        // --- المعالجة الذكية للنسبة المئوية ---
        if (expression.includes('%')) {
            // الحالة أ: عمليات مركبة مثل (100 + 10%) أو (200 * 5%)
            const compoundPattern = /(\d+(\.\d+)?)\s*([\+\-\*\/])\s*(\d+(\.\d+)?)%/g;
            
            if (compoundPattern.test(expression)) {
                expression = expression.replace(compoundPattern, (match, n1, p2, op, n2) => {
                    let num1 = parseFloat(n1);
                    let percent = parseFloat(n2);
                    let val = (num1 * percent) / 100; // حساب قيمة النسبة من الرقم الأول
                    
                    if (op === '+') return num1 + val;
                    if (op === '-') return num1 - val;
                    if (op === '*') return val;
                    if (op === '/') return num1 / (percent / 100);
                });
            } else {
                // الحالة ب: نسبة مئوية مفردة مثل (60%) يحولها إلى (0.6)
                expression = expression.replace(/(\d+(\.\d+)?)%/g, (match, n) => {
                    return parseFloat(n) / 100;
                });
            }
        }

        // تنفيذ العملية النهائية بعد التنظيف
        let result = eval(expression);
        
        // التحقق من أن النتيجة رقم صحيح
        if (isNaN(result) || !isFinite(result)) throw "Invalid";

        operationLogs.push(`${currentInput} = ${result}`);
        gTotal += parseFloat(result);
        exprDisp.innerText = currentInput;
        currentInput = result.toString();
        valDisp.innerText = currentInput;
        
    } catch (e) {
        valDisp.innerText = "Error";
        // تصفير المدخلات عند الخطأ لتجنب تكراره
        currentInput = "0"; 
    }
}


    // --- 4. وظائف علمية ومالية ---
    function runSci(type) {
        let v = parseFloat(currentInput);
        if (type === 'sin') currentInput = Math.sin(v * Math.PI / 180).toFixed(4);
        if (type === 'cos') currentInput = Math.cos(v * Math.PI / 180).toFixed(4);
        if (type === 'tan') currentInput = Math.tan(v * Math.PI / 180).toFixed(4);
        if (type === 'log') currentInput = Math.log10(v).toFixed(4);
        if (type === 'sqrt') currentInput = Math.sqrt(v).toFixed(4);
        if (type === 'pow') currentInput += "**";
        valDisp.innerText = currentInput;
    }

    function runFin(type) {
        let v = parseFloat(currentInput);
        switch(type) {
            case 'TAX+': currentInput = (v * 1.15).toFixed(2); break; // ضريبة 15%
            case 'TAX-': currentInput = (v / 1.15).toFixed(2); break;
            case 'MAR': currentInput = (v * 0.25).toFixed(2); break; // هامش ربح 25%
            case 'COST': currentInput = (v * 0.75).toFixed(2); break;
            case 'SELL': currentInput = (v * 1.30).toFixed(2); break;
            case 'PV': currentInput = (v / Math.pow(1+0.05, 1)).toFixed(2); break; 
            case 'FV': currentInput = (v * Math.pow(1+0.05, 1)).toFixed(2); break;
            default: alert("هذه العملية المالية تتطلب مدخلات متعددة (تدفقات نقدية)");
        }
        valDisp.innerText = currentInput;
    }

    function toggleHistoryPanel() {
        const panel = document.getElementById("casio-history-panel");
        const list = document.getElementById("history-list");
        panel.style.display = (panel.style.display === "block") ? "none" : "block";
        list.innerHTML = operationLogs.map(line => `<div style='padding:8px; border-bottom:1px solid #eee;'>${line}</div>`).reverse().join("");
    }

    // --- 5. دعم لوحة مفاتيح اللابتوب ---
    document.addEventListener('keydown', (e) => {
        if (document.getElementById("casio-master-wrapper").style.display === "flex") {
            if (e.key >= '0' && e.key <= '9') addChar(e.key);
            if (e.key === '.') addChar('.');
            if (e.key === '+') addChar('+');
            if (e.key === '-') addChar('-');
            if (e.key === '*') addChar('*');
            if (e.key === '/') addChar('/');
            if (e.key === 'Enter') { e.preventDefault(); calculateResult(); }
            if (e.key === 'Backspace') { e.preventDefault(); backspace(); }
            if (e.key === 'Escape') fullClear();
            if (e.key === '(' || e.key === ')') addChar(e.key);
        }
    });
</script>







