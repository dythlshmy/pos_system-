<?php
ob_start();
?>
<div class="dashboard">
    <h1>مرحباً بك في نظام الكاشير</h1>
    
    <div class="dashboard-stats">
        <div class="stat-card">
            <div class="stat-icon">💰</div>
            <div class="stat-title">مبيعات اليوم</div>
            <div class="stat-value"><?= $stats['today_sales_count'] ?></div>
            <small>القيمة: <?= number_format($stats['today_sales_total'], 2) ?> ريال</small>
        </div>
        
        <div class="stat-card">
            <div class="stat-icon">📦</div>
            <div class="stat-title">إجمالي المنتجات</div>
            <div class="stat-value"><?= $stats['total_products'] ?></div>
        </div>
        
        <div class="stat-card">
            <div class="stat-icon">👥</div>
            <div class="stat-title">إجمالي العملاء</div>
            <div class="stat-value"><?= $stats['total_customers'] ?></div>
        </div>
        
        <div class="stat-card">
            <div class="stat-icon">⚠️</div>
            <div class="stat-title">مخزون منخفض</div>
            <div class="stat-value"><?= $stats['low_stock'] ?></div>
        </div>
    </div>
</div>
<?php
$content = ob_get_clean();
require BASE_PATH . 'views/layouts/main.php';
?>