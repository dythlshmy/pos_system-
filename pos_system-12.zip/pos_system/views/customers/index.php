<?php ob_start(); ?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $title ?? 'إدارة العملاء' ?></title>
    <link rel="stylesheet" href="<?= asset('css/style.css') ?>">
    <style>
        /* ===== متغيرات التصميم ===== */
        :root {
            --primary: #2a3199ff;
            --primary-light: #2767a2ff;
            --primary-dark: #165ea1ff;
            --success: #4CAF50;
            --warning: #FF9800;
            --danger: #f44336;
            --info: #2196F3;
            --gray-100: #f8f9fa;
            --gray-200: #e9ecef;
            --gray-300: #dee2e6;
            --gray-400: #ced4da;
            --gray-500: #adb5bd;
            --gray-600: #6c757d;
            --dark: #343a40;
        }

        /* ===== التخطيط الرئيسي ===== */
        * {
            user-select: none;
            -webkit-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
        }

        input, textarea, [contenteditable="true"] {
            user-select: text !important;
            -webkit-user-select: text !important;
            -moz-user-select: text !important;
            -ms-user-select: text !important;
        }

        html, body {
            overflow: hidden !important;
            height: 100vh !important;
            width: 100vw !important;
            margin: 0 !important;
            padding: 0 !important;
            cursor: default;
            min-width: 1200px;
            background: #F5F7FA;
            font-family: 'Segoe UI', Tahoma, Arial, sans-serif;
        }

        /* ===== منع الطباعة ===== */
        @media print {
            body { display: none !important; }
        }

        /* ===== منع السحب ===== */
        [contenteditable], [draggable] {
            -webkit-user-drag: none;
            user-drag: none;
        }

        img {
            -webkit-user-drag: none;
            user-drag: none;
            pointer-events: none;
        }

        /* ===== الصفحة الرئيسية ===== */
        .customers-page {
            height: calc(100vh - 60px);
            display: flex;
            gap: 12px;
            padding: 15px;
            overflow: hidden;
            min-width: 1200px;
        }

        /* ===== الجزء الأيسر - لوحة التحكم ===== */
        .customers-control-panel {
            width: 320px;
            background: white;
            border-radius: 6px;
            box-shadow: 0 2px 6px rgba(0,0,0,0.05);
            border: 1px solid var(--gray-200);
            padding: 15px;
            overflow-y: auto;
            display: flex;
            flex-direction: column;
            gap: 12px;
            height: 100%;
        }

        /* ===== منطقة الرسائل ===== */
        .alerts-area {
            min-height: 35px;
        }

        .alert-message {
            height: 50px;
            width: 100%;
            border-radius: 6px;
            display: flex;
            align-items: center;
            padding: 0 12px;
            gap: 10px;
            animation: slideDown 0.20s ease;
            box-shadow: 0 2px 4px rgba(0,0,0,0.03);
            margin-bottom: 8px;
        }

        .alert-success {
            background: #E8F5E9;
            border-right: 4px solid #2E7D32;
        }

        .alert-error {
            background: #FFEBEE;
            border-right: 4px solid #C62828;
        }

        .alert-icon {
            width: 22px;
            height: 22px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 12px;
        }

        .alert-success .alert-icon {
            background: #2E7D32;
        }

        .alert-error .alert-icon {
            background: #C62828;
        }

        .alert-content {
            flex: 1;
            font-size: 13px;
            font-weight: 500;
        }

        .alert-success .alert-content {
            color: #1B5E20;
        }

        .alert-error .alert-content {
            color: #B71C1C;
        }

        .alert-close {
            cursor: pointer;
            font-size: 14px;
            color: var(--gray-600);
            opacity: 0.6;
            transition: opacity 0.3s;
        }

        .alert-close:hover {
            opacity: 1;
        }

        /* ===== نموذج العميل ===== */
        .customer-form {
            background: white;
            border-radius: 6px;
            padding: 15px;
            border: 1px solid var(--gray-200);
        }

        .form-title {
            font-size: 15px;
            font-weight: bold;
            color: var(--primary-dark);
            margin-bottom: 15px;
            padding-bottom: 8px;
            border-bottom: 1px solid var(--gray-200);
            display: flex;
            align-items: center;
            gap: 6px;
        }

        .form-group {
            margin-bottom: 12px;
        }

        .form-group label {
            display: block;
            margin-bottom: 4px;
            font-size: 12px;
            color: var(--gray-600);
        }

        .form-control {
            width: 100%;
            height: 40px;
            padding: 0 10px;
            border: 1px solid var(--gray-300);
            border-radius: 6px;
            font-size: 13px;
            transition: all 0.3s;
            background: white;
        }

        .form-control:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(79, 111, 143, 0.1);
        }

        /* ===== أزرار النموذج ===== */
        .form-actions {
            display: flex;
            gap: 8px;
            margin-top: 15px;
        }

        .btn {
            height: 40px;
            padding: 0 15px;
            border: none;
            border-radius: 6px;
            font-size: 13px;
            font-weight: 500;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 6px;
            transition: all 0.3s;
            flex: 1;
        }

        .btn-primary {
            background: var(--primary);
            color: white;
        }

        .btn-primary:hover:not(:disabled) {
            background: var(--primary-dark);
        }

        .btn-success {
            background: var(--success);
            color: white;
        }

        .btn-success:hover:not(:disabled) {
            background: #3d8b40;
        }

        .btn-danger {
            background: var(--danger);
            color: white;
        }

        .btn-danger:hover:not(:disabled) {
            background: #d32f2f;
        }

        .btn-warning {
            background: var(--warning);
            color: white;
        }

        .btn-outline {
            background: white;
            border: 1px solid var(--gray-300);
            color: var(--gray-700);
        }

        .btn-outline:hover {
            background: var(--gray-100);
        }

        .btn:disabled {
            opacity: 0.5;
            cursor: not-allowed;
        }

        /* ===== بطاقة معلومات العميل ===== */
        .customer-info-card {
            background: linear-gradient(135deg, #F5F9FF, #ffffff);
            border: 1px solid var(--gray-200);
            border-radius: 6px;
            padding: 15px;
            margin-top: 5px;
        }

        .info-card-title {
            font-size: 13px;
            font-weight: bold;
            color: var(--primary-dark);
            margin-bottom: 10px;
            display: flex;
            align-items: center;
            gap: 5px;
        }

        .info-row {
            display: flex;
            justify-content: space-between;
            margin-bottom: 8px;
            font-size: 13px;
        }

        .info-label {
            color: var(--gray-600);
        }

        .info-value {
            font-weight: bold;
        }

        .info-value.positive {
            color: var(--success);
        }

        .info-value.negative {
            color: var(--danger);
        }

        .info-value.warning {
            color: var(--warning);
        }

        /* ===== الجزء الأيمن - قسم العملاء ===== */
        .customers-list {
            flex: 1;
            background: white;
            border-radius: 6px;
            box-shadow: 0 2px 6px rgba(0,0,0,0.05);
            border: 1px solid var(--gray-200);
            display: flex;
            flex-direction: column;
            overflow: hidden;
            height: 100%;
        }

        /* ===== رأس القائمة ===== */
        .list-header {
            height: 60px;
            padding: 0 15px;
            border-bottom: 1px solid var(--gray-200);
            display: flex;
            align-items: center;
            justify-content: space-between;
            background: white;
            flex-shrink: 0;
        }

        .search-box {
            position: relative;
            width: 250px;
        }

        .search-box input {
            width: 100%;
            height: 38px;
            padding: 0 35px 0 35px;
            border: 1px solid var(--gray-300);
            border-radius: 6px;
            font-size: 13px;
        }

        .search-box .search-icon {
            position: absolute;
            right: 10px;
            top: 50%;
            transform: translateY(-50%);
            color: var(--gray-500);
            font-size: 14px;
        }

        .search-box .clear-icon {
            position: absolute;
            left: 10px;
            top: 50%;
            transform: translateY(-50%);
            color: var(--gray-500);
            font-size: 12px;
            cursor: pointer;
            display: none;
        }

        .search-box input:not(:placeholder-shown) + .clear-icon {
            display: block;
        }

        .header-actions {
            display: flex;
            gap: 8px;
        }

        /* ===== جدول العملاء ===== */
        .table-container {
            flex: 1;
            overflow-y: auto;
            padding: 0;
            height: calc(100% - 60px);
        }

        .customers-table {
            width: 100%;
            border-collapse: collapse;
            min-width: 1000px;
        }

        .customers-table th {
            position: sticky;
            top: 0;
            height: 40px;
            background: var(--primary);
            color: white;
            font-size: 12px;
            font-weight: 600;
            z-index: 10;
            padding: 0 8px;
            white-space: nowrap;
        }

        .customers-table th:first-child {
            border-radius: 0 6px 6px 0;
        }

        .customers-table th:last-child {
            border-radius: 6px 0 0 6px;
        }

        .customers-table td {
            height: 45px;
            border-bottom: 1px solid var(--gray-200);
            font-size: 12px;
            padding: 0 8px;
            white-space: nowrap;
        }

        .customers-table tbody tr {
            transition: background 0.2s;
            cursor: pointer;
        }

        .customers-table tbody tr:hover {
            background: var(--gray-100);
        }

        .customers-table tbody tr.selected {
            background: #E3F2FD;
            border-right: 3px solid var(--primary);
        }

        /* ===== شارات الحالة ===== */
        .status-badge {
            display: inline-block;
            padding: 4px 8px;
            border-radius: 12px;
            font-size: 11px;
            font-weight: bold;
            text-align: center;
            min-width: 50px;
        }

        .status-good {
            background: #C8E6C9;
            color: #2E7D32;
        }

        .status-warning {
            background: #FFF3E0;
            color: #F57C00;
        }

        .status-danger {
            background: #FFEBEE;
            color: #C62828;
        }

        .status-paid {
            background: #C8E6C9;
            color: #2E7D32;
        }

        .status-partial {
            background: #FFF3E0;
            color: #F57C00;
        }

        .status-unpaid {
            background: #FFEBEE;
            color: #C62828;
        }

        /* ===== ألوان الأرصدة ===== */
        .balance-positive {
            color: var(--success);
            font-weight: bold;
        }

        .balance-negative {
            color: var(--danger);
            font-weight: bold;
        }

        .balance-warning {
            color: var(--warning);
            font-weight: bold;
        }

        /* ===== أزرار العمليات ===== */
        .action-btn {
            width: 28px;
            height: 28px;
            border: none;
            border-radius: 4px;
            background: transparent;
            color: var(--gray-600);
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            transition: all 0.2s;
            font-size: 14px;
        }

        .action-btn.payment:hover {
            background: #E3F2FD;
            color: var(--primary);
        }

        .action-btn.edit:hover {
            background: #E8F5E9;
            color: var(--success);
        }

        .action-btn.delete:hover {
            background: #FFEBEE;
            color: var(--danger);
        }

        /* ===== النافذة المنبثقة ===== */
        .modal {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0,0,0,0.3);
            backdrop-filter: blur(2px);
            display: none;
            align-items: center;
            justify-content: center;
            z-index: 10000;
            animation: fadeIn 0.3s ease;
        }

        .modal.active {
            display: flex;
        }

        .modal-content {
            width: 950px;
            max-width: 950px;
            max-height: 85vh;
            background: white;
            border-radius: 8px;
            box-shadow: 0 8px 24px rgba(0,0,0,0.15);
            overflow: hidden;
            animation: slideUp 0.3s ease;
        }

        .modal-header {
            height: 55px;
            padding: 0 20px;
            border-bottom: 1px solid var(--gray-200);
            display: flex;
            align-items: center;
            justify-content: space-between;
            background: white;
        }

        .modal-header h3 {
            display: flex;
            align-items: center;
            gap: 8px;
            font-size: 16px;
            color: var(--dark);
        }

        .modal-close {
            width: 32px;
            height: 32px;
            border-radius: 6px;
            background: var(--gray-100);
            border: none;
            font-size: 16px;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            color: var(--gray-600);
            transition: all 0.2s;
        }

        .modal-close:hover {
            background: #FFEBEE;
            color: var(--danger);
        }

        .modal-body {
            padding: 20px;
            overflow-y: auto;
            max-height: calc(85vh - 55px);
        }

        /* ===== بطاقة ملخص العميل ===== */
        .summary-card {
            background: #FFF9C4;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            border-right: 4px solid #FBC02D;
        }

        .summary-title {
            font-size: 13px;
            color: #5D4037;
            margin-bottom: 5px;
        }

        .summary-amount {
            font-size: 24px;
            font-weight: bold;
            color: #5D4037;
        }

        .summary-small {
            font-size: 12px;
            color: #8D6E63;
            margin-top: 5px;
        }

        /* ===== جدول الفواتير في النافذة ===== */
        .invoices-table {
            width: 100%;
            border-collapse: collapse;
            font-size: 12px;
        }

        .invoices-table th {
            background: var(--gray-100);
            color: var(--gray-700);
            font-weight: 600;
            padding: 10px 5px;
            border-bottom: 2px solid var(--gray-300);
        }

        .invoices-table td {
            padding: 8px 5px;
            border-bottom: 1px solid var(--gray-200);
        }

        .products-list {
            font-size: 10px;
            color: var(--gray-600);
            line-height: 1.4;
        }

        .products-list span {
            display: block;
        }

        .partial-info {
            font-size: 10px;
            color: var(--warning);
            font-weight: bold;
        }

        .date-cell {
            position: relative;
        }

        .hijri-date {
            font-size: 9px;
            color: var(--success);
            margin-top: 2px;
        }

        /* ===== شريط التمرير ===== */
        ::-webkit-scrollbar {
            width: 6px;
            height: 6px;
        }

        ::-webkit-scrollbar-track {
            background: var(--gray-100);
            border-radius: 3px;
        }

        ::-webkit-scrollbar-thumb {
            background: var(--gray-400);
            border-radius: 3px;
        }

        ::-webkit-scrollbar-thumb:hover {
            background: var(--gray-500);
        }

        /* ===== تحميل ===== */
        .loading-overlay {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0,0,0,0.3);
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 20000;
        }

        .loading-spinner {
            background: white;
            padding: 20px 30px;
            border-radius: 8px;
            text-align: center;
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        }

        .spinner {
            width: 36px;
            height: 36px;
            border: 3px solid var(--gray-200);
            border-top: 3px solid var(--primary);
            border-radius: 50%;
            animation: spin 1s linear infinite;
            margin: 0 auto 8px;
        }

        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }

        @keyframes slideDown {
            from { transform: translateY(-100%); opacity: 0; }
            to { transform: translateY(0); opacity: 1; }
        }

        @keyframes slideUp {
            from { transform: translateY(30px); opacity: 0; }
            to { transform: translateY(0); opacity: 1; }
        }

        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }

        /* ===== أدوات التصفية ===== */
        .filter-toolbar {
            background: white;
            padding: 12px 15px;
            border-bottom: 1px solid var(--gray-200);
            display: flex;
            gap: 10px;
            align-items: center;
        }

        .filter-group {
            display: flex;
            align-items: center;
            gap: 5px;
        }

        .filter-group label {
            font-size: 12px;
            color: var(--gray-600);
        }

        .filter-input {
            height: 32px;
            padding: 0 8px;
            border: 1px solid var(--gray-300);
            border-radius: 4px;
            font-size: 12px;
        }

        .filter-btn {
            height: 32px;
            padding: 0 12px;
            background: var(--primary);
            color: white;
            border: none;
            border-radius: 4px;
            font-size: 12px;
            cursor: pointer;
        }

        .filter-btn:hover {
            background: var(--primary-dark);
        }

        /* ===== إحصائيات سريعة ===== */
        .stats-row {
            display: flex;
            gap: 10px;
            margin-bottom: 15px;
        }

        .stat-box {
            flex: 1;
            background: white;
            border: 1px solid var(--gray-200);
            border-radius: 6px;
            padding: 12px;
            text-align: center;
        }

        .stat-label {
            font-size: 11px;
            color: var(--gray-600);
            margin-bottom: 4px;
        }

        .stat-value {
            font-size: 16px;
            font-weight: bold;
        }

        .stat-value.primary {
            color: var(--primary);
        }

        .stat-value.success {
            color: var(--success);
        }

        .stat-value.warning {
            color: var(--warning);
        }

        .stat-value.danger {
            color: var(--danger);
        }

    </style>
    
</head>
<body>
    <!-- نظام الحماية -->
<script src="<?= BASE_URL ?>/assets/js/security.js?v=<?= time() ?>"></script>
    <div class="customers-page">
        <!-- ===== الجزء الأيسر: لوحة التحكم ===== -->
        <div class="customers-control-panel">
            <!-- منطقة الرسائل -->
            <div class="alerts-area" id="alertsArea"></div>

            <!-- نموذج إضافة/تحديث العميل -->
            <div class="customer-form">
                <div class="form-title">
                    <span>👤</span>
                    <span>بيانات العميل</span>
                </div>

                <div class="form-group">
                    <label>👤 اسم العميل <span style="color: var(--danger);">*</span></label>
                    <input type="text" class="form-control" id="customerName" placeholder="أدخل اسم العميل">
                </div>

                <div class="form-group">
                    <label>📞 رقم الهاتف</label>
                    <input type="text" class="form-control" id="customerPhone" placeholder="05xxxxxxxx">
                </div>

                <div class="form-group">
                    <label>📧 البريد الإلكتروني</label>
                    <input type="email" class="form-control" id="customerEmail" placeholder="example@domain.com">
                </div>

                <div class="form-group">
                    <label>💳 الحد الائتماني <span style="color: var(--danger);">*</span></label>
                    <input type="number" class="form-control" id="customerLimit" value="0" min="0" step="0.01">
                </div>

                <div class="form-group">
                    <label>📅 تاريخ الاستحقاق</label>
                    <input type="date" class="form-control" id="customerDueDate">
                </div>

                <div class="form-actions">
                    <button class="btn btn-primary" id="addCustomerBtn" onclick="addCustomer()">
                        <span>➕</span> إضافة عميل
                    </button>
                    <button class="btn btn-success" id="updateCustomerBtn" style="display: none;" onclick="updateCustomer()">
                        <span>✏️</span> تحديث
                    </button>
                    <button class="btn btn-danger" id="deleteCustomerBtn" style="display: none;" onclick="deleteCustomer()">
                        <span>🗑️</span> حذف
                    </button>
                    <button class="btn btn-outline" id="cancelEditBtn" style="display: none;" onclick="cancelEdit()">
                        <span>✖️</span> إلغاء
                    </button>
                </div>
            </div>

            <!-- بطاقة معلومات العميل المحدد -->
            <div class="customer-info-card" id="customerInfoCard" style="display: none;">
                <div class="info-card-title">
                    <span>📋</span>
                    <span>معلومات العميل المحدد</span>
                </div>
                <div class="info-row">
                    <span class="info-label">💰 الدين الحالي:</span>
                    <span class="info-value negative" id="currentDebt">0.00 ريال</span>
                </div>
                <div class="info-row">
                    <span class="info-label">✨ المتاح:</span>
                    <span class="info-value positive" id="availableCredit">0.00 ريال</span>
                </div>
                <div class="info-row">
                    <span class="info-label">📊 الحالة:</span>
                    <span class="info-value" id="customerStatusBadge"><span class="status-badge status-good">🟢 جيد</span></span>
                </div>
            </div>

            <!-- إحصائيات سريعة -->
            <div class="stats-row">
                <div class="stat-box">
                    <div class="stat-label">إجمالي العملاء</div>
                    <div class="stat-value primary" id="totalCustomers">0</div>
                </div>
                <div class="stat-box">
                    <div class="stat-label">إجمالي الديون</div>
                    <div class="stat-value warning" id="totalDebts">0.00</div>
                </div>
                <div class="stat-box">
                    <div class="stat-label">عملاء تجاوزوا</div>
                    <div class="stat-value danger" id="exceededCustomers">0</div>
                </div>
            </div>
        </div>

        <!-- ===== الجزء الأيمن: قائمة العملاء ===== -->
        <div class="customers-list">
            <!-- رأس القائمة -->
            <div class="list-header">
                <div class="search-box">
                    <span class="search-icon">🔍</span>
                    <input type="text" id="searchInput" placeholder="بحث بالاسم أو الهاتف..." onkeypress="if(event.key==='Enter') searchCustomers()">
                    <span class="clear-icon" onclick="clearSearch()">✖</span>
                </div>
                <div class="header-actions">
                    <button class="btn btn-primary" style="width: auto; padding: 0 15px;" onclick="openPaymentWindow()">
                        <span>💰</span> تسديد دفعات
                    </button>
                    <button class="btn btn-outline" style="width: auto; padding: 0 15px;" onclick="refreshList()">
                        <span>🔄</span> تحديث
                    </button>
                </div>
            </div>

            <!-- شريط التصفية -->
            <div class="filter-toolbar">
                <div class="filter-group">
                    <label>من:</label>
                    <input type="date" class="filter-input" id="dateFrom">
                </div>
                <div class="filter-group">
                    <label>إلى:</label>
                    <input type="date" class="filter-input" id="dateTo">
                </div>
                <button class="filter-btn" onclick="filterByDate()">تصفية</button>
                <button class="filter-btn" style="background: var(--gray-500);" onclick="clearFilter()">إلغاء</button>
            </div>

            <!-- جدول العملاء -->
            <div class="table-container">
                <table class="customers-table">
                    <thead>
                        <tr>
                            <th style="width: 80px;">عمليات</th>
                            <th style="width: 50px;">ID</th>
                            <th>اسم العميل</th>
                            <th>الهاتف</th>
                            <th>المبلغ المسموح</th>
                            <th>تاريخ التسديد</th>
                            <th>الدين الحالي</th>
                            <th>المتاح</th>
                            <th>الحالة</th>
                        </tr>
                    </thead>
                    <tbody id="customersTableBody">
                        <!-- سيتم تعبئتها عبر JavaScript -->
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- ===== نافذة كشف الدين والتسديد ===== -->
    <div class="modal" id="paymentModal">
        <div class="modal-content">
            <div class="modal-header">
                <h3>
                    <span>💰</span>
                    <span id="modalTitle">كشف الدين والتسديد - اسم العميل</span>
                </h3>
                <button class="modal-close" onclick="closePaymentModal()">✖</button>
            </div>
            <div class="modal-body" id="paymentModalBody">
                <!-- محتوى النافذة -->
            </div>
        </div>
    </div>

    <!-- ===== نافذة كشف الحساب ===== -->
    <div class="modal" id="statementModal">
        <div class="modal-content" style="width: 900px;">
            <div class="modal-header">
                <h3>
                    <span>📊</span>
                    <span>كشف حساب العميل</span>
                </h3>
                <button class="modal-close" onclick="closeStatementModal()">✖</button>
            </div>
            <div class="modal-body" id="statementModalBody">
                <!-- محتوى كشف الحساب -->
            </div>
        </div>
    </div>

   <script>
// ============================================
// المتغيرات العامة
// ============================================
const BASE_URL = '<?= BASE_URL ?>';
let selectedCustomerId = null;
let customers = [];
let currentStatistics = null;

// ============================================
// التهيئة
// ============================================
document.addEventListener('DOMContentLoaded', function() {
    loadCustomers();
    loadStatistics();
    
    // ===== البحث المباشر عند الكتابة =====
    const searchInput = document.getElementById('searchInput');
    let searchTimeout;
    
    searchInput.addEventListener('input', function() {
        clearTimeout(searchTimeout);
        const query = this.value.trim();
        
        // البحث بعد 3 أحرف أو أكثر
        if (query.length >= 3) {
            searchTimeout = setTimeout(() => {
                searchCustomers();
            }, 300); // تأخير 300ms لتجنب البحث المتكرر
        } else if (query.length === 0) {
            // إذا كان الحقل فارغاً، عرض كل العملاء
            renderCustomersTable(customers);
        }
    });
    
    // السماح بالبحث عند الضغط على Enter أيضاً
    searchInput.addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            e.preventDefault();
            clearTimeout(searchTimeout);
            searchCustomers();
        }
    });
});

// ============================================
// دوال عرض الرسائل
// ============================================
// ===== عرض الرسائل بشكل واضح =====
function showAlert(type, message, duration = 5000) {
    const area = document.getElementById('alertsArea');
    if (!area) return;
    
    const alertDiv = document.createElement('div');
    alertDiv.className = `alert-message alert-${type}`;
    
    // تخصيص الألوان حسب نوع الرسالة
    let bgColor, borderColor, iconColor, icon;
    
    switch(type) {
        case 'success':
            bgColor = '#d4edda';  // أخضر فاتح
            borderColor = '#28a745';  // أخضر غامق
            iconColor = '#28a745';
            icon = '✅';
            break;
        case 'error':
            bgColor = '#f8d7da';  // أحمر فاتح
            borderColor = '#dc3545';  // أحمر غامق
            iconColor = '#dc3545';
            icon = '❌';
            break;
        case 'warning':
            bgColor = '#fff3cd';  // أصفر فاتح
            borderColor = '#ffc107';  // أصفر غامق
            iconColor = '#ffc107';
            icon = '⚠️';
            break;
        case 'info':
            bgColor = '#d1ecf1';  // أزرق فاتح
            borderColor = '#17a2b8';  // أزرق غامق
            iconColor = '#17a2b8';
            icon = 'ℹ️';
            break;
        default:
            bgColor = '#e2e3e5';  // رمادي فاتح
            borderColor = '#6c757d';  // رمادي غامق
            iconColor = '#6c757d';
            icon = '📢';
    }
    
    alertDiv.style.cssText = `
        height: auto;
        min-height: 60px;
        width: 100%;
        border-radius: 8px;
        display: flex;
        align-items: center;
        padding: 15px 20px;
        gap: 15px;
        animation: slideDown 0.3s ease;
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        background: ${bgColor};
        border-right: 6px solid ${borderColor};
        margin-bottom: 12px;
        direction: rtl;
    `;
    
    alertDiv.innerHTML = `
        <div style="
            width: 32px;
            height: 32px;
            border-radius: 50%;
            background: ${borderColor};
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 18px;
            font-weight: bold;
            box-shadow: 0 2px 5px rgba(0,0,0,0.2);
        ">${icon}</div>
        <div style="
            flex: 1;
            font-size: 15px;
            font-weight: 600;
            color: #000000;
            line-height: 1.5;
            text-shadow: 0 1px 1px rgba(255,255,255,0.5);
        ">${message}</div>
        <div style="
            width: 28px;
            height: 28px;
            border-radius: 50%;
            background: rgba(0,0,0,0.1);
            color: #333;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 16px;
            cursor: pointer;
            transition: all 0.2s;
            font-weight: bold;
        " onclick="this.parentElement.remove()">✖</div>
    `;
    
    area.appendChild(alertDiv);
    
    // إضافة تأثير التمرير
    alertDiv.addEventListener('mouseenter', () => {
        alertDiv.style.transform = 'scale(1.02)';
        alertDiv.style.boxShadow = '0 6px 16px rgba(0,0,0,0.2)';
    });
    
    alertDiv.addEventListener('mouseleave', () => {
        alertDiv.style.transform = 'scale(1)';
        alertDiv.style.boxShadow = '0 4px 12px rgba(0,0,0,0.15)';
    });
    
    // إخفاء تلقائي بعد المدة المحددة
    setTimeout(() => {
        if (alertDiv.parentElement) {
            alertDiv.style.animation = 'slideOut 0.3s ease';
            alertDiv.style.transform = 'translateX(-100%)';
            setTimeout(() => {
                if (alertDiv.parentElement) alertDiv.remove();
            }, 300);
        }
    }, duration);
}

// أضف هذه الحركة في نهاية الـ Style
const style = document.createElement('style');
style.textContent = `
    @keyframes slideOut {
        from {
            transform: translateX(0);
            opacity: 1;
        }
        to {
            transform: translateX(-100%);
            opacity: 0;
        }
    }
`;
document.head.appendChild(style);
function showLoading(show, message = 'جاري التحميل...') {
    let overlay = document.getElementById('loadingOverlay');
    
    if (show) {
        if (!overlay) {
            overlay = document.createElement('div');
            overlay.id = 'loadingOverlay';
            overlay.className = 'loading-overlay';
            
            const spinner = document.createElement('div');
            spinner.className = 'loading-spinner';
            spinner.innerHTML = `
                <div class="spinner"></div>
                <div id="loadingMessage">${message}</div>
            `;
            
            overlay.appendChild(spinner);
            document.body.appendChild(overlay);
        } else {
            document.getElementById('loadingMessage').textContent = message;
        }
    } else if (overlay) {
        overlay.remove();
    }
}

// ============================================
// دوال تحميل البيانات
// ============================================
function loadCustomers() {
    showLoading(true, 'جاري تحميل العملاء...');
    
    fetch(BASE_URL + '/customers/get-all')
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(data => {
            showLoading(false);
            if (data.success) {
                customers = data.data;
                renderCustomersTable(customers);
            } else {
                showAlert('error', data.message || 'فشل تحميل العملاء');
            }
        })
        .catch(error => {
            showLoading(false);
            console.error('Load error:', error);
            showAlert('error', 'حدث خطأ في الاتصال بالخادم');
        });
}

function loadStatistics() {
    fetch(BASE_URL + '/customers/get-statistics')
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                currentStatistics = data.data;
                document.getElementById('totalCustomers').textContent = data.data.total_customers || 0;
                document.getElementById('totalDebts').textContent = (data.data.total_debts || 0).toFixed(2);
                document.getElementById('exceededCustomers').textContent = data.data.exceeded_customers || 0;
            }
        })
        .catch(error => console.error('Stats error:', error));
}

// ============================================
// دوال عرض الجدول
// ============================================
function renderCustomersTable(customersList) {
    const tbody = document.getElementById('customersTableBody');
    tbody.innerHTML = '';
    
    customersList.forEach(customer => {
        const available = customer.credit_limit - customer.current_balance;
        const availableClass = available >= 0 ? 'balance-positive' : 'balance-negative';
        
        let statusClass = 'status-good';
        let statusText = '🟢 جيد';
        
        if (available <= 0) {
            statusClass = 'status-danger';
            statusText = '🔴 تجاوز';
        } else if (available < customer.credit_limit * 0.5) {
            statusClass = 'status-warning';
            statusText = '🟡 متوسط';
        }
        
        const row = document.createElement('tr');
        row.setAttribute('data-id', customer.id);
        row.onclick = () => selectCustomer(customer.id);
        
        row.innerHTML = `
            <td>
                <button class="action-btn payment" onclick="event.stopPropagation(); openPaymentWindow(${customer.id})" title="تسديد">
                    <span>💰</span>
                </button>
                <button class="action-btn" onclick="event.stopPropagation(); openStatementWindow(${customer.id})" title="كشف حساب">
                    <span>📊</span>
                </button>
            </td>
            <td>#${customer.id}</td>
            <td>${customer.name}</td>
            <td>${customer.phone || '-'}</td>
            <td>${Number(customer.credit_limit).toFixed(2)} ريال</td>
            <td>${customer.payment_due_date || '-'}</td>
            <td class="balance-negative">${Number(customer.current_balance).toFixed(2)} ريال</td>
            <td class="${availableClass}">${available.toFixed(2)} ريال</td>
            <td><span class="status-badge ${statusClass}">${statusText}</span></td>
        `;
        
        tbody.appendChild(row);
    });
}

// ============================================
// دوال اختيار العميل
// ============================================
function selectCustomer(id) {
    document.querySelectorAll('#customersTableBody tr').forEach(row => {
        row.classList.remove('selected');
    });
    
    const selectedRow = document.querySelector(`#customersTableBody tr[data-id="${id}"]`);
    if (selectedRow) {
        selectedRow.classList.add('selected');
    }
    
    selectedCustomerId = id;
    
    fetch(BASE_URL + '/customers/get-customer-data?id=' + id)
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                fillCustomerForm(data.data.customer);
                showCustomerInfo(data.data.customer, data.data.summary);
                
                document.getElementById('addCustomerBtn').style.display = 'none';
                document.getElementById('updateCustomerBtn').style.display = 'flex';
                document.getElementById('deleteCustomerBtn').style.display = 'flex';
                document.getElementById('cancelEditBtn').style.display = 'flex';
            }
        })
        .catch(error => console.error('Select error:', error));
}

function fillCustomerForm(customer) {
    document.getElementById('customerName').value = customer.name || '';
    document.getElementById('customerPhone').value = customer.phone || '';
    document.getElementById('customerEmail').value = customer.email || '';
    document.getElementById('customerLimit').value = customer.credit_limit || 0;
    document.getElementById('customerDueDate').value = customer.payment_due_date || '';
}

function showCustomerInfo(customer, summary) {
    const card = document.getElementById('customerInfoCard');
    card.style.display = 'block';
    
    document.getElementById('currentDebt').textContent = Number(customer.current_balance).toFixed(2) + ' ريال';
    
    const available = customer.credit_limit - customer.current_balance;
    document.getElementById('availableCredit').textContent = available.toFixed(2) + ' ريال';
    
    let statusClass = 'status-good';
    let statusText = '🟢 جيد';
    
    if (available <= 0) {
        statusClass = 'status-danger';
        statusText = '🔴 تجاوز';
    } else if (available < customer.credit_limit * 0.5) {
        statusClass = 'status-warning';
        statusText = '🟡 متوسط';
    }
    
    document.getElementById('customerStatusBadge').innerHTML = `<span class="status-badge ${statusClass}">${statusText}</span>`;
}

function cancelEdit() {
    selectedCustomerId = null;
    document.getElementById('customerName').value = '';
    document.getElementById('customerPhone').value = '';
    document.getElementById('customerEmail').value = '';
    document.getElementById('customerLimit').value = 0;
    document.getElementById('customerDueDate').value = '';
    
    document.getElementById('customerInfoCard').style.display = 'none';
    
    document.getElementById('addCustomerBtn').style.display = 'flex';
    document.getElementById('updateCustomerBtn').style.display = 'none';
    document.getElementById('deleteCustomerBtn').style.display = 'none';
    document.getElementById('cancelEditBtn').style.display = 'none';
    
    document.querySelectorAll('#customersTableBody tr').forEach(row => {
        row.classList.remove('selected');
    });
}

// ============================================
// دوال إضافة/تحديث/حذف العميل
// ============================================
function addCustomer() {
    const name = document.getElementById('customerName').value.trim();
    const limit = document.getElementById('customerLimit').value;
    
    if (!name) {
        showAlert('error', 'اسم العميل مطلوب');
        return;
    }
    
    if (!limit || limit < 0) {
        showAlert('error', 'الحد الائتماني يجب أن يكون 0 أو أكثر');
        return;
    }
    
    const data = {
        name: name,
        phone: document.getElementById('customerPhone').value.trim(),
        email: document.getElementById('customerEmail').value.trim(),
        credit_limit: limit,
        payment_due_date: document.getElementById('customerDueDate').value || null
    };
    
    showLoading(true, 'جاري إضافة العميل...');
    
    fetch(BASE_URL + '/customers/add', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify(data)
    })
    .then(response => response.json())
    .then(result => {
        showLoading(false);
        if (result.success) {
            showAlert('success', '✅ تم إضافة العميل بنجاح');
            cancelEdit();
            loadCustomers();
            loadStatistics();
        } else {
            showAlert('error', result.message || 'فشل إضافة العميل');
        }
    })
    .catch(error => {
        showLoading(false);
        console.error('Add error:', error);
        showAlert('error', 'حدث خطأ في الاتصال بالخادم');
    });
}

function updateCustomer() {
    if (!selectedCustomerId) return;
    
    const name = document.getElementById('customerName').value.trim();
    const limit = document.getElementById('customerLimit').value;
    
    if (!name) {
        showAlert('error', 'اسم العميل مطلوب');
        return;
    }
    
    const data = {
        id: selectedCustomerId,
        name: name,
        phone: document.getElementById('customerPhone').value.trim(),
        email: document.getElementById('customerEmail').value.trim(),
        credit_limit: limit,
        payment_due_date: document.getElementById('customerDueDate').value || null
    };
    
    showLoading(true, 'جاري تحديث البيانات...');
    
    fetch(BASE_URL + '/customers/update', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify(data)
    })
    .then(response => response.json())
    .then(result => {
        showLoading(false);
        if (result.success) {
            showAlert('success', '✅ تم تحديث البيانات بنجاح');
            cancelEdit();
            loadCustomers();
            loadStatistics();
        } else {
            showAlert('error', result.message || 'فشل تحديث البيانات');
        }
    })
    .catch(error => {
        showLoading(false);
        console.error('Update error:', error);
        showAlert('error', 'حدث خطأ في الاتصال بالخادم');
    });
}

// ===== حذف عميل مع التحقق =====
function deleteCustomer() {
    if (!selectedCustomerId) return;
    
    // التحقق من وجود ديون أولاً (طلب الخادم)
    showLoading(true, 'جاري التحقق من بيانات العميل...');
    
    fetch(BASE_URL + '/customers/check-balance?id=' + selectedCustomerId)
        .then(response => response.json())
        .then(data => {
            showLoading(false);
            
            if (data.has_debt) {
                showAlert('error', `❌ لا يمكن حذف العميل لأنه مدين بمبلغ ${data.balance} ريال`);
                return;
            }
            
            if (data.has_unpaid_invoices) {
                showAlert('error', `❌ لا يمكن حذف العميل لأنه لديه ${data.invoices_count} فواتير غير مسددة`);
                return;
            }
            
            // إذا لم يكن عليه ديون، نطلب التأكيد
            if (confirm('هل أنت متأكد من حذف هذا العميل؟')) {
                proceedWithDelete();
            }
        })
        .catch(error => {
            showLoading(false);
            console.error('Check balance error:', error);
            // في حالة الخطأ، نكمل بحذر
            if (confirm('تعذر التحقق من الرصيد. هل أنت متأكد من حذف العميل؟')) {
                proceedWithDelete();
            }
        });
}

// ===== متابعة عملية الحذف بعد التحقق =====
function proceedWithDelete() {
    showLoading(true, 'جاري حذف العميل...');
    
    fetch(BASE_URL + '/customers/delete?id=' + selectedCustomerId, {
        method: 'DELETE'
    })
    .then(response => response.json())
    .then(result => {
        showLoading(false);
        if (result.success) {
            showAlert('success', '✅ تم حذف العميل بنجاح');
            cancelEdit();
            loadCustomers();
            loadStatistics();
        } else {
            showAlert('error', result.message || 'فشل حذف العميل');
        }
    })
    .catch(error => {
        showLoading(false);
        console.error('Delete error:', error);
        showAlert('error', 'حدث خطأ في الاتصال بالخادم');
    });
}

// ============================================
// دوال البحث والتصفية
// ============================================

// ===== البحث المباشر في الجدول (يعمل بالاسم والهاتف) =====
function searchCustomers() {
    const query = document.getElementById('searchInput').value.trim().toLowerCase();
    
    if (query.length < 1) {
        renderCustomersTable(customers);
        return;
    }
    
    // فلترة العملاء بناءً على الاسم أو رقم الهاتف
    const filtered = customers.filter(customer => {
        const name = (customer.name || '').toLowerCase();
        const phone = (customer.phone || '').toLowerCase();
        
        // البحث في الاسم والهاتف
        return name.includes(query) || phone.includes(query);
    });
    
    // ترتيب النتائج حسب الأولوية:
    // 1. التطابق التام مع الاسم
    // 2. الاسم يبدأ بـ query
    // 3. الاسم يحتوي على query
    // 4. الهاتف يبدأ بـ query
    // 5. الهاتف يحتوي على query
    filtered.sort((a, b) => {
        const aName = (a.name || '').toLowerCase();
        const bName = (b.name || '').toLowerCase();
        const aPhone = (a.phone || '').toLowerCase();
        const bPhone = (b.phone || '').toLowerCase();
        
        // حساب درجة التطابق لكل عميل
        const aScore = getMatchScore(aName, aPhone, query);
        const bScore = getMatchScore(bName, bPhone, query);
        
        return bScore - aScore; // ترتيب تنازلي (الأعلى أولاً)
    });
    
    renderCustomersTable(filtered);
    
    // إظهار عدد النتائج
    if (filtered.length === 0) {
        showAlert('info', 'لا توجد نتائج للبحث', 2000);
    } else {
        console.log(`🔍 تم العثور على ${filtered.length} نتيجة`);
    }
}

// ===== حساب درجة تطابق البحث =====
function getMatchScore(name, phone, query) {
    let score = 0;
    
    // التطابق التام مع الاسم (أعلى درجة)
    if (name === query) {
        score += 100;
    }
    // الاسم يبدأ بـ query
    else if (name.startsWith(query)) {
        score += 80;
    }
    // الاسم يحتوي على query
    else if (name.includes(query)) {
        score += 60;
    }
    
    // التطابق التام مع الهاتف
    if (phone === query) {
        score += 50;
    }
    // الهاتف يبدأ بـ query
    else if (phone.startsWith(query)) {
        score += 40;
    }
    // الهاتف يحتوي على query
    else if (phone.includes(query)) {
        score += 20;
    }
    
    return score;
}
function clearSearch() {
    document.getElementById('searchInput').value = '';
    renderCustomersTable(customers);
}

function filterByDate() {
    const from = document.getElementById('dateFrom').value;
    const to = document.getElementById('dateTo').value;
    
    if (!from || !to) {
        showAlert('error', 'الرجاء اختيار التاريخ من وإلى');
        return;
    }
    
    showLoading(true, 'جاري التصفية...');
    
    fetch(BASE_URL + '/customers/filter-by-date?from=' + from + '&to=' + to)
        .then(response => response.json())
        .then(data => {
            showLoading(false);
            if (data.success) {
                renderCustomersTable(data.data);
            } else {
                showAlert('error', data.message || 'فشل التصفية');
            }
        })
        .catch(error => {
            showLoading(false);
            console.error('Filter error:', error);
            showAlert('error', 'حدث خطأ في الاتصال بالخادم');
        });
}

function clearFilter() {
    document.getElementById('dateFrom').value = '';
    document.getElementById('dateTo').value = '';
    renderCustomersTable(customers);
}

function refreshList() {
    loadCustomers();
}

// ============================================
// دوال نافذة التسديد
// ============================================
function openPaymentWindow(customerId = null) {
    const modal = document.getElementById('paymentModal');
    const body = document.getElementById('paymentModalBody');
    
    if (customerId) {
        selectCustomer(customerId);
    }
    
    if (!selectedCustomerId) {
        showAlert('error', 'الرجاء اختيار عميل أولاً');
        return;
    }
    
    showLoading(true, 'جاري تحميل بيانات العميل...');
    
    fetch(BASE_URL + '/customers/get-customer-data?id=' + selectedCustomerId)
        .then(response => response.json())
        .then(data => {
            showLoading(false);
            
            if (data.success) {
                const customer = data.data.customer;
                const invoices = data.data.invoices.filter(inv => inv.remaining_amount > 0);
                
                document.getElementById('modalTitle').textContent = `كشف الدين والتسديد - ${customer.name}`;
                
                let invoicesHtml = '';
                invoices.forEach(inv => {
                    const products = inv.products ? inv.products.split('||').map(p => `<span>• ${p}</span>`).join('') : '-';
                    
                    let statusClass = 'status-unpaid';
                    let statusText = '🔴 غير مسدد';
                    
                    if (inv.remaining_amount <= 0) {
                        statusClass = 'status-paid';
                        statusText = '🟢 مسدد';
                    } else if (inv.paid_amount > 0) {
                        statusClass = 'status-partial';
                        statusText = '🟡 جزئي';
                    }
                    
                    invoicesHtml += `
                        <tr>
                            <td><input type="checkbox" class="invoice-checkbox" data-id="${inv.id}" data-remaining="${inv.remaining_amount}" onchange="updatePaymentSummary()"></td>
                            <td>${inv.invoice_number}</td>
                            <td><div class="products-list">${products}</div></td>
                            <td>${Number(inv.total_amount).toFixed(2)}</td>
                            <td>${Number(inv.paid_amount).toFixed(2)} (${((inv.paid_amount/inv.total_amount)*100).toFixed(1)}%)</td>
                            <td class="balance-negative">${Number(inv.remaining_amount).toFixed(2)} ريال</td>
                            <td>${inv.paid_amount > 0 ? 'مدفوع: ' + Number(inv.paid_amount).toFixed(2) : '-'}</td>
                            <td class="date-cell">
                                ${new Date(inv.created_at).toLocaleDateString('en-CA')}
                                <div class="hijri-date">هـ</div>
                            </td>
                            <td><span class="status-badge ${statusClass}">${statusText}</span></td>
                        </tr>
                    `;
                });
                
                body.innerHTML = `
                    <div class="summary-card">
                        <div class="summary-title">💰 إجمالي الدين الحالي</div>
                        <div class="summary-amount">${Number(customer.current_balance).toFixed(2)} ريال</div>
                        <div class="summary-small">الحد الائتماني: ${Number(customer.credit_limit).toFixed(2)} ريال</div>
                    </div>
                    
                    <h4 style="margin: 15px 0 10px;">📋 الفواتير غير المسددة</h4>
                    
                    <div style="overflow-x: auto; max-height: 400px; border: 1px solid var(--gray-200); border-radius: 6px;">
                        <table class="invoices-table">
                            <thead>
                                <tr>
                                    <th style="width: 30px;"><input type="checkbox" id="selectAllInvoices" onchange="toggleSelectAll()"></th>
                                    <th>رقم الفاتورة</th>
                                    <th>المنتجات</th>
                                    <th>الإجمالي</th>
                                    <th>المدفوع</th>
                                    <th>المتبقي</th>
                                    <th>المبلغ الجزئي</th>
                                    <th>التاريخ</th>
                                    <th>الحالة</th>
                                </tr>
                            </thead>
                            <tbody>
                                ${invoicesHtml || '<tr><td colspan="9" style="text-align: center; padding: 30px;">لا توجد فواتير غير مسددة</td></tr>'}
                            </tbody>
                        </table>
                    </div>
                    
                    <div style="margin-top: 20px; background: var(--gray-100); padding: 15px; border-radius: 6px;">
                        <div style="display: flex; justify-content: space-between; margin-bottom: 10px;">
                            <span>إجمالي جميع الفواتير: <strong id="totalAllInvoices">${Number(customer.current_balance).toFixed(2)} ريال</strong></span>
                            <span>إجمالي الفواتير المحددة: <strong id="totalSelectedInvoices" class="balance-positive">0.00 ريال</strong></span>
                        </div>
                        
                        <div style="display: flex; gap: 10px; align-items: flex-end;">
                            <div style="flex: 1;">
                                <label style="font-size: 12px; color: var(--gray-600);">💰 المبلغ المراد تسديده</label>
                                <input type="number" id="paymentAmount" class="form-control" value="0" min="0" step="0.01" style="height: 45px;">
                                <small style="color: var(--gray-500);">أدخل المبلغ المراد تسديده للفواتير المحددة ✅</small>
                            </div>
                            <button class="btn btn-success" style="height: 45px; width: 150px;" onclick="processPayment()">
                                <span>✅</span> تسديد المبلغ
                            </button>
                            <button class="btn btn-outline" style="height: 45px; width: 100px;" onclick="closePaymentModal()">
                                <span>❌</span> إلغاء
                            </button>
                        </div>
                    </div>
                `;
                
                modal.classList.add('active');
            }
        })
        .catch(error => {
            showLoading(false);
            console.error('Payment window error:', error);
            showAlert('error', 'حدث خطأ في تحميل البيانات');
        });
}

function closePaymentModal() {
    document.getElementById('paymentModal').classList.remove('active');
}

function toggleSelectAll() {
    const selectAll = document.getElementById('selectAllInvoices').checked;
    document.querySelectorAll('.invoice-checkbox').forEach(cb => cb.checked = selectAll);
    updatePaymentSummary();
}

function updatePaymentSummary() {
    let total = 0;
    document.querySelectorAll('.invoice-checkbox:checked').forEach(cb => {
        total += parseFloat(cb.dataset.remaining);
    });
    
    document.getElementById('totalSelectedInvoices').textContent = total.toFixed(2) + ' ريال';
    document.getElementById('paymentAmount').value = total.toFixed(2);
    document.getElementById('paymentAmount').max = total;
}

function processPayment() {
    const amount = parseFloat(document.getElementById('paymentAmount').value);
    const selectedInvoices = [];
    
    document.querySelectorAll('.invoice-checkbox:checked').forEach(cb => {
        selectedInvoices.push({
            id: cb.dataset.id,
            remaining: parseFloat(cb.dataset.remaining)
        });
    });
    
    if (selectedInvoices.length === 0) {
        showAlert('error', 'الرجاء اختيار فواتير للتسديد');
        return;
    }
    
    if (amount <= 0) {
        showAlert('error', 'المبلغ يجب أن يكون أكبر من 0');
        return;
    }
    
    if (amount > selectedInvoices.reduce((sum, inv) => sum + inv.remaining, 0)) {
        showAlert('error', 'المبلغ أكبر من إجمالي الفواتير المحددة');
        return;
    }
    
    const data = {
        customer_id: selectedCustomerId,
        amount: amount,
        invoices: selectedInvoices.map(inv => inv.id)
    };
    
    showLoading(true, 'جاري معالجة الدفعة...');
    
    fetch(BASE_URL + '/customers/process-payment', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify(data)
    })
    .then(response => response.json())
    .then(result => {
        showLoading(false);
        if (result.success) {
            showAlert('success', `✅ تم تسديد المبلغ بنجاح`);
            closePaymentModal();
            loadCustomers();
            loadStatistics();
        } else {
            showAlert('error', result.message || 'فشل عملية التسديد');
        }
    })
    .catch(error => {
        showLoading(false);
        console.error('Payment error:', error);
        showAlert('error', 'حدث خطأ في الاتصال بالخادم');
    });
}

// ============================================
// دوال كشف الحساب (محدثة مع حل مشكلة الطباعة)
// ============================================
function openStatementWindow(customerId) {
    selectCustomer(customerId);
    
    if (!selectedCustomerId) {
        showAlert('error', 'الرجاء اختيار عميل أولاً');
        return;
    }
    
    const modal = document.getElementById('statementModal');
    const body = document.getElementById('statementModalBody');
    
    const from = document.getElementById('dateFrom').value || new Date(new Date().getFullYear(), new Date().getMonth(), 1).toISOString().split('T')[0];
    const to = document.getElementById('dateTo').value || new Date().toISOString().split('T')[0];
    
    showLoading(true, 'جاري إنشاء كشف الحساب...');
    
    fetch(BASE_URL + '/customers/generate-statement', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({
            customer_id: selectedCustomerId,
            date_from: from,
            date_to: to,
            type: 'all'
        })
    })
    .then(response => response.json())
    .then(data => {
        showLoading(false);
        
        if (data.success) {
            displayStatement(data.data);
            modal.classList.add('active');
        } else {
            showAlert('error', data.message || 'فشل إنشاء كشف الحساب');
        }
    })
    .catch(error => {
        showLoading(false);
        console.error('Statement error:', error);
        showAlert('error', 'حدث خطأ في الاتصال بالخادم');
    });
}

function displayStatement(data) {
    const body = document.getElementById('statementModalBody');
    const customer = data.customer;
    const transactions = data.transactions;
    const summary = data.summary;
    
    let transactionsHtml = '';
    transactions.forEach(trans => {
        const typeClass = trans.transaction_type === 'invoice' ? 'invoice' : 
                         (trans.transaction_type === 'payment' ? 'payment' : 'return');
        const typeText = trans.transaction_type === 'invoice' ? 'فاتورة' : 
                        (trans.transaction_type === 'payment' ? 'دفعة' : 'مرتجع');
        
        transactionsHtml += `
            <tr class="${typeClass}">
                <td>${new Date(trans.transaction_date).toLocaleDateString('en-CA')}</td>
                <td>${typeText}</td>
                <td>${trans.invoice_number || '-'}</td>
                <td>${trans.debit > 0 ? Number(trans.debit).toFixed(2) + ' ريال' : '-'}</td>
                <td>${trans.credit > 0 ? Number(trans.credit).toFixed(2) + ' ريال' : '-'}</td>
                <td class="balance-${trans.running_balance >= 0 ? 'positive' : 'negative'}">${Number(trans.running_balance).toFixed(2)} ريال</td>
            </tr>
        `;
    });
    
    body.innerHTML = `
        <div style="padding: 5px;">
            <!-- رأس كشف الحساب -->
            <div style="text-align: center; margin-bottom: 20px; border-bottom: 2px solid #4F6F8F; padding-bottom: 10px;">
                <h2 style="margin: 0; color: #4F6F8F;">كشف حساب العميل</h2>
                <h3 style="margin: 5px 0; color: #333;">${customer.name}</h3>
                <p style="margin: 0; color: #666; font-size: 13px;">من ${data.date_from} إلى ${data.date_to}</p>
            </div>
            
            <!-- معلومات العميل -->
            <div style="background: #f5f5f5; padding: 15px; border-radius: 6px; margin-bottom: 20px; display: flex; flex-wrap: wrap; gap: 15px;">
                <div style="flex: 1; min-width: 200px;">
                    <strong style="color: #4F6F8F;">📞 الهاتف:</strong> ${customer.phone || '-'}
                </div>
                <div style="flex: 1; min-width: 200px;">
                    <strong style="color: #4F6F8F;">📧 البريد:</strong> ${customer.email || '-'}
                </div>
                <div style="flex: 1; min-width: 200px;">
                    <strong style="color: #4F6F8F;">💳 الحد الائتماني:</strong> ${Number(customer.credit_limit).toFixed(2)} ريال
                </div>
                <div style="flex: 1; min-width: 200px;">
                    <strong style="color: #4F6F8F;">💰 الرصيد الحالي:</strong> ${Number(customer.current_balance).toFixed(2)} ريال
                </div>
            </div>
            
            <!-- ملخص الإحصائيات -->
            <div style="display: flex; gap: 10px; margin-bottom: 20px; flex-wrap: wrap;">
                <div style="flex: 1; min-width: 150px; padding: 15px; border-radius: 6px; background: #e8f5e9; text-align: center;">
                    <div style="font-size: 12px; color: #2E7D32;">إجمالي المشتريات</div>
                    <strong style="font-size: 16px; color: #2E7D32;">${summary.total_invoices.toFixed(2)} ريال</strong>
                </div>
                <div style="flex: 1; min-width: 150px; padding: 15px; border-radius: 6px; background: #e3f2fd; text-align: center;">
                    <div style="font-size: 12px; color: #1565C0;">إجمالي المدفوعات</div>
                    <strong style="font-size: 16px; color: #1565C0;">${summary.total_payments.toFixed(2)} ريال</strong>
                </div>
                <div style="flex: 1; min-width: 150px; padding: 15px; border-radius: 6px; background: #fff3e0; text-align: center;">
                    <div style="font-size: 12px; color: #E65100;">إجمالي المرتجعات</div>
                    <strong style="font-size: 16px; color: #E65100;">${summary.total_returns.toFixed(2)} ريال</strong>
                </div>
                <div style="flex: 1; min-width: 150px; padding: 15px; border-radius: 6px; background: ${summary.final_balance >= 0 ? '#e8f5e9' : '#ffebee'}; text-align: center;">
                    <div style="font-size: 12px; color: ${summary.final_balance >= 0 ? '#2E7D32' : '#C62828'};">الرصيد النهائي</div>
                    <strong style="font-size: 16px; color: ${summary.final_balance >= 0 ? '#2E7D32' : '#C62828'};">${summary.final_balance.toFixed(2)} ريال</strong>
                </div>
            </div>
            
            <!-- جدول المعاملات -->
            <div style="overflow-x: auto; margin-bottom: 20px; border: 1px solid #e0e0e0; border-radius: 6px;">
                <table style="width: 100%; border-collapse: collapse; font-size: 12px;">
                    <thead>
                        <tr style="background: #4F6F8F; color: white;">
                            <th style="padding: 8px;">التاريخ</th>
                            <th style="padding: 8px;">النوع</th>
                            <th style="padding: 8px;">رقم الفاتورة</th>
                            <th style="padding: 8px;">مدين</th>
                            <th style="padding: 8px;">دائن</th>
                            <th style="padding: 8px;">الرصيد</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${transactionsHtml || '<tr><td colspan="6" style="text-align: center; padding: 30px;">لا توجد معاملات في هذه الفترة</td></tr>'}
                    </tbody>
                </table>
            </div>
            
            <!-- تاريخ الإنشاء -->
            <div style="margin-bottom: 20px; text-align: center; color: #999; font-size: 11px;">
                تم الإنشاء في: ${data.generated_at}
            </div>
            
            <!-- أزرار التحكم (لن تظهر في الطباعة) -->
            <div style="margin-top: 20px; display: flex; gap: 10px; justify-content: center; border-top: 1px solid #e0e0e0; padding-top: 20px;">
                <button onclick="printStatement()" style="background: #4F6F8F; color: white; border: none; padding: 10px 25px; border-radius: 6px; font-size: 14px; cursor: pointer; display: flex; align-items: center; gap: 5px;">
                    <span>🖨️</span> طباعة
                </button>
                    <button class="btn btn-success" onclick="downloadStatement()">
                        <span>📥</span> تحميل
                    </button>               
                <button onclick="closeStatementModal()" style="background: #f44336; color: white; border: none; padding: 10px 25px; border-radius: 6px; font-size: 14px; cursor: pointer; display: flex; align-items: center; gap: 5px;">
                    <span>❌</span> إغلاق
                </button>
            </div>
        </div>
    `;
}

// ===== دالة طباعة كشف الحساب (جديدة) =====
// ===== دالة طباعة كشف الحساب =====
function printStatement() {
    const statementContent = document.getElementById('statementModalBody').innerHTML;
    
    const printWindow = window.open('', '_blank', 'width=800,height=600');
    
    printWindow.document.write(`
        <!DOCTYPE html>
        <html dir="rtl">
        <head>
            <meta charset="UTF-8">
            <title>كشف حساب العميل</title>
            <style>
                body {
                    font-family: 'Segoe UI', Tahoma, Arial, sans-serif;
                    margin: 20px;
                    padding: 0;
                    background: white;
                }
                .statement-header {
                    text-align: center;
                    margin-bottom: 20px;
                    border-bottom: 2px solid #4F6F8F;
                    padding-bottom: 10px;
                }
                .customer-info {
                    background: #f5f5f5;
                    padding: 15px;
                    border-radius: 6px;
                    margin-bottom: 20px;
                    display: flex;
                    flex-wrap: wrap;
                    gap: 15px;
                }
                .summary-box {
                    flex: 1;
                    min-width: 150px;
                    padding: 15px;
                    border-radius: 6px;
                    text-align: center;
                }
                table {
                    width: 100%;
                    border-collapse: collapse;
                    font-size: 12px;
                }
                th {
                    background: #4F6F8F;
                    color: white;
                    padding: 8px;
                }
                td {
                    padding: 6px;
                    border-bottom: 1px solid #ddd;
                }
                .invoice { background: #e8f5e9; }
                .payment { background: #e3f2fd; }
                .return { background: #ffebee; }
                .balance-positive { color: #4CAF50; font-weight: bold; }
                .balance-negative { color: #f44336; font-weight: bold; }
                @media print {
                    body { background: white; }
                    button { display: none !important; }
                }
            </style>
        </head>
        <body>
            ${statementContent}
        </body>
        </html>
    `);
    
    printWindow.document.close();
    
    setTimeout(() => {
        printWindow.print();
        printWindow.close();
    }, 500);
}

function closeStatementModal() {
    document.getElementById('statementModal').classList.remove('active');
}
// ===== تحميل كشف الحساب بصيغة Word =====
function downloadStatement() {
    // الحصول على محتوى كشف الحساب
    const statementContent = document.getElementById('statementModalBody').innerHTML;
    
    // الحصول على اسم العميل من العنوان
    const customerName = document.querySelector('#modalTitle')?.textContent.replace('كشف الدين والتسديد - ', '') || 'عميل';
    
    // إنشاء محتوى Word بتنسيق جميل
    const wordContent = `
        <html xmlns:v="urn:schemas-microsoft-com:vml" xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:w="urn:schemas-microsoft-com:office:word" xmlns:m="http://schemas.microsoft.com/office/2004/12/omml" xmlns="http://www.w3.org/TR/REC-html40">
        <head>
            <meta charset="UTF-8">
            <title>كشف حساب - ${customerName}</title>
            <style>
                body {
                    font-family: 'Arial', 'Traditional Arabic', sans-serif;
                    direction: rtl;
                    margin: 30px;
                    line-height: 1.6;
                }
                .header {
                    text-align: center;
                    margin-bottom: 30px;
                    border-bottom: 2px solid #4F6F8F;
                    padding-bottom: 15px;
                }
                .header h1 {
                    color: #4F6F8F;
                    font-size: 24px;
                    margin: 0;
                }
                .header h2 {
                    color: #333;
                    font-size: 20px;
                    margin: 10px 0;
                }
                .customer-info {
                    background: #f5f5f5;
                    padding: 15px;
                    border-radius: 8px;
                    margin-bottom: 25px;
                    border-right: 4px solid #4F6F8F;
                }
                .customer-info p {
                    margin: 8px 0;
                    font-size: 14px;
                }
                .summary-boxes {
                    display: flex;
                    gap: 15px;
                    margin-bottom: 25px;
                    flex-wrap: wrap;
                }
                .summary-box {
                    flex: 1;
                    min-width: 150px;
                    padding: 15px;
                    background: #f0f0f0;
                    border-radius: 6px;
                    text-align: center;
                    border: 1px solid #ddd;
                }
                .summary-box .label {
                    font-size: 13px;
                    color: #666;
                    margin-bottom: 5px;
                }
                .summary-box .value {
                    font-size: 18px;
                    font-weight: bold;
                    color: #333;
                }
                .summary-box .value.positive {
                    color: #4CAF50;
                }
                .summary-box .value.negative {
                    color: #f44336;
                }
                table {
                    width: 100%;
                    border-collapse: collapse;
                    margin: 20px 0;
                    font-size: 13px;
                }
                th {
                    background: #4F6F8F;
                    color: white;
                    padding: 12px;
                    font-weight: normal;
                }
                td {
                    padding: 10px;
                    border-bottom: 1px solid #ddd;
                    text-align: center;
                }
                tr.invoice {
                    background: #e8f5e9;
                }
                tr.payment {
                    background: #e3f2fd;
                }
                tr.return {
                    background: #ffebee;
                }
                .balance-positive {
                    color: #4CAF50;
                    font-weight: bold;
                }
                .balance-negative {
                    color: #f44336;
                    font-weight: bold;
                }
                .footer {
                    text-align: center;
                    margin-top: 30px;
                    padding-top: 15px;
                    border-top: 1px solid #ddd;
                    color: #999;
                    font-size: 11px;
                }
                .date-info {
                    color: #666;
                    font-size: 12px;
                    margin-top: 5px;
                }
            </style>
        </head>
        <body>
            ${statementContent.replace(/<button[\s\S]*?<\/button>/g, '') // إزالة الأزرار
                               .replace(/class="no-print"/g, '') // إزالة كلاس no-print
                               .replace(/style="[^"]*"/g, function(match) {
                                   // الاحتفاظ بالأنماط المهمة
                                   return match;
                               })}
        </body>
        </html>
    `;
    
    // إنشاء blob وحفظ الملف
    const blob = new Blob([wordContent], { type: 'application/msword' });
    const url = window.URL.createObjectURL(blob);
    const link = document.createElement('a');
    
    // تحديد اسم الملف (تاريخ + اسم العميل)
    const now = new Date();
    const dateStr = now.toLocaleDateString('ar-EG').replace(/\//g, '-');
    const fileName = `كشف_حساب_${customerName}_${dateStr}.doc`;
    
    link.href = url;
    link.download = fileName;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    window.URL.revokeObjectURL(url);
    
    showAlert('success', `✅ تم تحميل الملف: ${fileName}`);
}
// ============================================
// ملف: security.js - الحماية المتكاملة للنظام
// ============================================

(function secureSystem() {
    'use strict';
    

    // ===== منع اختصارات لوحة المفاتيح (الحروف الإنجليزية والعربية) =====
    document.addEventListener('keydown', function(e) {
        
        // ===== منع اختصارات الحروف الإنجليزية =====
        // Ctrl+C / Ctrl+X / Ctrl+V / Ctrl+S / Ctrl+P / Ctrl+U / Ctrl+F / Ctrl+H / Ctrl+J
        // Ctrl+Shift+I / Ctrl+Shift+J / Ctrl+Shift+C / Ctrl+Shift+Delete
        if (e.ctrlKey) {
            const forbiddenKeys = [
                'c', 'C', 'x', 'X', 'v', 'V', 's', 'S', 'p', 'P', 'u', 'U', 
                'f', 'F', 'h', 'H', 'j', 'J', 'a', 'A', 'd', 'D', 'w', 'W',
                't', 'T', 'n', 'N', 'o', 'O', 'r', 'R', 'e', 'E', 'y', 'Y',
                'ق', 'ث', 'ت', 'ن', 'م', 'ك', 'ط', 'ئ', 'ء', 'ؤ', 'ر', 'ى',
                'ة', 'و', 'ز', 'ظ', 'ل', 'ا', 'س', 'ي', 'ب', 'ص', 'ش', 'ج'
            ];
            
            if (forbiddenKeys.includes(e.key)) {
                e.preventDefault();
                e.stopPropagation();
                showSecurityAlert('🚫 هذه العملية غير مسموح بها');
                return false;
            }
            
            // منع Ctrl+Shift+I (أدوات المطور)
            if (e.shiftKey && (e.key === 'I' || e.key === 'i' || e.key === 'ي')) {
                e.preventDefault();
                e.stopPropagation();
                showSecurityAlert('🚫 أدوات المطور معطلة');
                return false;
            }
            
            // منع Ctrl+Shift+J (وحدة التحكم)
            if (e.shiftKey && (e.key === 'J' || e.key === 'j' || e.key === 'ت')) {
                e.preventDefault();
                e.stopPropagation();
                showSecurityAlert('🚫 وحدة التحكم معطلة');
                return false;
            }
            
            // منع Ctrl+Shift+C (فحص العنصر)
            if (e.shiftKey && (e.key === 'C' || e.key === 'c' || e.key === 'س')) {
                e.preventDefault();
                e.stopPropagation();
                showSecurityAlert('🚫 فحص العنصر معطل');
                return false;
            }
            
            // منع Ctrl+Shift+Delete (مسح البيانات)
            if (e.shiftKey && e.key === 'Delete') {
                e.preventDefault();
                e.stopPropagation();
                showSecurityAlert('🚫 هذه العملية غير مسموح بها');
                return false;
            }
        }
        
        // ===== منع مفاتيح الوظائف =====
        const forbiddenFunctionKeys = [
            'F1', 'F2', 'F3', 'F4', 'F6', 'F7', 'F8', 'F9', 'F10', 'F11', 'F12'
        ];
        
        if (forbiddenFunctionKeys.includes(e.key)) {
            e.preventDefault();
            e.stopPropagation();
            
            if (e.key === 'F12') {
                showSecurityAlert('🚫 أدوات المطور معطلة');
            } else {
                showSecurityAlert(`🚫 مفتاح ${e.key} غير مسموح به`);
            }
            return false;
        }
        
        // ===== منع اختصارات الحروف العربية =====
        // Ctrl+ق (Copy) - يقابل C
        // Ctrl+ث (Save) - يقابل S
        // Ctrl+ت (Print) - يقابل P
        // Ctrl+ن (New) - يقابل N
        // Ctrl+م (Open) - يقابل O
        // Ctrl+ك (Find) - يقابل F
        // Ctrl+ط (History) - يقابل H
        // Ctrl+ئ (Downloads) - يقابل J
        if (e.ctrlKey) {
            const arabicKeys = ['ق', 'ث', 'ت', 'ن', 'م', 'ك', 'ط', 'ئ', 'ء', 'ؤ', 'ر', 'ى', 'ة', 'و', 'ز', 'ظ'];
            if (arabicKeys.includes(e.key)) {
                e.preventDefault();
                e.stopPropagation();
                showSecurityAlert('🚫 هذه العملية غير مسموح بها');
                return false;
            }
        }
        
        // ===== منع Alt+ مفاتيح =====
        if (e.altKey) {
            const forbiddenAltKeys = ['F4', 'Tab', 'Home', 'End', 'Left', 'Right', 'Up', 'Down'];
            if (forbiddenAltKeys.includes(e.key)) {
                e.preventDefault();
                e.stopPropagation();
                return false;
            }
        }
        
        // ===== منع F5 و Ctrl+R (Refresh) =====
      
        
        // ===== منع Alt+F4 (إغلاق النافذة) =====
        if (e.altKey && e.key === 'F4') {
            e.preventDefault();
            e.stopPropagation();
            return false;
        }
        
        // ===== منع Ctrl+T (New Tab) =====
        if (e.ctrlKey && (e.key === 't' || e.key === 'T' || e.key === 'ن')) {
            e.preventDefault();
            e.stopPropagation();
            showSecurityAlert('❌ لا يمكن فتح تبويب جديد');
            return false;
        }
        
        // ===== منع Ctrl+N (New Window) =====
        if (e.ctrlKey && (e.key === 'n' || e.key === 'N' || e.key === 'م')) {
            e.preventDefault();
            e.stopPropagation();
            showSecurityAlert('❌ لا يمكن فتح نافذة جديدة');
            return false;
        }
        
        // ===== منع Ctrl+W (Close Tab) =====
        if (e.ctrlKey && (e.key === 'w' || e.key === 'W' || e.key === 'ك')) {
            e.preventDefault();
            e.stopPropagation();
            return false;
        }
        
        // ===== منع Ctrl+H (History) =====
        if (e.ctrlKey && (e.key === 'h' || e.key === 'H' || e.key === 'ط')) {
            e.preventDefault();
            e.stopPropagation();
            showSecurityAlert('❌ لا يمكن فتح سجل التصفح');
            return false;
        }
        
        // ===== منع Ctrl+J (Downloads) =====
        if (e.ctrlKey && (e.key === 'j' || e.key === 'J' || e.key === 'ئ')) {
            e.preventDefault();
            e.stopPropagation();
            showSecurityAlert('❌ لا يمكن فتح التحميلات');
            return false;
        }
        
        // ===== منع Ctrl+U (View Source) =====
        if (e.ctrlKey && (e.key === 'u' || e.key === 'U' || e.key === 'ي')) {
            e.preventDefault();
            e.stopPropagation();
            showSecurityAlert('❌ لا يمكن عرض المصدر');
            return false;
        }
        
        // ===== منع Ctrl+P (Print) =====
        if (e.ctrlKey && (e.key === 'p' || e.key === 'P' || e.key === 'ت')) {
            e.preventDefault();
            e.stopPropagation();
            showSecurityAlert('❌ الطباعة غير متاحة', 'warning');
            return false;
        }
        
        // ===== منع Ctrl+S (Save) =====
        if (e.ctrlKey && (e.key === 's' || e.key === 'S' || e.key === 'ث')) {
            e.preventDefault();
            e.stopPropagation();
            showSecurityAlert('❌ لا يمكن حفظ الصفحة');
            return false;
        }
        
        // ===== منع Ctrl+F (Find) =====
        if (e.ctrlKey && (e.key === 'f' || e.key === 'F' || e.key === 'ك')) {
            e.preventDefault();
            e.stopPropagation();
            showSecurityAlert('❌ البحث غير متاح');
            return false;
        }
        
        // ===== منع Ctrl+A (Select All) خارج الحقول =====
        if (e.ctrlKey && (e.key === 'a' || e.key === 'A' || e.key === 'ا')) {
            if (!e.target.matches('input, textarea')) {
                e.preventDefault();
                e.stopPropagation();
                return false;
            }
        }
    }, true); // استخدام capture mode
    
    // ===== منع القائمة اليمنى =====
    document.addEventListener('contextmenu', function(e) {
        if (!e.target.matches('input, textarea')) {
            e.preventDefault();
            return false;
        }
    });
    
    // ===== منع السحب والإفلات =====
    document.addEventListener('dragstart', function(e) {
        e.preventDefault();
        return false;
    });
    
    document.addEventListener('drop', function(e) {
        e.preventDefault();
        return false;
    });
    
    // ===== منع الطباعة بالكامل =====
    window.print = function() {
        showSecurityAlert('🖨️ الطباعة غير متاحة', 'warning');
        return false;
    };
    
    window.addEventListener('beforeprint', function(e) {
        e.preventDefault();
        showSecurityAlert('🖨️ الطباعة غير متاحة', 'warning');
        return false;
    });
    
    // ===== منع حفظ الصفحة =====
    window.addEventListener('beforeunload', function(e) {
        // السماح بالخروج العادي فقط
        return undefined;
    });
    
    // ===== منع فتح View Source =====
    document.addEventListener('keydown', function(e) {
        if (e.ctrlKey && (e.key === 'u' || e.key === 'U' || e.key === 'ي')) {
            e.preventDefault();
            return false;
        }
    });
    
    // ===== كشف أدوات المطور =====
    (function detectDevTools() {
        const element = new Image();
        let devToolsOpen = false;
        
        Object.defineProperty(element, 'id', {
            get: function() {
                devToolsOpen = true;
                showSecurityAlert('🚫 تم اكتشاف أدوات المطور - سيتم إعادة التحميل', 'error');
                setTimeout(() => {
                    window.location.reload();
                }, 1000);
                return '';
            }
        });
        
        setInterval(() => {
            devToolsOpen = false;
            console.log(element);
            console.clear();
        }, 1000);
    })();
    
    // ===== منع اختصارات المتصفح الأخرى =====
    document.addEventListener('keydown', function(e) {
        // منع Ctrl+Shift+N (Incognito)
        if (e.ctrlKey && e.shiftKey && (e.key === 'n' || e.key === 'N' || e.key === 'م')) {
            e.preventDefault();
            showSecurityAlert('❌ وضع التصفح الخاص غير متاح');
            return false;
        }
        
        // منع Ctrl+Shift+P (Private)
        if (e.ctrlKey && e.shiftKey && (e.key === 'p' || e.key === 'P' || e.key === 'ت')) {
            e.preventDefault();
            showSecurityAlert('❌ وضع التصفح الخاص غير متاح');
            return false;
        }
        
        // منع Ctrl+D (Bookmark)
        if (e.ctrlKey && (e.key === 'd' || e.key === 'D' || e.key === 'ذ')) {
            e.preventDefault();
            showSecurityAlert('❌ لا يمكن إضافة إشارة مرجعية');
            return false;
        }
        
        // منع Ctrl+B (Bookmarks Bar)
        if (e.ctrlKey && (e.key === 'b' || e.key === 'B' || e.key === 'لا')) {
            e.preventDefault();
            showSecurityAlert('❌ لا يمكن إظهار شريط الإشارات');
            return false;
        }
        
        // منع Ctrl+E (Search)
        if (e.ctrlKey && (e.key === 'e' || e.key === 'E' || e.key === 'ي')) {
            e.preventDefault();
            return false;
        }
        
        // منع Ctrl+L (Address Bar)
        if (e.ctrlKey && (e.key === 'l' || e.key === 'L' || e.key === 'ل')) {
            e.preventDefault();
            return false;
        }
        
        // منع Ctrl+K (Search from Address)
        if (e.ctrlKey && (e.key === 'k' || e.key === 'K' || e.key === 'ك')) {
            e.preventDefault();
            return false;
        }
        
        // منع Ctrl+O (Open)
        if (e.ctrlKey && (e.key === 'o' || e.key === 'O' || e.key === 'م')) {
            e.preventDefault();
            return false;
        }
    });
    
    // ===== منع حفظ الصور =====
    document.querySelectorAll('img').forEach(img => {
        img.addEventListener('contextmenu', (e) => e.preventDefault());
        img.addEventListener('dragstart', (e) => e.preventDefault());
    });
    
    // ===== منع تحديد النص خارج الحقول =====
    document.addEventListener('selectstart', function(e) {
        if (!e.target.matches('input, textarea')) {
            e.preventDefault();
            return false;
        }
    });
    
    // ===== منع نسخ النص =====
    document.addEventListener('copy', function(e) {
        if (!e.target.matches('input, textarea')) {
            e.preventDefault();
            showSecurityAlert('❌ النسخ غير مسموح به');
            return false;
        }
    });
    
    document.addEventListener('cut', function(e) {
        if (!e.target.matches('input, textarea')) {
            e.preventDefault();
            showSecurityAlert('❌ القص غير مسموح به');
            return false;
        }
    });
    
    document.addEventListener('paste', function(e) {
        if (!e.target.matches('input, textarea')) {
            e.preventDefault();
            showSecurityAlert('❌ اللصق غير مسموح به');
            return false;
        }
    });
    
    // ===== تعطيل console.log في الإنتاج =====
    if (window.location.hostname !== 'localhost' && !window.location.hostname.includes('127.0.0.1')) {
        console.log = function() {};
        console.info = function() {};
        console.warn = function() {};
        console.error = function() {};
        console.debug = function() {};
        console.trace = function() {};
        console.table = function() {};
    }
    
    // ===== دالة عرض رسائل الأمان =====
    window.showSecurityAlert = function(message, type = 'error') {
        if (typeof showAlert === 'function') {
            showAlert(type, message);
        } else {
            const alertDiv = document.createElement('div');
            alertDiv.style.cssText = `
                position: fixed;
                top: 20px;
                right: 20px;
                background: ${type === 'error' ? '#f44336' : type === 'warning' ? '#ff9800' : '#2196F3'};
                color: white;
                padding: 15px 25px;
                border-radius: 6px;
                box-shadow: 0 2px 10px rgba(0,0,0,0.1);
                z-index: 99999;
                font-size: 14px;
                direction: rtl;
                max-width: 350px;
                animation: slideIn 0.3s ease;
            `;
            alertDiv.textContent = message;
            document.body.appendChild(alertDiv);
            setTimeout(() => alertDiv.remove(), 3000);
        }
    };
    
    console.log('✅ نظام الحماية المتقدم مفعل - جميع الاختصارات معطلة');
})();
</script>
</body>
</html>

<?php
$content = ob_get_clean();
require BASE_PATH . 'views/layouts/main.php';
?>

<?php 
    // تأكد من كتابة المسار الصحيح للملف
    include_once 'views/Casio.php'; 
?> 