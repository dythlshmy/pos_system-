<?php
$role = Auth::role();
$interfaces = [];
if ($role === 'admin') {
    $interfaces = [
        'global' => '🌐 النظام بالكامل',
        'dashboard' => '🏠 الرئيسية',
        'inventory' => '🏭 المخزن الرئيسي',
        'shelf' => '🛒 رف البيع',
        'pos' => '💰 نقطة البيع',
        'customers' => '👥 العملاء',
        'reports' => '📊 التقارير',
        'users' => '👨‍💼 المستخدمين',
        'settings' => '⚙️ الإعدادات'
    ];
} else {
    $interfaces = [
        'global' => '🌐 النظام بالكامل',
        'dashboard' => '🏠 الرئيسية',
        'pos' => '💰 نقطة البيع',
        'customers' => '👥 العملاء'
    ];
}
?>

<style>
/* Premium CSS for Shortcut Manager */
#shortcut-manager-modal {
    position: fixed;
    top: 50px;
    left: 50px;
    width: 600px;
    height: 700px;
    min-width: 400px;
    min-height: 400px;
    background: rgba(20, 25, 40, 0.95);
    backdrop-filter: blur(20px);
    border: 1px solid rgba(255, 255, 255, 0.1);
    box-shadow: 0 20px 50px rgba(0, 0, 0, 0.5);
    border-radius: 16px;
    z-index: 999999;
    display: none;
    flex-direction: column;
    color: #e2e8f0;
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    overflow: hidden;
    transition: all 0.2s cubic-bezier(0.25, 0.8, 0.25, 1);
    direction: rtl;
}

#shortcut-manager-modal.fullscreen {
    top: 0 !important;
    left: 0 !important;
    width: 100vw !important;
    height: 100vh !important;
    border-radius: 0;
}

#shortcut-manager-modal.minimized {
    height: 50px !important;
    overflow: hidden;
}

.sm-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 12px 20px;
    background: rgba(0, 0, 0, 0.3);
    border-bottom: 1px solid rgba(255,255,255,0.05);
    cursor: grab;
    user-select: none;
}

.sm-header:active {
    cursor: grabbing;
}

.sm-title {
    font-weight: bold;
    font-size: 16px;
    display: flex;
    align-items: center;
    gap: 10px;
    color: #fff;
}

.sm-controls {
    display: flex;
    gap: 10px;
}

.sm-btn {
    background: none;
    border: none;
    color: #a0aec0;
    cursor: pointer;
    font-size: 18px;
    transition: 0.3s;
    outline: none;
}

.sm-btn:hover {
    color: #fff;
}

.sm-btn.close:hover {
    color: #ff4d4f;
}

.sm-body {
    padding: 20px;
    overflow-y: auto;
    overflow-x: hidden;
    flex-grow: 1;
}

.sm-resize-handle {
    position: absolute;
    bottom: 0;
    left: 0;
    width: 20px;
    height: 20px;
    cursor: sw-resize;
    background: linear-gradient(135deg, transparent 50%, rgba(255,255,255,0.2) 50%);
}

.sm-card {
    background: rgba(255, 255, 255, 0.03);
    border: 1px solid rgba(255, 255, 255, 0.05);
    border-radius: 12px;
    padding: 15px;
    margin-bottom: 20px;
}

.sm-switch-row {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 10px;
}

.sm-switch {
    display: flex;
    align-items: center;
    gap: 10px;
    cursor: pointer;
}

.sm-switch input {
    display: none;
}

.sm-slider {
    width: 40px;
    height: 20px;
    background-color: #4a5568;
    border-radius: 20px;
    position: relative;
    transition: 0.3s;
}

.sm-slider::before {
    content: "";
    position: absolute;
    width: 16px;
    height: 16px;
    border-radius: 50%;
    background: white;
    top: 2px;
    left: 2px;
    transition: 0.3s;
}

.sm-switch input:checked + .sm-slider {
    background-color: #48bb78;
}

.sm-switch input:checked + .sm-slider::before {
    transform: translateX(20px);
}

.sm-input, .sm-select {
    width: 100%;
    padding: 10px 15px;
    background: rgba(0, 0, 0, 0.2);
    border: 1px solid rgba(255,255,255,0.1);
    color: #fff;
    border-radius: 8px;
    margin-bottom: 15px;
    outline: none;
    transition: 0.3s;
}

.sm-input:focus, .sm-select:focus {
    border-color: #3182ce;
    box-shadow: 0 0 0 2px rgba(49, 130, 206, 0.3);
}

.sm-add-group {
    display: flex;
    align-items: center;
    gap: 10px;
}

.sm-add-group > * {
    margin-bottom: 0;
}

.sm-key-input {
    width: 60px;
    text-align: center;
    text-transform: uppercase;
}

.sm-btn-primary {
    background: #3182ce;
    color: white;
    border: none;
    padding: 10px 20px;
    border-radius: 8px;
    cursor: pointer;
    font-weight: bold;
    transition: 0.3s;
    white-space: nowrap;
}

.sm-btn-primary:hover {
    background: #2b6cb0;
}

.sm-table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 10px;
}

.sm-table th, .sm-table td {
    padding: 12px;
    text-align: right;
    border-bottom: 1px solid rgba(255,255,255,0.05);
}

.sm-table th {
    color: #a0aec0;
    font-weight: normal;
    text-transform: uppercase;
    font-size: 12px;
}

.sm-table tr:focus, .sm-table tr.focused {
    background: rgba(49, 130, 206, 0.2);
    outline: none;
}

.sm-conflict-alert {
    background: rgba(229, 62, 62, 0.2);
    color: #fc8181;
    border: 1px solid rgba(229, 62, 62, 0.5);
    padding: 10px;
    border-radius: 8px;
    margin-top: 10px;
    display: none;
    font-size: 14px;
}

.sm-shortcut-kbd {
    background: #2d3748;
    padding: 2px 6px;
    border-radius: 4px;
    border: 1px solid #4a5568;
    border-bottom: 2px solid #4a5568;
    font-family: monospace;
    font-size: 12px;
    color: #e2e8f0;
}

/* Neon UX Rules */
.neon-yellow {
    box-shadow: 0 0 25px 8px rgba(255, 255, 0, 0.9), 0 0 15px rgba(255, 200, 0, 0.6) !important;
    background: linear-gradient(135deg, rgba(255,255,0,0.15), rgba(255,200,0,0.25)) !important;
    transform: scale(1.03) !important;
    transition: all 0.15s cubic-bezier(0.4, 0, 0.2, 1) !important;
    z-index: 100 !important;
    border: 1px solid rgba(255,255,0,0.5) !important;
}

.neon-purple {
    box-shadow: 0 0 20px 5px rgba(180, 0, 255, 0.9), 0 0 12px rgba(150, 0, 255, 0.6) !important;
    background: rgba(180, 0, 255, 0.1) !important;
    transform: scale(1.02) !important;
    transition: all 0.15s cubic-bezier(0.4, 0, 0.2, 1) !important;
    border: 1px solid rgba(180,0,255,0.4) !important;
}

.neon-green-flash {
    box-shadow: 0 0 30px 10px rgba(0, 255, 0, 0.9), 0 0 20px rgba(0, 255, 0, 0.7) !important;
    background: rgba(0, 255, 0, 0.2) !important;
    transform: scale(1.05) !important;
    transition: all 0.1s cubic-bezier(0.4, 0, 0.2, 1) !important;
    border: 1px solid rgba(0,255,0,0.8) !important;
}

.neon-red-flash {
    box-shadow: 0 0 30px 10px rgba(255, 0, 0, 0.9), 0 0 20px rgba(255, 0, 0, 0.7) !important;
    background: rgba(255, 0, 0, 0.2) !important;
    transform: scale(0.95) !important;
    transition: all 0.1s cubic-bezier(0.4, 0, 0.2, 1) !important;
    border: 1px solid rgba(255,0,0,0.8) !important;
}

.neon-white-glow {
    box-shadow: 0 0 10px 2px rgba(255, 255, 255, 0.5) !important;
    transition: all 0.3s ease !important;
}
</style>

<div id="shortcut-manager-modal">
    <div class="sm-header" id="sm-drag-handle">
        <div class="sm-title">⌨️ إدارة الاختصارات الذكية</div>
        <div class="sm-controls">
            <button class="sm-btn" onclick="ShortcutEngine.minimize()" title="إخفاء مؤقت">⛔</button>
            <button class="sm-btn" onclick="ShortcutEngine.toggleFullscreen()" title="ملء الشاشة">⛶</button>
            <button class="sm-btn close" onclick="ShortcutEngine.toggleModal()" title="إغلاق">❌</button>
        </div>
    </div>
    
    <div class="sm-body">
        <div class="sm-card">
            <h4 style="margin-top: 0; color: #63b3ed;">إعدادات الواجهة الحالية</h4>
            <select class="sm-select" id="sm-interface-select" onchange="ShortcutEngine.loadInterfaceData()">
                <?php foreach ($interfaces as $key => $name): ?>
                    <option value="<?= $key ?>"><?= $name ?></option>
                <?php endforeach; ?>
            </select>

            <div class="sm-switch-row">
                <span>تفعيل محرك الاختصارات في هذه الواجهة</span>
                <label class="sm-switch">
                    <input type="checkbox" id="sm-sys-active" onchange="ShortcutEngine.saveSettings(); ShortcutEngine.toggleSystemGlow(this.checked);">
                    <span class="sm-slider"></span>
                </label>
            </div>
            <div class="sm-switch-row">
                <span title="اختصار: Alt + ←/→">1. تنقل بين الواجهات (Interface)</span>
                <label class="sm-switch">
                    <input type="checkbox" id="sm-nav-interface" onchange="ShortcutEngine.saveLocalToggles()">
                    <span class="sm-slider"></span>
                </label>
            </div>
            <div class="sm-switch-row">
                <span title="اختصار: Ctrl + ↑/↓">2. تنقل داخل العناصر (Elements)</span>
                <label class="sm-switch">
                    <input type="checkbox" id="sm-nav-elements" onchange="ShortcutEngine.saveLocalToggles()">
                    <span class="sm-slider"></span>
                </label>
            </div>
            <div class="sm-switch-row">
                <span title="اختصار: ↑/↓ داخل القائمة">3. القوائم المنسدلة (Dropdown)</span>
                <label class="sm-switch">
                    <input type="checkbox" id="sm-nav-dropdown" onchange="ShortcutEngine.saveLocalToggles()">
                    <span class="sm-slider"></span>
                </label>
            </div>
            <div class="sm-switch-row">
                <span title="اختصار: Alt + ↑/↓ و Ctrl + ←/→">4. الجداول (Table)</span>
                <label class="sm-switch">
                    <input type="checkbox" id="sm-nav-table" onchange="ShortcutEngine.saveLocalToggles()">
                    <span class="sm-slider"></span>
                </label>
            </div>
            <div class="sm-switch-row">
                <span title="اختصار: Esc">5. نظام الهروب (Smart ESC)</span>
                <label class="sm-switch">
                    <input type="checkbox" id="sm-nav-esc" onchange="ShortcutEngine.saveLocalToggles()">
                    <span class="sm-slider"></span>
                </label>
            </div>
            <div class="sm-switch-row">
                <span title="اختصار: Enter">6. تنفيذ الأوامر (Enter)</span>
                <label class="sm-switch">
                    <input type="checkbox" id="sm-nav-enter" onchange="ShortcutEngine.saveLocalToggles()">
                    <span class="sm-slider"></span>
                </label>
            </div>
            <div class="sm-switch-row">
                <span>السماح بإضافة اختصارات مخصصة</span>
                <label class="sm-switch">
                    <input type="checkbox" id="sm-adding-active" onchange="ShortcutEngine.saveSettings()">
                    <span class="sm-slider"></span>
                </label>
            </div>
        </div>

        <div class="sm-card" id="sm-add-card">
            <h4 style="margin-top: 0; color: #48bb78;">إضافة اختصار جديد ⌨️</h4>
            <div class="sm-add-group">
                <select class="sm-select" id="sm-add-modifier" style="width: 120px;">
                    <option value="">بدون (حرف فقط)</option>
                    <option value="ctrl">Ctrl</option>
                    <option value="alt">Alt</option>
                    <option value="shift">Shift</option>
                </select>
                <span style="font-weight:bold; color:#718096;">+</span>
                <input type="text" class="sm-input sm-key-input" id="sm-add-key" maxlength="1" placeholder="زر">
                <span style="font-weight:bold; color:#718096;">=</span>
                <select class="sm-select" id="sm-add-target">
                    <option value="">اختر العنصر المستهدف...</option>
                    <!-- سيتم ملؤه تلقائياً بواسطة الـ DOM Parser -->
                </select>
                <button class="sm-btn-primary" onclick="ShortcutEngine.saveNewShortcut()">حفظ</button>
            </div>
            <div class="sm-conflict-alert" id="sm-conflict-msg"></div>
        </div>

        <div class="sm-card">
            <h4 style="margin-top: 0; color: #ed8936;">الاختصارات الحالية للواجهة</h4>
            <table class="sm-table" id="sm-shortcuts-table" tabindex="0">
                <thead>
                    <tr>
                        <th>المفتاح</th>
                        <th>العنصر المرتبط</th>
                        <th>العمليات (➡️⬅️)</th>
                    </tr>
                </thead>
                <tbody id="sm-shortcuts-tbody">
                    <!-- يتم جلبه ديناميكياً -->
                </tbody>
            </table>
        </div>
    </div>
    
    <div class="sm-resize-handle" id="sm-resize"></div>
</div>

<script>
/**
 * ShortcutEngine
 * Intelligent Keyboard Shortcut Management System - Performance Optimized
 */
const arabicToEnglish = {
    'ض': 'q', 'ص': 'w', 'ث': 'e', 'ق': 'r', 'ف': 't', 'غ': 'y', 'ع': 'u', 'ه': 'i', 'خ': 'o', 'ح': 'p',
    'ش': 'a', 'س': 's', 'ي': 'd', 'ب': 'f', 'ل': 'g', 'ا': 'h', 'ت': 'j', 'ن': 'k', 'م': 'l',
    'ئ': 'z', 'ء': 'x', 'ؤ': 'c', 'ر': 'v', 'لا': 'b', 'ى': 'n', 'ة': 'm',
    'َ': 'Q', 'ً': 'W', 'ُ': 'E', 'ٌ': 'R', 'لإ': 'T', 'إ': 'Y', '‘': 'U', '÷': 'I', '×': 'O', '؛': 'P',
    'ِ': 'A', 'ٍ': 'S', ']': 'D', '[': 'F', 'لأ': 'G', 'أ': 'H', 'ـ': 'J', '،': 'K', '/': 'L',
    '~': 'Z', 'ْ': 'X', '}': 'C', '{': 'V', 'لآ': 'B', 'آ': 'N', '’': 'M'
};

window.ShortcutEngine = (function() {
    let settings = {};
    let shortcuts = [];
    let elementsState = {};
    let isModalOpen = false;
    let autoPolledTargets = [];
    let localToggles = {
        interface: true,
        elements: true,
        dropdown: true,
        table: true,
        esc: true,
        enter: true
    };
    
    const BASE_URL_API = '<?= BASE_URL ?>';

    function loadLocalToggles() {
        const saved = localStorage.getItem(`sm_toggles_${interfaceSelect.value}`);
        if(saved) {
            try { localToggles = JSON.parse(saved); } catch(e){}
        } else {
            localToggles = { interface: true, elements: true, dropdown: true, table: true, esc: true, enter: true };
        }
        document.getElementById('sm-nav-interface').checked = localToggles.interface;
        document.getElementById('sm-nav-elements').checked = localToggles.elements;
        document.getElementById('sm-nav-dropdown').checked = localToggles.dropdown;
        document.getElementById('sm-nav-table').checked = localToggles.table;
        document.getElementById('sm-nav-esc').checked = localToggles.esc;
        document.getElementById('sm-nav-enter').checked = localToggles.enter;
    }

    function saveLocalToggles() {
        localToggles = {
            interface: document.getElementById('sm-nav-interface').checked,
            elements: document.getElementById('sm-nav-elements').checked,
            dropdown: document.getElementById('sm-nav-dropdown').checked,
            table: document.getElementById('sm-nav-table').checked,
            esc: document.getElementById('sm-nav-esc').checked,
            enter: document.getElementById('sm-nav-enter').checked
        };
        localStorage.setItem(`sm_toggles_${interfaceSelect.value}`, JSON.stringify(localToggles));
    }

    // Neon UX Helpers
    function applyNeon(el, className, duration = 0) {
        if (!el) return;
        el.classList.add(className);
        if (duration > 0) {
            setTimeout(() => { if(el) el.classList.remove(className); }, duration);
        }
    }

    function clearNeon(className) {
        document.querySelectorAll('.' + className).forEach(e => e.classList.remove(className));
    }

    // UI Elements
    const modal = document.getElementById('shortcut-manager-modal');
    const interfaceSelect = document.getElementById('sm-interface-select');
    
    // Auto-detect current interface based on URL
    function detectInterface() {
        const path = window.location.pathname.toLowerCase();
        let current = 'global';
        if (path.includes('dashboard')) current = 'dashboard';
        else if (path.includes('inventory')) current = 'inventory';
        else if (path.includes('shelf')) current = 'shelf';
        else if (path.includes('pos')) current = 'pos';
        else if (path.includes('customers')) current = 'customers';
        else if (path.includes('reports')) current = 'reports';
        else if (path.includes('users')) current = 'users';
        else if (path.includes('settings')) current = 'settings';
        
        interfaceSelect.value = current;
    }

    async function loadInterfaceData() {
        const iface = interfaceSelect.value;
        try {
            const req = await window.smartFetch(`${BASE_URL_API}/shortcuts/load?interface_name=${iface}`);
            if(!req) return;
            const res = await req.json();
            
            if (res.success) {
                settings = res.settings;
                shortcuts = res.shortcuts;
                elementsState = res.elements_state.reduce((acc, curr) => {
                    acc[curr.element_id] = curr.is_active == 1;
                    return acc;
                }, {});

                // Update UI toggles
                document.getElementById('sm-sys-active').checked = parseInt(settings.sys_active) === 1;
                document.getElementById('sm-adding-active').checked = parseInt(settings.adding_active) === 1;
                
                loadLocalToggles();
                scanDOMForTargets();
                renderShortcutsTable();
            }
        } catch (e) {
            console.error('Failed to load shortcuts:', e);
        }
    }

    // Auto Scan DOM for interactive elements and map them intelligently
    function getFriendlyName(el) {
        let labelText = '';
        if (el.id) {
           const label = document.querySelector(`label[for="${el.id}"]`);
           if (label) labelText = label.innerText;
        }
        if (!labelText && el.placeholder) labelText = el.placeholder;
        if (!labelText) labelText = el.innerText || el.textContent;
        if (!labelText && el.title) labelText = el.title;
        if (!labelText && el.name) labelText = el.name;
        
        labelText = (labelText || '').replace(/[\n\r]/g, ' ').trim().replace(/\s\s+/g, ' ');
        if (labelText.length > 50) labelText = labelText.substring(0, 50) + '...';
        
        let typeName = 'عنصر';
        if (el.tagName === 'BUTTON' || (el.tagName === 'INPUT' && (el.type === 'button' || el.type === 'submit'))) typeName = 'زر 🔘';
        else if (el.tagName === 'INPUT') typeName = `حقل إدخال ✏️`;
        else if (el.tagName === 'SELECT') typeName = 'قائمة منسدلة 🔻';
        else if (el.tagName === 'A') typeName = 'رابط 🔗';
        else if (el.classList.contains('table-row')) typeName = 'صف جدول 🗂️';
        
        return `${typeName} : ${labelText || el.id || 'بدون اسم'}`;
    }

    function scanDOMForTargets() {
        if(interfaceSelect.value !== detectInterfaceString() && interfaceSelect.value !== 'global') {
            document.getElementById('sm-add-target').innerHTML = '<option value="">الرجاء الانتقال للواجهة أولاً وسحب العناصر...</option>';
            return;
        }

        const elements = document.querySelectorAll('button:not([disabled]), input:not([disabled]), select:not([disabled]), a[href]:not([disabled]), .clickable, .table-row');
        const targetSelect = document.getElementById('sm-add-target');
        targetSelect.innerHTML = '<option value="">اختر العنصر المراد تنفيذ أمر عليه...</option>';
        
        const maxScan = 200;
        let count = 0;
        
        autoPolledTargets = [];

        elements.forEach(el => {
            if (count > maxScan) return;
            const id = el.id ? `#${el.id}` : (el.name ? `[name="${el.name}"]` : null);
            if (!id || id.includes('sm-')) return; 
            
            const rawText = el.innerText || el.placeholder || el.name || id;
            if (!rawText.trim()) return;
            
            const friendlyName = getFriendlyName(el);
            autoPolledTargets.push({ id, label: friendlyName });
            count++;
        });

        // ترتيب العناصر أبجديا
        autoPolledTargets.sort((a, b) => a.label.localeCompare(b.label, 'ar'));

        autoPolledTargets.forEach(tgt => {
            const opt = document.createElement('option');
            opt.value = tgt.id;
            opt.innerText = tgt.label;
            targetSelect.appendChild(opt);
        });
    }

    function detectInterfaceString() {
        const path = window.location.pathname.toLowerCase();
        if (path.includes('dashboard')) return 'dashboard';
        if (path.includes('inventory')) return 'inventory';
        if (path.includes('shelf')) return 'shelf';
        if (path.includes('pos')) return 'pos';
        if (path.includes('customers')) return 'customers';
        if (path.includes('reports')) return 'reports';
        if (path.includes('users')) return 'users';
        if (path.includes('settings')) return 'settings';
        return 'global';
    }

    async function saveSettings() {
        const sys = document.getElementById('sm-sys-active').checked ? 1 : 0;
        const add = document.getElementById('sm-adding-active').checked ? 1 : 0;
        
        // Save local toggles synchronously without DB requirement for new fields
        saveLocalToggles();

        settings.sys_active = sys;
        settings.adding_active = add;

        try {
            await window.smartFetch(`${BASE_URL_API}/shortcuts/save-settings`, {
                method: 'POST',
                body: JSON.stringify({
                    interface_name: interfaceSelect.value,
                    sys_active: sys,
                    nav_active: 1, // Legacy global support field
                    adding_active: add
                })
            });
            window.showSecurityAlert('✅ تم حفظ الإعدادات بنجاح', 'success');
        } catch (e) {}
    }

    async function saveNewShortcut() {
        const modifier = document.getElementById('sm-add-modifier').value;
        let keyChar = document.getElementById('sm-add-key').value.toLowerCase();
        const targetElement = document.getElementById('sm-add-target').value;

        if (!keyChar || !targetElement) {
            window.showSecurityAlert('⚠️ الرجاء تحديد المفتاح والعنصر المستهدف', 'warning');
            return;
        }

        // Arabic Translation
        if (arabicToEnglish[keyChar]) {
            keyChar = arabicToEnglish[keyChar];
        }

        try {
            const req = await window.smartFetch(`${BASE_URL_API}/shortcuts/save-shortcut`, {
                method: 'POST',
                body: JSON.stringify({
                    interface_name: interfaceSelect.value,
                    modifier: modifier,
                    key_char: keyChar,
                    target_element: targetElement
                })
            });
            const res = await req.json();
            if (res.success) {
                if (res.message) window.showSecurityAlert(res.message, 'warning');
                else window.showSecurityAlert('✅ تم إضافة الاختصار', 'success');
                loadInterfaceData();
                document.getElementById('sm-add-key').value = '';
            } else {
                document.getElementById('sm-conflict-msg').innerText = res.message;
                document.getElementById('sm-conflict-msg').style.display = 'block';
                setTimeout(() => document.getElementById('sm-conflict-msg').style.display = 'none', 4000);
            }
        } catch(e){}
    }

    async function deleteShortcut(id) {
        try {
            const req = await window.smartFetch(`${BASE_URL_API}/shortcuts/delete-shortcut`, {
                method: 'POST',
                body: JSON.stringify({ id: id })
            });
            const res = await req.json();
            if (res.success) {
                window.showSecurityAlert('🗑️ تم حذف الاختصار', 'info');
                loadInterfaceData();
            }
        } catch(e){}
    }

    function renderShortcutsTable() {
        const tbody = document.getElementById('sm-shortcuts-tbody');
        tbody.innerHTML = '';
        shortcuts.forEach(s => {
            const kbd = s.modifier ? `<span class="sm-shortcut-kbd">${s.modifier}</span> + <span class="sm-shortcut-kbd">${s.key_char.toUpperCase()}</span>` : `<span class="sm-shortcut-kbd">${s.key_char.toUpperCase()}</span>`;
            
            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td>${kbd}</td>
                <td style="color:#63b3ed; font-size:12px;">${s.target_element}</td>
                <td>
                    <button class="sm-btn" onclick="ShortcutEngine.deleteShortcut(${s.id})" style="color:#fc8181; font-size:14px;">🗑️ حذف</button>
                </td>
            `;
            tbody.appendChild(tr);
        });
    }

    // Modal Draggable Logic
    const dragHandle = document.getElementById('sm-drag-handle');
    let isDragging = false;
    let startX, startY, initialLeft, initialTop;

    dragHandle.addEventListener('mousedown', (e) => {
        isDragging = true;
        startX = e.clientX;
        startY = e.clientY;
        const rect = modal.getBoundingClientRect();
        initialLeft = rect.left;
        initialTop = rect.top;
        document.body.style.userSelect = 'none';
        modal.style.transition = 'none';
    });

    document.addEventListener('mousemove', (e) => {
        if (isDragging) {
            const dx = e.clientX - startX;
            const dy = e.clientY - startY;
            modal.style.left = `${initialLeft + dx}px`;
            modal.style.top = `${initialTop + dy}px`;
        }
    });

    document.addEventListener('mouseup', () => {
        isDragging = false;
        document.body.style.userSelect = '';
        modal.style.transition = 'all 0.2s cubic-bezier(0.25, 0.8, 0.25, 1)';
    });

    // Resize Logic
    const resizeHandle = document.getElementById('sm-resize');
    let isResizing = false;
    let initialWidth, initialHeight;

    resizeHandle.addEventListener('mousedown', (e) => {
        isResizing = true;
        startX = e.clientX;
        startY = e.clientY;
        const rect = modal.getBoundingClientRect();
        initialWidth = rect.width;
        initialHeight = rect.height;
        modal.style.transition = 'none';
        e.stopPropagation();
    });

    document.addEventListener('mousemove', (e) => {
        if (isResizing) {
            const dx = startX - e.clientX; // RTL resize from left
            const dy = e.clientY - startY;
            modal.style.width = `${initialWidth + dx}px`;
            modal.style.height = `${initialHeight + dy}px`;
        }
    });

    document.addEventListener('mouseup', () => {
        isResizing = false;
        modal.style.transition = 'all 0.2s cubic-bezier(0.25, 0.8, 0.25, 1)';
    });

    // --- CORE KBD INTERCEPTION ENGINE ---
    
    // Expose method for security.js to query
    function isSystemShortcut(e) {
        if (parseInt(settings.sys_active) !== 1) return false;
        
        let key = e.key.toLowerCase();
        if (arabicToEnglish[key]) key = arabicToEnglish[key]; // Autotranslate

        // Navigations bypass
        if (localToggles.esc && key === 'escape') return true;
        if (localToggles.interface && e.altKey && (key === 'arrowright' || key === 'arrowleft')) return true;
        if (localToggles.elements && e.ctrlKey && (key === 'arrowdown' || key === 'arrowup')) return true;
        if (localToggles.enter && key === 'enter') return true;
        if (localToggles.dropdown && (key === 'arrowdown' || key === 'arrowup')) return true;
        if (localToggles.table && (e.altKey || e.ctrlKey) && (key === 'arrowdown' || key === 'arrowup' || key === 'arrowleft' || key === 'arrowright')) return true;

        // Check against dynamic shortcuts
        for (const s of shortcuts) {
            if (s.key_char === key) {
                if (s.modifier === 'ctrl' && e.ctrlKey && !e.altKey && !e.shiftKey) return true;
                if (s.modifier === 'alt' && e.altKey && !e.ctrlKey && !e.shiftKey) return true;
                if (s.modifier === 'shift' && e.shiftKey && !e.ctrlKey && !e.altKey) return true;
                if (!s.modifier && !e.ctrlKey && !e.altKey && !e.shiftKey) return true;
            }
        }
        return false;
    }

    // Execute engine processing natively
    document.addEventListener('keydown', function(e) {
        if (parseInt(settings.sys_active) !== 1) return;

        let key = e.key.toLowerCase();
        if (arabicToEnglish[key]) key = arabicToEnglish[key];

        // 1. Module Cross-Navigation (Alt + Arrows) based on top_nav.php
        if (localToggles.interface && e.altKey && !e.ctrlKey && !e.shiftKey) {
            if (key === 'arrowright' || key === 'arrowleft') {
                e.preventDefault();
                
                // منع التكرار السريع عند استمرار الضغط لتفادي Session Deadlock
                if (window._isNavigatingInterface) return;
                window._isNavigatingInterface = true;
                setTimeout(() => { window._isNavigatingInterface = false; }, 400);

                // الحصول على الأزرار الفعلية في القائمة واستبعاد أزرار الخروج المخفية
                const navLinks = Array.from(document.querySelectorAll('.top-nav .nav-link')).filter(link => {
                    return link.href && !link.classList.contains('logout') && link.offsetParent !== null;
                });
                
                if (navLinks.length === 0) return;

                // إيجاد الموقع الحالي (العنصر النشط)
                let currentIndex = navLinks.findIndex(link => link.classList.contains('active'));
                if (currentIndex === -1) {
                    const currentPath = window.location.pathname.toLowerCase();
                    currentIndex = navLinks.findIndex(link => {
                        try { return currentPath.includes(new URL(link.href).pathname.toLowerCase()); } catch(e) { return false; }
                    });
                }
                if (currentIndex === -1) currentIndex = 0;

                // الحساب الدائري للفهرس التالي السهمين يمين للأمام يسار للخلف
                let nextIndex = currentIndex;
                if (key === 'arrowright') {
                    nextIndex = (currentIndex + 1) % navLinks.length;
                } else if (key === 'arrowleft') {
                    nextIndex = (currentIndex - 1 + navLinks.length) % navLinks.length;
                }

                const targetLink = navLinks[nextIndex];
                
                // التأثير البصري المشع المؤقت (Neon Yellow)
                applyNeon(targetLink, 'neon-yellow', 250);
                
                // تنفيذ التنقل بعد تأثير اللمعان
                setTimeout(() => {
                    targetLink.click();
                }, 150);

                return;
            }
        }

        // 1.5 Page Element Navigation (Ctrl + Up/Down/Enter)
        if (localToggles.elements && e.ctrlKey && !e.altKey && !e.shiftKey) {
            if (key === 'arrowdown' || key === 'arrowup') {
                e.preventDefault();
                // حصر التنقل داخل Container الواجهة المطلوبة
                const container = document.querySelector('.content-area') || document.body;
                
                // الحصول على كافة العناصر الممكن النقر او التركيز عليها
                let elements = Array.from(container.querySelectorAll('button:not([disabled]), input:not([disabled]), select:not([disabled]), textarea:not([disabled]), a[href], .clickable, [tabindex]:not([tabindex="-1"])'));
                
                // تصفية العناصر واستبعاد ما هو مخفي او خارج العرض
                elements = elements.filter(el => {
                    if (el.offsetParent === null) return false;
                    const style = window.getComputedStyle(el);
                    if (style.display === 'none' || style.visibility === 'hidden' || style.opacity === '0') return false;
                    
                    const rect = el.getBoundingClientRect();
                    return (
                        rect.top >= 0 &&
                        rect.left >= 0 &&
                        rect.bottom <= (window.innerHeight || document.documentElement.clientHeight) &&
                        rect.right <= (window.innerWidth || document.documentElement.clientWidth)
                    );
                });
                
                if (elements.length > 0) {
                    let currentIndex = elements.indexOf(document.activeElement);
                    let nextIndex = 0;
                    
                    if (currentIndex === -1) {
                        nextIndex = key === 'arrowdown' ? 0 : elements.length - 1;
                    } else {
                        if (key === 'arrowdown') {
                            nextIndex = (currentIndex + 1) % elements.length;
                        } else if (key === 'arrowup') {
                            nextIndex = (currentIndex - 1 + elements.length) % elements.length;
                        }
                    }
                    
                    const targetEl = elements[nextIndex];
                    targetEl.focus();
                    
                    // توهج بنفسجي Scoped Focus
                    clearNeon('neon-purple');
                    applyNeon(targetEl, 'neon-purple');
                }
                return;
            }
        }

        // تنفيذ العنصر بزر الإدخال بناءا على أمر التنقل الذكي
        if (localToggles.enter && key === 'enter' && !e.shiftKey && !e.ctrlKey && !e.altKey) {
            
            // تحقق إن كان هناك Dropdown/Select نشط
            if (document.activeElement && document.activeElement.tagName === 'SELECT') {
                 if(localToggles.dropdown) applyNeon(document.activeElement, 'neon-green-flash', 300);
                 // المتصفح ينفذ الاختيار طبيعيا
            } else {
                const activeEl = document.activeElement;
                if (activeEl && activeEl !== document.body && activeEl.tagName !== 'TEXTAREA') {
                    const isNavigable = activeEl.matches('button:not([disabled]), input:not([disabled]), select:not([disabled]), a[href], .clickable, [tabindex]:not([tabindex="-1"])');
                    if (isNavigable) {
                        e.preventDefault();
                        
                        applyNeon(activeEl, 'neon-green-flash', 250);
                        setTimeout(() => {
                            if(activeEl.tagName !== 'INPUT' || (activeEl.tagName === 'INPUT' && (activeEl.type === 'button' || activeEl.type === 'submit'))) {
                                activeEl.click();
                            }
                        }, 100);
                        return;
                    }
                }
            }
        }

        // 2. Dropdown Navigation Options (↓ / ↑ Pulse)
        if (localToggles.dropdown && document.activeElement && document.activeElement.tagName === 'SELECT' && !e.ctrlKey && !e.altKey) {
            if (key === 'arrowdown' || key === 'arrowup') {
                applyNeon(document.activeElement, 'neon-yellow', 300);
            }
        }

        // 3. Smart ESC Closure (Modals, Dropdowns, Sidebars & Global Back)
        if (localToggles.esc && key === 'escape') {
            const activeModals = document.querySelectorAll('.modal.show, .sweet-alert, #shortcut-manager-modal, .dropdown-menu.show, .sidebar.open, .nav-left.open, .select2-container--open');
            let closedAny = false;
            
            activeModals.forEach(m => {
                if(m.style.display !== 'none' || m.classList.contains('show') || m.classList.contains('open')) {
                    if (m.id !== 'shortcut-manager-modal') {
                        applyNeon(m, 'neon-red-flash', 300);
                        setTimeout(() => {
                            const closeBtn = m.querySelector('.close, [data-dismiss="modal"]');
                            if (closeBtn) closeBtn.click();
                            else {
                                m.style.display = 'none';
                                m.classList.remove('show', 'open', 'select2-container--open');
                            }
                        }, 150);
                        closedAny = true;
                    }
                }
            });
            
            if (!closedAny && isModalOpen) {
                applyNeon(modal, 'neon-red-flash', 300);
                setTimeout(() => toggleModal(), 150);
                closedAny = true;
            }
            
            if (closedAny) {
                e.preventDefault();
                return;
            } else {
                // If nothing was closed -> Go back
                applyNeon(document.body, 'neon-purple', 300);
                setTimeout(() => window.history.back(), 150);
                e.preventDefault();
                return;
            }
        }

        // 3. User Defined Shortcuts Execution
        for (const s of shortcuts) {
            let matches = false;
            if (s.key_char === key) {
                if (s.modifier === 'ctrl' && e.ctrlKey && !e.altKey && !e.shiftKey) matches = true;
                else if (s.modifier === 'alt' && e.altKey && !e.ctrlKey && !e.shiftKey) matches = true;
                else if (s.modifier === 'shift' && e.shiftKey && !e.ctrlKey && !e.altKey) matches = true;
                else if (!s.modifier && !e.ctrlKey && !e.altKey && !e.shiftKey) matches = true;
            }

            if (matches) {
                // Determine target element and execute action
                e.preventDefault();
                const target = document.querySelector(s.target_element);
                if (target) {
                    // Elements State Validator (If specifically disabled by manager, ignore)
                    if (elementsState[s.target_element] === false) {
                        window.showSecurityAlert('⚠️ هذا العنصر معطل حالياً', 'warning');
                        return;
                    }

                    if (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA') {
                        target.focus();
                        target.select(); // Highlight text for quick rewrite
                    } else if (target.tagName === 'SELECT') {
                        target.focus();
                        // Open dropdown logic can be tricky, native focus is best we can do.
                    } else {
                        target.click(); // Buttons, Links
                    }
                    console.log(`Executed shortcut for: ${s.target_element}`);
                }
                return;
            }
        }

        // 5. Table Navigation (Alt + Down/Up for Rows, Ctrl + Left/Right for Actions)
        if (localToggles.table) {
            // Find visible table
            const table = document.querySelector('table:not([style*="display: none"])');
            if (table) {
                const rows = Array.from(table.querySelectorAll('tbody tr:not([style*="display: none"])'));
                if (rows.length > 0) {
                    let focusedRowIdx = rows.findIndex(r => r.classList.contains('neon-yellow'));
                    
                    if (e.altKey && !e.ctrlKey && (key === 'arrowdown' || key === 'arrowup')) {
                        e.preventDefault();
                        if (focusedRowIdx >= 0) rows[focusedRowIdx].classList.remove('neon-yellow');
                        
                        if (focusedRowIdx === -1) {
                            focusedRowIdx = key === 'arrowdown' ? 0 : rows.length - 1;
                        } else {
                            if (key === 'arrowdown') focusedRowIdx = Math.min(focusedRowIdx + 1, rows.length - 1);
                            if (key === 'arrowup') focusedRowIdx = Math.max(focusedRowIdx - 1, 0);
                        }
                        
                        const targetRow = rows[focusedRowIdx];
                        applyNeon(targetRow, 'neon-yellow');
                        targetRow.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
                        return;
                    }
                    
                    // Row Operations (Ctrl + Left/Right)
                    if (e.ctrlKey && !e.altKey && focusedRowIdx >= 0 && (key === 'arrowleft' || key === 'arrowright')) {
                        e.preventDefault();
                        const row = rows[focusedRowIdx];
                        const actions = Array.from(row.querySelectorAll('button, a'));
                        
                        if(actions.length > 0) {
                            let actionIdx = actions.findIndex(a => a.classList.contains('neon-purple'));
                            if (actionIdx >= 0) actions[actionIdx].classList.remove('neon-purple');
                            
                            if (actionIdx === -1) {
                                actionIdx = 0;
                            } else {
                                if (key === 'arrowleft') actionIdx = Math.min(actionIdx + 1, actions.length - 1); // RTL visually Left is Next element physically
                                if (key === 'arrowright') actionIdx = Math.max(actionIdx - 1, 0);
                            }
                            
                            applyNeon(actions[actionIdx], 'neon-purple');
                            actions[actionIdx].focus();
                        }
                        return;
                    }
                }
            }
        }

    }, false); // Standard Phase (Capture phase in security.js intercepts first, but we bypassed it)

    // Initial Load execution
    detectInterface();
    loadInterfaceData();

    function toggleModal() {
        isModalOpen = !isModalOpen;
        modal.style.display = isModalOpen ? 'flex' : 'none';
        if (isModalOpen) {
            detectInterface();
            loadInterfaceData();
            modal.classList.remove('fullscreen');
            modal.classList.remove('minimized');
        }
    }

    return {
        toggleModal,
        toggleFullscreen: () => modal.classList.toggle('fullscreen'),
        minimize: () => modal.classList.toggle('minimized'),
        loadInterfaceData,
        saveSettings,
        saveLocalToggles,
        saveNewShortcut,
        deleteShortcut,
        isSystemShortcut,
        
        // System wide exposed triggers for UX
        toggleSystemGlow: (isActive) => {
            const state = isActive ? 'neon-green-flash' : 'neon-white-glow';
            applyNeon(interfaceSelect, state, 800);
        },
        triggerAutoSave: () => {
            applyNeon(document.body, 'neon-green-flash', 300);
        },
        triggerConflict: (hasConflict) => {
            applyNeon(document.body, hasConflict ? 'neon-red-flash' : 'neon-green-flash', 400);
        }
    };
})();
</script>
