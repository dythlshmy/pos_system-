<?php
ob_start();
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $title ?? 'سجل الحركات' ?></title>
    <link rel="stylesheet" href="<?= asset('css/style.css') ?>">
    <style>
        /* ===== المتغيرات العامة ===== */
        :root {
            --primary: #1a237e;
            --primary-light: #283593;
            --accent: #1976d2;
            --success: #2e7d32;
            --danger: #c62828;
            --warning: #ed6c02;
            --info: #0288d1;
            --gray-100: #f5f5f5;
            --gray-200: #e0e0e0;
            --gray-300: #bdbdbd;
            --gray-600: #214685ff;
            --gray-800: #111e45ff;
            --shadow: 0 2px 4px rgba(0,0,0,0.1);
            --shadow-lg: 0 4px 12px rgba(0,0,0,0.15);
        }

        /* ===== التخطيط العام ===== */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: var(--gray-100);
            height: 100vh;
            overflow: hidden;
        }

        .logs-page {
            height: calc(100vh - 60px);
            display: flex;
            gap: 15px;
            padding: 15px;
            overflow: hidden;
        }

        /* ===== الجانب الأيمن ===== */
        .right-panel {
            width: 280px;
            background: white;
            border-radius: 12px;
            box-shadow: var(--shadow);
            display: flex;
            flex-direction: column;
            overflow: hidden;
        }

        /* ===== رأس اللوحة ===== */
        .panel-header {
            padding: 15px;
            background: linear-gradient(135deg, var(--primary), var(--primary-light));
            color: white;
        }

        .panel-header h3 {
            font-size: 16px;
            font-weight: 600;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .panel-header h3 span {
            font-size: 20px;
        }

        /* ===== محتوى اللوحة ===== */
        .panel-content {
            flex: 1;
            overflow-y: auto;
            padding: 15px;
            scrollbar-width: thin;
            scrollbar-color: var(--accent) var(--gray-200);
        }

        .panel-content::-webkit-scrollbar {
            width: 6px;
        }

        .panel-content::-webkit-scrollbar-track {
            background: var(--gray-200);
            border-radius: 3px;
        }

        .panel-content::-webkit-scrollbar-thumb {
            background: var(--accent);
            border-radius: 3px;
        }

        /* ===== بطاقة الإحصائيات ===== */
        .stats-card {
            background: linear-gradient(135deg, var(--primary), var(--primary-light));
            color: white;
            border-radius: 10px;
            padding: 15px;
            margin-bottom: 15px;
        }

        .stats-title {
            font-size: 13px;
            opacity: 0.9;
            margin-bottom: 10px;
            display: flex;
            align-items: center;
            gap: 5px;
        }

        .stats-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 10px;
        }

        .stat-item {
            background: rgba(255,255,255,0.1);
            border-radius: 8px;
            padding: 10px;
            text-align: center;
        }

        .stat-number {
            font-size: 20px;
            font-weight: bold;
        }

        .stat-label {
            font-size: 10px;
            opacity: 0.8;
        }

        /* ===== مجموعة الفلاتر ===== */
        .filter-section {
            background: var(--gray-100);
            border-radius: 8px;
            padding: 12px;
            margin-bottom: 15px;
        }

        .filter-title {
            font-size: 13px;
            font-weight: 600;
            color: var(--gray-800);
            margin-bottom: 10px;
            display: flex;
            align-items: center;
            gap: 5px;
        }

        .filter-group {
            margin-bottom: 12px;
        }

        .filter-group label {
            display: block;
            font-size: 11px;
            color: var(--gray-600);
            margin-bottom: 4px;
        }

        .filter-control {
            width: 100%;
            height: 34px;
            padding: 0 8px;
            border: 1px solid var(--gray-200);
            border-radius: 6px;
            font-size: 12px;
            background: white;
        }

        .filter-control:focus {
            outline: none;
            border-color: var(--accent);
            box-shadow: 0 0 0 2px rgba(25,118,210,0.1);
        }

        /* ===== أزرار الإجراءات ===== */
        .action-buttons {
            display: flex;
            gap: 8px;
            margin-top: 15px;
        }

        .btn {
            height: 34px;
            padding: 0 12px;
            border: none;
            border-radius: 6px;
            font-size: 12px;
            font-weight: 500;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 5px;
            transition: all 0.3s;
            flex: 1;
        }

        .btn-primary {
            background: var(--accent);
            color: white;
        }

        .btn-primary:hover {
            background: #1565c0;
        }

        .btn-success {
            background: var(--success);
            color: white;
        }

        .btn-success:hover {
            background: #1b5e20;
        }

        .btn-back {
            background: var(--gray-600);
            color: white;
        }

        .btn-back:hover {
            background: var(--gray-800);
        }

        /* ===== الجانب الأيسر ===== */
        .left-panel {
            flex: 1;
            background: white;
            border-radius: 12px;
            box-shadow: var(--shadow);
            display: flex;
            flex-direction: column;
            overflow: hidden;
        }

        /* ===== شريط العنوان ===== */
        .left-header {
            padding: 15px;
            background: linear-gradient(135deg, var(--primary), var(--primary-light));
            color: white;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .left-header h2 {
            font-size: 18px;
            font-weight: 600;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .records-count {
            background: rgba(255,255,255,0.2);
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 12px;
        }

        /* ===== شريط البحث السريع ===== */
        .search-bar {
            padding: 12px 15px;
            background: var(--gray-100);
            border-bottom: 1px solid var(--gray-200);
        }

        .search-input {
            width: 100%;
            height: 36px;
            padding: 0 35px;
            border: 1px solid var(--gray-200);
            border-radius: 18px;
            font-size: 13px;
            background: white url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="%23757575" stroke-width="2"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>') no-repeat 12px center;
            background-size: 16px;
        }

        .search-input:focus {
            outline: none;
            border-color: var(--accent);
            box-shadow: 0 0 0 2px rgba(25,118,210,0.1);
        }

        /* ===== جدول السجل ===== */
        .table-container {
            flex: 1;
            overflow: auto;
            padding: 15px;
            scrollbar-width: thin;
            scrollbar-color: var(--accent) var(--gray-200);
        }

        .table-container::-webkit-scrollbar {
            width: 8px;
            height: 8px;
        }

        .table-container::-webkit-scrollbar-track {
            background: var(--gray-200);
            border-radius: 4px;
        }

        .table-container::-webkit-scrollbar-thumb {
            background: var(--accent);
            border-radius: 4px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            min-width: 900px;
            font-size: 13px;
        }

        th {
            background: var(--gray-200);
            padding: 12px;
            font-weight: 600;
            color: var(--gray-800);
            position: sticky;
            top: 0;
            z-index: 10;
            border-bottom: 2px solid var(--gray-300);
        }

        td {
            padding: 12px;
            border-bottom: 1px solid var(--gray-200);
            vertical-align: middle;
        }

        tr:hover {
            background: #f5f5f5;
        }

        /* ===== شارات الحالة ===== */
        .badge {
            display: inline-block;
            padding: 4px 10px;
            border-radius: 20px;
            font-size: 11px;
            font-weight: 500;
            white-space: nowrap;
        }

        .badge-add { background: #e8f5e8; color: #2e7d32; border: 1px solid #a5d6a7; }
        .badge-update { background: #e3f2fd; color: #1565c0; border: 1px solid #90caf9; }
        .badge-delete { background: #ffebee; color: #c62828; border: 1px solid #ef9a9a; }
        .badge-sell { background: #fff3e0; color: #e65100; border: 1px solid #ffb74d; }
        .badge-move { background: #e8eaf6; color: #1a237e; border: 1px solid #9fa8da; }
        .badge-default { background: var(--gray-100); color: var(--gray-600); border: 1px solid var(--gray-300); }

        /* ===== تنسيق الخلايا ===== */
        .text-center { text-align: center; }
        .text-right { text-align: right; }
        .text-left { text-align: left; }

        .user-info {
            display: flex;
            flex-direction: column;
        }

        .user-name {
            font-weight: 600;
            color: var(--primary);
        }

        .user-username {
            font-size: 10px;
            color: var(--gray-600);
        }

        .action-details {
            max-width: 300px;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }

        .action-details:hover {
            white-space: normal;
            word-wrap: break-word;
        }

        .ip-address {
            font-family: monospace;
            font-size: 11px;
            color: var(--gray-600);
        }

        /* ===== رسالة عدم وجود بيانات ===== */
        .empty-state {
            text-align: center;
            padding: 60px;
            color: var(--gray-600);
        }

        .empty-state .icon {
            font-size: 60px;
            margin-bottom: 20px;
            opacity: 0.5;
        }

        /* ===== شريط التحميل ===== */
        .loading {
            display: inline-block;
            width: 30px;
            height: 30px;
            border: 3px solid var(--gray-200);
            border-radius: 50%;
            border-top-color: var(--accent);
            animation: spin 1s ease-in-out infinite;
        }

        @keyframes spin {
            to { transform: rotate(360deg); }
        }

        /* ===== تجاوب ===== */
        @media (max-width: 1200px) {
            .logs-page {
                flex-direction: column;
            }
            .right-panel {
                width: 100%;
                height: auto;
            }
        }
    </style>
</head>
<body>

    <div class="logs-page">
        <!-- ===== الجانب الأيمن - لوحة التحكم ===== -->
        <div class="right-panel">
            <div class="panel-header">
                <h3>
                    <span>📊</span>
                    لوحة التحكم
                </h3>
            </div>
            
            <div class="panel-content">
                <!-- بطاقة إحصائيات اليوم -->
                <div class="stats-card">
                    <div class="stats-title">
                        <span>📅</span>
                        إحصائيات اليوم
                    </div>
                    <?php
                    $today = date('Y-m-d');
                    $todayStats = ['total' => 0, 'adds' => 0, 'updates' => 0, 'deletes' => 0, 'sales' => 0];
                    
                    foreach ($stats as $stat) {
                        if ($stat['date'] == $today) {
                            $todayStats = $stat;
                            break;
                        }
                    }
                    ?>
                    <div class="stats-grid">
                        <div class="stat-item">
                            <div class="stat-number"><?= $todayStats['total'] ?></div>
                            <div class="stat-label">إجمالي</div>
                        </div>
                        <div class="stat-item">
                            <div class="stat-number"><?= $todayStats['adds'] ?></div>
                            <div class="stat-label">إضافات</div>
                        </div>
                        <div class="stat-item">
                            <div class="stat-number"><?= $todayStats['updates'] ?></div>
                            <div class="stat-label">تحديثات</div>
                        </div>
                        <div class="stat-item">
                            <div class="stat-number"><?= $todayStats['deletes'] ?></div>
                            <div class="stat-label">حذف</div>
                        </div>
                        <div class="stat-item">
                            <div class="stat-number"><?= $todayStats['sales'] ?></div>
                            <div class="stat-label">مبيعات</div>
                        </div>
                    </div>
                </div>

                <!-- قسم الفلاتر -->
                <div class="filter-section">
                    <div class="filter-title">
                        <span>🔍</span>
                        فلاتر البحث
                    </div>
                    
                    <div class="filter-group">
                        <label>المستخدم</label>
                        <select class="filter-control" id="userFilter">
                            <option value="">كل المستخدمين</option>
                            <?php foreach ($users as $user): ?>
                                <option value="<?= $user['id'] ?>"><?= htmlspecialchars($user['full_name']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="filter-group">
                        <label>نوع الحركة</label>
                        <select class="filter-control" id="actionFilter">
                            <option value="">كل الحركات</option>
                            <option value="add">➕ إضافة</option>
                            <option value="update">✏️ تعديل</option>
                            <option value="delete">🗑️ حذف</option>
                            <option value="sell">💰 بيع</option>
                            <option value="move">🔄 نقل</option>
                            <option value="login">🔑 دخول</option>
                            <option value="logout">🚪 خروج</option>
                        </select>
                    </div>
                    
                    <div style="display: flex; gap: 8px;">
                        <div class="filter-group" style="flex: 1;">
                            <label>من تاريخ</label>
                            <input type="date" class="filter-control" id="dateFrom">
                        </div>
                        <div class="filter-group" style="flex: 1;">
                            <label>إلى تاريخ</label>
                            <input type="date" class="filter-control" id="dateTo">
                        </div>
                    </div>
                </div>

                <!-- أزرار الإجراءات -->
                <div class="action-buttons">
                    <button class="btn btn-primary" onclick="applyFilters()">
                        <span>🔍</span> بحث
                    </button>
                    <button class="btn btn-success" onclick="exportLogs()">
                        <span>📥</span> تصدير
                    </button>
                </div>
                
                <!-- زر العودة -->
                <div class="action-buttons" style="margin-top: 8px;">
                    <button class="btn btn-back" onclick="goBack()">
                        <span>🔙</span> عودة
                    </button>
                </div>
            </div>
        </div>

        <!-- ===== الجانب الأيسر - جدول السجل ===== -->
        <div class="left-panel">
            <div class="left-header">
                <h2>
                    <span>📋</span>
                    سجل الحركات
                </h2>
                <span class="records-count">إجمالي: <?= count($logs) ?></span>
            </div>
            
            <!-- شريط البحث السريع -->


            <!-- الجدول -->
            <div class="table-container">
                <table id="logsTable">
                    <thead>
                        <tr>
                            <th class="text-center">التاريخ والوقت</th>
                            <th class="text-center">المستخدم</th>
                            <th class="text-center">نوع الحركة</th>
                            <th class="text-center">التفاصيل</th>
                            <th class="text-center">IP</th>
                        </tr>
                    </thead>
                    <tbody id="logsTableBody">
                        <?php if (empty($logs)): ?>
                            <tr>
                                <td colspan="5">
                                    <div class="empty-state">
                                        <div class="icon">📊</div>
                                        <h3>لا توجد حركات في السجل</h3>
                                        <p>سيظهر هنا سجل جميع العمليات</p>
                                    </div>
                                </td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($logs as $log): ?>
                                <?php
                                // تحديد نوع الحركة
                                $action = $log['action'];
                                $badgeClass = 'badge-default';
                                $actionLabel = $action;
                                
                                if (strpos($action, 'add') !== false) {
                                    $badgeClass = 'badge-add';
                                    $actionLabel = '➕ إضافة';
                                } elseif (strpos($action, 'update') !== false) {
                                    $badgeClass = 'badge-update';
                                    $actionLabel = '✏️ تعديل';
                                } elseif (strpos($action, 'delete') !== false) {
                                    $badgeClass = 'badge-delete';
                                    $actionLabel = '🗑️ حذف';
                                } elseif (strpos($action, 'sell') !== false) {
                                    $badgeClass = 'badge-sell';
                                    $actionLabel = '💰 بيع';
                                } elseif (strpos($action, 'move') !== false) {
                                    $badgeClass = 'badge-move';
                                    $actionLabel = '🔄 نقل';
                                } elseif (strpos($action, 'login') !== false) {
                                    $badgeClass = 'badge-add';
                                    $actionLabel = '🔑 دخول';
                                } elseif (strpos($action, 'logout') !== false) {
                                    $badgeClass = 'badge-delete';
                                    $actionLabel = '🚪 خروج';
                                }
                                
                                $date = new DateTime($log['created_at']);
                                $formattedDate = $date->format('Y-m-d');
                                $formattedTime = $date->format('H:i:s');
                                ?>
                                <tr>
                                    <td class="text-center">
                                        <div style="font-weight: 500;"><?= $formattedDate ?></div>
                                        <div style="font-size: 11px; color: var(--gray-600);"><?= $formattedTime ?></div>
                                    </td>
                                    <td>
                                        <div class="user-info">
                                            <span class="user-name"><?= htmlspecialchars($log['user_name'] ?? 'غير معروف') ?></span>
                                            <span class="user-username">@<?= htmlspecialchars($log['username'] ?? 'unknown') ?></span>
                                        </div>
                                    </td>
                                    <td class="text-center">
                                        <span class="badge <?= $badgeClass ?>"><?= $actionLabel ?></span>
                                    </td>
                                    <td>
                                        <div class="action-details" title="<?= htmlspecialchars($log['details']) ?>">
                                            <?= htmlspecialchars($log['details']) ?>
                                        </div>
                                    </td>
                                    <td class="text-center">
                                        <span class="ip-address"><?= $log['ip_address'] ?? '-' ?></span>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <script>
        const BASE_URL = '<?= BASE_URL ?>';
        let searchTimeout = null;

        // دوال التنقل
        function goBack() {
            window.history.back();
        }

        // تطبيق الفلاتر
        // تطبيق الفلاتر - نسخة محسنة

     // تطبيق الفلاتر - نسخة محسنة
        // تطبيق الفلاتر
function applyFilters() {
    // جمع قيم الفلاتر
    const params = new URLSearchParams();
    
    // ✅ البحث النصي - الأهم
    const searchInput = document.getElementById('quickSearch')?.value;
    if (searchInput && searchInput.trim() !== '') {
        params.append('search', searchInput.trim());
    }
    
    const userFilter = document.getElementById('userFilter')?.value;
    if (userFilter) params.append('user_id', userFilter);
    
    const actionFilter = document.getElementById('actionFilter')?.value;
    if (actionFilter) params.append('action', actionFilter);
    
    const dateFrom = document.getElementById('dateFrom')?.value;
    if (dateFrom) params.append('date_from', dateFrom);
    
    const dateTo = document.getElementById('dateTo')?.value;
    if (dateTo) params.append('date_to', dateTo);

    console.log('🔍 جاري البحث بـ:', Object.fromEntries(params));

    showLoading();

    fetch(`${BASE_URL}/logs/search?${params}`)
        .then(response => {
            if (!response.ok) {
                throw new Error('Network error');
            }
            return response.json();
        })
        .then(data => {
            hideLoading();
            if (data.success) {
                updateTable(data.data);
                updateRecordsCount(data.count || data.data.length);
                if (data.data.length === 0) {
                    showMessage('لا توجد نتائج للبحث', 'info');
                }
            } else {
                showMessage(data.message || 'حدث خطأ في البحث', 'error');
            }
        })
        .catch(error => {
            hideLoading();
            console.error('❌ خطأ:', error);
            showMessage('حدث خطأ في الاتصال بالخادم', 'error');
        });
}
// دالة تحديث الجدول - محسنة
// تحديث الجدول - نسخة محسنة
function updateTable(logs) {
    const tbody = document.getElementById('logsTableBody');
    if (!tbody) return;

    tbody.innerHTML = '';

    if (logs.length === 0) {
        tbody.innerHTML = `
            <tr>
                <td colspan="5">
                    <div class="empty-state">
                        <div class="icon">🔍</div>
                        <h3>لا توجد نتائج</h3>
                        <p>حاول تغيير معايير البحث</p>
                    </div>
                </td>
            </tr>
        `;
        return;
    }

    logs.forEach(log => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td class="text-center">
                <div style="font-weight: 500;">${log.date || new Date(log.created_at).toLocaleDateString('ar-EG')}</div>
                <div style="font-size: 11px; color: var(--gray-600);">${log.time || new Date(log.created_at).toLocaleTimeString('ar-EG')}</div>
            </td>
            <td>
                <div class="user-info">
                    <span class="user-name">${log.user_name || 'غير معروف'}</span>
                    <span class="user-username">@${log.username || 'unknown'}</span>
                </div>
            </td>
            <td class="text-center">
                <span class="badge ${log.badge_class || 'badge-default'}">${log.display_action || log.action}</span>
            </td>
            <td>
                <div class="action-details" title="${log.details}">
                    ${log.details}
                </div>
            </td>
            <td class="text-center">
                <span class="ip-address">${log.ip_address || '-'}</span>
            </td>
        `;
        tbody.appendChild(row);
    });
}
        // البحث السريع
        document.getElementById('quickSearch').addEventListener('input', function() {
            clearTimeout(searchTimeout);
            searchTimeout = setTimeout(() => {
                applyFilters();
            }, 500);
        });

        // تحديث الجدول
        function updateTable(logs) {
            const tbody = document.getElementById('logsTableBody');
            if (!tbody) return;

            tbody.innerHTML = '';

            if (logs.length === 0) {
                tbody.innerHTML = `
                    <tr>
                        <td colspan="5">
                            <div class="empty-state">
                                <div class="icon">🔍</div>
                                <h3>لا توجد نتائج</h3>
                                <p>حاول تغيير معايير البحث</p>
                            </div>
                        </td>
                    </tr>
                `;
                return;
            }

            logs.forEach(log => {
                // تحديد نوع الحركة
                let badgeClass = 'badge-default';
                let actionLabel = log.action;
                
                if (log.action.includes('add')) {
                    badgeClass = 'badge-add';
                    actionLabel = '➕ إضافة';
                } else if (log.action.includes('update')) {
                    badgeClass = 'badge-update';
                    actionLabel = '✏️ تعديل';
                } else if (log.action.includes('delete')) {
                    badgeClass = 'badge-delete';
                    actionLabel = '🗑️ حذف';
                } else if (log.action.includes('sell')) {
                    badgeClass = 'badge-sell';
                    actionLabel = '💰 بيع';
                } else if (log.action.includes('move')) {
                    badgeClass = 'badge-move';
                    actionLabel = '🔄 نقل';
                } else if (log.action.includes('login')) {
                    badgeClass = 'badge-add';
                    actionLabel = '🔑 دخول';
                } else if (log.action.includes('logout')) {
                    badgeClass = 'badge-delete';
                    actionLabel = '🚪 خروج';
                }

                const date = new Date(log.created_at);
                const formattedDate = date.toLocaleDateString('ar-EG');
                const formattedTime = date.toLocaleTimeString('ar-EG');

                const row = document.createElement('tr');
                row.innerHTML = `
                    <td class="text-center">
                        <div style="font-weight: 500;">${formattedDate}</div>
                        <div style="font-size: 11px; color: var(--gray-600);">${formattedTime}</div>
                    </td>
                    <td>
                        <div class="user-info">
                            <span class="user-name">${log.user_name || 'غير معروف'}</span>
                            <span class="user-username">@${log.username || 'unknown'}</span>
                        </div>
                    </td>
                    <td class="text-center">
                        <span class="badge ${badgeClass}">${actionLabel}</span>
                    </td>
                    <td>
                        <div class="action-details" title="${log.details}">
                            ${log.details}
                        </div>
                    </td>
                    <td class="text-center">
                        <span class="ip-address">${log.ip_address || '-'}</span>
                    </td>
                `;
                tbody.appendChild(row);
            });
        }

        // تحديث عداد السجلات
        function updateRecordsCount(count) {
            const counter = document.querySelector('.records-count');
            if (counter) {
                counter.textContent = `إجمالي: ${count}`;
            }
        }

        // تصدير السجل
        function exportLogs() {
            const params = new URLSearchParams({
                user_id: document.getElementById('userFilter').value,
                action: document.getElementById('actionFilter').value,
                date_from: document.getElementById('dateFrom').value,
                date_to: document.getElementById('dateTo').value,
                search: document.getElementById('quickSearch').value
            });
            window.location.href = `${BASE_URL}/logs/export?${params}`;
        }

        // إظهار مؤشر التحميل
        function showLoading() {
            let loader = document.getElementById('tableLoader');
            if (!loader) {
                loader = document.createElement('div');
                loader.id = 'tableLoader';
                loader.className = 'loading';
                loader.style.position = 'absolute';
                loader.style.top = '50%';
                loader.style.left = '50%';
                loader.style.transform = 'translate(-50%, -50%)';
                document.querySelector('.table-container').style.position = 'relative';
                document.querySelector('.table-container').appendChild(loader);
            }
        }

        // إخفاء مؤشر التحميل
        function hideLoading() {
            const loader = document.getElementById('tableLoader');
            if (loader) loader.remove();
        }

        // عرض رسالة
       // عرض الرسائل
function showMessage(message, type = 'success') {
    const alertDiv = document.createElement('div');
    alertDiv.className = `alert alert-${type}`;
    alertDiv.textContent = message;
    alertDiv.style.cssText = `
        position: fixed;
        top: 20px;
        left: 50%;
        transform: translateX(-50%);
        z-index: 9999;
        min-width: 300px;
        text-align: center;
        padding: 12px 20px;
        border-radius: 8px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        animation: slideDown 0.3s ease;
        background: ${type === 'success' ? '#d4edda' : (type === 'error' ? '#f8d7da' : '#fff3cd')};
        color: ${type === 'success' ? '#155724' : (type === 'error' ? '#721c24' : '#856404')};
        border: 1px solid ${type === 'success' ? '#c3e6cb' : (type === 'error' ? '#f5c6cb' : '#ffeeba')};
    `;
    
    document.body.appendChild(alertDiv);
    
    setTimeout(() => {
        alertDiv.remove();
    }, 3000);
}

        // دعم مفتاح Enter
        document.getElementById('quickSearch').addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                applyFilters();
            }
        });
    </script>

    <style>
        @keyframes slideDown {
            from {
                transform: translate(-50%, -100%);
                opacity: 0;
            }
            to {
                transform: translate(-50%, 0);
                opacity: 1;
            }
        }
        
        .alert-success { background: #d4edda; color: #155724; border-color: #c3e6cb; }
        .alert-error { background: #f8d7da; color: #721c24; border-color: #f5c6cb; }
        .alert-warning { background: #fff3cd; color: #856404; border-color: #ffeeba; }
    </style>
</body>
</html>

<?php
$content = ob_get_clean();
require BASE_PATH . 'views/layouts/main.php';
?>