// ============================================================
// ملف: fix-false.js - إزالة false بصرياً فقط دون كسر النظام
// ============================================================

(function safeFixFalse() {
    'use strict';

    // 1. وظيفة التنظيف البصري: تحول false إلى فراغ إذا كان الغرض هو العرض فقط
    const visualCleanup = (value) => {
        return (value === false || value === 'false') ? '' : value;
    };

    // 2. إصلاح innerHTML و textContent (للعرض فقط)
    // تم استثناء المدخلات (Inputs) لضمان عدم مسح بيانات النماذج
    const originalInnerHTML = Object.getOwnPropertyDescriptor(Element.prototype, 'innerHTML');
    Object.defineProperty(Element.prototype, 'innerHTML', {
        get: originalInnerHTML.get,
        set: function(value) {
            return originalInnerHTML.set.call(this, visualCleanup(value));
        }
    });

    const originalTextContent = Object.getOwnPropertyDescriptor(Node.prototype, 'textContent');
    Object.defineProperty(Node.prototype, 'textContent', {
        get: originalTextContent.get,
        set: function(value) {
            return originalTextContent.set.call(this, visualCleanup(value));
        }
    });

    // 3. مراقبة التغيرات في الصفحة (DOM Observer)
    // هذا الجزء يضمن أن أي نص "false" يظهر في الجدول سيختفي فوراً
    const observer = new MutationObserver(function(mutations) {
        mutations.forEach(function(mutation) {
            // تنظيف النصوص المباشرة
            if (mutation.type === 'characterData') {
                if (mutation.target.nodeValue === 'false') {
                    mutation.target.nodeValue = '';
                }
            }
            
            // تنظيف العناصر الجديدة المضافة (مثل صفوف الجدول الجديدة)
            if (mutation.type === 'childList') {
                mutation.addedNodes.forEach(function(node) {
                    if (node.nodeType === 3 && node.nodeValue === 'false') {
                        node.nodeValue = '';
                    }
                    if (node.nodeType === 1) { // إذا كان عنصر HTML
                        node.querySelectorAll('*').forEach(el => {
                           if(el.textContent === 'false') el.textContent = '';
                        });
                    }
                });
            }
        });
    });

    // 4. تشغيل المراقبة بعد تحميل الصفحة
    const startObserver = () => {
        if (document.body) {
            observer.observe(document.body, {
                childList: true,
                subtree: true,
                characterData: true
            });
            fixExistingElements();
        }
    };

    // 5. دالة لإصلاح العناصر الموجودة مسبقاً عند تحميل الصفحة
    function fixExistingElements() {
        document.querySelectorAll('*').forEach(element => {
            element.childNodes.forEach(node => {
                if (node.nodeType === 3 && node.nodeValue === 'false') {
                    node.nodeValue = '';
                }
            });
        });
    }

    // التنفيذ
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', startObserver);
    } else {
        startObserver();
    }

    // ملاحظة: تم حذف تعديلات JSON.parse و JSON.stringify 
    // لأنها كانت تسبب خللاً في قراءة توكن الجلسة (Session Token) مما يؤدي لتسجيل الخروج.
    
    console.log('✅ نظام إخفاء false الآمن يعمل الآن دون التأثير على الجلسة');
})();
