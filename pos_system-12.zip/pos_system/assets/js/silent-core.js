/**
 * OmniCore Engine v17.6 - "The Stable Professional"
 * شريط تقدم متوهج بألوان الطيف - يظهر أسفل شريط التحكم تلقائياً
 */

const OmniCore = (function() {
    "use strict";

    const State = {
        isReady: false,
        lastRequestTime: 0,
        searchTimer: null
    };

    // 1. درع الحماية البصري + شريط التقدم المطور
    const injectShield = () => {
        if (document.getElementById('omni-v17-style')) return;
        const style = document.createElement('style');
        style.id = 'omni-v17-style';
        style.innerHTML = `
            #loadingOverlay, .loading, .spinner-border, .wait-msg, #preloader { display: none !important; }
            .modal, .sweet-alert, .swal2-container, [id*="Modal"] { display: block; opacity: 1 !important; visibility: visible !important; pointer-events: auto !important; z-index: 99999 !important; }
            
            /* شريط التقدم المتوهج - الموضع يتم ضبطه بواسطة JavaScript */
            #omni-progress {
                position: fixed;
                left: 0;
                width: 0;
                height: 4px;
                background: linear-gradient(
                    90deg,
                    #ff0000,  /* أحمر */
                    #ff7700,  /* برتقالي */
                    #ffff00,  /* أصفر */
                    #00ff00,  /* أخضر */
                    #0000ff,  /* أزرق */
                    #4b0082,  /* نيلي */
                    #8f00ff,  /* بنفسجي */
                    #ff00ff,  /* أرجواني */
                    #ff0066,  /* وردي */
                    #00ffff,  /* فيروزي */
                    #ff6600,  /* يوسفي */
                    #cc00ff   /* لافندر */
                );
                background-size: 300% 100%;
                z-index: 100000;
                transition: width 0.15s cubic-bezier(0.4, 0, 0.2, 1);
                border-radius: 0 4px 4px 0;
                box-shadow: 
                    0 0 8px rgba(255,0,0,0.8),
                    0 0 12px rgba(255,255,0,0.6),
                    0 0 16px rgba(0,255,0,0.5),
                    0 0 20px rgba(0,255,255,0.4),
                    0 0 24px rgba(255,0,255,0.3);
                filter: brightness(1.2) saturate(1.5);
                animation: spectralWave 1.2s linear infinite, glassPulse 1.8s ease-in-out infinite;
                backdrop-filter: blur(2px);
            }
            
            /* توهج إضافي لشريط التقدم */
            #omni-progress::before {
                content: '';
                position: absolute;
                top: 0;
                left: 0;
                right: 0;
                bottom: 0;
                background: inherit;
                filter: blur(8px);
                opacity: 0.7;
                z-index: -1;
                border-radius: inherit;
            }
            
            /* تأثير لمعان إضافي */
            #omni-progress::after {
                content: '';
                position: absolute;
                top: -2px;
                left: 0;
                right: 0;
                height: 8px;
                background: radial-gradient(ellipse at center, rgba(255,255,255,0.9) 0%, rgba(255,255,255,0) 80%);
                opacity: 0.6;
                border-radius: 4px;
                animation: shimmerMove 1s linear infinite;
            }
            
            /* حركة الأمواج الطيفية */
            @keyframes spectralWave {
                0% {
                    background-position: 0% 50%;
                }
                100% {
                    background-position: 300% 50%;
                }
            }
            
            /* نبض زجاجي متوهج */
            @keyframes glassPulse {
                0%, 100% {
                    box-shadow: 
                        0 0 8px rgba(255,0,0,0.6),
                        0 0 12px rgba(255,255,0,0.4),
                        0 0 16px rgba(0,255,0,0.3),
                        0 0 20px rgba(0,255,255,0.2);
                    filter: brightness(1.1) saturate(1.3);
                }
                50% {
                    box-shadow: 
                        0 0 16px rgba(255,0,0,0.9),
                        0 0 24px rgba(255,255,0,0.7),
                        0 0 32px rgba(0,255,0,0.6),
                        0 0 40px rgba(0,255,255,0.5),
                        0 0 48px rgba(255,0,255,0.4);
                    filter: brightness(1.4) saturate(1.8);
                }
            }
            
            /* حركة اللمعان */
            @keyframes shimmerMove {
                0% {
                    opacity: 0.3;
                    transform: translateX(-100%);
                }
                50% {
                    opacity: 0.8;
                }
                100% {
                    opacity: 0.3;
                    transform: translateX(100%);
                }
            }
            
            body.working { cursor: wait !important; }
        `;
        document.head.appendChild(style);
    };

    // 1.5 ضبط موضع شريط التقدم أسفل شريط التحكم تلقائياً
    const setProgressBarPosition = () => {
        const nav = document.querySelector('.top-nav');
        const progress = document.getElementById('omni-progress');
        
        if (nav && progress) {
            const navRect = nav.getBoundingClientRect();
            progress.style.top = navRect.bottom + 'px';
        } else if (progress) {
            // إذا لم يوجد .top-nav نضعها في أعلى الصفحة كحل احتياطي
            progress.style.top = '0px';
        }
    };

    // 2. معالج العمليات الخلفية المطور (Smart Interceptor)
    const setupFetchInterceptor = () => {
        const _originalFetch = window.fetch;
        window.fetch = async function(...args) {
            const now = Date.now();
            if (now - State.lastRequestTime < 100 && args[1]?.method === 'POST') {
                return new Promise((resolve) => resolve(new Response(JSON.stringify({status:'ignored'}))));
            }
            State.lastRequestTime = now;

            const progress = document.getElementById('omni-progress');
            if (progress) {
                progress.style.width = '30%';
                progress.style.opacity = '1';
            }
            
            let options = args[1] || {};
            options.headers = { ...options.headers, 'X-Requested-With': 'XMLHttpRequest' };

            try {
                const response = await _originalFetch(args[0], options);
                
                if (response.status === 401) window.location.reload();

                if (progress) {
                    progress.style.width = '100%';
                    setTimeout(() => {
                        if (progress) progress.style.opacity = '0.5';
                    }, 200);
                }
                return response;
            } catch (error) {
                if (progress) {
                    progress.style.width = '0%';
                    progress.style.opacity = '0.3';
                }
                throw error;
            } finally {
                setTimeout(() => { 
                    if (progress) {
                        progress.style.width = '0%';
                        setTimeout(() => {
                            if (progress) progress.style.opacity = '1';
                        }, 300);
                    }
                }, 400);
            }
        };
    };

    // 3. المراقب الذكي الخفيف (Efficient Observer)
    const startObserver = () => {
        const observer = new MutationObserver((mutations) => {
            for (let mutation of mutations) {
                for (let node of mutation.addedNodes) {
                    if (node.nodeType === 1) {
                        const id = node.id || "";
                        const cls = node.className || "";
                        if (id === 'productAnalyticsModal') { node.style.display = 'flex'; continue; }
                        if (id.includes('loading') || cls.includes('loader') || cls.includes('wait-msg')) {
                            node.style.display = 'none';
                            node.remove();
                        }
                    }
                }
            }
            // إعادة ضبط الموضع عند إضافة عناصر جديدة (لأن الـ nav قد يتغير)
            setProgressBarPosition();
        });
        observer.observe(document.documentElement, { childList: true, subtree: true });
    };

    // 4. تهيئة النظام
    const init = () => {
        if (State.isReady) return;
        injectShield();
        setupFetchInterceptor();
        startObserver();

        if (!document.getElementById('omni-progress')) {
            const bar = document.createElement('div');
            bar.id = 'omni-progress';
            document.body.appendChild(bar);
        }

        // ضبط الموضع عند التحميل
        setProgressBarPosition();
        
        // إعادة ضبط الموضع عند تغيير حجم النافذة
        window.addEventListener('resize', setProgressBarPosition);
        
        // إعادة ضبط الموضع عند التمرير (للتأكد من الثبات)
        window.addEventListener('scroll', setProgressBarPosition);

        // تحييد دوال التحميل القديمة
        window.showLoading = () => true;
        window.hideLoading = () => true;

        State.isReady = true;
        console.log("%c🚀 OmniCore v17.6: شريط التقدم يظهر أسفل شريط التحكم تلقائياً - توهج طيفي زجاجي", "color: #ff77ff; font-weight: bold; font-size: 12px;");
    };

    // 5. محرك البحث اللحظي الفائق
    window.turboSearch = function(inputElement, callback) {
        if (!inputElement) return;
        inputElement.addEventListener('input', function() {
            clearTimeout(State.searchTimer);
            State.searchTimer = setTimeout(() => callback(this.value), 80);
        });
    };

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }

    return { forceHide: () => window.hideLoading() };
})();