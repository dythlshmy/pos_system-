const fs = require('fs');
const file = 'c:/xampp/htdocs/pos_system/assets/js/inventory.js';
let content = fs.readFileSync(file, 'utf8');

const startIndex = content.indexOf('<div class="modal-footer" style="justify-content: center; gap: 15px;">');
const endIndex = content.indexOf('document.body.appendChild(modal);', startIndex) + 'document.body.appendChild(modal);'.length;

const cleanFunction = `<div class="modal-footer" style="justify-content: center; gap: 15px;">
                <button type="button" class="btn btn-success" id="btnYes_\${modalId}" onclick="if(!this.disabled){this.disabled=true; executeConfirm('\${modalId}', true);}">✅ نعم، متأكد</button>
                <button type="button" class="btn btn-danger" onclick="executeConfirm('\${modalId}', false)">❌ إلغاء</button>
            </div>
        </div>
    \`;
    
    window.confirmCallbacks = window.confirmCallbacks || {};
    window.confirmCallbacks[modalId] = {
        onConfirm: onConfirm,
        onCancel: onCancel
    };
    
    document.body.appendChild(modal);

    setTimeout(() => {
        const yesBtn = document.getElementById(\`btnYes_\${modalId}\`);
        if (yesBtn) {
            yesBtn.focus();
        }
    }, 10);`;

content = content.substring(0, startIndex) + cleanFunction + content.substring(endIndex);
fs.writeFileSync(file, content, 'utf8');
