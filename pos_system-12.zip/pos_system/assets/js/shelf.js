// ============================================
// ملف shelf.js - الإصدار النهائي والكامل
// ============================================

// متغيرات عامة
let currentShelfId = null;
let currentFilter = 'all';

// ===== تهيئة الصفحة =====
document.addEventListener('DOMContentLoaded', function() {
    console.log('✅ تم تحميل صفحة رف البيع');
    
    // منع القوائم والاختصارات
    disableContextMenu();
});

// ===== منع القوائم والاختصارات =====
function disableContextMenu() {
    document.addEventListener('contextmenu', function(e) {
        if (e.target.tagName !== 'INPUT' && e.target.tagName !== 'TEXTAREA') {
            e.preventDefault();
            return false;
        }
    });
    
    document.addEventListener('keydown', function(e) {
        if (e.ctrlKey && (e.key === 'c' || e.key === 'C' || 
                          e.key === 's' || e.key === 'S' || 
                          e.key === 'p' || e.key === 'P')) {
            e.preventDefault();
            return false;
        }
    });
}

// ===== دوال التبديل بين اللوحات =====
function switchPanel(panel) {
    document.querySelectorAll('.tab-btn').forEach(btn => btn.classList.remove('active'));
    document.querySelectorAll('.panel').forEach(p => p.classList.remove('active'));
    
    if (panel === 'stats') {
        document.querySelectorAll('.tab-btn')[0].classList.add('active');
        document.getElementById('statsPanel').classList.add('active');
    } else {
        document.querySelectorAll('.tab-btn')[1].classList.add('active');
        document.getElementById('batchesPanel').classList.add('active');
        loadBatches();
    }
}

// ===== دوال البحث والتصفية =====
function searchShelf() {
    const barcode = document.getElementById('barcodeSearch')?.value || '';
    const product = document.getElementById('productSearch')?.value || '';
    
    const rows = document.querySelectorAll('#shelfTableBody tr');
    
    rows.forEach(row => {
        const productName = row.querySelector('.product-name')?.textContent.toLowerCase() || '';
        let show = true;
        
        if (product && !productName.includes(product.toLowerCase())) show = false;
        
        if (currentFilter !== 'all') {
            const statusCell = row.querySelector('.status-badge')?.textContent || '';
            if (currentFilter === 'available' && !statusCell.includes('متاح')) show = false;
            if (currentFilter === 'low' && !statusCell.includes('منخفض')) show = false;
            if (currentFilter === 'expired' && !statusCell.includes('منتهي')) show = false;
        }
        
        row.style.display = show ? '' : 'none';
    });
}

function filterShelf(filter) {
    currentFilter = filter;
    
    document.querySelectorAll('.filter-chip').forEach(chip => {
        chip.classList.remove('active');
    });
    event.target.classList.add('active');
    
    searchShelf();
}

function filterByStat(type) {
    if (type === 'all') {
        document.querySelector('.filter-chip.all')?.click();
    } else if (type === 'available') {
        document.querySelector('.filter-chip.available')?.click();
    } else if (type === 'low') {
        document.querySelector('.filter-chip.low')?.click();
    } else if (type === 'expired') {
        document.querySelector('.filter-chip.expired')?.click();
    }
}

// ===== دوال النوافذ المنبثقة =====
function showDetails(id) {
    showLoading('جاري تحميل البيانات...');
    
    // استخدم الرابط القديم الذي كان يعمل
    fetch(`${BASE_URL}/inventory/get-batch-details?id=${id}`)
        .then(response => response.json())
        .then(data => {
            hideLoading();
            
            if (data.success) {
                // عرض البيانات
                const batch = data.data.batch;
                const product = data.data.product;
                
                alert(`📋 تفاصيل الكرتون
                
رقم الدفعة: ${batch.batch_number}
المنتج: ${product.name}
الكراتين المتبقية: ${batch.cartons_remaining}
سعر الوحدة: ${batch.selling_price_unit} ₪
تاريخ الانتهاء: ${batch.expiry_date}`);
                
            } else {
                alert('خطأ: ' + data.message);
            }
        })
        .catch(error => {
            hideLoading();
            alert('حدث خطأ: ' + error.message);
        });
}

function showDetailsModal(data) {
    const shelfItem = data.shelf_item || {};
    const batch = data.batch || {};
    const product = data.product || {};
    
    const modal = document.createElement('div');
    modal.className = 'modal';
    modal.innerHTML = `
        <div class="modal-content" style="max-width: 500px;">
            <div class="modal-header">
                <h3>📋 تفاصيل الكرتون</h3>
                <button class="modal-close" onclick="this.closest('.modal').remove()">×</button>
            </div>
            <div class="modal-body">
                <div style="background: #f5f5f5; padding: 15px; border-radius: 8px; margin-bottom: 20px;">
                    <p><strong>المنتج:</strong> ${product.name || 'غير معروف'}</p>
                    <p><strong>كود الرف:</strong> ${shelfItem.shelf_code || '---'}</p>
                    <p><strong>الباركود:</strong> ${product.barcode || '---'}</p>
                </div>
                
                <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 10px; margin-bottom: 20px;">
                    <div style="background: #e3f2fd; padding: 15px; border-radius: 8px; text-align: center;">
                        <div style="font-size: 24px; font-weight: bold;">${shelfItem.units_remaining || 0}</div>
                        <div style="font-size: 12px;">الوحدات</div>
                    </div>
                    <div style="background: #e8f5e8; padding: 15px; border-radius: 8px; text-align: center;">
                        <div style="font-size: 24px; font-weight: bold;">${parseFloat(shelfItem.selling_price_unit || 0).toFixed(2)} ₪</div>
                        <div style="font-size: 12px;">السعر</div>
                    </div>
                    <div style="background: #fff3e0; padding: 15px; border-radius: 8px; text-align: center;">
                        <div style="font-size: 24px; font-weight: bold;">${batch.expiry_date ? batch.expiry_date.substring(5) : '---'}</div>
                        <div style="font-size: 12px;">انتهاء</div>
                    </div>
                </div>
                
                <div style="text-align: center;">
                    <button class="modal-btn secondary" onclick="this.closest('.modal').remove()">إغلاق</button>
                </div>
            </div>
        </div>
    `;
    document.body.appendChild(modal);
}

function editShelf(id) {
    currentShelfId = id;
    
    showLoading('جاري تحميل البيانات...');
    
    fetch(`${BASE_URL}/shelf/item-details?id=${id}`)
        .then(response => response.json())
        .then(data => {
            hideLoading();
            
            if (data.success) {
                showEditModal(data.data);
            } else {
                showMessage('خطأ: ' + (data.message || 'فشل تحميل البيانات'), 'error');
            }
        })
        .catch(error => {
            hideLoading();
            console.error('Error:', error);
            showMessage('حدث خطأ في الاتصال بالخادم', 'error');
        });
}

function showEditModal(data) {
    const shelfItem = data.shelf_item || {};
    const product = data.product || {};
    
    const modal = document.createElement('div');
    modal.className = 'modal';
    modal.innerHTML = `
        <div class="modal-content" style="max-width: 450px;">
            <div class="modal-header">
                <h3>✏️ تعديل الكرتون</h3>
                <button class="modal-close" onclick="this.closest('.modal').remove()">×</button>
            </div>
            <div class="modal-body">
                <div style="background: #f5f5f5; padding: 10px; border-radius: 6px; margin-bottom: 15px;">
                    <p><strong>المنتج:</strong> ${product.name || 'غير معروف'}</p>
                    <p><strong>كود الرف:</strong> ${shelfItem.shelf_code || '---'}</p>
                </div>
                
                <div style="margin-bottom: 15px;">
                    <label style="display: block; margin-bottom: 5px;">الوحدات المتبقية</label>
                    <input type="number" id="editUnits" class="page-size-select" style="width: 100%;" value="${shelfItem.units_remaining || 0}">
                </div>
                
                <div style="margin-bottom: 15px;">
                    <label style="display: block; margin-bottom: 5px;">سعر البيع</label>
                    <input type="number" step="0.01" id="editPrice" class="page-size-select" style="width: 100%;" value="${shelfItem.selling_price_unit || 0}">
                </div>
                
                <div style="margin-bottom: 15px;">
                    <label style="display: block; margin-bottom: 5px;">الحالة</label>
                    <select id="editStatus" class="page-size-select" style="width: 100%;">
                        <option value="available" ${shelfItem.status === 'available' ? 'selected' : ''}>🟢 متاح</option>
                        <option value="low_stock" ${shelfItem.status === 'low_stock' ? 'selected' : ''}>🟡 منخفض</option>
                        <option value="out_of_stock" ${shelfItem.status === 'out_of_stock' ? 'selected' : ''}>🔴 نافد</option>
                        <option value="expired" ${shelfItem.status === 'expired' ? 'selected' : ''}>🔴 منتهي</option>
                    </select>
                </div>
                
                <div style="display: flex; gap: 10px; margin-top: 20px;">
                    <button class="modal-btn primary" onclick="saveEdit(${shelfItem.id})">💾 حفظ</button>
                    <button class="modal-btn secondary" onclick="this.closest('.modal').remove()">إلغاء</button>
                </div>
            </div>
        </div>
    `;
    document.body.appendChild(modal);
}

function saveEdit(id) {
    const units = document.getElementById('editUnits')?.value;
    const price = document.getElementById('editPrice')?.value;
    const status = document.getElementById('editStatus')?.value;
    
    if (!units || !price || !status) {
        showMessage('جميع الحقول مطلوبة', 'warning');
        return;
    }
    
    const formData = new URLSearchParams();
    formData.append('id', id);
    formData.append('units_remaining', units);
    formData.append('selling_price_unit', price);
    formData.append('status', status);
    
    showLoading('جاري حفظ التعديلات...');
    
    fetch(`${BASE_URL}/shelf/update-item`, {
        method: 'POST',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        hideLoading();
        
        if (data.success) {
            document.querySelector('.modal').remove();
            showMessage('تم التحديث بنجاح', 'success');
            setTimeout(() => location.reload(), 1500);
        } else {
            showMessage(data.message || 'فشل التحديث', 'error');
        }
    })
    .catch(error => {
        hideLoading();
        console.error('Error:', error);
        showMessage('حدث خطأ في الاتصال', 'error');
    });
}

function confirmDelete(id, code, product) {
    const modal = document.createElement('div');
    modal.className = 'modal';
    modal.innerHTML = `
        <div class="modal-content" style="max-width: 400px;">
            <div class="modal-header">
                <h3 style="color: #c62828;">🗑️ تأكيد الحذف</h3>
                <button class="modal-close" onclick="this.closest('.modal').remove()">×</button>
            </div>
            <div class="modal-body" style="text-align: center;">
                <p style="font-size: 16px; margin-bottom: 15px;">هل أنت متأكد من حذف هذا الكرتون؟</p>
                <p style="font-weight: bold; margin-bottom: 5px;">${code || ''}</p>
                <p style="color: #666; margin-bottom: 20px;">${product || ''}</p>
                <div style="display: flex; gap: 10px;">
                    <button class="modal-btn primary" style="background: #c62828;" onclick="deleteShelf(${id})">نعم، احذف</button>
                    <button class="modal-btn secondary" onclick="this.closest('.modal').remove()">إلغاء</button>
                </div>
            </div>
        </div>
    `;
    document.body.appendChild(modal);
}

function deleteShelf(id) {
    document.querySelector('.modal').remove();
    
    const formData = new URLSearchParams();
    formData.append('id', id);
    
    showLoading('جاري الحذف...');
    
    fetch(`${BASE_URL}/shelf/delete-item`, {
        method: 'POST',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        hideLoading();
        
        if (data.success) {
            showMessage('تم الحذف بنجاح', 'success');
            setTimeout(() => location.reload(), 1500);
        } else {
            showMessage(data.message || 'فشل الحذف', 'error');
        }
    })
    .catch(error => {
        hideLoading();
        console.error('Error:', error);
        showMessage('حدث خطأ في الاتصال', 'error');
    });
}

// ===== دوال اللوحات =====
function toggleDropdown() {
    const content = document.getElementById('infoDropdown');
    const icon = document.querySelector('.dropdown-icon');
    
    if (content.classList.contains('active')) {
        content.classList.remove('active');
        icon.textContent = '▼';
    } else {
        content.classList.add('active');
        icon.textContent = '▲';
    }
}

function loadBatches() {
    // يمكن إضافة طلب AJAX لاحقاً
}

// ===== دوال التحديث =====
function refreshStats() {
    location.reload();
}

function refreshData() {
    location.reload();
}

function exportToExcel() {
    window.location.href = `${BASE_URL}/reports/export-excel?type=shelf`;
}

function printTable() {
    window.print();
}

function changePageSize(size) {
    // للتوسع المستقبلي
}

function focusBarcode() {
    document.getElementById('barcodeSearch').focus();
}

// ===== دوال مساعدة =====
function showLoading(message = 'جاري التحميل...') {
    const loader = document.createElement('div');
    loader.id = 'loadingOverlay';
    loader.style.cssText = `
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: rgba(0,0,0,0.5);
        display: flex;
        align-items: center;
        justify-content: center;
        z-index: 20000;
    `;
    
    loader.innerHTML = `
        <div style="background: white; padding: 20px 40px; border-radius: 8px; text-align: center;">
            <div style="font-size: 30px; margin-bottom: 10px;">⏳</div>
            <div>${message}</div>
        </div>
    `;
    
    document.body.appendChild(loader);
}

function hideLoading() {
    const loader = document.getElementById('loadingOverlay');
    if (loader) loader.remove();
}

function showMessage(message, type = 'success') {
    const msgDiv = document.createElement('div');
    msgDiv.style.cssText = `
        position: fixed;
        top: 20px;
        left: 50%;
        transform: translateX(-50%);
        background: ${type === 'success' ? '#2e7d32' : type === 'error' ? '#c62828' : '#ed6c02'};
        color: white;
        padding: 12px 24px;
        border-radius: 4px;
        font-size: 14px;
        box-shadow: 0 2px 8px rgba(0,0,0,0.2);
        z-index: 21000;
    `;
    
    msgDiv.innerHTML = `
        <span style="margin-right: 8px;">${type === 'success' ? '✅' : type === 'error' ? '❌' : '⚠️'}</span>
        ${message}
    `;
    
    document.body.appendChild(msgDiv);
    
    setTimeout(() => {
        msgDiv.remove();
    }, 3000);
}

console.log('✅ تم تحميل shelf.js بنجاح');