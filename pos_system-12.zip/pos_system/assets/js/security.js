// ============================================
// ملف: security.js - الحماية المتكاملة للنظام (نسخة محسنة - تم إزالة منع التخزين المؤقت)
// ============================================
// يوفر حماية كاملة ضد جميع خصائص المتصفح:
// - منع حفظ كلمات المرور
// - منع اختصارات لوحة المفاتيح (إنجليزي + عربي)
// - منع القائمة اليمنى
// - منع الطباعة
// - منع حفظ الصفحة
// - منع تحديد النص
// - منع DevTools
// - منع رسائل المتصفح
// - منع فتح تبويبات جديدة
// - منع السحب والإفلات
// ============================================

(function secureSystem() {
    'use strict';

    // ============================================
    // 1. CSS للحماية (منع تحديد النص وإخفاء أيقونات كلمة المرور)
    // ============================================
    const style = document.createElement('style');
    style.textContent = `
        /* منع تحديد النص في جميع العناصر */
        * {
            user-select: none !important;
            -webkit-user-select: none !important;
            -moz-user-select: none !important;
            -ms-user-select: none !important;
        }
        
        /* السماح بالتحديد فقط في الحقول */
        input, textarea, select, [contenteditable="true"] {
            user-select: text !important;
            -webkit-user-select: text !important;
            -moz-user-select: text !important;
            -ms-user-select: text !important;
        }
        
        /* تغيير شكل المؤشر */
        body {
            cursor: default;
        }
        
        input, textarea, select, [contenteditable="true"] {
            cursor: text;
        }
        
        /* منع الطباعة */
        @media print {
            body { display: none !important; }
        }
        
        /* إخفاء أيقونات كلمة المرور في المتصفحات */
        input::-ms-reveal,
        input::-ms-clear {
            display: none !important;
        }
        
        input[type="password"]::-webkit-credentials-auto-fill-button,
        input[type="password"]::-webkit-caps-lock-indicator,
        input[type="password"]::-webkit-strong-password-visualizer {
            display: none !important;
            visibility: hidden !important;
            pointer-events: none !important;
        }
        
        /* منع تغيير لون الخلفية من المتصفح */
        input:-webkit-autofill,
        input:-webkit-autofill:hover,
        input:-webkit-autofill:focus,
        input:-webkit-autofill:active {
            -webkit-box-shadow: 0 0 0 30px white inset !important;
            -webkit-text-fill-color: #333 !important;
            caret-color: #333 !important;
            transition: background-color 5000s ease-in-out 0s;
        }
        
        /* منع ظهور نافذة حفظ كلمة المرور */
        form {
            autocomplete: off !important;
        }
    `;
    document.head.appendChild(style);

    // ============================================
    // 2. إضافة Meta Tags للأمان (تم إزالة وسوم منع التخزين المؤقت)
    // ============================================
    function addMetaTags() {
        const metaTags = [
            { name: 'robots', content: 'noindex, nofollow, noarchive, nosnippet' },
            // تم إزالة وسوم Cache-Control و Pragma و Expires
            // لأنها تمنع المتصفح من استعادة حالة الصفحة عند الضغط على زر الرجوع
            // { 'http-equiv': 'Cache-Control', content: 'no-store, no-cache, must-revalidate, max-age=0' },
            // { 'http-equiv': 'Pragma', content: 'no-cache' },
            // { 'http-equiv': 'Expires', content: '0' },
            { name: 'format-detection', content: 'telephone=no' },
            { name: 'format-detection', content: 'address=no' }
        ];

        metaTags.forEach(tag => {
            const meta = document.createElement('meta');
            for (let [key, value] of Object.entries(tag)) {
                meta.setAttribute(key, value);
            }
            document.head.appendChild(meta);
        });
    }
    addMetaTags();

    // ============================================
    // 3. منع اختصارات لوحة المفاتيح (محسن)
    // ============================================
    document.addEventListener('keydown', function (e) {
        
        // ===== السماح لاختصارات النظام المخصصة بالعمل =====
        if (window.ShortcutEngine && window.ShortcutEngine.isSystemShortcut(e)) {
            return true;
        }

        // التحقق مما إذا كان المستخدم في حقل إدخال
        const isInInput = e.target.matches('input, textarea, select');

        // ===== قائمة الاختصارات الممنوعة (إنجليزي + عربي) =====
        const forbiddenCombos = [
            // Ctrl + حروف
            { ctrl: true, keys: ['s', 'S', 'س'] }, // حفظ
            { ctrl: true, keys: ['p', 'P', 'ب'] }, // طباعة
            { ctrl: true, keys: ['u', 'U', 'ي'] }, // عرض المصدر
            { ctrl: true, keys: ['f', 'F', 'ك'] }, // بحث
            { ctrl: true, keys: ['h', 'H', 'ا'] }, // سجل
            { ctrl: true, keys: ['j', 'J', 'ت'] }, // تحميلات
            { ctrl: true, keys: ['d', 'D', 'ذ'] }, // إشارة مرجعية
            { ctrl: true, keys: ['n', 'N', 'م'] }, // نافذة جديدة
            { ctrl: true, keys: ['t', 'T', 'ن'] }, // تبويب جديد
            { ctrl: true, keys: ['w', 'W', 'ك'] }, // إغلاق تبويب
            { ctrl: true, keys: ['r', 'R', 'ز'] }, // تحديث

            // Ctrl + Shift + حروف
            { ctrl: true, shift: true, keys: ['i', 'I', 'غ'] }, // أدوات المطور
            { ctrl: true, shift: true, keys: ['j', 'J', 'ت'] }, // وحدة التحكم
            { ctrl: true, shift: true, keys: ['c', 'C', 'ق'] }, // فحص العنصر
            { ctrl: true, shift: true, keys: ['n', 'N', 'م'] }, // وضع التصفح الخاص
            { ctrl: true, shift: true, keys: ['p', 'P', 'ب'] }, // وضع التصفح الخاص
            { ctrl: true, shift: true, keys: ['q', 'Q', 'ش'] }, // تسجيل الخروج
            { ctrl: true, shift: true, keys: ['delete', 'Delete', 'مسح'] }, // مسح البيانات

            // Alt + حروف
            { alt: true, keys: ['f4', 'F4'] }, // إغلاق النافذة
            { alt: true, keys: ['tab', 'Tab'] }, // تبديل التبويبات
            { alt: true, keys: ['left', 'Left'] }, // رجوع
            { alt: true, keys: ['right', 'Right'] }, // تقدم
            { alt: true, keys: ['home', 'Home'] }, // الصفحة الرئيسية
            { alt: true, keys: ['d', 'D', 'ذ'] }, // شريط العناوين

            // مفاتيح الوظائف
            { keys: ['f1', 'F1'] },
            { keys: ['f2', 'F2'] },
            { keys: ['f3', 'F3'] },
            { keys: ['f4', 'F4'] },
            { keys: ['f5', 'F5'] },
            { keys: ['f6', 'F6'] },
            { keys: ['f7', 'F7'] },
            { keys: ['f8', 'F8'] },
            { keys: ['f9', 'F9'] },
            { keys: ['f10', 'F10'] },
            { keys: ['f11', 'F11'] },
            { keys: ['f12', 'F12'] },

            // مفاتيح النظام
            { keys: ['printscreen', 'PrintScreen', 'PrtScn'] },
            { keys: ['scrolllock', 'ScrollLock'] },
            { keys: ['pause', 'Pause'] },
            { keys: ['insert', 'Insert'] },
            { keys: ['delete', 'Delete'] },
            { keys: ['home', 'Home'] },
            { keys: ['end', 'End'] },
            { keys: ['pageup', 'PageUp'] },
            { keys: ['pagedown', 'PageDown'] },

            // Ctrl + أرقام
            { ctrl: true, keys: ['0', '١'] },
            { ctrl: true, keys: ['1', '١'] },
            { ctrl: true, keys: ['2', '٢'] },
            { ctrl: true, keys: ['3', '٣'] },
            { ctrl: true, keys: ['4', '٤'] },
            { ctrl: true, keys: ['5', '٥'] },
            { ctrl: true, keys: ['6', '٦'] },
            { ctrl: true, keys: ['7', '٧'] },
            { ctrl: true, keys: ['8', '٨'] },
            { ctrl: true, keys: ['9', '٩'] }
        ];

        // التحقق من الاختصار الحالي
        let isForbidden = false;
        let forbiddenKey = '';

        for (const combo of forbiddenCombos) {
            // التحقق من شروط الضغط
            if (combo.ctrl && !e.ctrlKey) continue;
            if (combo.shift && !e.shiftKey) continue;
            if (combo.alt && !e.altKey) continue;

            // التحقق من المفتاح
            if (combo.keys.includes(e.key)) {
                isForbidden = true;
                forbiddenKey = e.key;
                break;
            }
        }

        // استثناءات: السماح ببعض الاختصارات داخل الحقول
        if (isInInput) {
            // السماح بـ Ctrl+A داخل الحقول فقط
            if (e.ctrlKey && (e.key === 'a' || e.key === 'A' || e.key === ' ش')) {
                return true;
            }
            // السماح بالنسخ واللصق داخل الحقول
            if (e.ctrlKey && (e.key === 'c' || e.key === 'C' || e.key === ' ؤ' ||
                e.key === 'v' || e.key === 'V' || e.key === ' ر' ||
                e.key === 'x' || e.key === 'X' || e.key === ' ء')) {
                return true;
            }
        }

        if (isForbidden) {
            e.preventDefault();
            e.stopPropagation();

            // رسالة مناسبة حسب الاختصار
            let message = '🚫 هذه العملية غير مسموح بها';

            if (e.key === 'F12' || (e.ctrlKey && e.shiftKey && (e.key === 'I' || e.key === 'i'))) {
                message = '🚫 أدوات المطور معطلة';
            } else if (e.ctrlKey && (e.key === 'p' || e.key === 'P' || e.key === 'ب')) {
                message = '🖨️ الطباعة غير متاحة';
            } else if (e.ctrlKey && (e.key === 's' || e.key === 'S' || e.key === 'ص')) {
                message = '💾 لا يمكن حفظ الصفحة';
            } else if (e.key === 'F5' || (e.ctrlKey && (e.key === 'r' || e.key === 'R'))) {
                message = '🔄 لا يمكن تحديث الصفحة';
            } else if (e.ctrlKey && (e.key === 't' || e.key === 'T')) {
                message = '📑 لا يمكن فتح تبويب جديد';
            } else if (e.ctrlKey && (e.key === 'n' || e.key === 'N')) {
                message = '🪟 لا يمكن فتح نافذة جديدة';
            } else if (e.ctrlKey && (e.key === 'u' || e.key === 'U')) {
                message = '🔍 لا يمكن عرض المصدر';
            }

            showSecurityAlert(message, 'warning');
            return false;
        }
    }, true);

    // ============================================
    // 4. منع القائمة اليمنى (Context Menu)
    // ============================================
    document.addEventListener('contextmenu', function (e) {
        // السماح فقط في الحقول
        if (e.target.matches('input, textarea, select')) {
            return true;
        }
        e.preventDefault();
        showSecurityAlert('🖱️ القائمة اليمنى غير متاحة', 'info');
        return false;
    });

    // ============================================
    // 5. منع السحب والإفلات
    // ============================================
    document.addEventListener('dragstart', function (e) {
        e.preventDefault();
        return false;
    });

    document.addEventListener('drop', function (e) {
        e.preventDefault();
        return false;
    });

    document.addEventListener('dragover', function (e) {
        e.preventDefault();
        return false;
    });

    // منع سحب الصور
    document.querySelectorAll('img').forEach(img => {
        img.addEventListener('dragstart', (e) => e.preventDefault());
    });

    // ============================================
    // 6. منع الطباعة
    // ============================================
    window.print = function () {
        showSecurityAlert('🖨️ الطباعة غير متاحة', 'warning');
        return false;
    };

    window.addEventListener('beforeprint', function (e) {
        e.preventDefault();
        showSecurityAlert('🖨️ الطباعة غير متاحة', 'warning');
        return false;
    });

    // ============================================
    // 7. منع حفظ الصفحة
    // ============================================
    window.addEventListener('beforeunload', function (e) {
        // السماح بالخروج العادي فقط
        return undefined;
    });

    // ============================================
    // 8. منع فتح View Source
    // ============================================
    document.addEventListener('keydown', function (e) {
        if (window.ShortcutEngine && window.ShortcutEngine.isSystemShortcut(e)) return true;
        if (e.ctrlKey && (e.key === 'u' || e.key === 'U')) {
            e.preventDefault();
            showSecurityAlert('🔍 لا يمكن عرض المصدر', 'warning');
            return false;
        }
    });

    // ============================================
    // 9. كشف أدوات المطور (DevTools Detection)
    // ============================================
    (function detectDevTools() {
        const element = new Image();
        let devToolsOpen = false;

        Object.defineProperty(element, 'id', {
            get: function () {
                devToolsOpen = true;
                showSecurityAlert('🚫 تم اكتشاف أدوات المطور - سيتم إعادة التحميل', 'error');
                setTimeout(() => {
                    window.location.reload();
                }, 1000);
                return '';
            }
        });

        setInterval(() => {
            devToolsOpen = false;
            console.log(element);
            console.clear();
        }, 1000);

        // طريقة إضافية: قياس الفرق في الأبعاد
        setInterval(function () {
            const widthThreshold = window.outerWidth - window.innerWidth > 160;
            const heightThreshold = window.outerHeight - window.innerHeight > 160;

            if (widthThreshold || heightThreshold) {
                showSecurityAlert('🚫 تم اكتشاف أدوات المطور - سيتم إعادة التحميل', 'error');
                setTimeout(() => {
                    window.location.reload();
                }, 1000);
            }
        }, 1000);
    })();

    // ============================================
    // 10. منع اختصارات المتصفح الأخرى
    // ============================================
    document.addEventListener('keydown', function (e) {
        if (window.ShortcutEngine && window.ShortcutEngine.isSystemShortcut(e)) return true;
        // منع Ctrl+Shift+N (وضع التصفح الخاص)
        if (e.ctrlKey && e.shiftKey && (e.key === 'n' || e.key === 'N')) {
            e.preventDefault();
            showSecurityAlert('🕵️ وضع التصفح الخاص غير متاح', 'warning');
            return false;
        }

        // منع Ctrl+Shift+P (وضع التصفح الخاص)
        if (e.ctrlKey && e.shiftKey && (e.key === 'p' || e.key === 'P')) {
            e.preventDefault();
            showSecurityAlert('🕵️ وضع التصفح الخاص غير متاح', 'warning');
            return false;
        }

        // منع Ctrl+D (إشارة مرجعية)
        if (e.ctrlKey && (e.key === 'd' || e.key === 'D')) {
            e.preventDefault();
            showSecurityAlert('🔖 لا يمكن إضافة إشارة مرجعية', 'warning');
            return false;
        }

        // منع Ctrl+B (شريط الإشارات)
        if (e.ctrlKey && (e.key === 'b' || e.key === 'B')) {
            e.preventDefault();
            showSecurityAlert('📑 شريط الإشارات غير متاح', 'warning');
            return false;
        }

        // منع Ctrl+H (السجل)
        if (e.ctrlKey && (e.key === 'h' || e.key === 'H')) {
            e.preventDefault();
            showSecurityAlert('📋 السجل غير متاح', 'warning');
            return false;
        }

        // منع Ctrl+J (التحميلات)
        if (e.ctrlKey && (e.key === 'j' || e.key === 'J')) {
            e.preventDefault();
            showSecurityAlert('📥 التحميلات غير متاحة', 'warning');
            return false;
        }

        // منع Ctrl+E (بحث)
        if (e.ctrlKey && (e.key === 'e' || e.key === 'E')) {
            e.preventDefault();
            return false;
        }

        // منع Ctrl+L (شريط العناوين)
        if (e.ctrlKey && (e.key === 'l' || e.key === 'L')) {
            e.preventDefault();
            return false;
        }

        // منع Ctrl+K (بحث من شريط العناوين)
        if (e.ctrlKey && (e.key === 'k' || e.key === 'K')) {
            e.preventDefault();
            return false;
        }

        // منع Ctrl+O (فتح ملف)
        if (e.ctrlKey && (e.key === 'o' || e.key === 'O')) {
            e.preventDefault();
            showSecurityAlert('📂 فتح الملفات غير متاح', 'warning');
            return false;
        }
    });

    // ============================================
    // 11. منع حفظ الصور
    // ============================================
    document.querySelectorAll('img').forEach(img => {
        img.addEventListener('contextmenu', (e) => e.preventDefault());
        img.addEventListener('dragstart', (e) => e.preventDefault());
    });

    // ============================================
    // 12. منع تحديد النص خارج الحقول
    // ============================================
    document.addEventListener('selectstart', function (e) {
        if (!e.target.matches('input, textarea, select')) {
            e.preventDefault();
            return false;
        }
    });

    // ============================================
    // 13. منع نسخ/قص/لصق خارج الحقول
    // ============================================
    document.addEventListener('copy', function (e) {
        if (!e.target.matches('input, textarea, select')) {
            e.preventDefault();
            showSecurityAlert('📋 النسخ غير مسموح به', 'warning');
            return false;
        }
    });

    document.addEventListener('cut', function (e) {
        if (!e.target.matches('input, textarea, select')) {
            e.preventDefault();
            showSecurityAlert('✂️ القص غير مسموح به', 'warning');
            return false;
        }
    });

    document.addEventListener('paste', function (e) {
        if (!e.target.matches('input, textarea, select')) {
            e.preventDefault();
            showSecurityAlert('📋 اللصق غير مسموح به', 'warning');
            return false;
        }
    });

    // ============================================
    // 14. منع فتح الروابط في تبويب جديد
    // ============================================
    document.addEventListener('click', function (e) {
        const link = e.target.closest('a');
        if (link && link.target === '_blank') {
            e.preventDefault();
            window.location.href = link.href; // فتح في نفس التبويب
        }
    });

    // منع النقر على الروابط مع Ctrl
    document.addEventListener('keydown', function (e) {
        if (window.ShortcutEngine && window.ShortcutEngine.isSystemShortcut(e)) return true;
        if (e.ctrlKey && e.target.closest('a')) {
            e.preventDefault();
        }
    });

    // ============================================
    // 15. منع رسائل المتصفح (Alert, Confirm, Prompt)
    // ============================================
    window.alert = function (message) {
        showSecurityAlert(message, 'info');
        return true;
    };

    window.confirm = function (message) {
        showSecurityAlert(message + ' (نعم/لا)', 'warning');
        return true; // افتراضياً نعم
    };

    window.prompt = function (message, defaultValue) {
        showSecurityAlert(message + (defaultValue ? ' - القيمة الافتراضية: ' + defaultValue : ''), 'info');
        return defaultValue || '';
    };

    // ============================================
    // 16. تعطيل console.log في الإنتاج
    // ============================================
    if (window.location.hostname !== 'localhost' &&
        !window.location.hostname.includes('127.0.0.1') &&
        !window.location.hostname.includes('::1')) {

        const noop = function () { };
        const methods = ['log', 'info', 'warn', 'error', 'debug', 'trace', 'table', 'group', 'groupCollapsed', 'groupEnd', 'dir', 'dirxml'];

        methods.forEach(method => {
            console[method] = noop;
        });
    }

    // ============================================
    // 17. دالة عرض رسائل الأمان (محسنة)
    // ============================================
    window.showSecurityAlert = function (message, type = 'error', duration = 3000) {
        // إزالة أي رسالة سابقة
        const oldMessage = document.getElementById('securityMessage');
        if (oldMessage) oldMessage.remove();

        const alertDiv = document.createElement('div');
        alertDiv.id = 'securityMessage';

        // تحديد الألوان حسب النوع
        let bgColor, icon;
        switch (type) {
            case 'error':
                bgColor = '#f44336';
                icon = '❌';
                break;
            case 'warning':
                bgColor = '#ff9800';
                icon = '⚠️';
                break;
            case 'success':
                bgColor = '#4CAF50';
                icon = '✅';
                break;
            default:
                bgColor = '#2196F3';
                icon = 'ℹ️';
        }

        alertDiv.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            background: ${bgColor};
            color: white;
            padding: 15px 25px;
            border-radius: 8px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.2);
            z-index: 99999;
            font-size: 14px;
            direction: rtl;
            max-width: 350px;
            animation: securitySlideIn 0.3s ease;
            display: flex;
            align-items: center;
            gap: 10px;
            backdrop-filter: blur(5px);
            border: 1px solid rgba(255,255,255,0.2);
        `;

        alertDiv.innerHTML = `${icon} <span>${message}</span>`;

        // إضافة CSS للأنيميشن إذا لم يكن موجوداً
        if (!document.getElementById('securityAnimation')) {
            const animStyle = document.createElement('style');
            animStyle.id = 'securityAnimation';
            animStyle.textContent = `
                @keyframes securitySlideIn {
                    from {
                        opacity: 0;
                        transform: translateX(50px);
                    }
                    to {
                        opacity: 1;
                        transform: translateX(0);
                    }
                }
                @keyframes securitySlideOut {
                    from {
                        opacity: 1;
                        transform: translateX(0);
                    }
                    to {
                        opacity: 0;
                        transform: translateX(50px);
                    }
                }
            `;
            document.head.appendChild(animStyle);
        }

        document.body.appendChild(alertDiv);

        // إزالة الرسالة بعد المدة المحددة
        setTimeout(() => {
            if (alertDiv.parentElement) {
                alertDiv.style.animation = 'securitySlideOut 0.3s ease';
                setTimeout(() => {
                    if (alertDiv.parentElement) alertDiv.remove();
                }, 300);
            }
        }, duration);
    };

    // ============================================
    // 18. منع استخدام LocalStorage المكشوف
    // ============================================
    const originalSetItem = localStorage.setItem;
    const originalGetItem = localStorage.getItem;
    const originalRemoveItem = localStorage.removeItem;

    // تشفير بسيط للبيانات المخزنة
    localStorage.setItem = function (key, value) {
        // يمكن إضافة تشفير حقيقي هنا
        originalSetItem.call(this, key, value);
    };

    localStorage.getItem = function (key) {
        return originalGetItem.call(this, key);
    };

    // ============================================
    // 19. نموذج وهمي لمنع حفظ كلمات المرور
    // ============================================
    function addFakeForm() {
        const fakeForm = document.createElement('form');
        fakeForm.style.display = 'none';
        fakeForm.innerHTML = `
            <input type="text" name="fakeusername" value="fakeuser">
            <input type="password" name="fakepassword" value="fakepass">
        `;
        document.body.appendChild(fakeForm);
    }

    // تأخير الإضافة لضمان تحميل الصفحة
    setTimeout(addFakeForm, 100);

    // ============================================
    // 20. منع اختصارات المتصفح بالحروف العربية
    // ============================================
    const arabicToEnglish = {
        'ض': 'q', 'ص': 'w', 'ث': 'e', 'ق': 'r', 'ف': 't', 'غ': 'y', 'ع': 'u', 'ه': 'i', 'خ': 'o', 'ح': 'p',
        'ش': '[', 'س': ']', 'ي': '\\', 'ب': ']', 'ل': ';', 'ا': "'", 'ت': ',', 'ن': '.', 'م': '/',
        'ك': 's', 'ط': 'd', 'ذ': 'f', 'د': 'g', 'ز': 'h', 'ر': 'j', 'و': 'k', 'ة': 'l', 'ى': ';',
        'ء': 'z', 'ؤ': 'x', 'ئ': 'c', 'إ': 'v', 'أ': 'b', 'آ': 'n', 'لا': 'm'
    };

    document.addEventListener('keydown', function (e) {
        if (window.ShortcutEngine && window.ShortcutEngine.isSystemShortcut(e)) return true;
        if (e.ctrlKey && arabicToEnglish[e.key]) {
            const englishKey = arabicToEnglish[e.key];

            // إنشاء حدث مكافئ بالحرف الإنجليزي
            const fakeEvent = {
                ctrlKey: e.ctrlKey,
                shiftKey: e.shiftKey,
                altKey: e.altKey,
                key: englishKey,
                preventDefault: () => { },
                stopPropagation: () => { }
            };

            // منع الحدث الأصلي
            e.preventDefault();
            e.stopPropagation();

            // عرض رسالة مناسبة
            showSecurityAlert('🚫 هذه العملية غير مسموح بها', 'warning');
            return false;
        }
    }, true);

    console.log('✅ نظام الحماية المتقدم مفعل - جميع خصائص المتصفح معطلة (تم إزالة منع التخزين المؤقت)');
})();