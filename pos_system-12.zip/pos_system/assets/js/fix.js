const fs = require('fs');
const file = 'c:/xampp/htdocs/pos_system/assets/js/inventory.js';
let content = fs.readFileSync(file, 'utf8');

const target = 'document.body.appendChild(modal); setTimeout(() => { const yesBtn = document.getElementById(`btnYes_${modalId}`); if (yesBtn) { yesBtn.focus(); } }, 10);';
content = content.split(target).join('document.body.appendChild(modal);');

fs.writeFileSync(file, content, 'utf8');
