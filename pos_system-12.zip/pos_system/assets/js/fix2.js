const fs = require('fs');
const file = 'c:/xampp/htdocs/pos_system/assets/js/inventory.js';
let content = fs.readFileSync(file, 'utf8');

const startIndex = content.indexOf('function showDeleteSelectedBatches() {');
const endIndex = content.indexOf('function showDeleteBatchSelection() {');

if (startIndex !== -1 && endIndex !== -1) {
    const cleanFunction = `function showDeleteSelectedBatches() {
    const selected = [];
    document.querySelectorAll('.row-checkbox:checked').forEach(cb => {
        selected.push(cb.value);
    });
    if (selected.length === 0) {
        showNotification('warning', 'تنبيه', 'الرجاء تحديد دفعات للحذف من الجدول أولاً');
        return;
    }
    const modalOpt = document.getElementById('deleteOptionsModal');
    if (modalOpt) modalOpt.remove();
    showConfirmDialog(\`هل أنت متأكد من حذف \${selected.length} دفعة محددة؟\`, function() {
        showLoading('جاري الحذف...');
        let successCount = 0;
        let failCount = 0;
        const deleteNext = (index) => {
            if (index >= selected.length) {
                hideLoading();
                if (successCount > 0) showNotification('success', 'اكتمل', \`تم حذف \${successCount} دفعة.\`);
                if (failCount > 0) showNotification('warning', 'تنبيه', \`فشل حذف \${failCount} دفعة.\`);
                setTimeout(() => location.reload(), 2000);
                return;
            }
            const fd = new URLSearchParams(); fd.append('id', selected[index]);
            fetch(\`\${BASE_URL}/inventory/delete-batch\`, {method: 'POST', headers: {'Content-Type': 'application/x-www-form-urlencoded'}, body: fd.toString()})
            .then(r => r.json()).then(d => { if(d.success) successCount++; else failCount++; deleteNext(index + 1); })
            .catch(() => { failCount++; deleteNext(index + 1); });
        };
        deleteNext(0);
    });
}
`;
    content = content.substring(0, startIndex) + cleanFunction + content.substring(endIndex);
    fs.writeFileSync(file, content, 'utf8');
}
