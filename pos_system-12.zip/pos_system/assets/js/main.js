// main.js - نسخة محسّنة مع التنقل الديناميكي (SPA-like)
(function() {
    'use strict';

    // حفظ حالة النماذج قبل التنقل
    function saveFormsState() {
        const formsData = {};
        document.querySelectorAll('form').forEach((form, index) => {
            const formId = form.id || `form_${index}`;
            const formElements = {};
            form.querySelectorAll('input, select, textarea').forEach(el => {
                if (el.name) {
                    formElements[el.name] = el.value;
                }
            });
            formsData[formId] = formElements;
        });
        sessionStorage.setItem('savedFormsState', JSON.stringify(formsData));
    }

    // استعادة حالة النماذج بعد التنقل
    function restoreFormsState() {
        const saved = sessionStorage.getItem('savedFormsState');
        if (saved) {
            const formsData = JSON.parse(saved);
            for (const [formId, elements] of Object.entries(formsData)) {
                const form = document.getElementById(formId) || document.querySelector(`form[id="${formId}"]`);
                if (form) {
                    for (const [name, value] of Object.entries(elements)) {
                        const input = form.querySelector(`[name="${name}"]`);
                        if (input) input.value = value;
                    }
                }
            }
            sessionStorage.removeItem('savedFormsState');
        }
    }

    // تحميل المحتوى الجديد دون إعادة تحميل الصفحة
    async function loadContent(url) {
        // حماية النظام ضد تراكم الطلبات (Session Flooding & Deadlock Prevention)
        if (window._isOmniLoading && window._isOmniLoading === url) return;
        window._isOmniLoading = url;

        saveFormsState();
        
        // إظهار شريط التقدم (إن وجد)
        const progress = document.getElementById('omni-progress');
        if (progress) progress.style.width = '30%';

        try {
            const response = await fetch(url, {
                headers: { 'X-Requested-With': 'XMLHttpRequest' }
            });
            if (!response.ok) throw new Error('Network error');
            const html = await response.text();
            const parser = new DOMParser();
            const doc = parser.parseFromString(html, 'text/html');
            const newContent = doc.querySelector('.content-area')?.innerHTML || '';
            const newTitle = doc.querySelector('title')?.innerText || '';

            document.querySelector('.content-area').innerHTML = newContent;
            document.title = newTitle;
            history.pushState({ url }, '', url);
            
            restoreFormsState();
        } catch (err) {
            console.warn('AJAX navigation failed, fallback to full reload:', err);
            window.location.href = url;
        } finally {
            setTimeout(() => { window._isOmniLoading = false; }, 300);
            if (progress) {
                progress.style.width = '100%';
                setTimeout(() => { if(progress) progress.style.width = '0%'; }, 300);
            }
        }
    }

    // اعتراض جميع روابط التنقل
    document.addEventListener('click', function(e) {
        const link = e.target.closest('.nav-link');
        if (link && link.href && !link.target && !e.ctrlKey && !e.metaKey) {
            const url = new URL(link.href);
            if (url.origin === window.location.origin && !url.pathname.includes('/logout')) {
                e.preventDefault();
                loadContent(link.href);
            }
        }
    });

    // معالج زر الرجوع/التقدم
    window.addEventListener('popstate', function(event) {
        if (event.state && event.state.url) {
            loadContent(event.state.url);
        } else {
            window.location.reload();
        }
    });

    // تحسين الأداء: prefetch للروابط
    document.querySelectorAll('.nav-link').forEach(link => {
        link.addEventListener('mouseenter', function() {
            const href = this.getAttribute('href');
            if (href && !document.querySelector(`link[href="${href}"]`)) {
                const prefetchLink = document.createElement('link');
                prefetchLink.rel = 'prefetch';
                prefetchLink.href = href;
                document.head.appendChild(prefetchLink);
            }
        }, { once: true });
    });
})();