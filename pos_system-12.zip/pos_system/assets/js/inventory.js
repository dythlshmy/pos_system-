// ============================================
// ملف inventory.js - نسخة محسنة كتطبيق سطح مكتب
// ============================================

// ===== حماية بيئة المتصفح وتحويله إلى تطبيق سطح مكتب مغلق =====
(function() {
    // منع النقر بزر الماوس الأيمن
    document.addEventListener('contextmenu', function(e) {
        e.preventDefault();
        return false;
    });

    // منع تحديد النص خارج الحقول
    document.addEventListener('selectstart', function(e) {
        if (!e.target.matches('input, textarea, [contenteditable="true"]')) {
            e.preventDefault();
        }
    });

    // منع السحب والإفلات
    document.addEventListener('dragstart', function(e) {
        e.preventDefault();
    });

    // منع اختصارات المتصفح
    document.addEventListener('keydown', function(e) {
        if (e.key === 'F12' || 
            (e.ctrlKey && e.shiftKey && (e.key === 'I' || e.key === 'J' || e.key === 'C')) ||
            (e.ctrlKey && e.key === 'u') ||
            (e.ctrlKey && e.key === 's') ||
            (e.ctrlKey && e.key === 'p') ||
            (e.ctrlKey && e.shiftKey && e.key === 'Delete')) {
            e.preventDefault();
            return false;
        }
    });

    // تعطيل window.print
    window.print = function() { return false; };
})();

// تطبيق منع التحديد عبر CSS
const style = document.createElement('style');
style.textContent = `
    body {
        -webkit-user-select: none;
        -moz-user-select: none;
        -ms-user-select: none;
        user-select: none;
    }
    input, textarea, [contenteditable="true"] {
        -webkit-user-select: text;
        -moz-user-select: text;
        -ms-user-select: text;
        user-select: text;
    }
`;
document.head.appendChild(style);

// متغيرات عامة
let selectedRow = null;
let searchTimeout = null;
let autoRestockEnabled = false;

// متخصص بالتأخير لتخفيف عدد الطلبات
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// ===== تهيئة الصفحة =====
document.addEventListener('DOMContentLoaded', function() {
    // إضافة التصميم الأساسي للتطبيق
    initAppLayout();
    
    // تهيئة التبويبات
    initTabs();
    
    // توليد رقم دفعة
    generateBatchNumber();
    
    // إضافة مستمعين للفلاتر
    initFilters();
    
    // إضافة مستمع للبحث
    initSearchListener();
    
    // إضافة مستمع لحساب الربح
    initProfitCalculator();
    
    // تهيئة نظام الرفع التلقائي
    initAutoRestock();
    
    // التحقق من التنبيهات
    checkAlerts();
});

// ===== تهيئة تصميم التطبيق =====
function initAppLayout() {
    // تطبيق التصميم على الحاوية الرئيسية
    const container = document.querySelector('.container');
    if (container) {
        container.style.cssText = `
            width: 80%;
            max-width: 1400px;
            margin: 0 auto;
            height: 100vh;
            display: flex;
            flex-direction: column;
            overflow: hidden;
            background: #f8f9fa;
        `;
    }
    
    // تصميم شريط الأدوات
    const toolbar = document.querySelector('.toolbar');
    if (toolbar) {
        toolbar.style.cssText = `
            background: white;
            padding: 15px 20px;
            border-bottom: 1px solid #e0e0e0;
            box-shadow: 0 2px 4px rgba(0,0,0,0.05);
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-shrink: 0;
        `;
    }
    
    // تصميم منطقة التبويبات
    const tabsContainer = document.querySelector('.tabs');
    if (tabsContainer) {
        tabsContainer.style.cssText = `
            display: flex;
            gap: 5px;
            padding: 0 20px;
            background: white;
            border-bottom: 1px solid #e0e0e0;
            flex-shrink: 0;
        `;
    }
    
    // تصميم أزرار التبويبات
    document.querySelectorAll('.tab-btn').forEach(btn => {
        btn.style.cssText = `
            padding: 12px 25px;
            background: none;
            border: none;
            border-bottom: 3px solid transparent;
            color: #666;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.2s ease;
            font-size: 14px;
        `;
        
        btn.addEventListener('mouseenter', function() {
            if (!this.classList.contains('active')) {
                this.style.background = '#f5f5f5';
            }
        });
        
        btn.addEventListener('mouseleave', function() {
            if (!this.classList.contains('active')) {
                this.style.background = 'none';
            }
        });
    });
    
    // تصميم التبويب النشط
    const appStyle = document.createElement('style');
    appStyle.textContent = `
        .tab-btn.active {
            border-bottom-color: #dc3545 !important;
            color: #dc3545 !important;
            background: rgba(220, 53, 69, 0.05) !important;
        }
        
        .tab-panel {
            display: none;
            height: 100%;
            overflow-y: auto;
            padding: 20px;
        }
        
        .tab-panel.active {
            display: block;
        }
        
        /* تصميم شريط التمرير */
        ::-webkit-scrollbar {
            width: 10px;
            height: 10px;
        }
        
        ::-webkit-scrollbar-track {
            background: #f1f1f1;
            border-radius: 5px;
        }
        
        ::-webkit-scrollbar-thumb {
            background: #c1c1c1;
            border-radius: 5px;
        }
        
        ::-webkit-scrollbar-thumb:hover {
            background: #a8a8a8;
        }
        
        /* تصميم البطاقات */
        .card {
            background: white;
            border-radius: 12px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.05);
            padding: 20px;
            margin-bottom: 20px;
            border: 1px solid #e0e0e0;
            transition: transform 0.2s ease, box-shadow 0.2s ease;
        }
        
        .card:hover {
            box-shadow: 0 8px 15px rgba(0,0,0,0.1);
        }
        
        /* تصميم الجداول */
        .table-container {
            background: white;
            border-radius: 12px;
            border: 1px solid #e0e0e0;
            overflow: auto;
            max-height: calc(100vh - 250px);
            box-shadow: 0 4px 6px rgba(0,0,0,0.05);
        }
        
        table {
            width: 100%;
            border-collapse: collapse;
            min-width: 1000px;
        }
        
        th {
            background: #343a40;
            color: white;
            padding: 15px;
            font-weight: 600;
            font-size: 14px;
            position: sticky;
            top: 0;
            z-index: 10;
        }
        
        td {
            padding: 12px 15px;
            border-bottom: 1px solid #e0e0e0;
            color: #333;
        }
        
        tr:hover {
            background: #f8f9fa;
        }
        
        /* تصميم الحقول */
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: #495057;
            font-size: 14px;
        }
        
        .form-control {
            width: 100%;
            padding: 12px 15px;
            border: 2px solid #e0e0e0;
            border-radius: 8px;
            font-size: 14px;
            transition: border-color 0.2s ease;
            background: white;
        }
        
        .form-control:focus {
            border-color: #dc3545;
            outline: none;
        }
        
        /* تصميم الأزرار */
        .btn {
            padding: 10px 20px;
            border: none;
            border-radius: 8px;
            font-weight: 600;
            font-size: 14px;
            cursor: pointer;
            transition: all 0.2s ease;
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }
        
        .btn-primary {
            background: #0d6efd;
            color: white;
        }
        
        .btn-primary:hover {
            background: #0b5ed7;
            transform: translateY(-2px);
            box-shadow: 0 5px 10px rgba(13,110,253,0.3);
        }
        
        .btn-success {
            background: #28a745;
            color: white;
        }
        
        .btn-success:hover {
            background: #218838;
            transform: translateY(-2px);
            box-shadow: 0 5px 10px rgba(40,167,69,0.3);
        }
        
        .btn-danger {
            background: #dc3545;
            color: white;
        }
        
        .btn-danger:hover {
            background: #c82333;
            transform: translateY(-2px);
            box-shadow: 0 5px 10px rgba(220,53,69,0.3);
        }
        
        .btn-info {
            background: #17a2b8;
            color: white;
        }
        
        .btn-info:hover {
            background: #138496;
            transform: translateY(-2px);
            box-shadow: 0 5px 10px rgba(23,162,184,0.3);
        }
        
        .btn-warning {
            background: #ffc107;
            color: #333;
        }
        
        .btn-warning:hover {
            background: #e0a800;
            transform: translateY(-2px);
            box-shadow: 0 5px 10px rgba(255,193,7,0.3);
        }
        
        .btn-secondary {
            background: #6c757d;
            color: white;
        }
        
        .btn-secondary:hover {
            background: #5a6268;
            transform: translateY(-2px);
            box-shadow: 0 5px 10px rgba(108,117,125,0.3);
        }
        
        /* تصميم الإشعارات المنبثقة - نسخة محترفة */
        .notification-container {
            position: fixed;
            top: 20px;
            left: 50%;
            transform: translateX(-50%);
            z-index: 99999;
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 10px;
            pointer-events: none;
            width: 100%;
            max-width: 400px;
        }
        
        .notification {
            background: white;
            border-radius: 12px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.15), 0 0 0 1px rgba(0,0,0,0.05);
            padding: 16px 20px;
            display: flex;
            align-items: center;
            gap: 15px;
            width: 100%;
            pointer-events: auto;
            animation: notificationSlideIn 0.3s cubic-bezier(0.68, -0.55, 0.265, 1.55);
            border-right: 4px solid;
            transform-origin: top;
        }
        
        .notification.success {
            border-right-color: #28a745;
            background: linear-gradient(to right, #f8fff9, white);
        }
        
        .notification.error {
            border-right-color: #dc3545;
            background: linear-gradient(to right, #fff8f8, white);
        }
        
        .notification.warning {
            border-right-color: #ffc107;
            background: linear-gradient(to right, #fffaf0, white);
        }
        
        .notification.info {
            border-right-color: #17a2b8;
            background: linear-gradient(to right, #f0f9ff, white);
        }
        
        .notification-icon {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 20px;
            flex-shrink: 0;
        }
        
        .notification.success .notification-icon {
            background: #d4edda;
            color: #155724;
        }
        
        .notification.error .notification-icon {
            background: #f8d7da;
            color: #721c24;
        }
        
        .notification.warning .notification-icon {
            background: #fff3cd;
            color: #856404;
        }
        
        .notification.info .notification-icon {
            background: #d1ecf1;
            color: #0c5460;
        }
        
        .notification-content {
            flex: 1;
        }
        
        .notification-title {
            font-weight: 700;
            font-size: 14px;
            margin-bottom: 4px;
            color: #1a1a1a;
        }
        
        .notification-message {
            font-size: 13px;
            color: #4a4a4a;
            line-height: 1.4;
        }
        
        .notification-close {
            width: 28px;
            height: 28px;
            border-radius: 50%;
            background: #f5f5f5;
            border: none;
            color: #666;
            font-size: 18px;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: all 0.2s ease;
            flex-shrink: 0;
        }
        
        .notification-close:hover {
            background: #e0e0e0;
            color: #333;
            transform: scale(1.1);
        }
        
        @keyframes notificationSlideIn {
            0% {
                opacity: 0;
                transform: translateY(-20px) scale(0.95);
            }
            100% {
                opacity: 1;
                transform: translateY(0) scale(1);
            }
        }
        
        @keyframes notificationSlideOut {
            0% {
                opacity: 1;
                transform: translateY(0) scale(1);
            }
            100% {
                opacity: 0;
                transform: translateY(-20px) scale(0.95);
            }
        }
        
        .notification.exit {
            animation: notificationSlideOut 0.3s ease forwards;
        }
        
        /* تصميم شارة التنبيهات */
        .alert-badge {
            background: #dc3545;
            color: white;
            padding: 3px 8px;
            border-radius: 20px;
            font-size: 11px;
            margin-right: 8px;
            font-weight: bold;
        }
        
        /* تصميم شريط الفلاتر */
        .filters-bar {
            background: white;
            border-radius: 12px;
            padding: 15px;
            margin-bottom: 20px;
            border: 1px solid #e0e0e0;
            display: flex;
            gap: 15px;
            flex-wrap: wrap;
            align-items: center;
        }
        
        .filter-group {
            display: flex;
            align-items: center;
            gap: 10px;
            background: #f8f9fa;
            padding: 5px 15px;
            border-radius: 30px;
        }
        
        .filter-group label {
            color: #666;
            font-size: 13px;
        }
        
        .filter-group select, .filter-group input {
            border: none;
            background: none;
            padding: 8px;
            font-size: 13px;
            outline: none;
        }
        
        /* تصميم مؤشرات الحالة */
        .status-badge {
            padding: 5px 12px;
            border-radius: 30px;
            font-size: 12px;
            font-weight: bold;
            display: inline-block;
        }
        
        .status-available {
            background: #d4edda;
            color: #155724;
        }
        
        .status-warning {
            background: #fff3cd;
            color: #856404;
        }
        
        .status-expired {
            background: #f8d7da;
            color: #721c24;
        }
        
        .status-low {
            background: #cce5ff;
            color: #004085;
        }
        
        /* تصميم الأزرار الصغيرة */
        .btn-icon {
            width: 32px;
            height: 32px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            margin: 0 3px;
            transition: all 0.2s ease;
            font-size: 16px;
        }
        
        .btn-icon:hover {
            transform: translateY(-2px);
        }
        
        .btn-icon.btn-success { background: #28a745; color: white; }
        .btn-icon.btn-primary { background: #0d6efd; color: white; }
        .btn-icon.btn-info { background: #17a2b8; color: white; }
        .btn-icon.btn-danger { background: #dc3545; color: white; }
        
        /* تصميم النوافذ المنبثقة */
        .modal-overlay {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0,0,0,0.6);
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 20000;
            animation: fadeIn 0.2s ease;
        }
        
        .modal-window {
            background: white;
            width: 90%;
            max-width: 600px;
            max-height: 90vh;
            border-radius: 16px;
            overflow: hidden;
            box-shadow: 0 25px 50px rgba(0,0,0,0.3);
            animation: slideInUp 0.3s ease;
            display: flex;
            flex-direction: column;
        }
        
        .modal-header {
            padding: 20px 25px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-shrink: 0;
        }
        
        .modal-header.success { background: linear-gradient(135deg, #28a745, #218838); }
        .modal-header.error { background: linear-gradient(135deg, #dc3545, #c82333); }
        .modal-header.info { background: linear-gradient(135deg, #17a2b8, #138496); }
        .modal-header.warning { background: linear-gradient(135deg, #ffc107, #e0a800); }
        
        .modal-header h3 {
            color: white;
            margin: 0;
            font-size: 18px;
        }
        
        .modal-close {
            background: rgba(255,255,255,0.2);
            border: none;
            color: white;
            width: 30px;
            height: 30px;
            border-radius: 50%;
            font-size: 20px;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: background 0.2s ease;
        }
        
        .modal-close:hover {
            background: rgba(255,255,255,0.3);
        }
        
        .modal-body {
            padding: 25px;
            overflow-y: auto;
            flex: 1;
        }
        
        .modal-footer {
            padding: 15px 25px;
            background: #f8f9fa;
            border-top: 1px solid #e0e0e0;
            display: flex;
            justify-content: flex-end;
            gap: 10px;
            flex-shrink: 0;
        }
        
        /* تصميم نتائج البحث */
        .search-results {
            position: absolute;
            top: 100%;
            left: 0;
            right: 0;
            background: white;
            border: 1px solid #e0e0e0;
            border-radius: 8px;
            margin-top: 5px;
            max-height: 300px;
            overflow-y: auto;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            z-index: 1000;
        }
        
        .result-item {
            padding: 12px 15px;
            border-bottom: 1px solid #eee;
            cursor: pointer;
            transition: background 0.2s ease;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .result-item:hover {
            background: #f8f9fa;
        }
        
        /* تصميم شاشة التحميل */
        .loading-overlay {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0,0,0,0.5);
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 20000;
            animation: fadeIn 0.2s ease;
        }
        
        .loading-box {
            background: white;
            padding: 30px 50px;
            border-radius: 16px;
            box-shadow: 0 20px 40px rgba(0,0,0,0.2);
            text-align: center;
            animation: slideInUp 0.3s ease;
        }
        
        .loading-spinner {
            width: 50px;
            height: 50px;
            border: 4px solid #f3f3f3;
            border-top: 4px solid #dc3545;
            border-radius: 50%;
            animation: spin 1s linear infinite;
            margin: 0 auto 15px;
        }
        
        @keyframes slideInUp {
            from {
                transform: translateY(30px);
                opacity: 0;
            }
            to {
                transform: translateY(0);
                opacity: 1;
            }
        }
        
        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }
        
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
    `;
    
    document.head.appendChild(appStyle);
    
    // إنشاء حاوية الإشعارات
    const notificationContainer = document.createElement('div');
    notificationContainer.className = 'notification-container';
    notificationContainer.id = 'notificationContainer';
    document.body.appendChild(notificationContainer);
}

// ===== نظام الإشعارات المحترف =====
function showNotification(type = 'success', title, message, duration = 4000) {
    const container = document.getElementById('notificationContainer');
    if (!container) return;
    
    const icons = {
        success: '✓',
        error: '✕',
        warning: '⚠',
        info: 'ℹ'
    };
    
    const titles = {
        success: 'تم بنجاح',
        error: 'خطأ',
        warning: 'تنبيه',
        info: 'معلومة'
    };
    
    const notificationId = 'notif_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
    
    const notification = document.createElement('div');
    notification.id = notificationId;
    notification.className = `notification ${type}`;
    notification.innerHTML = `
        <div class="notification-icon">${icons[type]}</div>
        <div class="notification-content">
            <div class="notification-title">${title || titles[type]}</div>
            <div class="notification-message">${message}</div>
        </div>
        <button class="notification-close" onclick="removeNotification('${notificationId}')">×</button>
    `;
    
    container.appendChild(notification);
    
    // Auto remove after duration
    setTimeout(() => {
        removeNotification(notificationId);
    }, duration);
}

window.removeNotification = function(id) {
    const notification = document.getElementById(id);
    if (notification) {
        notification.classList.add('exit');
        setTimeout(() => {
            if (notification && notification.parentNode) {
                notification.remove();
            }
        }, 300);
    }
};

// ===== دوال التبويبات =====
function initTabs() {
    const tabs = document.querySelectorAll('.tab-btn');
    const panels = document.querySelectorAll('.tab-panel');
    
    tabs.forEach(tab => {
        tab.addEventListener('click', function() {
            tabs.forEach(t => t.classList.remove('active'));
            panels.forEach(p => p.classList.remove('active'));
            
            this.classList.add('active');
            const targetId = this.dataset.target;
            const panel = document.getElementById(targetId);
            if (panel) panel.classList.add('active');
        });
    });
}

// ===== دوال البحث =====
function initSearchListener() {
    const searchInput = document.getElementById('barcode_search');
    if (searchInput) {
        const wrapper = document.createElement('div');
        wrapper.style.position = 'relative';
        searchInput.parentNode.insertBefore(wrapper, searchInput);
        wrapper.appendChild(searchInput);
        
        searchInput.addEventListener('input', function() {
            clearTimeout(searchTimeout);
            searchTimeout = setTimeout(() => {
                searchByBarcode(this.value);
            }, 500);
        });
    }
    
    const quickSearch = document.getElementById('quickSearch');
    if (quickSearch) {
        quickSearch.addEventListener('input', debounce(applyFilters, 500));
    }
}

function searchByBarcode(keyword) {
    if (!keyword || keyword.length < 2) {
        document.getElementById('barcode_results')?.remove();
        return;
    }
    
    fetch(`${BASE_URL}/inventory/search-by-barcode?barcode=${encodeURIComponent(keyword)}`)
        .then(response => response.json())
        .then(data => {
            if (data.success && data.data.length > 0) {
                showSearchResults(data.data);
            } else {
                document.getElementById('barcode_results')?.remove();
            }
        })
        .catch(() => {});
}

function showSearchResults(products) {
    let resultsDiv = document.getElementById('barcode_results');
    if (!resultsDiv) {
        resultsDiv = document.createElement('div');
        resultsDiv.id = 'barcode_results';
        resultsDiv.className = 'search-results';
        document.getElementById('barcode_search').parentNode.appendChild(resultsDiv);
    }
    
    let html = '';
    products.forEach(product => {
        html += `
            <div class="result-item" onclick="selectProduct(${product.id})">
                <div>
                    <strong style="display:block; margin-bottom:3px;">${product.name}</strong>
                    <small style="color:#666;">${product.barcode}</small>
                </div>
                <span style="background:#e9ecef; padding:4px 10px; border-radius:30px; font-size:12px;">${product.units_per_carton} وحدة</span>
            </div>
        `;
    });
    
    resultsDiv.innerHTML = html;
}

function selectProduct(id) {
    const select = document.getElementById('batch_product_id');
    if (select) {
        for (let option of select.options) {
            if (option.value == id) {
                option.selected = true;
                break;
            }
        }
    }
    
    document.getElementById('barcode_results')?.remove();
    document.getElementById('barcode_search').value = '';
    calculateProfit();
    showNotification('success', 'تم الاختيار', 'تم اختيار المنتج بنجاح');
}

// ===== حساب الربح =====
function initProfitCalculator() {
    const costInput = document.getElementById('cost_price_carton');
    const priceInput = document.getElementById('selling_price_unit');
    const productSelect = document.getElementById('batch_product_id');
    
    if (costInput) costInput.addEventListener('input', calculateProfit);
    if (priceInput) priceInput.addEventListener('input', calculateProfit);
    if (productSelect) productSelect.addEventListener('change', calculateProfit);
}

function calculateProfit() {
    const costCarton = parseFloat(document.getElementById('cost_price_carton')?.value) || 0;
    const sellingUnit = parseFloat(document.getElementById('selling_price_unit')?.value) || 0;
    
    const productSelect = document.getElementById('batch_product_id');
    const selectedOption = productSelect?.selectedOptions[0];
    const unitsPerCarton = parseInt(selectedOption?.dataset.units) || 1;
    
    const costPerUnit = costCarton / unitsPerCarton;
    const profitPerUnit = sellingUnit - costPerUnit;
    const totalProfit = profitPerUnit * unitsPerCarton;
    
    const profitDisplay = document.getElementById('profitDisplay');
    if (profitDisplay) {
        profitDisplay.innerHTML = `💰 الربح: ${profitPerUnit.toFixed(2)} ₪/وحدة | إجمالي: ${totalProfit.toFixed(2)} ريال`;
        profitDisplay.style.color = profitPerUnit < 0 ? '#c62828' : '#2e7d32';
        profitDisplay.style.background = '#f8f9fa';
        profitDisplay.style.padding = '10px 15px';
        profitDisplay.style.borderRadius = '8px';
        profitDisplay.style.marginTop = '10px';
        profitDisplay.style.fontWeight = 'bold';
    }
}

// ===== توليد رقم دفعة =====
function generateBatchNumber() {
    const date = new Date();
    const year = date.getFullYear().toString().substr(-2);
    const month = ('0' + (date.getMonth() + 1)).slice(-2);
    const day = ('0' + date.getDate()).slice(-2);
    const random = Math.floor(Math.random() * 900) + 100;
    
    const batchInput = document.getElementById('batch_number');
    if (batchInput) {
        batchInput.value = `BATCH-${year}${month}${day}-${random}`;
    }
}

// ===== إضافة منتج =====
function addProduct() {
    const name = document.getElementById('product_name')?.value;
    const barcode = document.getElementById('product_barcode')?.value;
    const category = document.getElementById('product_category')?.value;
    const units = document.getElementById('units_per_carton')?.value;
    
    if (!name || !barcode || !units) {
        showNotification('error', 'خطأ', 'الرجاء ملء جميع الحقول المطلوبة');
        return;
    }
    
    fetch(`${BASE_URL}/inventory/add-product`, {
        method: 'POST',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: `name=${encodeURIComponent(name)}&barcode=${encodeURIComponent(barcode)}&category_id=${category}&units_per_carton=${units}`
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            showNotification('success', 'تم الإضافة', 'تم إضافة المنتج بنجاح');
            setTimeout(() => location.reload(), 1500);
        } else {
            showNotification('error', 'خطأ', data.message);
        }
    })
    .catch(() => {
        showNotification('error', 'خطأ', 'حدث خطأ في الاتصال');
    });
}

// ===== إضافة دفعة =====
function addBatch() {
    const productId = document.getElementById('batch_product_id')?.value;
    const batchNumber = document.getElementById('batch_number')?.value;
    const cartons = document.getElementById('cartons_quantity')?.value;
    const costPrice = document.getElementById('cost_price_carton')?.value;
    const sellingPrice = document.getElementById('selling_price_unit')?.value;
    const expiryDate = document.getElementById('expiry_date')?.value;
    const notes = document.getElementById('batch_notes')?.value;
    
    if (!productId || !batchNumber || !cartons || !costPrice || !sellingPrice || !expiryDate) {
        showNotification('error', 'خطأ', 'الرجاء ملء جميع الحقول المطلوبة');
        return;
    }
    
    const addBtn = document.querySelector('button[onclick="addBatch()"]');
    if (addBtn) addBtn.disabled = true;
    showLoading('جاري إضافة الدفعة...');
    
    fetch(`${BASE_URL}/inventory/add-batch`, {
        method: 'POST',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: `product_id=${productId}&batch_number=${encodeURIComponent(batchNumber)}&cartons_quantity=${cartons}&cost_price_carton=${costPrice}&selling_price_unit=${sellingPrice}&expiry_date=${expiryDate}&notes=${encodeURIComponent(notes)}`
    })
    .then(response => response.json())
    .then(data => {
        hideLoading();
        if (addBtn) addBtn.disabled = false;
        if (data.success) {
            showNotification('success', 'تم الإضافة', 'تم إضافة الدفعة بنجاح');
            setTimeout(() => location.reload(), 1500);
        } else {
            showNotification('error', 'خطأ', data.message);
        }
    })
    .catch(() => {
        hideLoading();
        if (addBtn) addBtn.disabled = false;
        showNotification('error', 'خطأ', 'حدث خطأ في الاتصال');
    });
}

// ===== رفع كرتون إلى الرف =====
function moveToShelf(batchId) {
    showConfirmDialog('هل أنت متأكد من رفع هذا الكرتون إلى الرف؟', function() {
        fetch(`${BASE_URL}/inventory/move-to-shelf`, {
            method: 'POST',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'},
            body: `batch_id=${batchId}`
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                showNotification('success', 'تم الرفع', 'تم رفع الكرتون إلى الرف بنجاح');
                setTimeout(() => location.reload(), 1500);
            } else {
                showNotification('error', 'خطأ', data.message);
            }
        });
    });
}

// ===== رفع FIFO =====
function moveFifo() {
    const productSelect = document.getElementById('filterProduct');
    const productId = productSelect?.value;
    
    if (!productId) {
        showNotification('warning', 'تنبيه', 'الرجاء اختيار منتج أولاً');
        return;
    }
    
    showConfirmDialog('هل تريد رفع أقدم كرتون من هذا المنتج إلى الرف؟', function() {
        fetch(`${BASE_URL}/inventory/move-fifo`, {
            method: 'POST',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'},
            body: `product_id=${productId}`
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                showNotification('success', 'تم الرفع', 'تم رفع الكرتون إلى الرف بنجاح');
                setTimeout(() => location.reload(), 1500);
            } else {
                showNotification('error', 'خطأ', data.message);
            }
        });
    });
}

// ===== رفع كراتين محددة =====
function moveSelectedToShelf() {
    const selected = [];
    document.querySelectorAll('.row-checkbox:checked').forEach(cb => {
        selected.push(cb.value);
    });
    
    if (selected.length === 0) {
        showNotification('warning', 'تنبيه', 'الرجاء اختيار دفعات أولاً');
        return;
    }
    
    showConfirmDialog(`هل أنت متأكد من رفع ${selected.length} كرتون إلى الرف؟`, function() {
        let successCount = 0;
        let failCount = 0;
        
        selected.forEach(batchId => {
            fetch(`${BASE_URL}/inventory/move-to-shelf`, {
                method: 'POST',
                headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                body: `batch_id=${batchId}`
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    successCount++;
                } else {
                    failCount++;
                }
                
                if (successCount + failCount === selected.length) {
                    if (successCount > 0) {
                        showNotification('success', 'تم الرفع', `تم رفع ${successCount} كرتون بنجاح`);
                    }
                    if (failCount > 0) {
                        showNotification('warning', 'تحذير', `فشل رفع ${failCount} كرتون`);
                    }
                    setTimeout(() => location.reload(), 2000);
                }
            });
        });
    });
}

// ===== عرض خيارات الرفع التلقائي =====

// ===== تنفيذ الرفع الذكي =====
function executeAutoRestock() {
    showConfirmDialog('هل تريد تنفيذ الرفع الذكي للمنتجات النافدة؟', function() {
        showLoading('جاري تنفيذ الرفع الذكي...');
        
        fetch(`${BASE_URL}/auto-restock/execute`, {
            method: 'POST',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'}
        })
        .then(response => response.json())
        .then(data => {
            hideLoading();
            
            if (data.success) {
                let msg = data.message;
                if (data.restocked?.length) {
                    msg = `تم رفع: ${data.restocked.map(r => r.product).join(', ')}`;
                }
                if (data.failed?.length) {
                    msg += `\nفشل: ${data.failed.join(', ')}`;
                }
                showNotification(data.failed?.length ? 'warning' : 'success', 'نتيجة الرفع', msg);
                setTimeout(() => location.reload(), 2000);
            } else {
                showNotification('error', 'خطأ', data.message);
            }
        })
        .catch(() => {
            hideLoading();
            showNotification('error', 'خطأ', 'حدث خطأ في الاتصال');
        });
    });
}

// ===== نظام الرفع التلقائي =====
let autoRestockInterval = null;

function initAutoRestock() {
    addAutoRestockButton();
    getAutoRestockStatus();
    if (autoRestockInterval) clearInterval(autoRestockInterval);
    autoRestockInterval = setInterval(() => { if (autoRestockEnabled) executeAutoRestock(true); }, 60000);
}

function executeAutoRestock(silent = false) {
    if (!silent) showLoading('جاري فحص الرفوف للرفع الذكي...');
    fetch(BASE_URL + '/auto-restock/execute', { method: 'POST', headers: {'Content-Type': 'application/json'} })
    .then(r => r.json()).then(data => {
        if (!silent) hideLoading();
        if (data.success && data.restocked && data.restocked.length > 0) {
            let msg = `تم التعبئة: \n`;
            data.restocked.slice(0, 3).forEach(i => msg += `- ${i.product} (للرف ${i.shelf_code})\n`);
            if (data.restocked.length > 3) msg += '...والمزيد';
            showNotification('success', 'رفع ذكي', msg, 7000);
            if (typeof applyFilters === 'function') applyFilters(); 
        } else if (!silent) {
            if (data.success) showNotification('info', 'الرفع الذكي', 'جميع الرفوف ممتلئة ولا تحتاج لرفع');
            else showNotification('error', 'خطأ', data.message || 'حدث خطأ');
        }
    }).catch(err => {
        if (!silent) { hideLoading(); showNotification('error', 'خطأ', 'فشل الاتصال بالرفع الذكي'); }
    });
}

function getAutoRestockStatus() {
    fetch(`${BASE_URL}/auto-restock/status`)
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                autoRestockEnabled = data.enabled;
                updateAutoRestockButton();
            }
        })
        .catch(() => {});
}

function addAutoRestockButton() {
    const toolbar = document.querySelector('.toolbar-left');
    if (!toolbar || document.getElementById('autoRestockToggle')) return;
    const toggleBtn = document.createElement('button');
    toggleBtn.id = 'autoRestockToggle';
    toggleBtn.className = 'btn btn-info btn-sm';
    toggleBtn.innerHTML = '<span>🤖</span> تشغيل التلقائي';
    toggleBtn.onclick = toggleAutoRestock;
    toggleBtn.title = 'تفعيل/تعطيل الرفع التلقائي';
    toggleBtn.style.marginRight = '5px';
    toolbar.appendChild(toggleBtn);
}

function updateAutoRestockButton() {
    const btn = document.getElementById('autoRestockToggle');
    if (!btn) return;
    
    if (autoRestockEnabled) {
        btn.innerHTML = '<span>🤖</span> إيقاف التلقائي';
        btn.classList.remove('btn-info');
        btn.classList.add('btn-success');
    } else {
        btn.innerHTML = '<span>🤖</span> تشغيل التلقائي';
        btn.classList.remove('btn-success');
        btn.classList.add('btn-info');
    }
}

function toggleAutoRestock() {
    const newState = !autoRestockEnabled;
    fetch(`${BASE_URL}/auto-restock/toggle`, { method: 'POST', headers: {'Content-Type': 'application/x-www-form-urlencoded'}, body: `enabled=${newState}` })
    .then(r => r.json()).then(data => {
        if (data.success) {
            autoRestockEnabled = data.enabled;
            updateAutoRestockButton();
            if (autoRestockEnabled) { 
                showNotification('success', 'التشغيل التلقائي', 'تم التفعيل، يتم فحص الرفوف فوراً...'); 
                if (typeof executeAutoRestock === 'function') executeAutoRestock(false); 
            } else { 
                showNotification('info', 'تم الإيقاف', 'تم إيقاف الرفع التلقائي'); 
            }
        }
    }).catch(() => {});
}

// ===== التحقق من التنبيهات =====
function checkAlerts() {
    fetch(`${BASE_URL}/alerts/get-unread`)
        .then(response => response.json())
        .then(data => {
            if (data.success && data.count > 0) {
                showAlertIcon(data.count);
                showNotification('warning', 'تنبيهات جديدة', `لديك ${data.count} تنبيه جديد`, 5000);
            }
        })
        .catch(() => {});
}

function showAlertIcon(count) {
    const alertBtn = document.querySelector('button[onclick="openAlerts()"]');
    if (alertBtn) {
        let badge = alertBtn.querySelector('.alert-badge');
        if (!badge) {
            badge = document.createElement('span');
            badge.className = 'alert-badge';
            alertBtn.appendChild(badge);
        }
        badge.textContent = count;
    }
}

// ===== دوال الفلاتر =====
function initFilters() {
    document.querySelectorAll('input[name="status_filter"]').forEach(r => r.addEventListener('change', applyFilters));
    document.getElementById('filterProduct')?.addEventListener('change', applyFilters);
    document.getElementById('filterCategory')?.addEventListener('change', applyFilters);
    document.getElementById('dateFrom')?.addEventListener('change', applyFilters);
    document.getElementById('dateTo')?.addEventListener('change', applyFilters);
}

function applyFilters() {
    const search = document.getElementById('quickSearch')?.value || '';
    const productId = document.getElementById('filterProduct')?.value || '';
    const categoryId = document.getElementById('filterCategory')?.value || '';
    const dateFrom = document.getElementById('dateFrom')?.value || '';
    const dateTo = document.getElementById('dateTo')?.value || '';
    
    let status = '';
    const selected = document.querySelector('input[name="status_filter"]:checked');
    if (selected) status = selected.value;
    
    let url = `${BASE_URL}/inventory/filter?search=${encodeURIComponent(search)}`;
    if (productId) url += `&product_id=${productId}`;
    if (categoryId) url += `&category_id=${categoryId}`;
    if (status) url += `&status=${status}`;
    if (dateFrom) url += `&date_from=${dateFrom}`;
    if (dateTo) url += `&date_to=${dateTo}`;
    
    showLoading('جاري تطبيق الفلاتر...');
    
    fetch(url)
        .then(response => response.json())
        .then(data => {
            hideLoading();
            if (data.success) updateTable(data.data);
        })
        .catch(() => hideLoading());
}

function resetFilters() {
    document.getElementById('quickSearch').value = '';
    document.getElementById('dateFrom').value = '';
    document.getElementById('dateTo').value = '';
    document.getElementById('filterProduct').value = '';
    document.getElementById('filterCategory').value = '';
    document.querySelector('input[name="status_filter"][value=""]').checked = true;
    location.reload();
}

function filterByType(type) {
    let val = '';
    if (type === 'expired') val = 'expired';
    else if (type === 'expiring') val = 'expiring';
    else if (type === 'low') val = 'low';
    
    const radio = document.querySelector(`input[name="status_filter"][value="${val}"]`);
    if (radio) {
        radio.checked = true;
        applyFilters();
    }
}

// ===== تحديث الجدول =====
function updateTable(data) {
    const tbody = document.getElementById('inventoryTableBody');
    if (!tbody) return;
    
    tbody.innerHTML = '';
    
    if (data.length === 0) {
        tbody.innerHTML = '<tr><td colspan="10" style="text-align:center;padding:40px;">لا توجد نتائج</td></tr>';
        return;
    }
    
    data.forEach((batch, i) => {
        const today = new Date();
        const expiry = new Date(batch.expiry_date);
        const daysLeft = (expiry - today) / (1000*60*60*24);
        
        let status = '', cls = '';
        if (expiry < today) { status = 'منتهي'; cls = 'status-expired'; }
        else if (daysLeft <= 30) { status = 'قريب'; cls = 'status-warning'; }
        else if (batch.cartons_remaining < 5) { status = 'منخفض'; cls = 'status-low'; }
        else { status = 'متاح'; cls = 'status-available'; }
        
        const row = document.createElement('tr');
        row.innerHTML = `
            <td><input type="checkbox" class="row-checkbox" value="${batch.id}" style="width:18px;height:18px;cursor:pointer;"></td>
            <td>${i+1}</td>
            <td><strong>${batch.product_name || ''}</strong></td>
            <td>${batch.batch_number || ''}</td>
            <td><span style="font-weight:bold; color:#0d6efd;">${batch.cartons_remaining || 0}</span></td>
            <td>${parseFloat(batch.cost_price_carton||0).toFixed(2)} ₪</td>
            <td>${parseFloat(batch.selling_price_unit||0).toFixed(2)} ₪</td>
            <td>${new Date(batch.expiry_date).toLocaleDateString('ar-EG')}</td>
            <td><span class="status-badge ${cls}">${status}</span></td>
            <td class="action-buttons" style="white-space: nowrap;">
                <button class="btn-icon btn-success" onclick="moveToShelf(${batch.id})" title="رفع إلى الرف">🔼</button>
                <button class="btn-icon btn-primary" onclick="editBatch(${batch.id})" title="تعديل">✏️</button>
                <button class="btn-icon btn-info" onclick="showDetails(${batch.id})" title="تفاصيل">📋</button>
                <button class="btn-icon btn-danger" onclick="showDeleteBatchModal(${batch.id}, '${batch.product_name}', '${batch.batch_number}')" title="حذف">🗑️</button>
            </td>
        `;
        tbody.appendChild(row);
    });
}

// ===== دوال مساعدة =====
function toggleSelectAll() {
    const selectAll = document.getElementById('selectAll');
    document.querySelectorAll('.row-checkbox').forEach(cb => cb.checked = selectAll.checked);
}

function exportExcel() {
    window.location.href = `${BASE_URL}/reports/export-excel?type=inventory`;
}

function refreshData() {
    location.reload();
}

function changePageSize() {
    applyFilters();
}

function openInventoryAudit() {
    window.location.href = `${BASE_URL}/audit`;
}

function openActivityLog() {
    window.location.href = `${BASE_URL}/logs`;
}

function openAlerts() {
    window.location.href = `${BASE_URL}/alerts`;
}

function openFifoReport() {
    showNotification('info', 'قريباً', 'سيتم تفعيل التقرير قريباً');
}

function clearProductForm() {
    document.getElementById('product_name').value = '';
    document.getElementById('product_barcode').value = '';
    document.getElementById('product_category').value = '';
    document.getElementById('units_per_carton').value = '1';
}

function clearBatchForm() {
    document.getElementById('batch_product_id').value = '';
    generateBatchNumber();
    document.getElementById('cartons_quantity').value = '1';
    document.getElementById('cost_price_carton').value = '0.00';
    document.getElementById('selling_price_unit').value = '0.00';
    document.getElementById('batch_notes').value = '';
}

function incrementUnits() {
    const input = document.getElementById('units_per_carton');
    if (input) input.value = parseInt(input.value) + 1;
}

function decrementUnits() {
    const input = document.getElementById('units_per_carton');
    if (input && parseInt(input.value) > 1) input.value = parseInt(input.value) - 1;
}

function incrementCartons() {
    const input = document.getElementById('cartons_quantity');
    if (input) input.value = parseInt(input.value) + 1;
}

function decrementCartons() {
    const input = document.getElementById('cartons_quantity');
    if (input && parseInt(input.value) > 1) input.value = parseInt(input.value) - 1;
}

function showLoading(message = 'جاري التحميل...') {
    hideLoading();
    const loader = document.createElement('div');
    loader.id = 'customLoading';
    loader.className = 'loading-overlay';
    
    const box = document.createElement('div');
    box.className = 'loading-box';
    box.innerHTML = `
        <div class="loading-spinner"></div>
        <div style="color: #333; font-weight: bold;">${message}</div>
    `;
    
    loader.appendChild(box);
    document.body.appendChild(loader);
}

function hideLoading() {
    const loader = document.getElementById('customLoading');
    if (loader) loader.remove();
}

function closeModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) modal.remove();
}

function debounce(func, wait) {
    let timeout;
    return function(...args) {
        clearTimeout(timeout);
        timeout = setTimeout(() => func(...args), wait);
    };
}

// ===== دوال التأكيد المخصصة =====
function showConfirmDialog(message, onConfirm, onCancel = null) {
    const modalId = 'confirmDialog_' + Date.now();
    
    const modal = document.createElement('div');
    modal.id = modalId;
    modal.className = 'modal-overlay';
    modal.innerHTML = `
        <div class="modal-window" style="max-width: 400px;">
            <div class="modal-header warning">
                <h3>⚠️ تأكيد العملية</h3>
                <button class="modal-close" onclick="closeModal('${modalId}')">×</button>
            </div>
            <div class="modal-body" style="text-align: center; padding: 30px 25px;">
                <div style="font-size: 48px; margin-bottom: 20px;">❓</div>
                <p style="font-size: 18px; margin-bottom: 10px; color: #333;">${message}</p>
            </div>
            <div class="modal-footer" style="justify-content: center; gap: 15px;">
                <button type="button" class="btn btn-success" id="btnYes_${modalId}" onclick="if(!this.disabled){this.disabled=true; executeConfirm('${modalId}', true);}">✅ نعم، متأكد</button>
                <button type="button" class="btn btn-danger" onclick="executeConfirm('${modalId}', false)">❌ إلغاء</button>
            </div>
        </div>
    `;
    
    window.confirmCallbacks = window.confirmCallbacks || {};
    window.confirmCallbacks[modalId] = {
        onConfirm: onConfirm,
        onCancel: onCancel
    };
    
    document.body.appendChild(modal);

    setTimeout(() => {
        const yesBtn = document.getElementById(`btnYes_${modalId}`);
        if (yesBtn) {
            yesBtn.focus();
        }
    }, 10);
}

window.executeConfirm = function(modalId, confirmed) {
    closeModal(modalId);
    
    const callbacks = window.confirmCallbacks?.[modalId];
    if (callbacks) {
        if (confirmed && callbacks.onConfirm) {
            callbacks.onConfirm();
        } else if (!confirmed && callbacks.onCancel) {
            callbacks.onCancel();
        }
        delete window.confirmCallbacks[modalId];
    }
};

// ===== دوال تفاصيل وتعديل =====
function showDetails(batchId) {
    fetch(BASE_URL + '/inventory/get-batch-details?id=' + batchId)
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                showBatchDetailsModal(data.data);
            } else {
                showNotification('error', 'خطأ', data.message);
            }
        });
}

function showBatchDetailsModal(data) {
    const modal = document.createElement('div');
    modal.className = 'modal-overlay';
    modal.innerHTML = `
        <div class="modal-window" style="max-width: 600px;">
            <div class="modal-header info">
                <h3>📋 تفاصيل الدفعة</h3>
                <button class="modal-close" onclick="this.closest('.modal-overlay').remove()">×</button>
            </div>
            <div class="modal-body">
                <div style="margin-bottom: 20px;">
                    <div style="background: #f8f9fa; padding: 15px; border-radius: 8px; margin-bottom: 15px;">
                        <p style="margin-bottom: 10px;"><strong>رقم الدفعة:</strong> ${data.batch.batch_number}</p>
                        <p style="margin-bottom: 10px;"><strong>المنتج:</strong> ${data.product.name}</p>
                        <p style="margin-bottom: 10px;"><strong>الباركود:</strong> ${data.product.barcode}</p>
                        <p style="margin-bottom: 10px;"><strong>الكراتين المتبقية:</strong> ${data.batch.cartons_remaining}</p>
                        <p style="margin-bottom: 10px;"><strong>تكلفة الكرتون:</strong> ${parseFloat(data.batch.cost_price_carton).toFixed(2)} ₪</p>
                        <p style="margin-bottom: 10px;"><strong>سعر الوحدة:</strong> ${parseFloat(data.batch.selling_price_unit).toFixed(2)} ₪</p>
                        <p style="margin-bottom: 10px;"><strong>تاريخ الانتهاء:</strong> ${data.batch.expiry_date}</p>
                        <p><strong>ملاحظات:</strong> ${data.batch.notes || 'لا توجد'}</p>
                    </div>
                </div>
                
                ${data.shelf_items && data.shelf_items.length > 0 ? `
                    <h4 style="margin-bottom: 15px; color: #333;">📦 عناصر الرف</h4>
                    <table style="width: 100%; border-collapse: collapse; background: white; border-radius: 8px; overflow: hidden;">
                        <tr style="background: #343a40; color: white;">
                            <th style="padding: 10px;">كود الرف</th>
                            <th style="padding: 10px;">الوحدات</th>
                            <th style="padding: 10px;">الحالة</th>
                        </tr>
                        ${data.shelf_items.map(item => `
                            <tr style="border-bottom: 1px solid #e0e0e0;">
                                <td style="padding: 10px;">${item.shelf_code}</td>
                                <td style="padding: 10px;"><strong>${item.units_remaining}</strong></td>
                                <td style="padding: 10px;">
                                    <span class="status-badge status-${item.status}">${item.status}</span>
                                </td>
                            </tr>
                        `).join('')}
                    </table>
                ` : '<p style="color: #999; text-align: center; padding: 20px;">لا توجد عناصر في الرف</p>'}
            </div>
            <div class="modal-footer">
                <button class="btn btn-info" onclick="this.closest('.modal-overlay').remove()">إغلاق</button>
            </div>
        </div>
    `;
    
    document.body.appendChild(modal);
}

function editBatch(batchId) {
    fetch(BASE_URL + '/inventory/check-permission')
        .then(response => response.json())
        .then(data => {
            if (!data.isAdmin) {
                showNotification('error', 'غير مصرح', 'غير مصرح لك بالتعديل');
                return;
            }
            
            fetch(BASE_URL + '/inventory/get-batch-details?id=' + batchId)
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        showEditBatchModal(data.data);
                    }
                });
        });
}

function showEditBatchModal(data) {
    const modal = document.createElement('div');
    modal.className = 'modal-overlay';
    modal.innerHTML = `
        <div class="modal-window" style="max-width: 500px;">
            <div class="modal-header" style="background: linear-gradient(135deg, #1a237e, #0d47a1);">
                <h3 style="color: white;">✏️ تعديل الدفعة</h3>
                <button class="modal-close" onclick="this.closest('.modal-overlay').remove()">×</button>
            </div>
            <div class="modal-body">
                <div style="background: #f8f9fa; padding: 15px; border-radius: 8px; margin-bottom: 20px;">
                    <p><strong>رقم الدفعة:</strong> ${data.batch.batch_number}</p>
                    <p><strong>المنتج:</strong> ${data.product.name}</p>
                </div>
                
                <div class="form-group">
                    <label>تكلفة الكرتون</label>
                    <input type="number" step="0.01" id="edit_cost" value="${data.batch.cost_price_carton}" class="form-control">
                </div>
                
                <div class="form-group">
                    <label>سعر البيع</label>
                    <input type="number" step="0.01" id="edit_price" value="${data.batch.selling_price_unit}" class="form-control">
                </div>
                
                <div class="form-group">
                    <label>تاريخ الانتهاء</label>
                    <input type="date" id="edit_expiry" value="${data.batch.expiry_date}" class="form-control">
                </div>
                
                <div class="form-group">
                    <label>ملاحظات</label>
                    <textarea id="edit_notes" class="form-control" rows="3">${data.batch.notes || ''}</textarea>
                </div>
            </div>
            <div class="modal-footer">
                <button onclick="saveBatchEdit(${data.batch.id})" class="btn btn-success">💾 حفظ التعديلات</button>
                <button class="btn btn-danger" onclick="this.closest('.modal-overlay').remove()">إلغاء</button>
            </div>
        </div>
    `;
    
    document.body.appendChild(modal);
}

function saveBatchEdit(batchId) {
    const data = {
        id: batchId,
        cost_price_carton: document.getElementById('edit_cost')?.value,
        selling_price_unit: document.getElementById('edit_price')?.value,
        expiry_date: document.getElementById('edit_expiry')?.value,
        notes: document.getElementById('edit_notes')?.value
    };
    
    fetch(BASE_URL + '/inventory/update-batch', {
        method: 'POST',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: new URLSearchParams(data)
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            showNotification('success', 'تم التحديث', 'تم تحديث الدفعة بنجاح');
            setTimeout(() => {
                document.querySelector('.modal-overlay')?.remove();
                location.reload();
            }, 1500);
        } else {
            showNotification('error', 'خطأ', data.message);
        }
    });
}

// ===== دوال حذف المنتج والدفعة =====
function showDeleteOptions() {
    const modal = document.createElement('div');
    modal.className = 'modal-overlay';
    modal.id = 'deleteOptionsModal';
    modal.innerHTML = `
        <div class="modal-window" style="max-width: 400px;">
            <div class="modal-header error">
                <h3>🗑️ خيارات الحذف</h3>
                <button class="modal-close" onclick="this.closest('.modal-overlay').remove()">×</button>
            </div>
            <div class="modal-body">
                <p style="margin-bottom: 20px; text-align: center; color: #666;">اختر نوع الحذف الذي تريد تنفيذه:</p>
                
                <div style="display: flex; flex-direction: column; gap: 10px;">
                    <button onclick="showDeleteSelectedBatches()" 
                            class="btn btn-warning" style="justify-content: center; padding: 15px; background-color: #ff9800; color: white;">
                        <span style="font-size: 20px;">🗑️</span> حذف الدفعات المحددة
                    </button>
                    
                    <button onclick="showDeleteBatchSelection()" 
                            class="btn btn-danger" style="justify-content: center; padding: 15px;">
                        <span style="font-size: 20px;">📦</span> حذف دفعة يدوياً
                    </button>
                    
                    <button onclick="showDeleteProductSelection()" 
                            class="btn btn-danger" style="justify-content: center; padding: 15px;">
                        <span style="font-size: 20px;">🏷️</span> حذف منتج بالكامل
                    </button>
                </div>
            </div>
            <div class="modal-footer">
                <button class="btn btn-secondary" onclick="this.closest('.modal-overlay').remove()">إلغاء</button>
            </div>
        </div>
    `;
    
    document.body.appendChild(modal);
}

function showDeleteSelectedBatches() {
    const selected = [];
    document.querySelectorAll('.row-checkbox:checked').forEach(cb => {
        selected.push(cb.value);
    });
    if (selected.length === 0) {
        showNotification('warning', 'تنبيه', 'الرجاء تحديد دفعات للحذف من الجدول أولاً');
        return;
    }
    const modalOpt = document.getElementById('deleteOptionsModal');
    if (modalOpt) modalOpt.remove();
    showConfirmDialog(`هل أنت متأكد من حذف ${selected.length} دفعة محددة؟`, function() {
        showLoading('جاري الحذف...');
        let successCount = 0;
        let failCount = 0;
        const deleteNext = (index) => {
            if (index >= selected.length) {
                hideLoading();
                if (successCount > 0) showNotification('success', 'اكتمل', `تم حذف ${successCount} دفعة.`);
                if (failCount > 0) showNotification('warning', 'تنبيه', `فشل حذف ${failCount} دفعة.`);
                setTimeout(() => location.reload(), 2000);
                return;
            }
            const fd = new URLSearchParams(); fd.append('id', selected[index]);
            fetch(`${BASE_URL}/inventory/delete-batch`, {method: 'POST', headers: {'Content-Type': 'application/x-www-form-urlencoded'}, body: fd.toString()})
            .then(r => r.json()).then(d => { if(d.success) successCount++; else failCount++; deleteNext(index + 1); })
            .catch(() => { failCount++; deleteNext(index + 1); });
        };
        deleteNext(0);
    });
}
function showDeleteBatchSelection() {
    closeModal('deleteOptionsModal');
    showLoading('جاري تحميل الدفعات...');
    
    fetch(`${BASE_URL}/inventory/filter`)
        .then(response => response.json())
        .then(data => {
            hideLoading();
            
            if (!data.success || !data.data || data.data.length === 0) {
                showNotification('warning', 'لا توجد دفعات', 'لا توجد دفعات لعرضها');
                return;
            }
            
            let batchesHtml = '';
            data.data.forEach((batch, index) => {
                batchesHtml += `
                    <tr>
                        <td style="padding: 10px;">${index + 1}</td>
                        <td style="padding: 10px;"><strong>${batch.product_name || ''}</strong></td>
                        <td style="padding: 10px;">${batch.batch_number || ''}</td>
                        <td style="padding: 10px;"><span style="color:#0d6efd; font-weight:bold;">${batch.cartons_remaining || 0}</span></td>
                        <td style="padding: 10px;">
                            <button onclick="deleteBatch(${batch.id})" class="btn btn-danger btn-sm" style="padding:5px 15px;">
                                حذف
                            </button>
                        </td>
                    </tr>
                `;
            });
            
            const modal = document.createElement('div');
            modal.className = 'modal-overlay';
            modal.innerHTML = `
                <div class="modal-window" style="max-width: 800px;">
                    <div class="modal-header error">
                        <h3>🗑️ حذف دفعة</h3>
                        <button class="modal-close" onclick="this.closest('.modal-overlay').remove()">×</button>
                    </div>
                    <div class="modal-body">
                        <div style="margin-bottom: 15px;">
                            <input type="text" placeholder="ابحث عن دفعة..." class="form-control" 
                                   onkeyup="filterBatchesTable(this.value)" style="width:100%;">
                        </div>
                        
                        <div style="max-height: 400px; overflow-y: auto;">
                            <table style="width:100%; border-collapse:collapse;">
                                <thead>
                                    <tr style="background:#343a40; color:white; position:sticky; top:0;">
                                        <th style="padding:10px;">#</th>
                                        <th style="padding:10px;">المنتج</th>
                                        <th style="padding:10px;">رقم الدفعة</th>
                                        <th style="padding:10px;">الكراتين</th>
                                        <th style="padding:10px;">الإجراء</th>
                                    </tr>
                                </thead>
                                <tbody id="batchesTableBody">
                                    ${batchesHtml}
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button class="btn btn-secondary" onclick="this.closest('.modal-overlay').remove()">إغلاق</button>
                    </div>
                </div>
            `;
            
            document.body.appendChild(modal);
            
            window.filterBatchesTable = function(searchText) {
                const rows = document.querySelectorAll('#batchesTableBody tr');
                searchText = searchText.toLowerCase();
                rows.forEach(row => {
                    const productName = row.cells[1].textContent.toLowerCase();
                    const batchNum = row.cells[2].textContent.toLowerCase();
                    row.style.display = (productName.includes(searchText) || batchNum.includes(searchText)) ? '' : 'none';
                });
            };
        })
        .catch(() => {
            hideLoading();
            showNotification('error', 'خطأ', 'فشل تحميل الدفعات');
        });
}

function deleteBatch(batchId, skipConfirm = false) {
    if (!skipConfirm) {
        showConfirmDialog('هل أنت متأكد من حذف هذه الدفعة؟', function() {
            deleteBatch(batchId, true);
        });
        return;
    }
    
    showLoading('جاري حذف الدفعة...');
    
    const formData = new URLSearchParams();
    formData.append('id', batchId);
    
    fetch(`${BASE_URL}/inventory/delete-batch`, {
        method: 'POST',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: formData.toString()
    })
    .then(response => response.json())
    .then(data => {
        hideLoading();
        
        if (data.success) {
            showNotification('success', 'تم الحذف', 'تم حذف الدفعة بنجاح');
            setTimeout(() => location.reload(), 1500);
        } else {
            showNotification('error', 'خطأ', data.message || 'فشل في حذف الدفعة');
        }
    })
    .catch(() => {
        hideLoading();
        showNotification('error', 'خطأ', 'حدث خطأ في الاتصال');
    });
}

function showDeleteBatchModal(batchId, productName, batchNumber) {
    showConfirmDialog(`هل أنت متأكد من حذف الدفعة: ${productName} - ${batchNumber}؟`, function() {
        deleteBatch(batchId, true);
    });
}

function showDeleteProductSelection() {
    closeModal('deleteOptionsModal');
    showLoading('جاري تحميل المنتجات...');
    
    fetch(`${BASE_URL}/inventory/get-products`, {
        method: 'POST',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: 'action=get_products'
    })
    .then(response => response.text())
    .then(text => {
        hideLoading();
        
        let data;
        try {
            data = JSON.parse(text);
        } catch (e) {
            showNotification('error', 'خطأ', 'خطأ في استجابة الخادم');
            return;
        }
        
        if (!data.success) {
            showNotification('error', 'خطأ', data.message || 'فشل تحميل المنتجات');
            return;
        }
        
        if (!data.data || data.data.length === 0) {
            showNotification('warning', 'لا توجد منتجات', 'لا توجد منتجات لعرضها');
            return;
        }
        
        showProductListModal(data.data);
    })
    .catch(() => {
        hideLoading();
        showNotification('error', 'خطأ', 'حدث خطأ في الاتصال');
    });
}

function showProductListModal(products) {
    const oldModal = document.getElementById('productListModal');
    if (oldModal) oldModal.remove();
    
    let productsHtml = '';
    products.forEach((product, index) => {
        productsHtml += `
            <tr>
                <td style="padding: 10px;">${index + 1}</td>
                <td style="padding: 10px;"><strong>${product.name || ''}</strong></td>
                <td style="padding: 10px;">${product.barcode || ''}</td>
                <td style="padding: 10px;">${product.category_name || 'غير محدد'}</td>
                <td style="padding: 10px;">
                    <button onclick="confirmDeleteProduct(${product.id}, '${product.name.replace(/'/g, "\\'")}')" 
                            class="btn btn-danger btn-sm" style="padding:5px 15px;">
                        حذف
                    </button>
                </td>
            </tr>
        `;
    });
    
    const modal = document.createElement('div');
    modal.id = 'productListModal';
    modal.className = 'modal-overlay';
    modal.innerHTML = `
        <div class="modal-window" style="max-width: 900px;">
            <div class="modal-header error">
                <h3>🗑️ حذف منتج</h3>
                <button class="modal-close" onclick="this.closest('.modal-overlay').remove()">×</button>
            </div>
            <div class="modal-body">
                <div style="margin-bottom: 15px; display:flex; gap:10px;">
                    <input type="text" id="productSearchInput" placeholder="ابحث عن منتج..." 
                           class="form-control" style="flex:1;"
                           onkeyup="filterProductsTable(this.value)">
                    <span style="background:#dc3545; color:white; padding:8px 20px; border-radius:30px; font-weight:bold;" id="productCount">${products.length}</span>
                </div>
                
                <div style="max-height: 400px; overflow-y: auto;">
                    <table style="width:100%; border-collapse:collapse;">
                        <thead>
                            <tr style="background:#343a40; color:white; position:sticky; top:0;">
                                <th style="padding:10px;">#</th>
                                <th style="padding:10px;">المنتج</th>
                                <th style="padding:10px;">الباركود</th>
                                <th style="padding:10px;">القسم</th>
                                <th style="padding:10px;">الإجراء</th>
                            </tr>
                        </thead>
                        <tbody id="productsTableBody">
                            ${productsHtml}
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="modal-footer">
                <button class="btn btn-secondary" onclick="this.closest('.modal-overlay').remove()">إغلاق</button>
            </div>
        </div>
    `;
    
    document.body.appendChild(modal);
    
    window.filterProductsTable = function(searchText) {
        const rows = document.querySelectorAll('#productsTableBody tr');
        let visibleCount = 0;
        searchText = searchText.toLowerCase();
        
        rows.forEach(row => {
            const productName = row.cells[1].textContent.toLowerCase();
            const barcode = row.cells[2].textContent.toLowerCase();
            
            if (productName.includes(searchText) || barcode.includes(searchText)) {
                row.style.display = '';
                visibleCount++;
            } else {
                row.style.display = 'none';
            }
        });
        
        const countSpan = document.getElementById('productCount');
        if (countSpan) countSpan.textContent = visibleCount;
    };
}

function confirmDeleteProduct(productId, productName) {
    const modal = document.createElement('div');
    modal.id = 'confirmDeleteModal';
    modal.className = 'modal-overlay';
    modal.innerHTML = `
        <div class="modal-window" style="max-width: 450px;">
            <div class="modal-header error">
                <h3>⚠️ تأكيد الحذف النهائي</h3>
                <button class="modal-close" onclick="this.closest('.modal-overlay').remove()">×</button>
            </div>
            <div class="modal-body">
                <div style="background: #f8f9fa; border: 2px solid #dc3545; border-radius: 10px; padding: 20px; margin-bottom: 20px; text-align: center;">
                    <p style="font-size: 16px; margin-bottom: 10px; color: #dc3545; font-weight: bold;">أنت على وشك حذف المنتج:</p>
                    <div style="font-size: 22px; font-weight: bold; color: #343a40;">${productName}</div>
                </div>
                
                <div style="background: #fff3cd; border: 1px solid #ffc107; border-radius: 8px; padding: 15px; margin-bottom: 20px; color: #856404;">
                    <strong>⛔ هذا الإجراء لا يمكن التراجع عنه</strong><br>
                    سيتم حذف المنتج وجميع الدفعات المرتبطة به نهائياً.
                </div>
            </div>
            <div class="modal-footer">
                <button onclick="executeDeleteProduct(${productId})" class="btn btn-danger">نعم، احذف نهائياً</button>
                <button class="btn btn-secondary" onclick="this.closest('.modal-overlay').remove()">إلغاء</button>
            </div>
        </div>
    `;
    
    document.body.appendChild(modal);
}

function executeDeleteProduct(productId) {
    const confirmModal = document.getElementById('confirmDeleteModal');
    if (confirmModal) confirmModal.remove();
    
    const productModal = document.getElementById('productListModal');
    if (productModal) productModal.remove();
    
    showLoading('جاري حذف المنتج...');
    
    const formData = new URLSearchParams();
    formData.append('id', productId);
    
    fetch(`${BASE_URL}/inventory/delete-product`, {
        method: 'POST',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: formData.toString()
    })
    .then(response => response.text())
    .then(text => {
        hideLoading();
        
        let data;
        try {
            data = JSON.parse(text);
        } catch (e) {
            showNotification('error', 'خطأ', 'خطأ في استجابة الخادم');
            return;
        }
        
        if (data.success) {
            showNotification('success', 'تم الحذف', 'تم حذف المنتج وجميع بياناته بنجاح');
            setTimeout(() => location.reload(), 2000);
        } else {
            showNotification('error', 'خطأ', data.message || 'فشل في حذف المنتج');
        }
    })
    .catch(() => {
        hideLoading();
        showNotification('error', 'خطأ', 'حدث خطأ في الاتصال');
    });
}
function toggleFullscreen() {
    const modal = document.querySelector('.history-modal');
    if (!modal) return;
    
    if (!isFullscreen) {
        modal.style.width = '100%';
        modal.style.height = '100%';
        modal.style.maxWidth = '100%';
        modal.style.borderRadius = '0';
    } else {
        modal.style.width = '900px';
        modal.style.height = '80vh';
        modal.style.maxWidth = '90%';
        modal.style.borderRadius = '8px';
    }
    
    isFullscreen = !isFullscreen;
}


(function() {
    const obliterateChromeAutofill = () => {
        // استهداف جميع حقول كلمة المرور
        const passwordInputs = document.querySelectorAll('input[type="password"]');

        passwordInputs.forEach(originalInput => {
            // تجاهل الحقل إذا تم تطبيق الخدعة عليه مسبقاً
            if (originalInput.hasAttribute('data-cloned')) return;
            originalInput.setAttribute('data-cloned', 'true');

            // 1. إخفاء الحقل الأصلي تماماً عن المتصفح والمستخدم
            originalInput.style.position = 'absolute';
            originalInput.style.opacity = '0';
            originalInput.style.pointerEvents = 'none';
            originalInput.style.zIndex = '-9999';
            originalInput.tabIndex = -1; // منع الوصول إليه بزر Tab

            // 2. إنشاء حقل بديل "وهمي" آمن تماماً
            const clone = document.createElement('input');
            clone.type = 'text'; // نوع نصي عادي
            clone.className = originalInput.className; // نسخ نفس التصميم
            clone.placeholder = originalInput.placeholder; // نسخ النص الإرشادي
            
            // إضافة سمات تمنع إضافات الطرف الثالث (مثل LastPass وقوقل)
            clone.setAttribute('autocomplete', 'new-password'); // كسر التوقع
            clone.setAttribute('data-lpignore', 'true');
            clone.setAttribute('data-form-type', 'other');
            clone.setAttribute('spellcheck', 'false');

            // تشفير النص بصرياً ليظهر كنقاط
            clone.style.webkitTextSecurity = 'disc';
            clone.style.textSecurity = 'disc';

            // 3. المزامنة السرية: أي شيء يكتب في البديل، ينسخ للأصلي
            clone.addEventListener('input', function() {
                originalInput.value = this.value;
                // إطلاق حدث التغيير في حال كان هناك كود آخر يعتمد عليه
                originalInput.dispatchEvent(new Event('input', { bubbles: true }));
            });

            // 4. إدراج الحقل البديل في الواجهة قبل الحقل الأصلي
            originalInput.parentNode.insertBefore(clone, originalInput);

            // 5. منع النقر المزدوج الذي قد يثير شكوك المتصفح
            clone.addEventListener('mousedown', function(e) {
                if (e.detail > 1) e.preventDefault();
            });
        });
    };

    // التنفيذ فوراً عند تحميل الصفحة
    obliterateChromeAutofill();

    // مراقبة النوافذ المنبثقة (Modals) لتطبيق الخدعة على أي حقل يظهر فجأة
    const observer = new MutationObserver(obliterateChromeAutofill);
    observer.observe(document.body, { childList: true, subtree: true });

})();

