<?php
// config/menu.php
return [
    'dashboard'  => ['title' => 'الرئيسية', 'icon' => '🏠', 'role' => 'all'],
    'inventory'  => ['title' => 'المخزن الرئيسي', 'icon' => '🏭', 'role' => 'admin'],
    'shelf'      => ['title' => 'رف البيع', 'icon' => '🛒', 'role' => 'admin'],
    'pos'        => ['title' => 'نقطة البيع', 'icon' => '💰', 'role' => 'all'],
    'customers'  => ['title' => 'العملاء', 'icon' => '👥', 'role' => 'all'],
    'reports'    => ['title' => 'التقارير', 'icon' => '📊', 'role' => 'admin'],
    'settings'   => ['title' => 'الإعدادات', 'icon' => '⚙️', 'role' => 'admin'],
];
