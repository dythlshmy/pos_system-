<?php
function redirect($url) {
    $url = ltrim($url, '/');
    header('Location: ' . BASE_URL . '/' . $url);
    exit;
}

function asset($path) {
    return BASE_URL . '/assets/' . ltrim($path, '/');
}

function view($view, $data = []) {
    extract($data);
    $viewPath = BASE_PATH . 'views/' . str_replace('.', '/', $view) . '.php';
    if (file_exists($viewPath)) {
        require $viewPath;
    } else {
        die("الصفحة غير موجودة: " . $viewPath);
    }
}

function isPost() {
    return $_SERVER['REQUEST_METHOD'] === 'POST';
}

function isGet() {
    return $_SERVER['REQUEST_METHOD'] === 'GET';
}

function sanitize($input) {
    return htmlspecialchars(trim($input), ENT_QUOTES, 'UTF-8');
}

/**
 * طباعة مصفوفة للت Debug
 */
function debug($var) {
    echo '<pre style="direction: ltr; background: #f4f4f4; padding: 10px; border: 1px solid #ccc; margin: 10px; border-radius: 5px;">';
    print_r($var);
    echo '</pre>';
}

/**
 * إنشاء رقم فاتورة فريد
 */
function generateInvoiceNumber($prefix = 'INV') {
    return $prefix . '-' . date('Ymd') . '-' . rand(1000, 9999);
}

/**
 * إنشاء رقم دفعة فريد
 */
function generateBatchNumber($productId = null) {
    $date = date('ymd');
    $random = rand(100, 999);
    if ($productId) {
        return "BATCH-{$productId}-{$date}-{$random}";
    }
    return "BATCH-{$date}-{$random}";
}

/**
 * تنسيق التاريخ
 */
function formatDate($date, $format = 'Y-m-d') {
    if (!$date || $date == '0000-00-00' || $date == '1970-01-01') {
        return '-';
    }
    return date($format, strtotime($date));
}

/**
 * تنسيق المبلغ
 */
function formatMoney($amount) {
    return number_format((float)$amount, 2, '.', ',') . ' ' . CURRENCY;
}

/**
 * قطع النص الطويل
 */
function truncate($text, $length = 50) {
    if (mb_strlen($text) <= $length) {
        return $text;
    }
    return mb_substr($text, 0, $length) . '...';
}

/**
 * الحصول على عنوان IP
 */
function getClientIP() {
    $ipaddress = '';
    if (isset($_SERVER['HTTP_CLIENT_IP']))
        $ipaddress = $_SERVER['HTTP_CLIENT_IP'];
    else if(isset($_SERVER['HTTP_X_FORWARDED_FOR']))
        $ipaddress = $_SERVER['HTTP_X_FORWARDED_FOR'];
    else if(isset($_SERVER['HTTP_X_FORWARDED']))
        $ipaddress = $_SERVER['HTTP_X_FORWARDED'];
    else if(isset($_SERVER['HTTP_FORWARDED_FOR']))
        $ipaddress = $_SERVER['HTTP_FORWARDED_FOR'];
    else if(isset($_SERVER['HTTP_FORWARDED']))
        $ipaddress = $_SERVER['HTTP_FORWARDED'];
    else if(isset($_SERVER['REMOTE_ADDR']))
        $ipaddress = $_SERVER['REMOTE_ADDR'];
    else
        $ipaddress = 'UNKNOWN';
    return $ipaddress;
}

/**
 * تسجيل نشاط في الملف
 */
function logToFile($message, $type = 'info') {
    $logFile = BASE_PATH . 'storage/logs/' . date('Y-m-d') . '.log';
    $logDir = dirname($logFile);
    
    if (!is_dir($logDir)) {
        mkdir($logDir, 0777, true);
    }
    
    $timestamp = date('Y-m-d H:i:s');
    $logMessage = "[$timestamp] [$type] $message" . PHP_EOL;
    
    file_put_contents($logFile, $logMessage, FILE_APPEND);
}

if (!function_exists('is_license_active')) {
    function is_license_active() {
        static $licenseModel = null;
        if ($licenseModel === null) {
            $licenseModel = new LicenseModel();
        }
        $status = $licenseModel->checkLicenseStatus();
        return $status['status'] === 'active';
    }
}

if (!function_exists('get_license_info')) {
    function get_license_info() {
        $licenseModel = new LicenseModel();
        return $licenseModel->checkLicenseStatus();
    }
}

if (!function_exists('generate_fingerprint')) {
    function generate_fingerprint() {
        $fingerprint = new Fingerprint();
        return $fingerprint->generateFingerprintKey();
    }
}

if (!function_exists('format_date')) {
    function format_date($date, $format = 'Y-m-d') {
        if (!$date) return '';
        return date($format, strtotime($date));
    }
}