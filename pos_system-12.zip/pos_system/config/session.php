<?php
// إعدادات تمديد الجلسة
ini_set('session.gc_maxlifetime', 86400); // يوم كامل
ini_set('session.cookie_lifetime', 86400);

if (session_status() === PHP_SESSION_NONE) {
    // تأمين الكوكيز لتعمل مع الـ Ajax بكثرة
    session_set_cookie_params([
        'lifetime' => 86400,
        'path' => '/',
        'domain' => '',
        'secure' => false, // اجعله true إذا كنت تستخدم https
        'httponly' => true,
        'samesite' => 'Lax'
    ]);
    session_start();
}
