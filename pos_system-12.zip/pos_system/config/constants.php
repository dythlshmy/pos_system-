<?php
// منع إعادة تعريف الثوابت
if (!defined('BASE_PATH')) {
    define('BASE_PATH', dirname(__DIR__) . DIRECTORY_SEPARATOR);
}

if (!defined('BASE_URL')) {
    define('BASE_URL', 'http://localhost/pos_system');
}

if (!defined('DB_HOST')) {
    define('DB_HOST', 'localhost');
    define('DB_NAME', 'smart_stock_db');
    define('DB_USER', 'root');
    define('DB_PASS', '');
    define('DB_CHARSET', 'utf8mb4');
    define('TIMEZONE', 'Asia/Riyadh');
}

if (!defined('APP_NAME')) {
    define('APP_NAME', 'نظام الكاشير');
    define('APP_VERSION', '1.0.0');
    define('PAGINATION_LIMIT', 20);
    define('LOW_STOCK_LIMIT', 5);
    define('DATE_FORMAT', 'Y-m-d');
    define('DATETIME_FORMAT', 'Y-m-d H:i:s');
    define('CURRENCY', 'ريال');
}

// ============================================
// ✅ ثوابت نظام الترخيص والتشفير (إضافات جديدة)
// ============================================

// كلمات المرور الثابتة (يجب أن تطابق نظام المطور)
if (!defined('PASSWORD1')) {
    define('PASSWORD1', "I'm developer @.DiaaiD");
    define('PASSWORD2', "085213");
}

// مفتاح JWT السري (يجب أن يطابق نظام المطور تماماً)
if (!defined('JWT_SECRET')) {
    define('JWT_SECRET', 'X9pL2wR7mQ4nB8vC1xZ5kY3hN6jU8iK9');
}

// إعدادات الترخيص
if (!defined('LICENSE_CHECK_INTERVAL')) {
    define('LICENSE_CHECK_INTERVAL', 3600); // التحقق كل ساعة (بالثواني)
    define('LICENSE_GRACE_PERIOD', 7);      // فترة السماح بالأيام
    define('LICENSE_WARNING_DAYS', 7);      // أيام التحذير قبل انتهاء الترخيص
}

date_default_timezone_set(TIMEZONE);