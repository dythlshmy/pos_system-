<?php
define('LICENSE_PASSWORD1', "I'm developer @.DiaaiD");
define('LICENSE_PASSWORD2', "085213");
define('ENCRYPTION_KEY', 'f4k3J8sH2nR5vB9xW1mQ6pL3zY7cA4eD');
define('HMAC_SECRET', 'X9pL2wR7mQ4nB8vC1xZ5kY3hN6jU8iK9');
define('ENCRYPTION_ALGO', 'aes-256-gcm');
define('HASH_ALGO', 'sha3-512');