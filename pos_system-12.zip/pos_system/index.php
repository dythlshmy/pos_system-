<?php
require_once __DIR__ . '/core/fast-core.php';
error_reporting(E_ALL & ~E_NOTICE);

error_reporting(E_ALL);
ini_set('display_errors', 1);

define('BASE_PATH', __DIR__ . DIRECTORY_SEPARATOR);
define('BASE_URL', 'http://localhost/pos_system');

require_once BASE_PATH . 'config/constants.php';
require_once BASE_PATH . 'config/session.php';
require_once BASE_PATH . 'config/functions.php';
require_once BASE_PATH . 'config/database.php';

spl_autoload_register(function ($class) {
    $directories = ['core/', 'controllers/', 'models/'];
    foreach ($directories as $directory) {
        $file = BASE_PATH . $directory . $class . '.php';
        if (file_exists($file)) {
            require_once $file;
            return true;
        }
    }
    return false;
});

$request_uri = $_SERVER['REQUEST_URI'];
$script_name = $_SERVER['SCRIPT_NAME'];
$base = dirname($script_name);

if (strpos($request_uri, $base) === 0) {
    $request_uri = substr($request_uri, strlen($base));
}

$request_uri = strtok($request_uri, '?');
$request_uri = ltrim($request_uri, '/');

if (empty($request_uri)) {
    $request_uri = 'login';
}

// تخزين المسار الحالي للـ Middleware
$_GET['url'] = $request_uri;

require_once BASE_PATH . 'core/Router.php';
require_once BASE_PATH . 'core/Middleware.php';
// تأكيد بدء الجلسة
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// ============================================
// ✅ التحقق من الترخيص عند كل طلب
// ============================================
// الصفحات المستثناة من التحقق (صفحات الترخيص نفسها)
$license_exempt = [
    'license',
    'license/index',
    'license/activate',
    'license/fingerprint',
    'license/status',
    'license/debug',
    'license/reset'
];

// التحقق من الترخيص أولاً (لجميع الصفحات ما عدا صفحات الترخيص)
if (!in_array($request_uri, $license_exempt)) {
    Middleware::checkLicense();
}

// ============================================
// ✅ التحقق من تسجيل الدخول للمسارات المحمية
// ============================================
$protected_routes = [
    'dashboard', 
    'inventory', 
    'pos', 
    'customers', 
    'reports', 
    'users', 
    'settings', 
    'audit', 
    'alerts',
    'logs', 
    'return', 
    'shelf', 
    'auto-restock'
];

foreach ($protected_routes as $route) {
    if (strpos($request_uri, $route) === 0) {
        Middleware::checkAuth();
        break;
    }
}

// ============================================
// ✅ التحقق من صلاحية المدير للمسارات الحساسة
// ============================================
$admin_routes = [
    'users',
    'settings',
    'audit',
    'license/debug',
    'license/reset'
];

foreach ($admin_routes as $route) {
    if (strpos($request_uri, $route) === 0) {
        Middleware::checkPermission('admin');
        break;
    }
}

// ============================================
// المسارات الأساسية للمشروع - نسخة كاملة ومتكاملة
// ============================================

// ===== مسارات الترخيص (جديدة) =====
Router::add('license', 'LicenseController', 'index', 'GET');
Router::add('license/activate', 'LicenseController', 'activate', 'POST');
Router::add('license/fingerprint', 'LicenseController', 'fingerprint', 'GET');
Router::add('license/status', 'LicenseController', 'status', 'GET');
Router::add('license/debug', 'LicenseController', 'debug', 'GET');     // للمدير فقط
Router::add('license/reset', 'LicenseController', 'reset', 'POST');    // للمدير فقط

// ===== مسارات المصادقة =====
Router::add('', 'LoginController', 'index', 'GET');
Router::add('login', 'LoginController', 'index', 'GET');
Router::add('login', 'LoginController', 'login', 'POST');
Router::add('logout', 'LoginController', 'logout', 'GET');
Router::add('dashboard', 'DashboardController', 'index', 'GET');
// ===== مسار تسجيل الدخول الاحتياطي =====
Router::add('backup-login', 'LoginController', 'showBackupForm', 'GET');
Router::add('backup-login', 'LoginController', 'backupLogin', 'POST');
// ... باقي المسارات ...
// ===== مسارات العملاء =====
Router::add('customers/check-balance', 'CustomersController', 'checkBalance', 'GET');
Router::add('customers', 'CustomersController', 'index', 'GET');
Router::add('customers/get-all', 'CustomersController', 'getAll', 'GET');
Router::add('customers/get-statistics', 'CustomersController', 'getStatistics', 'GET');
Router::add('customers/get-customer-data', 'CustomersController', 'getCustomerData', 'GET');
Router::add('customers/add', 'CustomersController', 'add', 'POST');
Router::add('customers/update', 'CustomersController', 'update', 'POST');
Router::add('customers/delete', 'CustomersController', 'delete', 'DELETE');
Router::add('customers/filter-by-date', 'CustomersController', 'filterByDate', 'GET');
Router::add('customers/process-payment', 'CustomersController', 'processPayment', 'POST');
Router::add('customers/generate-statement', 'CustomersController', 'generateStatement', 'POST');

// ===== مسارات المخزون الرئيسية =====
Router::add('inventory', 'InventoryController', 'index', 'GET');
Router::add('shelf', 'InventoryController', 'shelf', 'GET');

// ===== مسارات المنتجات (POST) =====
Router::add('inventory/get-products', 'InventoryController', 'getProducts', 'POST');
Router::add('inventory/add-product', 'InventoryController', 'addProduct', 'POST');
Router::add('inventory/update-product', 'InventoryController', 'updateProduct', 'POST');
Router::add('inventory/delete-product', 'InventoryController', 'deleteProduct', 'POST');

// ===== مسارات المنتجات (GET) =====
Router::add('inventory/get-products', 'InventoryController', 'getProducts', 'GET');
Router::add('inventory/get-product', 'InventoryController', 'getProduct', 'GET');

// ===== مسارات الدفعات =====
Router::add('inventory/add-batch', 'InventoryController', 'addBatch', 'POST');
Router::add('inventory/delete-batch', 'InventoryController', 'deleteBatch', 'POST');
Router::add('inventory/get-batches', 'InventoryController', 'getBatches', 'POST');
Router::add('inventory/update-batch', 'InventoryController', 'updateBatch', 'POST');
Router::add('inventory/get-batch-details', 'InventoryController', 'getBatchDetails', 'GET');

// ===== مسارات رف البيع =====
Router::add('inventory/move-to-shelf', 'InventoryController', 'moveToShelf', 'POST');
Router::add('inventory/move-fifo', 'InventoryController', 'moveFifo', 'POST');
Router::add('inventory/get-shelf', 'InventoryController', 'getShelf', 'GET');
Router::add('inventory/sell-from-shelf', 'InventoryController', 'sellFromShelf', 'POST');

// ===== مسارات الفلاتر والبحث =====
Router::add('inventory/filter', 'InventoryController', 'filter', 'GET');
Router::add('inventory/search-by-barcode', 'InventoryController', 'searchByBarcode', 'GET');

// ===== مسارات المساعدة =====
Router::add('inventory/get-categories', 'InventoryController', 'getCategories', 'GET');
Router::add('inventory/check-permission', 'InventoryController', 'checkPermission', 'GET');

// ===== مسارات الاختبار =====
Router::add('inventory/test', 'InventoryController', 'test', 'GET');
Router::add('inventory/test-post', 'InventoryController', 'testPost', 'POST');

// ===== مسارات التقارير =====
Router::add('reports', 'ReportsControllers', 'index', 'GET');
Router::add('reports/export', 'ReportsControllers', 'export', 'GET');
Router::add('reports/print', 'ReportsControllers', 'print', 'GET');
Router::add('reports/products-history', 'ReportsControllers', 'productsHistory', 'GET');
Router::add('reports/physical-inventories', 'ReportsControllers', 'physicalInventory', 'POST');  // تم التصحيح
Router::add('reports/audit-history', 'ReportsControllers', 'auditHistory', 'GET');
Router::add('reports/get-batch-details', 'ReportsControllers', 'getBatchDetails', 'GET');

// ===== مسارات API الجديدة =====
Router::add('reports/product-batches', 'ReportsControllers', 'getProductBatches', 'GET');
Router::add('reports/batch-sales', 'ReportsControllers', 'getBatchSales', 'GET');
Router::add('reports/product-inventory-details', 'ReportsControllers', 'getProductInventoryDetails', 'GET');
Router::add('reports/product-quick-stats', 'ReportsControllers', 'getProductQuickStats', 'GET');
Router::add('reports/last-audit', 'ReportsControllers', 'getLastAudit', 'GET');
Router::add('reports/save-physical-inventory', 'ReportsControllers', 'savePhysicalInventory', 'POST');
Router::add('reports/product-audit-history', 'ReportsControllers', 'getProductAuditHistory', 'GET');
Router::add('reports/edit-inventory-audit', 'ReportsControllers', 'editInventoryAudit', 'POST');
Router::add('reports/delete-inventory-audit', 'ReportsControllers', 'deleteInventoryAudit', 'POST');
Router::add('reports/apply-inventory-audit', 'ReportsControllers', 'applyInventoryAudit', 'POST');


// ===== مسارات تحليل المبيعات والربحية =====
Router::add('reports/product-sales-analysis', 'ReportsControllers', 'getProductSalesAnalysis', 'GET');  // تم التصحيح
Router::add('reports/product-profit-analysis', 'ReportsControllers', 'getProductProfitAnalysis', 'GET');  // تم التصحيح
// ===== مسارات المستخدمين =====
Router::add('users', 'UsersController', 'index', 'GET');
Router::add('users/get-users', 'UsersController', 'getUsers', 'GET');
Router::add('users/add-user', 'UsersController', 'addUser', 'POST');
Router::add('users/update-user', 'UsersController', 'updateUser', 'POST');
Router::add('users/change-password', 'UsersController', 'changePassword', 'POST');
Router::add('users/toggle-user', 'UsersController', 'toggleUser', 'POST');
Router::add('users/get-backup-password', 'UsersController', 'getBackupPassword', 'GET');
Router::add('users/update-backup-password', 'UsersController', 'updateBackupPassword', 'POST');

// ===== مسارات الإعدادات =====
Router::add('settings', 'SettingsController', 'index', 'GET');
Router::add('settings/save', 'SettingsController', 'save', 'POST');
Router::add('settings/test-print', 'SettingsController', 'testPrint', 'POST');

// ===== مسارات سجل الحركات =====
Router::add('logs', 'LogController', 'index', 'GET');
Router::add('logs/search', 'LogController', 'search', 'GET');
Router::add('logs/export', 'LogController', 'export', 'GET');

// ===== مسارات الجرد =====
Router::add('audit', 'AuditController', 'index', 'GET');
Router::add('audit/start', 'AuditController', 'start', 'POST');
Router::add('audit/get-products', 'AuditController', 'getProducts', 'GET');
Router::add('audit/save-item', 'AuditController', 'saveItem', 'POST');
Router::add('audit/complete', 'AuditController', 'complete', 'POST');
Router::add('audit/report/{id}', 'AuditController', 'report', 'GET');
Router::add('audit/export/{id}', 'AuditController', 'export', 'GET');
Router::add('audit/get-quantities', 'AuditController', 'getQuantities', 'GET');

// ===== مسارات التنبيهات =====
Router::add('alerts', 'AlertController', 'index', 'GET');
Router::add('alerts/get-unread', 'AlertController', 'getUnread', 'GET');
Router::add('alerts/mark-read', 'AlertController', 'markRead', 'POST');
Router::add('alerts/mark-all-read', 'AlertController', 'markAllRead', 'POST');
Router::add('alerts/delete', 'AlertController', 'delete', 'POST');
Router::add('alerts/refresh', 'AlertController', 'refresh', 'POST');

// ===== مسارات الرفع التلقائي =====
Router::add('auto-restock/execute', 'AutoRestockController', 'execute', 'POST');
Router::add('auto-restock/check', 'AutoRestockController', 'check', 'GET');
Router::add('auto-restock/toggle', 'AutoRestockController', 'toggle', 'POST');
Router::add('auto-restock/status', 'AutoRestockController', 'status', 'GET');

// ===== مسارات رف البيع الإضافية =====
Router::add('shelf', 'InventoryController', 'shelf', 'GET');
Router::add('shelf/update', 'InventoryController', 'updateShelfItem', 'POST');
Router::add('shelf/delete', 'InventoryController', 'deleteShelfItem', 'POST');
Router::add('shelf/sell', 'InventoryController', 'sellFromShelf', 'POST');
Router::add('shelf/info', 'InventoryController', 'getShelfInfo', 'GET');
Router::add('shelf/search', 'InventoryController', 'searchShelf', 'GET');
Router::add('shelf/item-details', 'InventoryController', 'getShelfItemDetails', 'GET');
Router::add('shelf/test', 'InventoryController', 'testShelfDetails', 'GET');

// ===== مسارات إعدادات الطباعة والنسخ الاحتياطي =====
Router::add('settings', 'SettingsController', 'index', 'GET');
Router::add('settings/save', 'SettingsController', 'save', 'POST');
Router::add('settings/test-print', 'SettingsController', 'testPrint', 'POST');
Router::add('settings/export-db', 'SettingsController', 'exportDb', 'POST');
Router::add('settings/import-db', 'SettingsController', 'importDb', 'POST');
Router::add('settings/reset-system', 'SettingsController', 'resetSystem', 'POST');
Router::add('settings/auto-backup', 'SettingsController', 'autoBackup', 'GET');

// ===== مسارات نقطة البيع =====
Router::add('pos', 'PosController', 'index', 'GET');
Router::add('pos/search-products', 'PosController', 'searchProducts', 'GET');
Router::add('pos/search-by-barcode', 'PosController', 'searchByBarcode', 'GET');
Router::add('pos/process-sale', 'PosController', 'processSale', 'POST');
Router::add('pos/search-invoice', 'PosController', 'searchInvoice', 'GET');
Router::add('pos/reprint', 'PosController', 'reprintInvoice', 'POST');
Router::add('pos/download-invoice', 'PosController', 'downloadInvoice', 'GET');
Router::add('pos/check-quantities', 'PosController', 'checkQuantities', 'POST');  
Router::add('pos/check-quantities-before-sale', 'PosController', 'checkQuantitiesBeforeSale', 'POST');

// ===== مسارات الإرجاع =====
Router::add('return', 'ReturnController', 'index', 'GET');
Router::add('return/search-invoice', 'ReturnController', 'searchInvoice', 'GET');
Router::add('return/process-return', 'ReturnController', 'processReturn', 'POST');

// ===== مسارات إدارة الأقسام =====
Router::add('inventory/add-category', 'InventoryController', 'addCategory', 'POST');
Router::add('inventory/get-categories', 'InventoryController', 'getCategories', 'GET');
Router::add('inventory/update-category', 'InventoryController', 'updateCategory', 'POST');
Router::add('inventory/delete-category', 'InventoryController', 'deleteCategory', 'POST');

// ===== مسارات اختصارات لوحة المفاتيح =====
Router::add('shortcuts/load', 'ShortcutController', 'load', 'GET');
Router::add('shortcuts/save-settings', 'ShortcutController', 'saveSettings', 'POST');
Router::add('shortcuts/save-element-state', 'ShortcutController', 'saveElementState', 'POST');
Router::add('shortcuts/save-shortcut', 'ShortcutController', 'saveShortcut', 'POST');
Router::add('shortcuts/delete-shortcut', 'ShortcutController', 'deleteShortcut', 'POST');

// ===== صفحة اختبار البصمة (مؤقتة) =====
if ($request_uri === 'test-fingerprint') {
    require_once 'core/Fingerprint.php';
    
    $fp = new Fingerprint();
    $data = $fp->collect();
    $key = $fp->generateFingerprintKey();
    
    echo "<h1>🔍 اختبار نظام البصمة</h1>";
    echo "<h2>مفتاح البصمة:</h2>";
    echo "<code style='font-size:24px; background:#f0f0f0; padding:10px; display:block; text-align:center;'>$key</code>";
    
    echo "<h2>بيانات الجهاز:</h2>";
    echo "<pre>";
    print_r($data);
    echo "</pre>";
    exit;
}
// ============================================
// معالجة الطلب
// ============================================
Router::dispatch($request_uri);
?>