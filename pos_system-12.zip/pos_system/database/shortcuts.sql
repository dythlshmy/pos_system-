-- جدول الإعدادات العامة للواجهات (General Interface Settings)
CREATE TABLE IF NOT EXISTS `shortcut_settings` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `user_id` INT NOT NULL,
    `interface_name` VARCHAR(100) NOT NULL,
    `sys_active` TINYINT(1) DEFAULT 1,
    `nav_active` TINYINT(1) DEFAULT 1,
    `adding_active` TINYINT(1) DEFAULT 1,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY `user_interface_unique` (`user_id`, `interface_name`),
    CONSTRAINT `fk_shortcut_settings_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- جدول حالة تفعيل العناصر الفردية (Individual Elements State)
CREATE TABLE IF NOT EXISTS `shortcut_elements_state` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `user_id` INT NOT NULL,
    `interface_name` VARCHAR(100) NOT NULL,
    `element_id` VARCHAR(255) NOT NULL,
    `is_active` TINYINT(1) DEFAULT 1,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY `user_interface_element_unique` (`user_id`, `interface_name`, `element_id`),
    CONSTRAINT `fk_shortcut_elements_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- جدول اختصارات المستخدمين (User Created Shortcuts)
CREATE TABLE IF NOT EXISTS `user_shortcuts` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `user_id` INT NOT NULL,
    `interface_name` VARCHAR(100) NOT NULL,
    `modifier` VARCHAR(50) DEFAULT '',
    `key_char` VARCHAR(50) NOT NULL,
    `target_element` VARCHAR(255) NOT NULL,
    `description` VARCHAR(255) DEFAULT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY `user_interface_keys_unique` (`user_id`, `interface_name`, `modifier`, `key_char`),
    CONSTRAINT `fk_user_shortcuts_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
