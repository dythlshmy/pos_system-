<?php
require_once BASE_PATH . 'config/encryption.php';

class LicenseValidator {
    
    private $password1 = LICENSE_PASSWORD1;
    private $password2 = LICENSE_PASSWORD2;
    private $encryption_key = ENCRYPTION_KEY;
    private $hmac_secret = HMAC_SECRET;
    private $steps = [];
    
    public function validateLicense($license_key) {
        $this->steps = [];
        $this->addStep("1️⃣ إزالة التنسيق من المفتاح");
        $clean_key = str_replace('-', '', $license_key);
        
        $this->addStep("2️⃣ فك ترميز Base32");
        $binary = $this->base32_decode($clean_key);
        
        $signature = substr($binary, -64);
        $encrypted_data = substr($binary, 0, -64);
        
        $this->addStep("3️⃣ التحقق من التوقيع باستخدام HMAC-SHA3-512");
        $expected_sig = hash_hmac('sha3-512', $encrypted_data, $this->hmac_secret, true);
        
        if (!hash_equals($signature, $expected_sig)) {
            $this->addStep("❌ فشل التحقق: التوقيع غير صحيح");
            return ['success' => false, 'message' => 'المفتاح مزور', 'steps' => $this->steps];
        }
        $this->addStep("✅ التوقيع صحيح");
        
        $iv = substr($encrypted_data, 0, 12);
        $ciphertext = substr($encrypted_data, 12, -16);
        $tag = substr($encrypted_data, -16);
        
        $this->addStep("4️⃣ فك تشفير AES-256-GCM");
        $decrypted = openssl_decrypt($ciphertext, 'aes-256-gcm', $this->encryption_key, OPENSSL_RAW_DATA, $iv, $tag);
        
        if (!$decrypted) {
            $this->addStep("❌ فشل فك التشفير");
            return ['success' => false, 'message' => 'فشل فك التشفير', 'steps' => $this->steps];
        }
        $this->addStep("✅ تم فك التشفير بنجاح");
        
        $this->addStep("5️⃣ فك ضغط GZIP");
        $license_data = gzuncompress($decrypted);
        
        if (!$license_data) {
            $this->addStep("❌ فشل فك الضغط");
            return ['success' => false, 'message' => 'بيانات المفتاح تالفة', 'steps' => $this->steps];
        }
        $this->addStep("✅ تم فك الضغط بنجاح");
        
        $parts = explode('|', $license_data);
        
        if (count($parts) !== 10) {
            $this->addStep("❌ صيغة المفتاح غير صحيحة");
            return ['success' => false, 'message' => 'صيغة المفتاح غير صحيحة', 'steps' => $this->steps];
        }
        
        $this->addStep("6️⃣ التحقق من كلمات المرور الثابتة");
        if ($parts[0] !== $this->password1 || $parts[9] !== $this->password2) {
            $this->addStep("❌ كلمات المرور غير صحيحة");
            return ['success' => false, 'message' => 'المفتاح غير صحيح', 'steps' => $this->steps];
        }
        $this->addStep("✅ كلمات المرور صحيحة");
        
        $decoded_data = [
            'password1' => $parts[0],
            'cpu' => $parts[1],
            'motherboard' => $parts[2],
            'year' => $parts[3],
            'disk' => $parts[4],
            'month' => $parts[5],
            'computer' => $parts[6],
            'day' => $parts[7],
            'uuid' => $parts[8],
            'password2' => $parts[9]
        ];
        
        return [
            'success' => true,
            'message' => 'تم فك المفتاح بنجاح',
            'data' => $decoded_data,
            'expiry_date' => "{$decoded_data['year']}-{$decoded_data['month']}-{$decoded_data['day']}",
            'steps' => $this->steps
        ];
    }
    
    public function compareWithCurrentDevice($license_data) {
        $this->steps = [];
        $this->addStep("🔍 مقارنة بصمة الجهاز:");
        
        $fingerprint = new Fingerprint();
        $current = $fingerprint->collect();
        
        $results = [];
        $all_match = true;
        
        $cpu_match = ($license_data['cpu'] === $current['cpu']);
        $results['cpu'] = $cpu_match;
        $this->addStep(($cpu_match ? "✅" : "❌") . " CPU: " . ($cpu_match ? "مطابق" : "غير مطابق"));
        if (!$cpu_match) $all_match = false;
        
        $mb_match = ($license_data['motherboard'] === $current['motherboard']);
        $results['motherboard'] = $mb_match;
        $this->addStep(($mb_match ? "✅" : "❌") . " اللوحة الأم: " . ($mb_match ? "مطابق" : "غير مطابق"));
        if (!$mb_match) $all_match = false;
        
        $disk_match = ($license_data['disk'] === $current['disk']);
        $results['disk'] = $disk_match;
        $this->addStep(($disk_match ? "✅" : "❌") . " القرص الصلب: " . ($disk_match ? "مطابق" : "غير مطابق"));
        if (!$disk_match) $all_match = false;
        
        $computer_match = ($license_data['computer'] === $current['computer']);
        $results['computer'] = $computer_match;
        $this->addStep(($computer_match ? "✅" : "❌") . " اسم الجهاز: " . ($computer_match ? "مطابق" : "غير مطابق"));
        if (!$computer_match) $all_match = false;
        
        $uuid_match = ($license_data['uuid'] === $current['uuid']);
        $results['uuid'] = $uuid_match;
        $this->addStep(($uuid_match ? "✅" : "❌") . " UUID: " . ($uuid_match ? "مطابق" : "غير مطابق"));
        if (!$uuid_match) $all_match = false;
        
        return [
            'success' => $all_match,
            'results' => $results,
            'steps' => $this->steps,
            'current_device' => $current
        ];
    }
    
    public function checkExpiry($expiry_date) {
        $this->steps = [];
        $this->addStep("📅 التحقق من تاريخ الصلاحية:");
        
        $today = date('Y-m-d');
        $expiry = date('Y-m-d', strtotime($expiry_date));
        
        $this->addStep("   اليوم: $today");
        $this->addStep("   الانتهاء: $expiry");
        
        if ($today > $expiry) {
            $this->addStep("❌ الترخيص منتهي الصلاحية");
            return ['success' => false, 'message' => 'انتهت صلاحية الترخيص', 'steps' => $this->steps];
        }
        
        $days = floor((strtotime($expiry) - strtotime($today)) / (60 * 60 * 24));
        $this->addStep("✅ الترخيص ساري المفعول");
        $this->addStep("   الأيام المتبقية: $days يوم");
        
        return ['success' => true, 'days_remaining' => $days, 'steps' => $this->steps];
    }
    
    private function base32_decode($input) {
        $alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
        $input = strtoupper($input);
        $output = '';
        $buffer = 0;
        $bitsLeft = 0;
        
        for ($i = 0; $i < strlen($input); $i++) {
            $charValue = strpos($alphabet, $input[$i]);
            if ($charValue === false) continue;
            
            $buffer = ($buffer << 5) | $charValue;
            $bitsLeft += 5;
            
            if ($bitsLeft >= 8) {
                $bitsLeft -= 8;
                $output .= chr(($buffer >> $bitsLeft) & 0xFF);
            }
        }
        return $output;
    }
    
    private function addStep($step) {
        $this->steps[] = $step;
    }
    
    public function getSteps() {
        return $this->steps;
    }
}