<?php
/**
 * نظام جمع بصمة الجهاز - متوافق مع نظام المطور (JWT)
 * الإصدار: 2.0
 * التاريخ: 2026-03-15
 */

class Fingerprint {
    
    private $data = [];
    
    public function __construct() {
        // لا حاجة لقاعدة بيانات
    }
    
    /**
     * جمع معلومات الجهاز
     * 
     * @return array بيانات الجهاز (cpu, motherboard, disk, computer, uuid)
     */
    public function collect() {
        $this->data = [
            'cpu' => $this->getCPU_ID(),
            'motherboard' => $this->getMotherboardSerial(),
            'disk' => $this->getDiskSerial(),
            'computer' => $this->getComputerName(),
            'uuid' => $this->getOS_UUID()
        ];
        
        return $this->data;
    }
    
    /**
     * توليد مفتاح البصمة - متوافق مع نظام المطور (يستخدم Base64 للتوافق مع JWT)
     * 
     * @return string مفتاح البصمة بصيغة DEV-XXXX-XXXX-XXXX
     */
    public function generateFingerprintKey() {
        if (empty($this->data)) {
            $this->collect();
        }
        
        // 1️⃣ بناء النص
        $raw = implode('|', $this->data);
        
        // 2️⃣ تحويل إلى Base64 (أبسط وأكثر توافقاً مع JWT)
        $encoded = base64_encode($raw);
        
        // 3️⃣ إزالة علامات = من النهاية
        $encoded = rtrim($encoded, '=');
        
        // 4️⃣ تقسيم إلى أجزاء (كل جزء 4 حروف)
        $parts = [];
        for ($i = 0; $i < strlen($encoded); $i += 4) {
            $parts[] = substr($encoded, $i, 4);
        }
        
        // 5️⃣ بناء المفتاح بصيغة DEV-XXXX-XXXX-XXXX
        $result = 'DEV-';
        for ($i = 0; $i < count($parts); $i++) {
            if ($i > 0) {
                $result .= '-';
            }
            $result .= $parts[$i];
        }
        
        return $result;
    }
    
    /**
     * فك مفتاح البصمة (للاستخدام في التشخيص)
     * 
     * @param string $fingerprint_key مفتاح البصمة
     * @return array نتيجة الفك
     */
    public function debugKey($fingerprint_key) {
        // إزالة "DEV-" والشرطات
        $clean = str_replace('DEV-', '', $fingerprint_key);
        $clean = str_replace('-', '', $clean);
        
        // إعادة بناء Base64
        $base64 = $clean;
        
        // إضافة علامات = إذا لزم الأمر
        $mod = strlen($base64) % 4;
        if ($mod > 0) {
            $base64 .= str_repeat('=', 4 - $mod);
        }
        
        // فك التشفير
        $decoded = base64_decode($base64);
        
        // تقسيم البيانات
        $decoded_parts = $decoded ? explode('|', $decoded) : [];
        
        return [
            'original_data' => $this->data,
            'fingerprint_key' => $fingerprint_key,
            'clean_key' => $clean,
            'base64_reconstructed' => $base64,
            'decoded_raw' => $decoded,
            'decoded_parts' => $decoded_parts,
            'success' => ($decoded === implode('|', $this->data))
        ];
    }
    
    /**
     * الحصول على البيانات كاملة (للتشخيص)
     * 
     * @return array بيانات الجهاز
     */
    public function getRawData() {
        if (empty($this->data)) {
            $this->collect();
        }
        return $this->data;
    }
    
    /**
     * اختبار التوافق مع نظام المطور
     * صفحة تشخيص كاملة
     */
    public function testCompatibility() {
        if (empty($this->data)) {
            $this->collect();
        }
        
        $raw = implode('|', $this->data);
        $base64_encoded = base64_encode($raw);
        $base64_without_padding = rtrim($base64_encoded, '=');
        $fingerprint_key = $this->generateFingerprintKey();
        
        header('Content-Type: text/html; charset=utf-8');
        
        echo "<!DOCTYPE html>";
        echo "<html dir='rtl' lang='ar'>";
        echo "<head><meta charset='UTF-8'><title>🔍 اختبار توافق Fingerprint</title>";
        echo "<style>
            body { font-family: 'Tajawal', sans-serif; background: #f4f7fa; padding: 30px; }
            .container { max-width: 1000px; margin: 0 auto; }
            .card { background: white; border-radius: 12px; padding: 25px; margin-bottom: 20px; box-shadow: 0 2px 10px rgba(0,0,0,0.05); }
            h1 { color: #1a1a2e; text-align: center; margin-bottom: 30px; }
            h2 { color: #0f3460; border-bottom: 2px solid #f0f0f0; padding-bottom: 10px; }
            .success { background: #d4edda; color: #155724; padding: 15px; border-radius: 8px; }
            .error { background: #f8d7da; color: #721c24; padding: 15px; border-radius: 8px; }
            code { background: #f0f0f0; padding: 2px 5px; border-radius: 3px; font-family: monospace; }
            .key-box { background: #1a1a2e; color: white; padding: 20px; border-radius: 8px; text-align: center; }
            .key-box code { background: rgba(255,255,255,0.2); color: white; font-size: 18px; padding: 10px; display: inline-block; }
            table { width: 100%; border-collapse: collapse; margin-top: 15px; }
            td, th { padding: 12px; border-bottom: 1px solid #f0f0f0; text-align: right; }
            th { background: #f8f9fa; }
        </style>";
        echo "</head><body>";
        echo "<div class='container'>";
        
        echo "<h1>🔍 اختبار توافق Fingerprint مع نظام المطور (JWT)</h1>";
        
        // 1. البيانات الأصلية
        echo "<div class='card'>";
        echo "<h2>📊 1. البيانات الأصلية للجهاز</h2>";
        echo "<table>";
        foreach ($this->data as $key => $value) {
            echo "<tr><th>$key</th><td><code>$value</code></td></tr>";
        }
        echo "</table>";
        echo "</div>";
        
        // 2. النص الخام
        echo "<div class='card'>";
        echo "<h2>📝 2. النص الخام (بعد الدمج)</h2>";
        echo "<code style='background:#f0f0f0; padding:10px; display:block; word-break:break-all;'>$raw</code><br>";
        echo "الطول: " . strlen($raw) . " حرف";
        echo "</div>";
        
        // 3. Base64
        echo "<div class='card'>";
        echo "<h2>🔢 3. بعد تحويل Base64</h2>";
        echo "<code style='background:#f0f0f0; padding:10px; display:block; word-break:break-all;'>$base64_encoded</code><br>";
        echo "الطول: " . strlen($base64_encoded) . " حرف<br>";
        echo "بعد إزالة padding: <code>$base64_without_padding</code><br>";
        echo "</div>";
        
        // 4. مفتاح البصمة النهائي
        echo "<div class='card'>";
        echo "<h2>🔑 4. مفتاح البصمة النهائي</h2>";
        echo "<div class='key-box'>";
        echo "<code>$fingerprint_key</code><br>";
        echo "<small style='color: #a0aec0;'>انسخ هذا المفتاح وأدخله في نظام المطور</small>";
        echo "</div>";
        echo "</div>";
        
        // 5. اختبار فك التشفير
        echo "<div class='card'>";
        echo "<h2>🔄 5. اختبار فك التشفير</h2>";
        
        $debug = $this->debugKey($fingerprint_key);
        
        if ($debug['success']) {
            echo "<div class='success'>✅ فك التشفير ناجح - البيانات متطابقة</div>";
            
            if (count($debug['decoded_parts']) === 5) {
                echo "<table>";
                $fields = ['cpu', 'motherboard', 'disk', 'computer', 'uuid'];
                foreach ($fields as $index => $field) {
                    $match = isset($debug['decoded_parts'][$index]) && 
                             $debug['decoded_parts'][$index] === $this->data[$field];
                    $status = $match ? '✅' : '❌';
                    echo "<tr><th>$field</th><td><code>" . htmlspecialchars($debug['decoded_parts'][$index] ?? '') . "</code></td><td>$status</td></tr>";
                }
                echo "</table>";
            }
        } else {
            echo "<div class='error'>❌ فك التشفير فاشل</div>";
        }
        echo "</div>";
        
        // 6. الاستنتاج النهائي
        echo "<div class='card'>";
        echo "<h2>📋 6. الاستنتاج النهائي</h2>";
        
        if ($debug['success'] && count($debug['decoded_parts']) === 5) {
            echo "<div class='success' style='font-size:18px; text-align:center;'>";
            echo "✅ النظام يعمل بشكل صحيح ومتوافق مع نظام المطور<br>";
            echo "يمكنك استخدام مفتاح البصمة في نظام المطور لإنشاء ترخيص JWT";
            echo "</div>";
        } else {
            echo "<div class='error' style='font-size:18px; text-align:center;'>";
            echo "❌ هناك مشكلة في التوافق مع نظام المطور<br>";
            echo "يرجى التحقق من البيانات أعلاه";
            echo "</div>";
        }
        echo "</div>";
        
        echo "</div></body></html>";
        exit;
    }
    
    // ========== دوال جمع المعلومات (بدون تغيير) ==========
    
    /**
     * الحصول على CPU ID
     */
    private function getCPU_ID() {
        if (PHP_OS_FAMILY === 'Windows') {
            $output = shell_exec('wmic cpu get ProcessorId /value 2>&1');
            if ($output && preg_match('/ProcessorId=([^\s]+)/', $output, $matches)) {
                return trim($matches[1]);
            }
        }
        return 'CPU-' . substr(md5(php_uname()), 0, 8);
    }
    
    /**
     * الحصول على Motherboard Serial
     */
    private function getMotherboardSerial() {
        if (PHP_OS_FAMILY === 'Windows') {
            $output = shell_exec('wmic baseboard get SerialNumber /value 2>&1');
            if ($output && preg_match('/SerialNumber=([^\s]+)/', $output, $matches)) {
                $serial = trim($matches[1]);
                if ($serial && $serial !== 'To be filled by O.E.M.') {
                    return $serial;
                }
            }
        }
        return 'MB-' . substr(md5(php_uname()), 0, 8);
    }
    
    /**
     * الحصول على Disk Serial
     */
    private function getDiskSerial() {
        if (PHP_OS_FAMILY === 'Windows') {
            $output = shell_exec('wmic diskdrive get SerialNumber /value 2>&1');
            if ($output && preg_match('/SerialNumber=([^\s]+)/', $output, $matches)) {
                return trim($matches[1]);
            }
        }
        return 'DISK-' . substr(md5(getenv('SystemDrive') ?: 'C:'), 0, 8);
    }
    
    /**
     * الحصول على Computer Name
     */
    private function getComputerName() {
        return gethostname();
    }
    
    /**
     * الحصول على OS UUID
     */
    private function getOS_UUID() {
        if (PHP_OS_FAMILY === 'Windows') {
            $output = shell_exec('reg query "HKLM\\SOFTWARE\\Microsoft\\Cryptography" /v MachineGuid 2>&1');
            if ($output && preg_match('/MachineGuid\s+REG_SZ\s+(\S+)/', $output, $matches)) {
                return trim($matches[1]);
            }
        }
        return 'UUID-' . substr(md5(php_uname()), 0, 8);
    }
}