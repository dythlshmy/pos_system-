<?php
class Auth {
    
    public static function attempt($username, $password) {
        try {
            $db = Database::getInstance();
            
            $stmt = $db->prepare("SELECT * FROM users WHERE username = ? AND is_active = 1");
            $stmt->execute([$username]);
            $user = $stmt->fetch();

            if ($user && password_verify($password, $user['password'])) {
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['user_role'] = $user['role'];
                $_SESSION['user_name'] = $user['full_name'];
                $_SESSION['username'] = $user['username'];
                $_SESSION['is_logged_in'] = true;
                
                $updateStmt = $db->prepare("UPDATE users SET last_login = NOW() WHERE id = ?");
                $updateStmt->execute([$user['id']]);
                
                return true;
            }
            return false;
            
        } catch (PDOException $e) {
            error_log("Auth error: " . $e->getMessage());
            return false;
        }
    }

    public static function check() {
        return isset($_SESSION['user_id']) && isset($_SESSION['is_logged_in']) && $_SESSION['is_logged_in'] === true;
    }

    public static function user() {
        if (!self::check()) return null;
        
        try {
            $db = Database::getInstance();
            $stmt = $db->prepare("SELECT * FROM users WHERE id = ?");
            $stmt->execute([$_SESSION['user_id']]);
            return $stmt->fetch();
        } catch (PDOException $e) {
            error_log("Auth user error: " . $e->getMessage());
            return null;
        }
    }

    public static function id() {
        return $_SESSION['user_id'] ?? null;
    }

    public static function role() {
        return $_SESSION['user_role'] ?? null;
    }

    public static function name() {
        return $_SESSION['user_name'] ?? null;
    }
    
    public static function username() {
        return $_SESSION['username'] ?? null;
    }

    public static function isAdmin() {
        return self::role() === 'admin';
    }
    
    public static function isStaff() {
        return self::role() === 'staff';
    }

    public static function logout() {
        $_SESSION = array();
        
        if (ini_get("session.use_cookies")) {
            $params = session_get_cookie_params();
            setcookie(session_name(), '', time() - 42000,
                $params["path"], $params["domain"],
                $params["secure"], $params["httponly"]
            );
        }
        
        session_destroy();
    }
}
?>