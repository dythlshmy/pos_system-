<?php
/**
 * FastCore v1.0 - تحسين استجابة النظام الفورية
 */

// 1. منع تأخير الجلسات (Session Lock) - أهم سبب للتعليق
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
// قراءة البيانات ثم تحرير الملف فوراً للسماح بطلبات أخرى بالتوازي
session_write_close(); 

// 2. إيقاف فحص الملفات المتكرر (OpCache)
// يخبر السيرفر بـ "ثق في الكود الموجود ولا تبحث عن تعديلات كل ثانية"
ini_set('opcache.validate_timestamps', '0');

// 3. ضغط المخرجات (Gzip Compression)
// يجعل البيانات المرسلة بين البرمجيات أصغر بـ 70% وبالتالي أسرع
if (!ob_start("ob_gzhandler")) ob_start();

// 4. أوامر صارمة للمتصفح (برنامج EXE) لتخزين الملفات
// تمنع المتصفح من طلب ملفات الـ CSS/JS من القرص الصلب في كل مرة
$expires = 60 * 60 * 24 * 30; // 30 يوم
header("Pragma: public");
header("Cache-Control: max-age=" . $expires);
header('Expires: ' . gmdate('D, d M Y H:i:s', time() + $expires) . ' GMT');

// 5. إعدادات الذاكرة (لضمان عدم البطء في العمليات الكبيرة)
ini_set('memory_limit', '512M');
set_time_limit(30); // منع العمليات من "التعليق" لأكثر من 30 ثانية
