<?php
class Controller {
    
    /**
     * دالة البناء - إضافة للتوافق مع نظام الترخيص
     */
    public function __construct() {
        // يمكن إضافة تهيئة مشتركة هنا
    }
    
    protected function view($view, $data = []) {
        extract($data);
        $viewPath = BASE_PATH . 'views/' . str_replace('.', '/', $view) . '.php';
        if (file_exists($viewPath)) {
            require $viewPath;
        } else {
            die("الصفحة غير موجودة: " . $viewPath);
        }
    }

    protected function redirect($url) {
        $url = ltrim($url, '/');
        header('Location: ' . BASE_URL . '/' . $url);
        exit;
    }

    protected function json($data, $statusCode = 200) {
        http_response_code($statusCode);
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode($data, JSON_UNESCAPED_UNICODE);
        exit;
    }

    protected function isPost() {
        return $_SERVER['REQUEST_METHOD'] === 'POST';
    }

    protected function isGet() {
        return $_SERVER['REQUEST_METHOD'] === 'GET';
    }

    protected function getPost($key = null, $default = null) {
        if ($key === null) return $_POST;
        return $_POST[$key] ?? $default;
    }

    protected function getQuery($key = null, $default = null) {
        if ($key === null) return $_GET;
        return $_GET[$key] ?? $default;
    }

    protected function isAjax() {
        return !empty($_SERVER['HTTP_X_REQUESTED_WITH']) && 
               strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest';
    }

    protected function userId() {
        return $_SESSION['user_id'] ?? null;
    }

    protected function requireAdmin() {
        if (!Auth::isAdmin()) {
            if ($this->isAjax()) {
                $this->json(['success' => false, 'message' => 'غير مصرح'], 403);
                exit;
            }
            $this->redirect('dashboard');
        }
    }

    protected function error($message, $code = 400) {
        $this->json(['success' => false, 'message' => $message], $code);
    }

    protected function success($data = null, $message = 'تم بنجاح') {
        $response = ['success' => true, 'message' => $message];
        if ($data !== null) {
            $response['data'] = $data;
        }
        $this->json($response);
    }

    // ============================================
    // دوال نظام الترخيص
    // ============================================

    protected function checkLicense() {
        if (!class_exists('LicenseModel')) {
            return ['status' => 'active'];
        }
        
        $licenseModel = new LicenseModel();
        $status = $licenseModel->checkLicenseStatus();
        
        if ($status['status'] !== 'active') {
            if ($this->isAjax()) {
                $this->json([
                    'success' => false,
                    'message' => 'الترخيص غير نشط',
                    'redirect' => BASE_URL . '/license'
                ], 403);
            } else {
                header('Location: ' . BASE_URL . '/license');
                exit;
            }
        }
        return $status;
    }

    protected function getLicenseInfo() {
        if (!class_exists('LicenseModel')) {
            return [
                'status' => 'active', 
                'message' => 'نظام الترخيص غير مفعل'
            ];
        }
        
        $licenseModel = new LicenseModel();
        return $licenseModel->checkLicenseStatus();
    }

    protected function logLicenseActivity($action, $details) {
        $logFile = BASE_PATH . 'storage/logs/license.log';
        $logDir = dirname($logFile);
        
        if (!is_dir($logDir)) {
            mkdir($logDir, 0755, true);
        }
        
        $logEntry = date('Y-m-d H:i:s') . " | $action | $details | IP: " . ($_SERVER['REMOTE_ADDR'] ?? 'unknown') . PHP_EOL;
        file_put_contents($logFile, $logEntry, FILE_APPEND | LOCK_EX);
    }

    protected function requireLicense() {
        $licenseInfo = $this->getLicenseInfo();
        
        if ($licenseInfo['status'] !== 'active') {
            if ($this->isAjax()) {
                $this->json([
                    'success' => false,
                    'message' => 'الترخيص غير نشط. الرجاء تفعيل الترخيص أولاً.',
                    'redirect' => BASE_URL . '/license'
                ], 403);
            } else {
                $_SESSION['error'] = 'الترخيص غير نشط. الرجاء تفعيل الترخيص أولاً.';
                header('Location: ' . BASE_URL . '/license');
                exit;
            }
        }
        return true;
    }

    protected function getLicenseNotification() {
        $licenseInfo = $this->getLicenseInfo();
        
        if ($licenseInfo['status'] === 'active') {
            $days = $licenseInfo['days_remaining'] ?? 0;
            if ($days <= 7) {
                return [
                    'show' => true,
                    'type' => 'warning',
                    'message' => "⚠️ الترخيص سينتهي بعد $days أيام. الرجاء تجديد الترخيص."
                ];
            }
            return ['show' => false];
        } else {
            return [
                'show' => true,
                'type' => 'danger',
                'message' => '🔴 الترخيص غير نشط. الرجاء تفعيل الترخيص.',
                'button' => 'تفعيل الآن',
                'link' => BASE_URL . '/license'
            ];
        }
    }

    protected function getDeviceFingerprint() {
        if (!class_exists('Fingerprint')) {
            return 'Fingerprint class not available';
        }
        
        $fingerprint = new Fingerprint();
        return $fingerprint->generateFingerprintKey();
    }

    protected function isLicenseExpired() {
        $licenseInfo = $this->getLicenseInfo();
        
        if ($licenseInfo['status'] !== 'active') {
            return true;
        }
        
        $expiryDate = $licenseInfo['expiry_date'] ?? null;
        if (!$expiryDate) {
            return true;
        }
        
        $today = date('Y-m-d');
        return $today > $expiryDate;
    }

    protected function getLicenseDaysRemaining() {
        $licenseInfo = $this->getLicenseInfo();
        
        if ($licenseInfo['status'] !== 'active') {
            return 0;
        }
        
        return $licenseInfo['days_remaining'] ?? 0;
    }

    protected function executeIfLicensed($callback) {
        if ($this->isLicenseExpired()) {
            if ($this->isAjax()) {
                $this->json([
                    'success' => false,
                    'message' => 'الترخيص منتهي. لا يمكن تنفيذ هذا الإجراء.'
                ], 403);
            }
            return false;
        }
        return $callback();
    }
    
}
