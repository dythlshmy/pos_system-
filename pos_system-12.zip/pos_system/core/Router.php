<?php
/**
 * Router Engine v2.0 - High Performance Edition
 * تم التحسين لحل مشاكل اللاق وتعليق الجلسات عند تسجيل الخروج
 */
class Router {
    private static $routes = [];
    private static $static_routes = []; // ✅ مسارات ثابتة للوصول الفوري O(1)
    private static $middleware = [];

    /**
     * إضافة مسار جديد - محسنة لفصل المسارات الثابتة عن الديناميكية
     */
    public static function add($route, $controller, $action, $method = 'GET') {
        $method = strtoupper($method);
        $route = trim($route, '/');
        
        // إذا كان المسار لا يحتوي على أقواس ديناميكية { } أو علامة *
        if (strpos($route, '{') === false && strpos($route, '*') === false) {
            self::$static_routes[$method][$route] = [
                'controller' => $controller,
                'action' => $action,
                'original_route' => $route
            ];
        } else {
            self::$routes[$method][] = [
                'route' => $route,
                'controller' => $controller,
                'action' => $action
            ];
        }
    }

    /**
     * إضافة middleware لمسار
     */
    public static function addMiddleware($route, $middleware) {
        $route = trim($route, '/');
        if (!isset(self::$middleware[$route])) {
            self::$middleware[$route] = [];
        }
        self::$middleware[$route][] = $middleware;
    }

    /**
     * معالجة الطلب وتوجيهه - نسخة فائقة السرعة
     */
    public static function dispatch($url) {
        $requestMethod = $_SERVER['REQUEST_METHOD'];
        $url = trim($url, '/');

        // 1️⃣ البحث في المسارات الثابتة (سريع جداً لروابط مثل logout, login, dashboard)
        if (isset(self::$static_routes[$requestMethod][$url])) {
            $route = self::$static_routes[$requestMethod][$url];
            self::execute($route['controller'], $route['action'], [], $route['original_route']);
            return;
        }

        // 2️⃣ البحث في المسارات الديناميكية (فقط إذا لم يتم العثور على مسار ثابت)
        if (isset(self::$routes[$requestMethod])) {
            foreach (self::$routes[$requestMethod] as $route) {
                $pattern = self::buildPattern($route['route']);
                
                if (preg_match($pattern, $url, $matches)) {
                    array_shift($matches); // إزالة المطابقة الكاملة
                    self::execute($route['controller'], $route['action'], $matches, $route['route']);
                    return;
                }
            }
        }

        // 404 - الصفحة غير موجودة
        self::handleError(404, "الصفحة غير موجودة: $url");
    }

    /**
     * تنفيذ الكنترولر والميدل وير بشكل منفصل لضمان استقرار الجلسة
     */
    private static function execute($controllerName, $action, $params = [], $routeKey = null) {
        // ✅ تنفيذ middleware إذا وجد لهذا المسار
        if ($routeKey !== null && isset(self::$middleware[$routeKey])) {
            foreach (self::$middleware[$routeKey] as $middleware) {
                if (class_exists($middleware)) {
                    $mw = new $middleware();
                    if (method_exists($mw, 'handle')) {
                        // إذا أرجع الميدل وير false أو قام بعمل exit، يتوقف التنفيذ هنا
                        if ($mw->handle() === false) return;
                    }
                }
            }
        }

        // التحقق من وجود الكلاس
        if (!class_exists($controllerName)) {
            self::handleError(500, "النظام لا يجد المتحكم: $controllerName");
            return;
        }

        $controller = new $controllerName();

        // التحقق من وجود الميثود
        if (!method_exists($controller, $action)) {
            self::handleError(500, "العملية $action غير معرفة في $controllerName");
            return;
        }

        // استدعاء الميثود مع المعاملات
        call_user_func_array([$controller, $action], $params);
    }

    /**
     * بناء نمط regex للمسار الديناميكي
     */
    private static function buildPattern($route) {
        $pattern = preg_replace('/\{[a-z]+\}/', '([^/]+)', $route);
        $pattern = str_replace('*', '.*', $pattern);
        return '#^' . $pattern . '$#';
    }

    /**
     * تسجيل الخطأ في ملف مع حماية المجلد
     */
    private static function logError($code, $message) {
        $logFile = BASE_PATH . 'storage/logs/error.log';
        if (!is_dir(dirname($logFile))) mkdir(dirname($logFile), 0755, true);
        
        $logEntry = date('Y-m-d H:i:s') . " | $code | $message | URL: " . ($_SERVER['REQUEST_URI'] ?? '') . PHP_EOL;
        file_put_contents($logFile, $logEntry, FILE_APPEND | LOCK_EX);
    }

    /**
     * معالجة الأخطاء بشكل احترافي يدعم AJAX و HTML
     */
    private static function handleError($code, $message) {
        http_response_code($code);
        self::logError($code, $message);
        
        if (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
            header('Content-Type: application/json; charset=utf-8');
            echo json_encode(['success' => false, 'message' => $message, 'code' => $code], JSON_UNESCAPED_UNICODE);
            exit;
        }

        echo '<!DOCTYPE html><html lang="ar" dir="rtl"><head><meta charset="UTF-8"><title>خطأ ' . $code . '</title>';
        echo '<style>
            body { font-family: "Segoe UI", Tahoma; background: #f8f9fa; display: flex; justify-content: center; align-items: center; height: 100vh; margin: 0; }
            .error-box { background: white; padding: 40px; border-radius: 15px; box-shadow: 0 10px 30px rgba(0,0,0,0.1); text-align: center; border-top: 5px solid #1a237e; }
            .error-code { font-size: 80px; color: #1a237e; font-weight: bold; margin: 0; }
            .btn { background: #1a237e; color: white; padding: 12px 25px; text-decoration: none; border-radius: 8px; display: inline-block; margin-top: 20px; transition: 0.3s; }
            .btn:hover { background: #d32f2f; }
        </style></head><body>';
        echo '<div class="error-box"><div class="error-code">' . $code . '</div><p>' . htmlspecialchars($message) . '</p>';
        echo '<a href="' . BASE_URL . '/dashboard" class="btn">العودة للرئيسية</a></div></body></html>';
        exit;
    }

    /**
     * عرض جميع المسارات (لأغراض المطور فقط)
     */
    public static function listRoutes() {
        echo '<pre>';
        print_r(['static' => self::$static_routes, 'dynamic' => self::$routes]);
        echo '</pre>';
    }
}
