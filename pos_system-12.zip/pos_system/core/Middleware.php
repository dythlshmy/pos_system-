<?php
/**
 * الطبقات الوسيطة - نظام الحماية والتحقق
 * الإصدار: 3.0
 * التاريخ: 2026-04-03
 * الوظائف: التحقق من الترخيص، التحقق من تسجيل الدخول، التحقق من الصلاحيات
 * التحديث: حل مشكلة تجمد الجلسات (Session Deadlock) وتحسين الأداء
 */

class Middleware {
    
    /**
     * بدء الجلسة بشكل آمن (بدون قفل إذا كانت موجودة مسبقاً)
     */
    private static function smartSessionStart() {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
    }
    
    /**
     * إغلاق الجلسة فوراً لتحرير القفل (Critical for AJAX)
     */
    private static function smartSessionClose() {
        if (session_status() === PHP_SESSION_ACTIVE) {
            session_write_close();
        }
    }
    
    /**
     * إعادة توجيه المستخدم غير المصرح له
     */
    private static function redirectUnauthorized() {
        if (self::isAjax()) {
            header('HTTP/1.0 401 Unauthorized');
            echo json_encode([
                'success' => false, 
                'message' => 'يجب تسجيل الدخول أولاً', 
                'redirect' => BASE_URL . '/login'
            ], JSON_UNESCAPED_UNICODE);
            exit;
        }
        $_SESSION['redirect_after_login'] = $_SERVER['REQUEST_URI'];
        header('Location: ' . BASE_URL . '/login');
        exit;
    }
    
    /**
     * إعادة توجيه إلى صفحة الترخيص
     */
    private static function redirectToLicense($message) {
        self::smartSessionStart();
        $_SESSION['redirect_after_license'] = $_SERVER['REQUEST_URI'];
        $_SESSION['license_error'] = $message;
        self::smartSessionClose();
        
        if (self::isAjax()) {
            header('HTTP/1.0 403 Forbidden');
            echo json_encode([
                'success' => false, 
                'message' => $message, 
                'redirect' => BASE_URL . '/license'
            ], JSON_UNESCAPED_UNICODE);
            exit;
        }
        header('Location: ' . BASE_URL . '/license');
        exit;
    }
    
    /**
     * تدمير الجلسة وإعادة التوجيه
     */
    private static function destroySessionAndRedirect() {
        self::smartSessionStart();
        session_destroy();
        self::smartSessionClose();
        header('Location: ' . BASE_URL . '/login');
        exit;
    }
    
    /**
     * التحقق من الترخيص عند كل طلب - نسخة محسنة مع إدارة الجلسة الذكية
     * يتم استدعاؤها في كل مرة يفتح فيها المستخدم أي صفحة داخلية
     * 
     * @return bool true إذا كان الترخيص صالحاً
     */
      public static function checkLicense() {
    // التأكد من وجود جلسة نشطة
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }
    
    // باقي الكود...

    // الصفحات المسموح بها بدون ترخيص
    $allowed_routes = [
        'license',
        'license/index',
        'license/activate',
        'license/fingerprint',
        'license/status',
        'login',
        'login/index',
        'login/login'
    ];
    
    $current_route = $_GET['url'] ?? 'dashboard';
    
    // إذا كانت الصفحة مسموح بها → نسمح بالدخول مباشرة
    if (in_array($current_route, $allowed_routes)) {
        return true;
    }
    
    // التحقق من وجود LicenseModel (نظام الترخيص مفعل)
    if (!class_exists('LicenseModel')) {
        // إذا نظام الترخيص غير مفعل، نسمح بالدخول
        return true;
    }
    
    // التحقق من الترخيص عند كل طلب
    try {
        $licenseModel = new LicenseModel();
        $status = $licenseModel->verifyLicenseAtStartup();
        
        if ($status['status'] !== 'active') {
            // تخزين الرابط الأصلي للعودة إليه بعد التفعيل
            $_SESSION['redirect_after_license'] = $_SERVER['REQUEST_URI'];
            
            // تخزين رسالة الخطأ
            $_SESSION['license_error'] = $status['message'];
            
            // إزالة متغيرات التفعيل من الجلسة
            unset($_SESSION['license_activated']);
            unset($_SESSION['license_status']);
            
            // توجيه إلى صفحة الترخيص
            header('Location: ' . BASE_URL . '/license');
            exit;
        }
        
        // ✅ الترخيص نشط - تعيين جميع متغيرات الجلسة
        $_SESSION['license_activated'] = true;              // هذا السطر كان مفقوداً
        $_SESSION['license_status'] = $status;
        $_SESSION['license_expiry'] = $status['expiry_date'];
        $_SESSION['license_days'] = $status['days_remaining'] ?? 0;
        
        return true;
        
    } catch (Exception $e) {
        // في حالة حدوث خطأ، نسجله ونتجه إلى صفحة الترخيص
        error_log('خطأ في التحقق من الترخيص: ' . $e->getMessage());
        
        $_SESSION['license_error'] = 'حدث خطأ في التحقق من الترخيص';
        header('Location: ' . BASE_URL . '/license');
        exit;
    }
}
    
    /**
     * التحقق من تسجيل الدخول - نسخة محسنة مع إدارة الجلسة الذكية
     * يتم استدعاؤها للصفحات التي تتطلب تسجيل دخول
     * 
     * @return bool true إذا كان المستخدم مسجلاً
     */
    public static function checkAuth() {
        // بدء الجلسة للقراءة فقط
        self::smartSessionStart();
        
        // الصفحات المسموح بها بدون تسجيل دخول
        $allowed_routes = [
            'login',
            'login/index',
            'login/login',
            'license',
            'license/index',
            'license/activate',
            'license/fingerprint',
            'license/status'
        ];
        
        $current_route = $_GET['url'] ?? 'dashboard';
        
        // إذا كانت الصفحة مسموح بها → نسمح بالدخول مباشرة
        if (in_array($current_route, $allowed_routes)) {
            self::smartSessionClose();
            return true;
        }
        
        // قراءة بيانات المستخدم من الجلسة
        $user_id = $_SESSION['user_id'] ?? null;
        $user_role = $_SESSION['user_role'] ?? null;
        
        // إغلاق الجلسة فوراً بعد قراءة البيانات
        self::smartSessionClose();
        
        // التحقق من وجود جلسة مستخدم
        if (!$user_id) {
            self::redirectUnauthorized();
        }
        
        // التحقق من أن المستخدم لا يزال نشطاً (اختياري)
        if (self::isUserActive($user_id) === false) {
            self::destroySessionAndRedirect();
        }
        
        return true;
    }
    
    /**
     * التحقق من صلاحيات المستخدم
     * 
     * @param string $required_role الصلاحية المطلوبة (admin, staff)
     * @return bool true إذا كان المستخدم يملك الصلاحية
     */
    public static function checkPermission($required_role = 'staff') {
        // بدء الجلسة للقراءة
        self::smartSessionStart();
        $user_id = $_SESSION['user_id'] ?? null;
        $user_role = $_SESSION['user_role'] ?? 'staff';
        self::smartSessionClose();
        
        // التحقق من تسجيل الدخول أولاً
        if (!$user_id) {
            if (self::isAjax()) {
                header('HTTP/1.0 401 Unauthorized');
                echo json_encode([
                    'success' => false, 
                    'message' => 'يجب تسجيل الدخول أولاً'
                ], JSON_UNESCAPED_UNICODE);
                exit;
            }
            header('Location: ' . BASE_URL . '/login');
            exit;
        }
        
        // التحقق من الصلاحية
        if ($required_role === 'admin' && $user_role !== 'admin') {
            if (self::isAjax()) {
                header('HTTP/1.0 403 Forbidden');
                echo json_encode([
                    'success' => false, 
                    'message' => 'غير مصرح بالوصول إلى هذه الصفحة'
                ], JSON_UNESCAPED_UNICODE);
                exit;
            }
            
            $_SESSION['error'] = 'ليس لديك صلاحية للوصول إلى هذه الصفحة';
            header('Location: ' . BASE_URL . '/dashboard');
            exit;
        }
        
        return true;
    }
    
    /**
     * التحقق من أن الطلب AJAX
     * 
     * @return bool
     */
    private static function isAjax() {
        return !empty($_SERVER['HTTP_X_REQUESTED_WITH']) && 
               strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest';
    }
    
    /**
     * التحقق من أن المستخدم لا يزال نشطاً في قاعدة البيانات
     * 
     * @param int $user_id معرف المستخدم
     * @return bool
     */
    private static function isUserActive($user_id) {
        // هذه دالة اختيارية - يمكن تنفيذها إذا كان لديك نموذج مستخدم
        // إذا لم تكن موجودة، نرجع true
        if (!class_exists('UserModel')) {
            return true;
        }
        
        try {
            $userModel = new UserModel();
            return $userModel->isActive($user_id);
        } catch (Exception $e) {
            error_log('خطأ في التحقق من نشاط المستخدم: ' . $e->getMessage());
            return true;
        }
    }
    
    /**
     * تنفيذ عدة Middlewares معاً
     * 
     * @param array $middlewares قائمة Middlewares للتنفيذ
     * @param array $request بيانات الطلب
     * @param callable $next الدالة التالية
     * @return mixed
     */
    public static function pipe($middlewares, $request, $next) {
        $index = 0;
        
        $run = function() use (&$index, $middlewares, $request, $next, &$run) {
            if ($index < count($middlewares)) {
                $middleware = $middlewares[$index++];
                return $middleware::handle($request, $run);
            }
            
            return $next($request);
        };
        
        return $run();
    }
    
    /**
     * معالج الطلبات (للاستخدام مع pipe) - نسخة محسنة
     * 
     * @param array $request بيانات الطلب
     * @param callable $next الدالة التالية
     * @return mixed
     */
    public static function handle($request, $next) {
        // بدء الجلسة للقراءة
        self::smartSessionStart();
        $user_id = $_SESSION['user_id'] ?? null;
        self::smartSessionClose();
        
        // التحقق من تسجيل الدخول
        if (!$user_id) {
            if (self::isAjax()) {
                header('HTTP/1.0 401 Unauthorized');
                echo json_encode([
                    'success' => false, 
                    'message' => 'يجب تسجيل الدخول أولاً'
                ], JSON_UNESCAPED_UNICODE);
                exit;
            }
            
            $_SESSION['redirect_after_login'] = $_SERVER['REQUEST_URI'];
            header('Location: ' . BASE_URL . '/login');
            exit;
        }
        
        return $next($request);
    }
    
    /**
     * منع الوصول المباشر إلى الملفات
     * يمكن استخدامها في بداية كل ملف PHP
     */
    public static function preventDirectAccess() {
        if (basename($_SERVER['PHP_SELF']) == basename(__FILE__)) {
            header('HTTP/1.0 403 Forbidden');
            die('الوصول المباشر غير مسموح');
        }
    }
    
    /**
     * تنظيف المدخلات للحماية من XSS
     * 
     * @param array $data البيانات المراد تنظيفها
     * @return array البيانات بعد التنظيف
     */
    public static function sanitizeInput($data) {
        if (is_array($data)) {
            foreach ($data as $key => $value) {
                $data[$key] = self::sanitizeInput($value);
            }
        } else {
            $data = htmlspecialchars(trim($data), ENT_QUOTES, 'UTF-8');
        }
        
        return $data;
    }
    
    /**
     * التحقق من CSRF token
     * 
     * @param string $token التوكن المرسل
     * @return bool
     */
    public static function verifyCsrfToken($token) {
        self::smartSessionStart();
        $stored_token = $_SESSION['csrf_token'] ?? null;
        self::smartSessionClose();
        
        if (!$stored_token) {
            return false;
        }
        
        return hash_equals($stored_token, $token);
    }
    
    /**
     * توليد CSRF token جديد
     * 
     * @return string
     */
    public static function generateCsrfToken() {
        self::smartSessionStart();
        
        if (!isset($_SESSION['csrf_token'])) {
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        }
        
        $token = $_SESSION['csrf_token'];
        self::smartSessionClose();
        
        return $token;
    }
    
    /**
     * التحقق من مصدر الطلب (Referer)
     * 
     * @return bool
     */
    public static function checkReferer() {
        if (!isset($_SERVER['HTTP_REFERER'])) {
            return false;
        }
        
        $referer = parse_url($_SERVER['HTTP_REFERER'], PHP_URL_HOST);
        $host = $_SERVER['HTTP_HOST'];
        
        return $referer === $host;
    }
    
    /**
     * تسجيل الخروج - نسخة محسنة
     */
    public static function logout() {
        self::smartSessionStart();
        
        // تخزين أي بيانات مهمة قبل المسح
        $redirect = $_SESSION['redirect_after_login'] ?? BASE_URL . '/login';
        
        // مسح الجلسة بالكامل
        $_SESSION = [];
        
        // حذف كوكي الجلسة
        if (ini_get("session.use_cookies")) {
            $params = session_get_cookie_params();
            setcookie(
                session_name(),
                '',
                time() - 42000,
                $params["path"],
                $params["domain"],
                $params["secure"],
                $params["httponly"]
            );
        }
        
        // تدمير الجلسة
        session_destroy();
        
        return $redirect;
    }
}