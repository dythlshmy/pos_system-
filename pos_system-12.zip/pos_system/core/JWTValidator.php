<?php
/**
 * JWT Validator - الإصدار النهائي
 * يستقبل المفاتيح ويتحقق منها بشكل صحيح
 */

class JWTValidator {
    
    private $secret_key;
    private $password1;
    private $password2;
    
    public function __construct() {
        $this->secret_key = 'X9pL2wR7mQ4nB8vC1xZ5kY3hN6jU8iK9';
        $this->password1 = "I'm developer @.DiaaiD";
        $this->password2 = "085213";
    }
    
    /**
     * التحقق من صحة المفتاح - يعمل مع المفاتيح المنسقة
     */
    public function validateLicense($license_key) {
        try {
            // 1. التحقق من الصيغة
            if (strpos($license_key, 'POS-') !== 0) {
                throw new Exception("المفتاح يجب أن يبدأ بـ POS-");
            }
            
            // 2. استخراج JWT (إزالة POS- فقط، لا نحذف النقاط)
            $jwt = substr($license_key, 4);
            
            // 3. التحقق من وجود 3 أجزاء
            $parts = explode('.', $jwt);
            if (count($parts) !== 3) {
                throw new Exception("صيغة JWT غير صحيحة - يجب أن يحتوي على نقطتين");
            }
            
            list($header_b64, $payload_b64, $signature_b64) = $parts;
            
            // 4. التحقق من التوقيع
            $signature = $this->base64UrlDecode($signature_b64);
            $expected_signature = hash_hmac('sha256', $header_b64 . "." . $payload_b64, $this->secret_key, true);
            
            if (!hash_equals($signature, $expected_signature)) {
                throw new Exception("فشل التحقق من التوقيع");
            }
            
            // 5. فك الـ payload
            $payload_json = $this->base64UrlDecode($payload_b64);
            $payload = json_decode($payload_json, true);
            
            if (!$payload) {
                throw new Exception("فشل فك بيانات المفتاح");
            }
            
            // 6. التحقق من كلمات المرور
            if ($payload['p1'] !== $this->password1) {
                throw new Exception("كلمة المرور الأولى غير صحيحة");
            }
            
            if ($payload['p2'] !== $this->password2) {
                throw new Exception("كلمة المرور الثانية غير صحيحة");
            }
            
            // 7. استخراج البيانات
            $device_data = [
                'cpu' => $payload['cpu'],
                'motherboard' => $payload['mb'],
                'disk' => $payload['disk'],
                'computer' => $payload['pc'],
                'uuid' => $payload['uuid']
            ];
            
            $expiry_date = $payload['year'] . '-' . $payload['month'] . '-' . $payload['day'];
            
            // 8. التحقق من التاريخ
            if (time() > $payload['exp']) {
                throw new Exception("انتهت صلاحية الترخيص");
            }
            
            return [
                'success' => true,
                'message' => 'المفتاح صحيح',
                'device_data' => $device_data,
                'expiry_date' => $expiry_date,
                'days_remaining' => floor(($payload['exp'] - time()) / 86400)
            ];
            
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => $e->getMessage()
            ];
        }
    }
    
    /**
     * فك Base64URL
     */
    private function base64UrlDecode($data) {
        return base64_decode(strtr($data, '-_', '+/'));
    }
}