<?php
require_once __DIR__ . '/../core/Model.php';
require_once __DIR__ . '/Product.php';
require_once __DIR__ . '/Shelf.php';

class Inventory extends Model {
    protected $table = 'main_inventory';
    protected $primaryKey = 'id';

    /**
     * الحصول على جميع الدفعات مع تفاصيل المنتج
     */
    public function getAllWithProduct() {
        $sql = "SELECT i.*, p.name as product_name, p.barcode, p.units_per_carton,
                       c.name as category_name
                FROM {$this->table} i
                JOIN products p ON i.product_id = p.id
                LEFT JOIN categories c ON p.category_id = c.id
                WHERE i.cartons_remaining > 0
                ORDER BY i.entry_date ASC";
        $stmt = $this->db->prepare($sql);
        $stmt->execute();
        return $stmt->fetchAll();
    }

    /**
     * الحصول على دفعات منتج معين
     */
    public function getByProduct($productId) {
        $sql = "SELECT * FROM {$this->table} 
                WHERE product_id = ? AND cartons_remaining > 0
                ORDER BY entry_date ASC";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([$productId]);
        return $stmt->fetchAll();
    }

    /**
     * الحصول على أقدم دفعة (FIFO) لمنتج معين
     */
    public function getOldestBatch($productId) {
        $sql = "SELECT * FROM {$this->table} 
                WHERE product_id = ? AND cartons_remaining > 0
                ORDER BY entry_date ASC
                LIMIT 1";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([$productId]);
        return $stmt->fetch();
    }

    /**
     * التحقق من وجود قيمة في جدول معين
     */
    public function exists($table, $field, $value, $excludeId = null) {
        $sql = "SELECT COUNT(*) as count FROM {$table} WHERE {$field} = ?";
        $params = [$value];
        
        if ($excludeId) {
            $sql .= " AND id != ?";
            $params[] = $excludeId;
        }
        
        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        $result = $stmt->fetch();
        return ($result['count'] ?? 0) > 0;
    }

    /**
     * توليد كود رف فريد
     */
    private function generateUniqueShelfCode($batchId) {
        $baseCode = 'RF' . str_pad($batchId, 3, '0', STR_PAD_LEFT);
        $shelfCode = $baseCode . date('ymd');
        $counter = 1;
        
        // التحقق من uniqueness
        while ($this->exists('shelf_inventory', 'shelf_code', $shelfCode)) {
            $shelfCode = $baseCode . date('ymd') . '-' . $counter;
            $counter++;
        }
        
        return $shelfCode;
    }

    /**
     * إضافة دفعة جديدة
     */
    public function addBatch($data) {
        try {
            $this->db->beginTransaction();

            // حساب سعر الوحدة
            $costPriceUnit = $data['cost_price_carton'] / $data['units_per_carton'];

            $sql = "INSERT INTO {$this->table} 
                    (product_id, batch_number, cartons_quantity, cartons_remaining, 
                     cost_price_carton, cost_price_unit, selling_price_unit, expiry_date, notes) 
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
            
            $stmt = $this->db->prepare($sql);
            $result = $stmt->execute([
                $data['product_id'],
                $data['batch_number'],
                $data['cartons_quantity'],
                $data['cartons_quantity'],
                $data['cost_price_carton'],
                $costPriceUnit,
                $data['selling_price_unit'],
                $data['expiry_date'],
                $data['notes'] ?? null
            ]);

            if (!$result) {
                throw new Exception('فشل في إضافة الدفعة');
            }

            $batchId = $this->db->lastInsertId();

            $this->db->commit();

            $this->logActivity('add_batch', 'تم إضافة دفعة جديدة: ' . $data['batch_number']);

            return [
                'success' => true, 
                'message' => 'تم إضافة الدفعة بنجاح',
                'batch_id' => $batchId
            ];

        } catch (Exception $e) {
            $this->db->rollBack();
            return ['success' => false, 'message' => 'خطأ: ' . $e->getMessage()];
        }
    }

    /**
     * رفع كرتون إلى الرف
     */
    public function moveToShelf($batchId) {
        try {
            $this->db->beginTransaction();

            // الحصول على معلومات الدفعة
            $batch = $this->find($batchId);
            if (!$batch) {
                throw new Exception('الدفعة غير موجودة');
            }

            if ($batch['cartons_remaining'] <= 0) {
                throw new Exception('لا توجد كراتين متاحة في هذه الدفعة');
            }

            // الحصول على معلومات المنتج
            $productModel = new Product();
            $product = $productModel->find($batch['product_id']);
            if (!$product) {
                throw new Exception('المنتج غير موجود');
            }

            // التحقق من عدم وجود كرتون مفتوح لنفس المنتج على الرف
            $shelfCheckSql = "SELECT COUNT(*) as open_cartons 
                              FROM shelf_inventory s
                              JOIN main_inventory i ON s.main_inventory_id = i.id
                              WHERE i.product_id = ? AND s.units_remaining > 0";
            $shelfCheckStmt = $this->db->prepare($shelfCheckSql);
            $shelfCheckStmt->execute([$batch['product_id']]);
            $shelfCheckResult = $shelfCheckStmt->fetch();
            
            if (($shelfCheckResult['open_cartons'] ?? 0) > 0) {
                throw new Exception('لا يمكن إضافة كرتون جديد؛ يوجد كرتون متاح بالفعل على الرف. يرجى استهلاكه أولاً أو استخدام خاصية الإحلال التلقائي');
            }

            // خصم كرتون من المخزن الرئيسي
            $newRemaining = $batch['cartons_remaining'] - 1;
            $updateSql = "UPDATE {$this->table} SET cartons_remaining = ? WHERE id = ?";
            $updateStmt = $this->db->prepare($updateSql);
            $updateResult = $updateStmt->execute([$newRemaining, $batchId]);

            if (!$updateResult) {
                throw new Exception('فشل في تحديث المخزن الرئيسي');
            }

            // إنشاء كود رف فريد
            $shelfCode = $this->generateUniqueShelfCode($batchId);

            // إضافة إلى رف البيع
            $shelfModel = new Shelf();
            $shelfResult = $shelfModel->addToShelf([
                'main_inventory_id' => $batchId,
                'shelf_code' => $shelfCode,
                'units_remaining' => $product['units_per_carton'],
                'selling_price_unit' => $batch['selling_price_unit']
            ]);

            if (!$shelfResult['success']) {
                throw new Exception($shelfResult['message']);
            }

            $this->db->commit();

            $this->logActivity('move_to_shelf', 'تم رفع كرتون إلى الرف: ' . $shelfCode);

            return [
                'success' => true, 
                'message' => 'تم رفع الكرتون إلى الرف بنجاح',
                'shelf_code' => $shelfCode
            ];

        } catch (Exception $e) {
            $this->db->rollBack();
            return ['success' => false, 'message' => 'خطأ: ' . $e->getMessage()];
        }
    }

    /**
     * الحصول على إحصائيات المخزن
     */
    public function getStats() {
        $sql = "SELECT 
                COUNT(DISTINCT product_id) as total_products,
                COUNT(*) as total_batches,
                SUM(cartons_remaining) as total_cartons,
                SUM(cartons_remaining * cost_price_carton) as total_cost_value,
                SUM(cartons_remaining * (selling_price_unit * units_per_carton)) as total_selling_value,
                COUNT(CASE WHEN expiry_date < CURDATE() THEN 1 END) as expired_batches,
                COUNT(CASE WHEN expiry_date BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 30 DAY) THEN 1 END) as expiring_soon
                FROM {$this->table} i
                JOIN products p ON i.product_id = p.id
                WHERE i.cartons_remaining > 0";
        $stmt = $this->db->prepare($sql);
        $stmt->execute();
        return $stmt->fetch();
    }

    /**
     * البحث في المخزون
     */
    public function search($filters = []) {
        $sql = "SELECT i.*, p.name as product_name, p.barcode, p.units_per_carton,
                       c.name as category_name
                FROM {$this->table} i
                JOIN products p ON i.product_id = p.id
                LEFT JOIN categories c ON p.category_id = c.id
                WHERE i.cartons_remaining > 0";

        $params = [];

        if (!empty($filters['product_id'])) {
            $sql .= " AND i.product_id = ?";
            $params[] = $filters['product_id'];
        }

        if (!empty($filters['category_id'])) {
            $sql .= " AND p.category_id = ?";
            $params[] = $filters['category_id'];
        }

        if (!empty($filters['expiry_status'])) {
            if ($filters['expiry_status'] === 'expired') {
                $sql .= " AND i.expiry_date < CURDATE()";
            } elseif ($filters['expiry_status'] === 'expiring_soon') {
                $sql .= " AND i.expiry_date BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 30 DAY)";
            }
        }

        if (!empty($filters['stock_status'])) {
            if ($filters['stock_status'] === 'low') {
                $sql .= " AND i.cartons_remaining < 5";
            } elseif ($filters['stock_status'] === 'out') {
                $sql .= " AND i.cartons_remaining = 0";
            }
        }

        if (!empty($filters['search'])) {
            $sql .= " AND (p.name LIKE ? OR p.barcode LIKE ? OR i.batch_number LIKE ?)";
            $searchTerm = "%{$filters['search']}%";
            $params[] = $searchTerm;
            $params[] = $searchTerm;
            $params[] = $searchTerm;
        }

        // إضافة فلتر الحد الأقصى للنتائج (لـ recent batches)
        if (!empty($filters['limit'])) {
            $sql .= " LIMIT ?";
            $params[] = $filters['limit'];
        } else {
            $sql .= " ORDER BY i.entry_date ASC";
        }

        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }

    /**
     * حذف دفعة
     */
    public function deleteBatch($id) {
        $checkSql = "SELECT COUNT(*) as count FROM shelf_inventory WHERE main_inventory_id = ?";
        $checkStmt = $this->db->prepare($checkSql);
        $checkStmt->execute([$id]);
        $result = $checkStmt->fetch();

        if ($result['count'] > 0) {
            return ['success' => false, 'message' => 'لا يمكن حذف الدفعة لأنها مستخدمة في رف البيع'];
        }

        $sql = "DELETE FROM {$this->table} WHERE id = ?";
        $stmt = $this->db->prepare($sql);
        
        if ($stmt->execute([$id])) {
            $this->logActivity('delete_batch', 'تم حذف دفعة رقم: ' . $id);
            return ['success' => true, 'message' => 'تم حذف الدفعة بنجاح'];
        }
        
        return ['success' => false, 'message' => 'فشل في حذف الدفعة'];
    }

    /**
     * تسجيل النشاط
     */
    private function logActivity($action, $details) {
        if (isset($_SESSION['user_id'])) {
            $sql = "INSERT INTO activity_logs (user_id, action, details, ip_address) VALUES (?, ?, ?, ?)";
            $stmt = $this->db->prepare($sql);
            $stmt->execute([
                $_SESSION['user_id'],
                $action,
                $details,
                $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1'
            ]);
        }
    }

    /**
     * رفع تلقائي للمنتجات التي نفدت من الرف
     */
    public function autoRestockShelf() {
        try {
            $this->db->beginTransaction();
            
            $shelfModel = new Shelf();
            $outOfStock = $shelfModel->getOutOfStockProducts();
            
            $restocked = [];
            $failed = [];
            
            foreach ($outOfStock as $item) {
                // الحصول على أقدم دفعة للمنتج
                $oldestBatch = $this->getOldestBatch($item['product_id']);
                
                if ($oldestBatch && $oldestBatch['cartons_remaining'] > 0) {
                    // رفع كرتون جديد
                    $result = $this->moveToShelf($oldestBatch['id']);
                    
                    if ($result['success']) {
                        // تحديث حالة الكرتون القديم
                        $shelfModel->updateStatus($item['id'], 'restocked');
                        
                        $restocked[] = [
                            'product' => $item['product_name'],
                            'batch' => $oldestBatch['batch_number'],
                            'shelf_code' => $result['shelf_code']
                        ];
                        
                        // تسجيل العملية
                        $this->logActivity('auto_restock', 'تم رفع كرتون تلقائي للمنتج: ' . $item['product_name']);
                    } else {
                        $failed[] = $item['product_name'];
                    }
                } else {
                    $failed[] = $item['product_name'] . ' (لا توجد دفعات)';
                }
            }
            
            $this->db->commit();
            
            return [
                'success' => true,
                'restocked' => $restocked,
                'failed' => $failed,
                'count' => count($restocked),
                'message' => 'تم رفع ' . count($restocked) . ' كرتون تلقائياً'
            ];
            
        } catch (Exception $e) {
            $this->db->rollBack();
            return [
                'success' => false,
                'message' => 'خطأ: ' . $e->getMessage()
            ];
        }
    }

    /**
 * الحصول على آخر الدفعات المرفوعة
 * @param int $limit عدد الدفعات المطلوبة
 * @return array
 */
/**
 * الحصول على آخر الدفعات المرفوعة
 * @param int $limit عدد الدفعات المطلوبة
 * @return array
 */
public function getRecentBatches($limit = 10) {
    $limit = (int)$limit;
    
    $sql = "SELECT i.*, p.name as product_name 
            FROM {$this->table} i
            JOIN products p ON i.product_id = p.id
            ORDER BY i.entry_date DESC
            LIMIT " . $limit;
    
    $stmt = $this->db->prepare($sql);
    $stmt->execute();
    return $stmt->fetchAll();
}
    /**
     * الحصول على دفعات محدودة (لـ API)
     * @param int $limit عدد الدفعات المطلوبة
     * @return array
     */
    public function getLimited($limit = 10) {
        $sql = "SELECT i.*, p.name as product_name 
                FROM {$this->table} i
                JOIN products p ON i.product_id = p.id
                WHERE i.cartons_remaining > 0
                ORDER BY i.entry_date DESC
                LIMIT ?";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([$limit]);
        return $stmt->fetchAll();
    }
}