<?php
require_once __DIR__ . '/../core/Model.php';

class Category extends Model {
    
    protected $table = 'categories';
    protected $primaryKey = 'id';

    /**
     * الحصول على جميع الأقسام النشطة
     */
    public function getAllActive() {
        $sql = "SELECT * FROM {$this->table} WHERE is_active = 1 ORDER BY name ASC";
        $stmt = $this->db->query($sql);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * الحصول على جميع الأقسام
     */
    public function getAll() {
        $sql = "SELECT * FROM {$this->table} ORDER BY name ASC";
        $stmt = $this->db->query($sql);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * إضافة قسم جديد
     */
    public function add($data) {
        $sql = "INSERT INTO {$this->table} (name, description, is_active, created_at) 
                VALUES (?, ?, ?, NOW())";
        
        $stmt = $this->db->prepare($sql);
        return $stmt->execute([
            $data['name'],
            $data['description'] ?? null,
            $data['is_active'] ?? 1
        ]);
    }

    /**
     * تحديث قسم
     */
    public function update($id, $data) {
        $sql = "UPDATE {$this->table} 
                SET name = ?, description = ?, is_active = ? 
                WHERE id = ?";
        
        $stmt = $this->db->prepare($sql);
        return $stmt->execute([
            $data['name'],
            $data['description'] ?? null,
            $data['is_active'] ?? 1,
            $id
        ]);
    }

    /**
     * تعطيل قسم
     */
    public function deactivate($id) {
        $sql = "UPDATE {$this->table} SET is_active = 0 WHERE id = ?";
        $stmt = $this->db->prepare($sql);
        return $stmt->execute([$id]);
    }

    /**
     * تفعيل قسم
     */
    public function activate($id) {
        $sql = "UPDATE {$this->table} SET is_active = 1 WHERE id = ?";
        $stmt = $this->db->prepare($sql);
        return $stmt->execute([$id]);
    }

    /**
     * البحث عن قسم بالاسم
     */
    public function findByName($name) {
        $sql = "SELECT * FROM {$this->table} WHERE name = ?";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([$name]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    /**
     * الحصول على إحصائيات الأقسام
     */
    public function getStatistics() {
        $sql = "SELECT 
                    COUNT(*) as total_categories,
                    SUM(CASE WHEN is_active = 1 THEN 1 ELSE 0 END) as active_categories,
                    SUM(CASE WHEN is_active = 0 THEN 1 ELSE 0 END) as inactive_categories
                FROM {$this->table}";
        
        $stmt = $this->db->query($sql);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    /**
     * الحصول على الأقسام مع عدد المنتجات في كل قسم
     */
    public function getWithProductCount() {
        $sql = "SELECT 
                    c.*,
                    COUNT(p.id) as product_count
                FROM {$this->table} c
                LEFT JOIN products p ON c.id = p.category_id AND p.is_active = 1
                GROUP BY c.id
                ORDER BY c.name ASC";
        
        $stmt = $this->db->query($sql);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * البحث في الأقسام
     */
    public function search($keyword) {
        $keyword = '%' . $keyword . '%';
        
        $sql = "SELECT * FROM {$this->table} 
                WHERE name LIKE ? OR description LIKE ?
                ORDER BY name ASC";
        
        $stmt = $this->db->prepare($sql);
        $stmt->execute([$keyword, $keyword]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * الحصول على قسم معين
     */
    public function getById($id) {
        $sql = "SELECT * FROM {$this->table} WHERE id = ?";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([$id]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    /**
     * التحقق من وجود منتجات في القسم
     */
    public function hasProducts($id) {
        $sql = "SELECT COUNT(*) as count FROM products WHERE category_id = ? AND is_active = 1";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([$id]);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return $result['count'] > 0;
    }
}