<?php
require_once __DIR__ . '/../core/Model.php';

class Shelf extends Model {
    protected $table = 'shelf_inventory';
    protected $primaryKey = 'id';

    /**
     * الحصول على جميع محتويات الرف مع التفاصيل
     */
  /**
 * الحصول على جميع محتويات الرف مع التفاصيل - نسخة محسنة
 */
public function getAllWithDetails() {
    $sql = "SELECT s.*, 
                   p.id as product_id,
                   p.name as product_name, 
                   p.barcode, 
                   p.units_per_carton,
                   i.batch_number, 
                   i.expiry_date, 
                   i.cost_price_unit,
                   i.cartons_quantity,
                   i.cartons_remaining as main_cartons_remaining,
                   (s.units_remaining * s.selling_price_unit) as total_value,
                   (s.units_remaining * (s.selling_price_unit - i.cost_price_unit)) as expected_profit
            FROM {$this->table} s
            LEFT JOIN main_inventory i ON s.main_inventory_id = i.id
            LEFT JOIN products p ON i.product_id = p.id
            ORDER BY s.added_at ASC";
    $stmt = $this->db->prepare($sql);
    $stmt->execute();
    return $stmt->fetchAll();
}

    /**
     * إضافة كرتون إلى الرف
     */
    public function addToShelf($data) {
        $sql = "INSERT INTO {$this->table} 
                (shelf_code, main_inventory_id, units_remaining, selling_price_unit, status) 
                VALUES (?, ?, ?, ?, 'available')";
        $stmt = $this->db->prepare($sql);
        
        try {
            $result = $stmt->execute([
                $data['shelf_code'],
                $data['main_inventory_id'],
                $data['units_remaining'],
                $data['selling_price_unit']
            ]);
            
            if ($result) {
                return [
                    'success' => true, 
                    'message' => 'تم إضافة الكرتون إلى الرف بنجاح',
                    'id' => $this->db->lastInsertId()
                ];
            }
            return ['success' => false, 'message' => 'فشل في إضافة الكرتون إلى الرف'];
            
        } catch (PDOException $e) {
            return ['success' => false, 'message' => 'خطأ: ' . $e->getMessage()];
        }
    }

    /**
     * الحصول على المنتجات التي نفدت من الرف
     */
    public function getOutOfStockProducts() {
        $sql = "SELECT s.*, p.id as product_id, p.name as product_name, p.units_per_carton,
                       i.id as batch_id, i.batch_number, i.cost_price_carton, i.cost_price_unit,
                       i.selling_price_unit as batch_price
                FROM {$this->table} s
                LEFT JOIN main_inventory i ON s.main_inventory_id = i.id
                LEFT JOIN products p ON i.product_id = p.id
                WHERE s.units_remaining = 0 
                AND s.status = 'out_of_stock'
                AND i.cartons_remaining > 0
                ORDER BY s.updated_at DESC";
        
        $stmt = $this->db->prepare($sql);
        $stmt->execute();
        return $stmt->fetchAll();
    }

    /**
     * تحديث حالة الكرتون في الرف
     */
    public function updateStatus($id, $status) {
        $sql = "UPDATE {$this->table} SET status = ?, updated_at = NOW() WHERE id = ?";
        $stmt = $this->db->prepare($sql);
        return $stmt->execute([$status, $id]);
    }

    /**
     * الحصول على عناصر الرف لدفعة معينة
     */
    public function getByBatchId($batchId) {
        $sql = "SELECT s.*, p.name as product_name 
                FROM {$this->table} s
                LEFT JOIN main_inventory i ON s.main_inventory_id = i.id
                LEFT JOIN products p ON i.product_id = p.id
                WHERE i.id = ?";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([$batchId]);
        return $stmt->fetchAll();
    }

    /**
     * الحصول على إحصائيات الرف
     */
    /**
 * الحصول على إحصائيات الرف - نسخة محسنة
 */
public function getStats() {
    $sql = "SELECT 
            COUNT(DISTINCT s.id) as total_shelves,
            COALESCE(SUM(s.units_remaining), 0) as total_units,
            COUNT(DISTINCT s.main_inventory_id) as total_batches,
            COALESCE(SUM(s.units_remaining * s.selling_price_unit), 0) as total_value,
            COALESCE(SUM(s.units_remaining * (s.selling_price_unit - i.cost_price_unit)), 0) as total_profit,
            COUNT(CASE WHEN s.status = 'available' THEN 1 END) as available_count,
            COUNT(CASE WHEN s.status = 'low_stock' THEN 1 END) as low_stock_count,
            COUNT(CASE WHEN s.status = 'out_of_stock' THEN 1 END) as out_of_stock_count,
            COUNT(CASE WHEN s.status = 'expired' THEN 1 END) as expired_count
            FROM {$this->table} s
            LEFT JOIN main_inventory i ON s.main_inventory_id = i.id";
    
    $stmt = $this->db->prepare($sql);
    $stmt->execute();
    $result = $stmt->fetch();
    
    if (!$result) {
        return [
            'total_shelves' => 0,
            'total_units' => 0,
            'total_batches' => 0,
            'total_value' => 0,
            'total_profit' => 0,
            'available_count' => 0,
            'low_stock_count' => 0,
            'out_of_stock_count' => 0,
            'expired_count' => 0
        ];
    }
    
    return $result;
}

   /**
 * الحصول على أقدم منتج في الرف
 */
/**
 * الحصول على أقدم منتج في الرف
 */
public function getOldestProduct() {
    $sql = "SELECT s.*, p.name as product_name 
            FROM {$this->table} s
            LEFT JOIN main_inventory i ON s.main_inventory_id = i.id
            LEFT JOIN products p ON i.product_id = p.id
            WHERE s.units_remaining > 0
            ORDER BY s.added_at ASC
            LIMIT 1";
    $stmt = $this->db->prepare($sql);
    $stmt->execute();
    return $stmt->fetch();
}

/**
 * الحصول على أحدث منتج في الرف
 */
public function getLatestProduct() {
    $sql = "SELECT s.*, p.name as product_name 
            FROM {$this->table} s
            LEFT JOIN main_inventory i ON s.main_inventory_id = i.id
            LEFT JOIN products p ON i.product_id = p.id
            WHERE s.units_remaining > 0
            ORDER BY s.added_at DESC
            LIMIT 1";
    $stmt = $this->db->prepare($sql);
    $stmt->execute();
    return $stmt->fetch();
}

    /**
     * البحث في الرف
     */
   /**
 * البحث في الرف - نسخة محسنة
 */
public function search($filters = []) {
    $sql = "SELECT s.*, p.name as product_name, p.barcode, p.units_per_carton,
                   i.batch_number, i.expiry_date, i.cost_price_unit,
                   i.product_id
            FROM {$this->table} s
            LEFT JOIN main_inventory i ON s.main_inventory_id = i.id
            LEFT JOIN products p ON i.product_id = p.id
            WHERE 1=1";

    $params = [];

    // فلتر الحالة
    if (!empty($filters['status'])) {
        if ($filters['status'] === 'available') {
            $sql .= " AND s.status = 'available'";
        } elseif ($filters['status'] === 'low') {
            $sql .= " AND s.status = 'low_stock'";
        } elseif ($filters['status'] === 'expired') {
            $sql .= " AND s.status = 'expired'";
        }
    }

    // فلتر البحث النصي
    if (!empty($filters['search'])) {
        $sql .= " AND (p.name LIKE ? OR p.barcode LIKE ?)";
        $searchTerm = "%{$filters['search']}%";
        $params[] = $searchTerm;
        $params[] = $searchTerm;
    }

    // فلتر الباركود
    if (!empty($filters['barcode'])) {
        $sql .= " AND p.barcode = ?";
        $params[] = $filters['barcode'];
    }

    // ترتيب النتائج
    if (!empty($filters['sort'])) {
        switch ($filters['sort']) {
            case 'expiry':
                $sql .= " ORDER BY i.expiry_date ASC";
                break;
            case 'price':
                $sql .= " ORDER BY s.selling_price_unit ASC";
                break;
            case 'quantity':
                $sql .= " ORDER BY s.units_remaining ASC";
                break;
            default:
                $sql .= " ORDER BY s.added_at ASC";
        }
    } else {
        $sql .= " ORDER BY s.added_at ASC";
    }

    $stmt = $this->db->prepare($sql);
    $stmt->execute($params);
    return $stmt->fetchAll();
}

    /**
     * تحديث كرتون في الرف
     */
    /**
 * تحديث كرتون في الرف
 */
public function updateShelf($id, $data) {
    $fields = [];
    $params = [];

    if (isset($data['units_remaining'])) {
        $fields[] = "units_remaining = ?";
        $params[] = $data['units_remaining'];
    }

    if (isset($data['selling_price_unit'])) {
        $fields[] = "selling_price_unit = ?";
        $params[] = $data['selling_price_unit'];
    }

    if (isset($data['status'])) {
        $fields[] = "status = ?";
        $params[] = $data['status'];
    }

    if (empty($fields)) {
        return ['success' => false, 'message' => 'لا توجد بيانات للتحديث'];
    }

    $params[] = $id;
    $sql = "UPDATE {$this->table} SET " . implode(', ', $fields) . ", updated_at = NOW() WHERE id = ?";
    
    $stmt = $this->db->prepare($sql);
    
    if ($stmt->execute($params)) {
        return ['success' => true, 'message' => 'تم تحديث الكرتون بنجاح'];
    }
    
    return ['success' => false, 'message' => 'فشل في تحديث الكرتون'];
}

/**
 * حذف كرتون من الرف
 */
public function removeFromShelf($id, $reason = '') {
    $sql = "DELETE FROM {$this->table} WHERE id = ?";
    $stmt = $this->db->prepare($sql);
    
    if ($stmt->execute([$id])) {
        return ['success' => true, 'message' => 'تم حذف الكرتون من الرف بنجاح'];
    }
    
    return ['success' => false, 'message' => 'فشل في حذف الكرتون'];
}
    /**
     * بيع وحدات من الرف
     */
    public function sellUnits($shelfId, $quantity, $saleType = 'cash', $customerId = null) {
        try {
            $this->db->beginTransaction();

            $shelf = $this->find($shelfId);
            if (!$shelf) {
                throw new Exception('الكرتون غير موجود');
            }

            $currentRemaining = $shelf['units_remaining'];

            $sql = "SELECT i.*, p.name as product_name, p.units_per_carton, p.id as product_id 
                    FROM main_inventory i
                    LEFT JOIN products p ON i.product_id = p.id
                    WHERE i.id = ?";
            $stmt = $this->db->prepare($sql);
            $stmt->execute([$shelf['main_inventory_id']]);
            $inventory = $stmt->fetch();

            if (!$inventory) {
                throw new Exception('معلومات المنتج غير موجودة');
            }

            $newRemaining = $currentRemaining - $quantity;
            $currentMainInventoryId = $shelf['main_inventory_id'];
            $costAtSale = $inventory['cost_price_unit'];

            // الإحلال التلقائي إذا كانت الكمية المطلوبة أكبر من المتبقية
            if ($newRemaining < 0) {
                // جلب أقدم دفعة (FIFO) باستثناء الدفعة الحالية إذا كانت فارغة
                $inventoryModel = new Inventory(); // Need to require Inventory at top if not there, or use direct DB query
                
                $fifoSql = "SELECT * FROM main_inventory 
                            WHERE product_id = ? AND cartons_remaining > 0
                            ORDER BY expiry_date ASC, entry_date ASC
                            LIMIT 1";
                $fifoStmt = $this->db->prepare($fifoSql);
                $fifoStmt->execute([$inventory['product_id']]);
                $oldestBatch = $fifoStmt->fetch();

                if (!$oldestBatch) {
                    throw new Exception('الكمية المطلوبة غير متاحة، ولا توجد كراتين في المخزن الرئيسي');
                }

                // خصم كرتون من المخزن الرئيسي
                $updateMainSql = "UPDATE main_inventory SET cartons_remaining = cartons_remaining - 1 WHERE id = ?";
                $updateMainStmt = $this->db->prepare($updateMainSql);
                $updateMainStmt->execute([$oldestBatch['id']]);

                // تصفير الوحدات القديمة، وإضافة السعة الجديدة، ثم الخصم
                // old units are considered zeroed, new units = units_per_carton
                $newRemaining = $inventory['units_per_carton'] - ($quantity - $currentRemaining);
                
                if ($newRemaining < 0) {
                     // In case the required quantity is still greater than 1 full carton
                     // (This requires a loop to pull multiple cartons, but keeping it simple for now based on requirements)
                     throw new Exception('الكمية المطلوبة أكبر من سعة كرتون واحد إضافي، يرجى البيع على دفعات');
                }

                $currentMainInventoryId = $oldestBatch['id'];
                $costAtSale = $oldestBatch['cost_price_unit'];
            }

            $updateSql = "UPDATE {$this->table} SET units_remaining = ?, main_inventory_id = ?, updated_at = NOW()";
            
            if ($newRemaining == 0) {
                $updateSql .= ", status = 'out_of_stock'";
            } elseif ($newRemaining < 5) {
                $updateSql .= ", status = 'low_stock'";
            } else {
                $updateSql .= ", status = 'available'";
            }
            
            $updateSql .= " WHERE id = ?";
            
            $updateStmt = $this->db->prepare($updateSql);
            $updateStmt->execute([$newRemaining, $currentMainInventoryId, $shelfId]);

            $invoiceNumber = 'INV-' . date('Ymd') . '-' . rand(1000, 9999);
            $totalAmount = $quantity * $shelf['selling_price_unit'];

            $saleSql = "INSERT INTO sales (invoice_number, customer_id, sale_type, total_amount, paid_amount, created_by) 
                        VALUES (?, ?, ?, ?, ?, ?)";
            $saleStmt = $this->db->prepare($saleSql);
            $saleStmt->execute([
                $invoiceNumber,
                $customerId,
                $saleType,
                $totalAmount,
                $saleType === 'cash' ? $totalAmount : 0,
                $_SESSION['user_id'] ?? 1
            ]);

            $saleId = $this->db->lastInsertId();

            $itemSql = "INSERT INTO sale_items (sale_id, shelf_inventory_id, quantity, price_unit, cost_at_sale, subtotal) 
                        VALUES (?, ?, ?, ?, ?, ?)";
            $itemStmt = $this->db->prepare($itemSql);
            $itemStmt->execute([
                $saleId,
                $shelfId,
                $quantity,
                $shelf['selling_price_unit'],
                $costAtSale,
                $totalAmount
            ]);

            $this->db->commit();

            return [
                'success' => true,
                'message' => 'تمت عملية البيع بنجاح',
                'sale_id' => $saleId,
                'invoice_number' => $invoiceNumber
            ];

        } catch (Exception $e) {
            $this->db->rollBack();
            return ['success' => false, 'message' => 'خطأ: ' . $e->getMessage()];
        }
    }
}