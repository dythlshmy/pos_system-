<?php
require_once __DIR__ . '/../core/Model.php';

class ReturnModel extends Model {
    protected $table = 'returns';
    protected $primaryKey = 'id';
    
    // ... باقي دوال الكلاس

    /**
     * الحصول على جميع المنتجات مع معلومات القسم
     */
    public function getAllWithCategory() {
        $sql = "SELECT p.*, c.name as category_name 
                FROM {$this->table} p
                LEFT JOIN categories c ON p.category_id = c.id
                WHERE p.is_active = 1
                ORDER BY p.name ASC";
        $stmt = $this->db->prepare($sql);
        $stmt->execute();
        return $stmt->fetchAll();
    }

    /**
     * البحث عن منتج بالباركود
     */
    public function findByBarcode($barcode) {
        $sql = "SELECT p.*, c.name as category_name 
                FROM {$this->table} p
                LEFT JOIN categories c ON p.category_id = c.id
                WHERE p.barcode = ? AND p.is_active = 1";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([$barcode]);
        return $stmt->fetch();
    }

    /**
     * البحث عن منتجات (بحث عام)
     */
    public function search($keyword) {
        $sql = "SELECT p.*, c.name as category_name 
                FROM {$this->table} p
                LEFT JOIN categories c ON p.category_id = c.id
                WHERE (p.name LIKE ? OR p.barcode LIKE ?) AND p.is_active = 1
                ORDER BY p.name ASC
                LIMIT 20";
        $keyword = "%$keyword%";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([$keyword, $keyword]);
        return $stmt->fetchAll();
    }

    /**
     * الحصول على منتجات قسم معين
     */
    public function getByCategory($categoryId) {
        $sql = "SELECT * FROM {$this->table} 
                WHERE category_id = ? AND is_active = 1 
                ORDER BY name ASC";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([$categoryId]);
        return $stmt->fetchAll();
    }

    /**
     * التحقق من وجود باركود مكرر
     */
    public function barcodeExists($barcode, $excludeId = null) {
        if ($excludeId) {
            $sql = "SELECT COUNT(*) as count FROM {$this->table} 
                    WHERE barcode = ? AND id != ?";
            $stmt = $this->db->prepare($sql);
            $stmt->execute([$barcode, $excludeId]);
        } else {
            $sql = "SELECT COUNT(*) as count FROM {$this->table} WHERE barcode = ?";
            $stmt = $this->db->prepare($sql);
            $stmt->execute([$barcode]);
        }
        $result = $stmt->fetch();
        return ($result['count'] ?? 0) > 0;
    }

    /**
     * إضافة منتج جديد
     */
    public function createProduct($data) {
        // التحقق من الباركود
        if ($this->barcodeExists($data['barcode'])) {
            return ['success' => false, 'message' => 'الباركود موجود مسبقاً'];
        }

        $sql = "INSERT INTO {$this->table} (category_id, name, barcode, units_per_carton, is_active) 
                VALUES (?, ?, ?, ?, 1)";
        $stmt = $this->db->prepare($sql);
        
        try {
            $result = $stmt->execute([
                $data['category_id'] ?: null,
                $data['name'],
                $data['barcode'],
                $data['units_per_carton']
            ]);
            
            if ($result) {
                return ['success' => true, 'message' => 'تم إضافة المنتج بنجاح', 'id' => $this->db->lastInsertId()];
            }
            return ['success' => false, 'message' => 'فشل في إضافة المنتج'];
            
        } catch (PDOException $e) {
            return ['success' => false, 'message' => 'خطأ في قاعدة البيانات: ' . $e->getMessage()];
        }
    }

    /**
     * تحديث منتج
     */
    public function updateProduct($id, $data) {
        // التحقق من الباركود مع استثناء هذا المنتج
        if ($this->barcodeExists($data['barcode'], $id)) {
            return ['success' => false, 'message' => 'الباركود موجود مسبقاً'];
        }

        $sql = "UPDATE {$this->table} 
                SET category_id = ?, name = ?, barcode = ?, units_per_carton = ? 
                WHERE id = ?";
        $stmt = $this->db->prepare($sql);
        
        try {
            $result = $stmt->execute([
                $data['category_id'] ?: null,
                $data['name'],
                $data['barcode'],
                $data['units_per_carton'],
                $id
            ]);
            
            if ($result) {
                return ['success' => true, 'message' => 'تم تحديث المنتج بنجاح'];
            }
            return ['success' => false, 'message' => 'فشل في تحديث المنتج'];
            
        } catch (PDOException $e) {
            return ['success' => false, 'message' => 'خطأ في قاعدة البيانات: ' . $e->getMessage()];
        }
    }

    /**
     * حذف منتج (تعطيل)
     */
    public function deleteProduct($id) {
        $sql = "UPDATE {$this->table} SET is_active = 0 WHERE id = ?";
        $stmt = $this->db->prepare($sql);
        return $stmt->execute([$id]);
    }

    /**
     * تفعيل منتج
     */
    public function activateProduct($id) {
        $sql = "UPDATE {$this->table} SET is_active = 1 WHERE id = ?";
        $stmt = $this->db->prepare($sql);
        return $stmt->execute([$id]);
    }

    /**
     * الحصول على إحصائيات المنتجات
     */
    public function getStats() {
        $sql = "SELECT 
                COUNT(*) as total_products,
                COUNT(DISTINCT category_id) as total_categories,
                AVG(units_per_carton) as avg_units_per_carton
                FROM {$this->table} 
                WHERE is_active = 1";
        $stmt = $this->db->prepare($sql);
        $stmt->execute();
        return $stmt->fetch();
    }

    /**
     * جلب المنتج مع كامل تفاصيله
     */
    public function getWithDetails($id) {
        $sql = "SELECT p.*, c.name as category_name, 
                       (SELECT COUNT(*) FROM main_inventory WHERE product_id = p.id AND cartons_remaining > 0) as batches_count,
                       (SELECT SUM(cartons_remaining) FROM main_inventory WHERE product_id = p.id) as total_cartons
                FROM {$this->table} p
                LEFT JOIN categories c ON p.category_id = c.id
                WHERE p.id = ?";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([$id]);
        return $stmt->fetch();
    }
}