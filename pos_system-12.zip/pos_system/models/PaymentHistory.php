<?php
require_once __DIR__ . '/../core/Model.php';

class PaymentHistory extends Model {
    protected $table = 'payment_history';
    
    public function __construct() {
        parent::__construct($this->table);
    }
    
    /**
     * تسجيل دفعة جديدة
     */
    public function addPayment($customerId, $amount, $saleId = null, $method = 'cash', $notes = '') {
        $sql = "INSERT INTO payment_history (customer_id, sale_id, amount, payment_method, notes, created_by)
                VALUES (?, ?, ?, ?, ?, ?)";
        $stmt = $this->db->prepare($sql);
        return $stmt->execute([$customerId, $saleId, $amount, $method, $notes, Auth::id()]);
    }
    
    /**
     * جلب مدفوعات عميل
     */
    public function getCustomerPayments($customerId, $limit = 50) {
        $sql = "SELECT ph.*, s.invoice_number 
                FROM payment_history ph
                LEFT JOIN sales s ON ph.sale_id = s.id
                WHERE ph.customer_id = ?
                ORDER BY ph.payment_date DESC
                LIMIT ?";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([$customerId, $limit]);
        return $stmt->fetchAll();
    }
    
    /**
     * إجمالي مدفوعات عميل
     */
    public function getTotalPayments($customerId) {
        $sql = "SELECT COALESCE(SUM(amount), 0) as total 
                FROM payment_history 
                WHERE customer_id = ?";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([$customerId]);
        return $stmt->fetchColumn();
    }
}