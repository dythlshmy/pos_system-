<?php
/**
 * نموذج الترخيص - التعامل مع قاعدة البيانات
 * الإصدار: 2.0
 * التاريخ: 2026-03-14
 * التوافق: متوافق مع نظام المطور (JWT)
 */

class LicenseModel {
    
    private $db;
    
    /**
     * المُنشئ - الاتصال بقاعدة البيانات
     */
    public function __construct() {
        $this->db = Database::getInstance();
    }
    
    // ============================================
    // دوال التحقق عند التشغيل
    // ============================================
    
    /**
     * التحقق من صحة الترخيص عند تشغيل النظام
     * يتم استدعاؤها في كل مرة يفتح فيها المستخدم النظام
     * 
     * @return array نتيجة التحقق مع تفاصيل الحالة
     */
    public function verifyLicenseAtStartup() {
        try {
            // جمع بصمة الجهاز الحالي
            $fingerprint = new Fingerprint();
            $current_device = $fingerprint->collect();
            
            // التحقق من نجاح جمع بصمة الجهاز
            if (empty($current_device['cpu']) || empty($current_device['motherboard'])) {
                throw new Exception("فشل جمع بصمة الجهاز");
            }
            
            // البحث عن ترخيص نشط لهذا الجهاز
            $sql = "SELECT l.*, d.fingerprint_key, d.cpu_id, d.motherboard_serial, 
                           d.disk_serial, d.computer_name, d.os_uuid
                    FROM licenses l
                    JOIN devices d ON l.device_id = d.id
                    WHERE d.cpu_id = :cpu 
                    AND d.motherboard_serial = :mb 
                    AND d.disk_serial = :disk
                    AND l.status = 'active'
                    ORDER BY l.id DESC LIMIT 1";
            
            $stmt = $this->db->prepare($sql);
            $stmt->execute([
                'cpu' => $current_device['cpu'],
                'mb' => $current_device['motherboard'],
                'disk' => $current_device['disk']
            ]);
            
            $license = $stmt->fetch();
            
            // ========== التحقق 1: هل يوجد ترخيص؟ ==========
            if (!$license) {
                return [
                    'status' => 'no_license',
                    'message' => 'لا يوجد ترخيص لهذا الجهاز',
                    'fingerprint' => $fingerprint->generateFingerprintKey(),
                    'can_access' => false,
                    'redirect' => BASE_URL . '/license'
                ];
            }
            
            // ========== التحقق 2: هل الترخيص لا يزال نشطاً؟ ==========
            if ($license['status'] !== 'active') {
                return [
                    'status' => 'inactive',
                    'message' => 'الترخيص غير نشط',
                    'fingerprint' => $fingerprint->generateFingerprintKey(),
                    'can_access' => false,
                    'redirect' => BASE_URL . '/license'
                ];
            }
            
            // ========== التحقق 3: هل تاريخ الصلاحية ساري؟ ==========
            $today = date('Y-m-d');
            if ($today > $license['expiry_date']) {
                // تحديث حالة الترخيص إلى منتهي
                $this->updateLicenseStatus($license['id'], 'expired');
                
                return [
                    'status' => 'expired',
                    'message' => 'انتهت صلاحية الترخيص',
                    'expiry_date' => $license['expiry_date'],
                    'fingerprint' => $fingerprint->generateFingerprintKey(),
                    'can_access' => false,
                    'redirect' => BASE_URL . '/license'
                ];
            }
            
            // ========== التحقق 4: هل بصمة الجهاز لا تزال مطابقة؟ ==========
            $matches = [
                'cpu' => ($license['cpu_id'] === $current_device['cpu']),
                'motherboard' => ($license['motherboard_serial'] === $current_device['motherboard']),
                'disk' => ($license['disk_serial'] === $current_device['disk']),
                'computer' => ($license['computer_name'] === $current_device['computer']),
                'uuid' => ($license['os_uuid'] === $current_device['uuid'])
            ];
            
            foreach ($matches as $component => $match) {
                if (!$match) {
                    // تم تغيير أحد مكونات الجهاز! إبطال الترخيص
                    $this->updateLicenseStatus($license['id'], 'revoked');
                    
                    // تسجيل التغيير في سجل الأمان
                    $this->logSecurityEvent(
                        $license['id'],
                        'device_changed',
                        "تم تغيير مكون الجهاز: $component"
                    );
                    
                    return [
                        'status' => 'revoked',
                        'message' => "تم تغيير مكون الجهاز: $component",
                        'fingerprint' => $fingerprint->generateFingerprintKey(),
                        'can_access' => false,
                        'redirect' => BASE_URL . '/license'
                    ];
                }
            }
            
            // ========== كل شيء سليم - تحديث آخر تحقق ==========
            $this->updateLastVerification($license['id']);
            
            // حساب الأيام المتبقية
            $expiry = new DateTime($license['expiry_date']);
            $now = new DateTime();
            $days_remaining = $now->diff($expiry)->days;
            
            return [
                'status' => 'active',
                'message' => 'الترخيص ساري المفعول',
                'expiry_date' => $license['expiry_date'],
                'days_remaining' => $days_remaining,
                'license_key' => $license['license_key'],
                'fingerprint_key' => $license['fingerprint_key'],
                'can_access' => true
            ];
            
        } catch (Exception $e) {
            error_log('خطأ في verifyLicenseAtStartup: ' . $e->getMessage());
            
            return [
                'status' => 'error',
                'message' => 'حدث خطأ في التحقق من الترخيص',
                'can_access' => false,
                'redirect' => BASE_URL . '/license'
            ];
        }
    }
    
    /**
     * التحقق من حالة الترخيص (للتوافق مع الإصدارات القديمة)
     * 
     * @return array حالة الترخيص
     */
    public function checkLicenseStatus() {
        return $this->verifyLicenseAtStartup();
    }
    
    // ============================================
    // دوال إدارة التراخيص
    // ============================================
    
    /**
     * تفعيل ترخيص جديد (يحذف القديم تلقائياً)
     * 
     * @param string $license_key مفتاح الترخيص
     * @param array $device_data بيانات الجهاز
     * @param string $expiry_date تاريخ الانتهاء
     * @return array نتيجة العملية
     */
    public function activateLicense($license_key, $device_data, $expiry_date) {
        try {
            $this->db->beginTransaction();
            
            // 1️⃣ البحث عن الجهاز أو إنشاؤه
            $device_id = $this->getOrCreateDevice($device_data);
            
            // 2️⃣ إلغاء أي تراخيص سابقة نشطة لنفس الجهاز
            $this->deactivateExistingLicenses($device_id);
            
            // 3️⃣ التحقق من عدم وجود نفس المفتاح مسبقاً
            $existing = $this->getLicenseByKey($license_key);
            if ($existing && $existing['status'] === 'active') {
                throw new Exception("هذا المفتاح مستخدم بالفعل على جهاز آخر");
            }
            
            // 4️⃣ إدراج الترخيص الجديد
            $sql = "INSERT INTO licenses SET
                    license_key = :license_key,
                    device_id = :device_id,
                    cpu_id = :cpu,
                    motherboard_serial = :mb,
                    disk_serial = :disk,
                    computer_name = :computer,
                    os_uuid = :uuid,
                    expiry_date = :expiry_date,
                    status = 'active',
                    activated_at = NOW(),
                    last_verified = NOW()";
            
            $stmt = $this->db->prepare($sql);
            $stmt->execute([
                'license_key' => $license_key,
                'device_id' => $device_id,
                'cpu' => $device_data['cpu'],
                'mb' => $device_data['motherboard'],
                'disk' => $device_data['disk'],
                'computer' => $device_data['computer'],
                'uuid' => $device_data['uuid'],
                'expiry_date' => $expiry_date
            ]);
            
            $license_id = $this->db->lastInsertId();
            
            // 5️⃣ تسجيل عملية التفعيل
            $this->logActivation($license_id, $device_id, $license_key);
            
            $this->db->commit();
            
            return [
                'success' => true,
                'message' => 'تم تفعيل الترخيص بنجاح',
                'license_id' => $license_id
            ];
            
        } catch (Exception $e) {
            $this->db->rollBack();
            error_log('خطأ في activateLicense: ' . $e->getMessage());
            
            return [
                'success' => false,
                'message' => 'خطأ في التفعيل: ' . $e->getMessage()
            ];
        }
    }
    
    /**
     * البحث عن الجهاز أو إنشاؤه
     * 
     * @param array $device_data بيانات الجهاز
     * @return int معرف الجهاز
     */
    private function getOrCreateDevice($device_data) {
        // البحث عن الجهاز
        $sql = "SELECT id FROM devices WHERE 
                cpu_id = :cpu AND 
                motherboard_serial = :mb AND 
                disk_serial = :disk";
        
        $stmt = $this->db->prepare($sql);
        $stmt->execute([
            'cpu' => $device_data['cpu'],
            'mb' => $device_data['motherboard'],
            'disk' => $device_data['disk']
        ]);
        
        $device = $stmt->fetch();
        
        if ($device) {
            // تحديث آخر ظهور
            $sql = "UPDATE devices SET last_seen = NOW() WHERE id = :id";
            $stmt = $this->db->prepare($sql);
            $stmt->execute(['id' => $device['id']]);
            
            return $device['id'];
        }
        
        // إنشاء جهاز جديد
        $fingerprint = new Fingerprint();
        $fingerprint_hash = hash('sha256', implode('|', $device_data));
        
        $sql = "INSERT INTO devices SET
                fingerprint_key = :key,
                fingerprint_hash = :hash,
                cpu_id = :cpu,
                motherboard_serial = :mb,
                disk_serial = :disk,
                computer_name = :computer,
                os_uuid = :uuid,
                first_seen = NOW(),
                last_seen = NOW()";
        
        $stmt = $this->db->prepare($sql);
        $stmt->execute([
            'key' => $fingerprint->generateFingerprintKey(),
            'hash' => $fingerprint_hash,
            'cpu' => $device_data['cpu'],
            'mb' => $device_data['motherboard'],
            'disk' => $device_data['disk'],
            'computer' => $device_data['computer'],
            'uuid' => $device_data['uuid']
        ]);
        
        return $this->db->lastInsertId();
    }
    
    /**
     * إلغاء التراخيص السابقة لنفس الجهاز
     * 
     * @param int $device_id معرف الجهاز
     */
    private function deactivateExistingLicenses($device_id) {
        $sql = "UPDATE licenses SET status = 'replaced' 
                WHERE device_id = :device_id AND status = 'active'";
        $stmt = $this->db->prepare($sql);
        $stmt->execute(['device_id' => $device_id]);
    }
    
    /**
     * البحث عن ترخيص بالمفتاح
     * 
     * @param string $license_key مفتاح الترخيص
     * @return array|false بيانات الترخيص أو false
     */
    private function getLicenseByKey($license_key) {
        $sql = "SELECT * FROM licenses WHERE license_key = :key LIMIT 1";
        $stmt = $this->db->prepare($sql);
        $stmt->execute(['key' => $license_key]);
        return $stmt->fetch();
    }
    
    // ============================================
    // دوال التحديث والتسجيل
    // ============================================
    
    /**
     * تحديث حالة الترخيص
     * 
     * @param int $license_id معرف الترخيص
     * @param string $status الحالة الجديدة
     */
    private function updateLicenseStatus($license_id, $status) {
        $sql = "UPDATE licenses SET status = :status WHERE id = :id";
        $stmt = $this->db->prepare($sql);
        $stmt->execute(['id' => $license_id, 'status' => $status]);
        
        // تسجيل التغيير
        $this->logLicenseChange($license_id, $status);
    }
    
    /**
     * تحديث آخر تحقق
     * 
     * @param int $license_id معرف الترخيص
     */
    private function updateLastVerification($license_id) {
        $sql = "UPDATE licenses SET last_verified = NOW() WHERE id = :id";
        $stmt = $this->db->prepare($sql);
        $stmt->execute(['id' => $license_id]);
        
        // تسجيل التحقق
        $sql = "INSERT INTO license_verifications SET
                license_id = :license_id,
                verification_status = 'success',
                verified_at = NOW()";
        
        $stmt = $this->db->prepare($sql);
        $stmt->execute(['license_id' => $license_id]);
    }
    
    /**
     * تسجيل عملية التفعيل
     * 
     * @param int $license_id معرف الترخيص
     * @param int $device_id معرف الجهاز
     * @param string $license_key مفتاح الترخيص
     */
    private function logActivation($license_id, $device_id, $license_key) {
        $sql = "INSERT INTO license_logs SET
                license_id = :license_id,
                action = 'activate',
                details = :details,
                ip_address = :ip,
                created_at = NOW()";
        
        $stmt = $this->db->prepare($sql);
        $stmt->execute([
            'license_id' => $license_id,
            'details' => "تم تفعيل ترخيص جديد: " . substr($license_key, 0, 20) . "...",
            'ip' => $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1'
        ]);
    }
    
    /**
     * تسجيل تغيير حالة الترخيص
     * 
     * @param int $license_id معرف الترخيص
     * @param string $new_status الحالة الجديدة
     */
    private function logLicenseChange($license_id, $new_status) {
        $sql = "INSERT INTO license_logs SET
                license_id = :license_id,
                action = 'status_changed',
                details = :details,
                ip_address = :ip,
                created_at = NOW()";
        
        $stmt = $this->db->prepare($sql);
        $stmt->execute([
            'license_id' => $license_id,
            'details' => "تغيرت حالة الترخيص إلى: $new_status",
            'ip' => $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1'
        ]);
    }
    
    /**
     * تسجيل حدث أمني
     * 
     * @param int $license_id معرف الترخيص
     * @param string $action الإجراء
     * @param string $details التفاصيل
     */
    private function logSecurityEvent($license_id, $action, $details) {
        $sql = "INSERT INTO license_logs SET
                license_id = :license_id,
                action = :action,
                details = :details,
                ip_address = :ip,
                created_at = NOW()";
        
        $stmt = $this->db->prepare($sql);
        $stmt->execute([
            'license_id' => $license_id,
            'action' => $action,
            'details' => $details,
            'ip' => $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1'
        ]);
    }
    
    /**
     * تسجيل محاولة فاشلة
     * 
     * @param string $license_key مفتاح الترخيص (قد يكون فارغاً)
     * @param string $reason سبب الفشل
     */
    public function logFailedAttempt($license_key, $reason) {
        try {
            $sql = "INSERT INTO license_logs SET
                    action = 'failed_activation',
                    details = :details,
                    ip_address = :ip,
                    created_at = NOW()";
            
            $stmt = $this->db->prepare($sql);
            $stmt->execute([
                'details' => "محاولة تفعيل فاشلة: $reason" . 
                            ($license_key ? " - المفتاح: " . substr($license_key, 0, 20) : ""),
                'ip' => $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1'
            ]);
        } catch (Exception $e) {
            // تجاهل خطأ التسجيل
            error_log('فشل تسجيل المحاولة الفاشلة: ' . $e->getMessage());
        }
    }
    
    // ============================================
    // دوال إضافية
    // ============================================
    
    /**
     * الحصول على سجل التحقق لترخيص معين
     * 
     * @param int $license_id معرف الترخيص
     * @param int $limit عدد السجلات
     * @return array سجل التحقق
     */
    public function getVerificationHistory($license_id, $limit = 10) {
        $sql = "SELECT * FROM license_verifications 
                WHERE license_id = :license_id 
                ORDER BY verified_at DESC 
                LIMIT :limit";
        
        $stmt = $this->db->prepare($sql);
        $stmt->bindValue(':license_id', $license_id, PDO::PARAM_INT);
        $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
        $stmt->execute();
        
        return $stmt->fetchAll();
    }
    
    /**
     * الحصول على سجل العمليات لترخيص معين
     * 
     * @param int $license_id معرف الترخيص
     * @param int $limit عدد السجلات
     * @return array سجل العمليات
     */
    public function getLicenseLogs($license_id, $limit = 20) {
        $sql = "SELECT * FROM license_logs 
                WHERE license_id = :license_id 
                ORDER BY created_at DESC 
                LIMIT :limit";
        
        $stmt = $this->db->prepare($sql);
        $stmt->bindValue(':license_id', $license_id, PDO::PARAM_INT);
        $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
        $stmt->execute();
        
        return $stmt->fetchAll();
    }
    
    /**
     * إعادة تعيين الترخيص (مسح الترخيص الحالي)
     * للاستخدام في حالات الطوارئ فقط
     * 
     * @return bool نجاح العملية
     */
    public function resetLicense() {
        try {
            $this->db->beginTransaction();
            
            // حذف جميع التراخيص النشطة
            $sql = "UPDATE licenses SET status = 'reset' WHERE status = 'active'";
            $this->db->exec($sql);
            
            // حذف الأجهزة غير المرتبطة بتراخيص (اختياري)
            $sql = "DELETE FROM devices WHERE id NOT IN (SELECT device_id FROM licenses)";
            $this->db->exec($sql);
            
            // تسجيل عملية إعادة التعيين
            $sql = "INSERT INTO license_logs SET
                    action = 'system_reset',
                    details = 'تم إعادة تعيين نظام الترخيص',
                    ip_address = :ip,
                    created_at = NOW()";
            
            $stmt = $this->db->prepare($sql);
            $stmt->execute(['ip' => $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1']);
            
            $this->db->commit();
            return true;
            
        } catch (Exception $e) {
            $this->db->rollBack();
            error_log('خطأ في resetLicense: ' . $e->getMessage());
            return false;
        }
    }
    
    /**
     * الحصول على إحصائيات الترخيص
     * 
     * @return array إحصائيات
     */
    public function getStatistics() {
        $stats = [];
        
        // إجمالي التراخيص
        $stmt = $this->db->query("SELECT COUNT(*) FROM licenses");
        $stats['total_licenses'] = $stmt->fetchColumn();
        
        // التراخيص النشطة
        $stmt = $this->db->query("SELECT COUNT(*) FROM licenses WHERE status = 'active'");
        $stats['active_licenses'] = $stmt->fetchColumn();
        
        // التراخيص المنتهية
        $stmt = $this->db->query("SELECT COUNT(*) FROM licenses WHERE status = 'expired'");
        $stats['expired_licenses'] = $stmt->fetchColumn();
        
        // الأجهزة المسجلة
        $stmt = $this->db->query("SELECT COUNT(*) FROM devices");
        $stats['total_devices'] = $stmt->fetchColumn();
        
        // آخر 10 محاولات فاشلة
        $stmt = $this->db->query("
            SELECT * FROM license_logs 
            WHERE action = 'failed_activation' 
            ORDER BY created_at DESC 
            LIMIT 5
        ");
        $stats['recent_failures'] = $stmt->fetchAll();
        
        return $stats;
    }
}