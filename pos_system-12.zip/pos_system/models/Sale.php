<?php
require_once __DIR__ . '/../core/Model.php';

class Sale extends Model {
    protected $table = 'sales';
    protected $primaryKey = 'id';

    /**
     * إنشاء فاتورة جديدة
     */
    public function createSale($data) {
        $sql = "INSERT INTO {$this->table} 
                (invoice_number, customer_id, sale_type, total_amount, paid_amount, remaining_amount, discount, created_by) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        
        $stmt = $this->db->prepare($sql);
        $result = $stmt->execute([
            $data['invoice_number'],
            $data['customer_id'] ?? null,
            $data['sale_type'],
            $data['total_amount'],
            $data['paid_amount'],
            $data['remaining_amount'],
            $data['discount'] ?? 0,
            $data['created_by']
        ]);

        if ($result) {
            return $this->db->lastInsertId();
        }
        
        return false;
    }

    /**
     * الحصول على فاتورة مع تفاصيلها
     */
    public function getWithItems($id) {
        $sale = $this->find($id);
        if (!$sale) return null;
        
        $sql = "SELECT si.*, p.name as product_name, p.barcode,
                       sh.shelf_code, mi.batch_number, mi.expiry_date
                FROM sale_items si
                JOIN shelf_inventory sh ON si.shelf_inventory_id = sh.id
                JOIN main_inventory mi ON sh.main_inventory_id = mi.id
                JOIN products p ON mi.product_id = p.id
                WHERE si.sale_id = ?";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([$id]);
        $sale['items'] = $stmt->fetchAll();
        
        return $sale;
    }

    /**
     * البحث عن فاتورة برقمها
     */
    public function findByInvoiceNumber($invoiceNumber) {
        $sql = "SELECT s.*, c.name as customer_name, c.phone as customer_phone,
                       c.credit_limit, c.current_balance
                FROM {$this->table} s
                LEFT JOIN customers c ON s.customer_id = c.id
                WHERE s.invoice_number = ?";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([$invoiceNumber]);
        return $stmt->fetch();
    }

    /**
     * تحديث عدد مرات الطباعة
     */
    public function incrementPrintCount($id) {
        $sql = "UPDATE {$this->table} 
                SET printed_count = printed_count + 1, 
                    last_printed_at = NOW() 
                WHERE id = ?";
        $stmt = $this->db->prepare($sql);
        return $stmt->execute([$id]);
    }

    /**
     * ===== الدوال المضافة (الجديدة) =====
     */

    /**
     * الحصول على فواتير عميل معين
     */
    public function getByCustomer($customerId, $limit = null) {
        $sql = "SELECT * FROM {$this->table} 
                WHERE customer_id = ? 
                ORDER BY created_at DESC";
        
        if ($limit) {
            $sql .= " LIMIT " . intval($limit);
        }
        
        $stmt = $this->db->prepare($sql);
        $stmt->execute([$customerId]);
        return $stmt->fetchAll();
    }

    /**
     * الحصول على فواتير حسب الفترة
     */
    public function getByDateRange($from, $to, $type = null) {
        $sql = "SELECT * FROM {$this->table} 
                WHERE DATE(created_at) BETWEEN ? AND ?";
        
        $params = [$from, $to];
        
        if ($type) {
            $sql .= " AND sale_type = ?";
            $params[] = $type;
        }
        
        $sql .= " ORDER BY created_at DESC";
        
        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }

    /**
     * الحصول على إحصائيات المبيعات
     */
    public function getStatistics($from = null, $to = null) {
        $sql = "SELECT 
                    COUNT(*) as total_invoices,
                    SUM(CASE WHEN sale_type = 'cash' THEN total_amount ELSE 0 END) as cash_total,
                    SUM(CASE WHEN sale_type = 'credit' THEN total_amount ELSE 0 END) as credit_total,
                    SUM(paid_amount) as total_paid,
                    SUM(remaining_amount) as total_remaining,
                    COUNT(DISTINCT customer_id) as total_customers
                FROM {$this->table}";
        
        $params = [];
        
        if ($from && $to) {
            $sql .= " WHERE DATE(created_at) BETWEEN ? AND ?";
            $params = [$from, $to];
        }
        
        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetch();
    }

    /**
     * تحديث المبالغ المدفوعة
     */
    public function updatePaidAmount($id, $additionalPaid) {
        $sale = $this->find($id);
        if (!$sale) return false;
        
        $newPaid = $sale['paid_amount'] + $additionalPaid;
        $newRemaining = $sale['total_amount'] - $newPaid;
        
        $sql = "UPDATE {$this->table} 
                SET paid_amount = ?,
                    remaining_amount = ?
                WHERE id = ?";
        
        $stmt = $this->db->prepare($sql);
        return $stmt->execute([$newPaid, $newRemaining, $id]);
    }

    /**
     * إلغاء فاتورة (حذف)
     */
    public function cancelSale($id) {
        $sql = "DELETE FROM {$this->table} WHERE id = ?";
        $stmt = $this->db->prepare($sql);
        return $stmt->execute([$id]);
    }

    /**
     * الحصول على آخر فاتورة
     */
    public function getLastInvoice() {
        $sql = "SELECT * FROM {$this->table} ORDER BY id DESC LIMIT 1";
        $stmt = $this->db->query($sql);
        return $stmt->fetch();
    }

    /**
     * الحصول على فواتير اليوم
     */
    public function getTodaySales() {
        $today = date('Y-m-d');
        $sql = "SELECT * FROM {$this->table} 
                WHERE DATE(created_at) = ? 
                ORDER BY created_at DESC";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([$today]);
        return $stmt->fetchAll();
    }

    /**
     * البحث المتقدم في الفواتير
     */
    public function advancedSearch($criteria) {
        $sql = "SELECT s.*, c.name as customer_name 
                FROM {$this->table} s
                LEFT JOIN customers c ON s.customer_id = c.id
                WHERE 1=1";
        $params = [];
        
        if (!empty($criteria['invoice_number'])) {
            $sql .= " AND s.invoice_number LIKE ?";
            $params[] = '%' . $criteria['invoice_number'] . '%';
        }
        
        if (!empty($criteria['customer_id'])) {
            $sql .= " AND s.customer_id = ?";
            $params[] = $criteria['customer_id'];
        }
        
        if (!empty($criteria['sale_type'])) {
            $sql .= " AND s.sale_type = ?";
            $params[] = $criteria['sale_type'];
        }
        
        if (!empty($criteria['date_from'])) {
            $sql .= " AND DATE(s.created_at) >= ?";
            $params[] = $criteria['date_from'];
        }
        
        if (!empty($criteria['date_to'])) {
            $sql .= " AND DATE(s.created_at) <= ?";
            $params[] = $criteria['date_to'];
        }
        
        $sql .= " ORDER BY s.created_at DESC";
        
        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }
}