<?php
require_once __DIR__ . '/../core/Model.php';

class Audit extends Model {
    protected $table = 'inventory_audits';
    protected $primaryKey = 'id';

    /**
     * بدء جرد جديد
     */
    public function startAudit($userId) {
        try {
            $sql = "INSERT INTO {$this->table} (user_id, status) VALUES (?, 'pending')";
            $stmt = $this->db->prepare($sql);
            $stmt->execute([$userId]);
            return $this->db->lastInsertId();
        } catch (PDOException $e) {
            error_log("Audit Error in startAudit: " . $e->getMessage());
            return false;
        }
    }

    /**
     * إنهاء الجرد
     */
    public function completeAudit($auditId, $totalDiscrepancy) {
        try {
            $sql = "UPDATE {$this->table} SET status = 'completed', total_discrepancy = ? WHERE id = ?";
            $stmt = $this->db->prepare($sql);
            return $stmt->execute([$totalDiscrepancy, $auditId]);
        } catch (PDOException $e) {
            error_log("Audit Error in completeAudit: " . $e->getMessage());
            return false;
        }
    }

    /**
     * الحصول على جميع الجردات مع اسم المستخدم
     */
    public function getAllWithUser() {
        try {
            $sql = "SELECT a.*, u.full_name as user_name 
                    FROM {$this->table} a
                    LEFT JOIN users u ON a.user_id = u.id
                    ORDER BY a.audit_date DESC";
            $stmt = $this->db->query($sql);
            return $stmt->fetchAll();
        } catch (PDOException $e) {
            error_log("Audit Error in getAllWithUser: " . $e->getMessage());
            return [];
        }
    }

    /**
     * الحصول على إحصائيات الجرد
     */
    public function getStats() {
        try {
            $sql = "SELECT 
                    COUNT(*) as total_audits,
                    COUNT(CASE WHEN status = 'completed' THEN 1 END) as completed_audits,
                    COUNT(CASE WHEN status = 'pending' THEN 1 END) as pending_audits,
                    COALESCE(SUM(total_discrepancy), 0) as total_discrepancy
                    FROM {$this->table}";
            $stmt = $this->db->query($sql);
            $result = $stmt->fetch();
            
            if (!$result) {
                return [
                    'total_audits' => 0,
                    'completed_audits' => 0,
                    'pending_audits' => 0,
                    'total_discrepancy' => 0
                ];
            }
            
            return $result;
        } catch (PDOException $e) {
            error_log("Audit Error in getStats: " . $e->getMessage());
            return [
                'total_audits' => 0,
                'completed_audits' => 0,
                'pending_audits' => 0,
                'total_discrepancy' => 0
            ];
        }
    }

    /**
     * الحصول على جرد معين
     */
    public function getAudit($id) {
        try {
            $sql = "SELECT a.*, u.full_name as user_name 
                    FROM {$this->table} a
                    LEFT JOIN users u ON a.user_id = u.id
                    WHERE a.id = ?";
            $stmt = $this->db->prepare($sql);
            $stmt->execute([$id]);
            return $stmt->fetch();
        } catch (PDOException $e) {
            error_log("Audit Error in getAudit: " . $e->getMessage());
            return null;
        }
    }
}