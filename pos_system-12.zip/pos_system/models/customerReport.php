<?php
require_once __DIR__ . '/../core/Model.php';

class CustomerReport extends Model {
    protected $table = 'customer_reports';
    
    public function __construct() {
        parent::__construct($this->table);
    }
    
    /**
     * حفظ تقرير جديد
     */
    public function save($data) {
        $sql = "INSERT INTO customer_reports 
                (customer_id, report_type, report_data, date_from, date_to, generated_by)
                VALUES (?, ?, ?, ?, ?, ?)";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([
            $data['customer_id'],
            $data['report_type'],
            $data['report_data'],
            $data['date_from'],
            $data['date_to'],
            $data['generated_by']
        ]);
        return $this->db->lastInsertId();
    }
    
    /**
     * تحديث مسار الملف
     */
    public function update($id, $data) {
        $sql = "UPDATE customer_reports SET file_path = ? WHERE id = ?";
        $stmt = $this->db->prepare($sql);
        return $stmt->execute([$data['file_path'], $id]);
    }
    
    /**
     * جلب تقارير عميل
     */
    public function getCustomerReports($customerId, $limit = 20) {
        $sql = "SELECT cr.*, u.username as generated_by_name
                FROM customer_reports cr
                JOIN users u ON cr.generated_by = u.id
                WHERE cr.customer_id = ?
                ORDER BY cr.generated_at DESC
                LIMIT ?";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([$customerId, $limit]);
        return $stmt->fetchAll();
    }
    
    /**
     * مسار حفظ الملفات
     */
    public function getSavePath() {
        $setting = new Setting();
        $path = $setting->get('print_save_path');
        if (!$path) {
            $path = __DIR__ . '/../storage/exports/';
        }
        if (!is_dir($path)) {
            mkdir($path, 0777, true);
        }
        return rtrim($path, '/') . '/';
    }
}