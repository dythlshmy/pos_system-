<?php
require_once __DIR__ . '/../core/Model.php';

class Customer extends Model {
    protected $table = 'customers';
    protected $primaryKey = 'id';

    /**
     * الحصول على العملاء النشطين
     */
    public function getActive() {
        $sql = "SELECT * FROM {$this->table} WHERE is_active = 1 ORDER BY name ASC";
        $stmt = $this->db->query($sql);
        return $stmt->fetchAll();
    }

    /**
     * البحث عن عميل
     */
    public function search($keyword) {
        $sql = "SELECT * FROM {$this->table} 
                WHERE (name LIKE ? OR phone LIKE ? OR email LIKE ?) 
                AND is_active = 1 
                ORDER BY name ASC 
                LIMIT 20";
        $keyword = "%$keyword%";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([$keyword, $keyword, $keyword]);
        return $stmt->fetchAll();
    }

    /**
     * تحديث رصيد العميل
     */
    public function updateBalance($id, $amount) {
        $sql = "UPDATE {$this->table} SET current_balance = current_balance + ? WHERE id = ?";
        $stmt = $this->db->prepare($sql);
        return $stmt->execute([$amount, $id]);
    }

    /**
     * التحقق من الحد الائتماني
     */
    public function checkCreditLimit($id, $additionalAmount) {
        $customer = $this->find($id);
        if (!$customer) return false;
        
        $newBalance = $customer['current_balance'] + $additionalAmount;
        return $newBalance <= $customer['credit_limit'];
    }
}