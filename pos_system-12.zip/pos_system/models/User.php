<?php
require_once __DIR__ . '/../core/Model.php';

class User extends Model {
    
    protected $table = 'users';
    protected $primaryKey = 'id';

    /**
     * التحقق من صحة بيانات تسجيل الدخول
     */
    public function authenticate($username, $password) {
        $user = $this->findByUsername($username);
        
        if ($user && $user['is_active'] == 1 && password_verify($password, $user['password'])) {
            return $user;
        }
        
        return false;
    }

    /**
     * البحث عن مستخدم باسم المستخدم
     */
    public function findByUsername($username) {
        $sql = "SELECT * FROM {$this->table} WHERE username = ?";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([$username]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    /**
     * الحصول على جميع المستخدمين
     */
    public function getAllUsers() {
        $sql = "SELECT id, username, full_name, email, phone, role, is_active, created_at 
                FROM {$this->table} 
                ORDER BY id ASC";
        $stmt = $this->db->query($sql);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * إنشاء مستخدم جديد
     */
    public function createUser($data) {
        $sql = "INSERT INTO {$this->table} 
                (username, password, full_name, email, phone, role, is_active, created_at) 
                VALUES (?, ?, ?, ?, ?, ?, 1, NOW())";
        
        $stmt = $this->db->prepare($sql);
        return $stmt->execute([
            $data['username'],
            $data['password'],
            $data['full_name'],
            $data['email'] ?? null,
            $data['phone'] ?? null,
            $data['role']
        ]);
    }

    /**
     * تحديث بيانات مستخدم
     */
    public function updateUser($id, $data) {
        $sql = "UPDATE {$this->table} 
                SET username = ?, full_name = ?, email = ?, phone = ?, role = ? 
                WHERE id = ?";
        
        $stmt = $this->db->prepare($sql);
        return $stmt->execute([
            $data['username'],
            $data['full_name'],
            $data['email'] ?? null,
            $data['phone'] ?? null,
            $data['role'],
            $id
        ]);
    }

    /**
     * تغيير كلمة المرور
     */
    public function changePassword($userId, $newPassword) {
        $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);
        
        $sql = "UPDATE {$this->table} SET password = ? WHERE id = ?";
        $stmt = $this->db->prepare($sql);
        return $stmt->execute([$hashedPassword, $userId]);
    }

    /**
     * تحديث حالة المستخدم (تفعيل/تعطيل)
     */
    public function updateStatus($userId, $status) {
        $sql = "UPDATE {$this->table} SET is_active = ? WHERE id = ?";
        $stmt = $this->db->prepare($sql);
        return $stmt->execute([$status, $userId]);
    }

    /**
     * تحديث آخر تسجيل دخول
     */
    public function updateLastLogin($userId) {
        $sql = "UPDATE {$this->table} SET last_login = NOW() WHERE id = ?";
        $stmt = $this->db->prepare($sql);
        return $stmt->execute([$userId]);
    }

    /**
     * الحصول على إحصائيات المستخدمين
     */
    public function getStatistics() {
        $sql = "SELECT 
                    COUNT(*) as total_users,
                    SUM(CASE WHEN role = 'admin' THEN 1 ELSE 0 END) as total_admins,
                    SUM(CASE WHEN role = 'staff' THEN 1 ELSE 0 END) as total_staff,
                    SUM(CASE WHEN is_active = 1 THEN 1 ELSE 0 END) as active_users,
                    SUM(CASE WHEN is_active = 0 THEN 1 ELSE 0 END) as inactive_users
                FROM {$this->table}";
        
        $stmt = $this->db->query($sql);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    /**
     * البحث عن المستخدمين
     */
    public function search($keyword) {
        $keyword = '%' . $keyword . '%';
        
        $sql = "SELECT id, username, full_name, email, phone, role, is_active, created_at 
                FROM {$this->table} 
                WHERE username LIKE ? 
                   OR full_name LIKE ? 
                   OR email LIKE ? 
                   OR phone LIKE ?
                ORDER BY id ASC";
        
        $stmt = $this->db->prepare($sql);
        $stmt->execute([$keyword, $keyword, $keyword, $keyword]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * الحصول على كلمة المرور الاحتياطية للمدير
     */
    public function getBackupPassword() {
        $sql = "SELECT setting_value FROM settings WHERE setting_key = 'backup_password'";
        $stmt = $this->db->prepare($sql);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    /**
     * تحديث كلمة المرور الاحتياطية للمدير
     */
   /**
 * جلب كلمات المرور لجميع المستخدمين لغرض فحص التكرار
 */
public function getAllPasswordsForValidation() {
    $sql = "SELECT password, backup_password FROM {$this->table}";
    $stmt = $this->db->query($sql);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

/**
 * الدالة المحدثة للحفظ في جدول users
 */
public function updateBackupPassword($userId, $hashedPassword) {
    $sql = "UPDATE {$this->table} SET backup_password = ? WHERE id = ?";
    $stmt = $this->db->prepare($sql);
    return $stmt->execute([$hashedPassword, $userId]);
}


    /**
     * الحصول على المستخدمين النشطين فقط
     */
    public function getActiveUsers() {
        $sql = "SELECT id, username, full_name, role 
                FROM {$this->table} 
                WHERE is_active = 1 
                ORDER BY full_name ASC";
        $stmt = $this->db->query($sql);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}