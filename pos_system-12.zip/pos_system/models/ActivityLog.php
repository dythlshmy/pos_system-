<?php
require_once __DIR__ . '/../core/Model.php';

class ActivityLog extends Model {
    protected $table = 'activity_logs';
    protected $primaryKey = 'id';

    /**
     * تسجيل حركة جديدة
     */
    public function log($action, $details, $userId = null) {
        if (!$userId && isset($_SESSION['user_id'])) {
            $userId = $_SESSION['user_id'];
        }

        $sql = "INSERT INTO activity_logs (user_id, action, details, ip_address, created_at) 
                VALUES (?, ?, ?, ?, NOW())";
        $stmt = $this->db->prepare($sql);
        return $stmt->execute([
            $userId,
            $action,
            $details,
            $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1'
        ]);
    }

    /**
     * الحصول على جميع الحركات مع اسم المستخدم
     * ✅ نسخة مبسطة بدون LIMIT متغير
     */
    public function getAllWithUser($limit = 100) {
        // استخدام قيمة ثابتة في الاستعلام نفسه
        $sql = "SELECT l.*, u.full_name as user_name, u.username 
                FROM activity_logs l
                LEFT JOIN users u ON l.user_id = u.id
                ORDER BY l.created_at DESC
                LIMIT " . (int)$limit;
        
        $stmt = $this->db->prepare($sql);
        $stmt->execute();
        return $stmt->fetchAll();
    }

    /**
     * البحث في سجل الحركات
     */
        /**
 * البحث في سجل الحركات - نسخة محسنة للبحث النصي
 */
public function search($filters = []) {
    $sql = "SELECT l.*, u.full_name as user_name, u.username 
            FROM activity_logs l
            LEFT JOIN users u ON l.user_id = u.id
            WHERE 1=1";
    $params = [];

    // ===== البحث النصي (الأكثر أهمية) =====
    if (!empty($filters['search'])) {
        $searchTerm = "%" . $filters['search'] . "%";
        $sql .= " AND (";
        $sql .= " l.action LIKE ? OR ";        // البحث في نوع الحركة
        $sql .= " l.details LIKE ? OR ";       // البحث في التفاصيل
        $sql .= " u.full_name LIKE ? ";        // البحث في اسم المستخدم
        $sql .= ")";
        
        // إضافة معامل البحث ثلاث مرات (لكل حقل)
        $params[] = $searchTerm;
        $params[] = $searchTerm;
        $params[] = $searchTerm;
    }

    // ===== فلتر المستخدم =====
    if (!empty($filters['user_id'])) {
        $sql .= " AND l.user_id = ?";
        $params[] = $filters['user_id'];
    }

    // ===== فلتر نوع الحركة =====
    if (!empty($filters['action'])) {
        $sql .= " AND l.action LIKE ?";
        $params[] = "%" . $filters['action'] . "%";
    }

    // ===== فلتر التاريخ =====
    if (!empty($filters['date_from'])) {
        $sql .= " AND DATE(l.created_at) >= ?";
        $params[] = $filters['date_from'];
    }

    if (!empty($filters['date_to'])) {
        $sql .= " AND DATE(l.created_at) <= ?";
        $params[] = $filters['date_to'];
    }

    $sql .= " ORDER BY l.created_at DESC LIMIT 500";

    // للتصحيح - يمكنك إزالة هذا السطر بعد التأكد من العمل
    error_log("SQL: " . $sql);
    error_log("Params: " . print_r($params, true));

    $stmt = $this->db->prepare($sql);
    $stmt->execute($params);
    return $stmt->fetchAll();
}

    /**
     * الحصول على أنواع الحركات المتاحة
     */
    public function getActionTypes() {
        $sql = "SELECT DISTINCT action FROM activity_logs ORDER BY action";
        $stmt = $this->db->query($sql);
        return $stmt->fetchAll();
    }

    /**
     * الحصول على إحصائيات الحركات
     */
    public function getStats($days = 7) {
        $sql = "SELECT 
                DATE(created_at) as date,
                COUNT(*) as total,
                COUNT(CASE WHEN action LIKE '%add%' THEN 1 END) as adds,
                COUNT(CASE WHEN action LIKE '%update%' THEN 1 END) as updates,
                COUNT(CASE WHEN action LIKE '%delete%' THEN 1 END) as deletes,
                COUNT(CASE WHEN action LIKE '%sell%' THEN 1 END) as sales
                FROM activity_logs
                WHERE created_at >= DATE_SUB(NOW(), INTERVAL ? DAY)
                GROUP BY DATE(created_at)
                ORDER BY date DESC";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([$days]);
        return $stmt->fetchAll();
    }
}