<?php
require_once __DIR__ . '/../core/Model.php';

class AuditItem extends Model {
    protected $table = 'audit_items';
    protected $primaryKey = 'id';

    /**
     * إضافة عنصر جرد
     */
    public function addItem($auditId, $productId, $expectedQty, $actualQty, $reason = '') {
        try {
            $difference = $actualQty - $expectedQty;
            
            // التحقق من وجود العنصر مسبقاً
            $checkSql = "SELECT id FROM {$this->table} WHERE audit_id = ? AND product_id = ?";
            $checkStmt = $this->db->prepare($checkSql);
            $checkStmt->execute([$auditId, $productId]);
            $existing = $checkStmt->fetch();

            if ($existing) {
                $sql = "UPDATE {$this->table} 
                        SET expected_qty = ?, actual_qty = ?, difference = ?, reason = ? 
                        WHERE audit_id = ? AND product_id = ?";
                $stmt = $this->db->prepare($sql);
                return $stmt->execute([$expectedQty, $actualQty, $difference, $reason, $auditId, $productId]);
            } else {
                $sql = "INSERT INTO {$this->table} 
                        (audit_id, product_id, expected_qty, actual_qty, difference, reason) 
                        VALUES (?, ?, ?, ?, ?, ?)";
                $stmt = $this->db->prepare($sql);
                return $stmt->execute([$auditId, $productId, $expectedQty, $actualQty, $difference, $reason]);
            }
        } catch (PDOException $e) {
            error_log("AuditItem Error in addItem: " . $e->getMessage());
            return false;
        }
    }

    /**
     * الحصول على عناصر جرد معين
     */
    public function getByAuditId($auditId) {
        try {
            $sql = "SELECT ai.*, p.name as product_name, p.barcode 
                    FROM {$this->table} ai
                    JOIN products p ON ai.product_id = p.id
                    WHERE ai.audit_id = ?
                    ORDER BY ai.id ASC";
            $stmt = $this->db->prepare($sql);
            $stmt->execute([$auditId]);
            return $stmt->fetchAll();
        } catch (PDOException $e) {
            error_log("AuditItem Error in getByAuditId: " . $e->getMessage());
            return [];
        }
    }

    /**
     * الحصول على إحصائيات عناصر الجرد
     */
    public function getStatsByAuditId($auditId) {
        try {
            $sql = "SELECT 
                    COUNT(*) as total_items,
                    SUM(CASE WHEN difference > 0 THEN 1 ELSE 0 END) as surplus_count,
                    SUM(CASE WHEN difference < 0 THEN 1 ELSE 0 END) as deficit_count,
                    SUM(CASE WHEN difference = 0 THEN 1 ELSE 0 END) as match_count,
                    COALESCE(SUM(ABS(difference)), 0) as total_discrepancy,
                    COALESCE(SUM(CASE WHEN difference > 0 THEN difference ELSE 0 END), 0) as total_surplus,
                    COALESCE(SUM(CASE WHEN difference < 0 THEN ABS(difference) ELSE 0 END), 0) as total_deficit
                    FROM {$this->table}
                    WHERE audit_id = ?";
            $stmt = $this->db->prepare($sql);
            $stmt->execute([$auditId]);
            return $stmt->fetch();
        } catch (PDOException $e) {
            error_log("AuditItem Error in getStatsByAuditId: " . $e->getMessage());
            return null;
        }
    }
}