  <?php
require_once __DIR__ . '/../core/Model.php';

class Report extends Model {
    
    /**
     * الحصول على إحصائيات المبيعات النقدية
     */
    public function getCashStats($from = null, $to = null) {
        $db = Database::getInstance();
        
        $sql = "SELECT 
                    COALESCE(SUM(s.total_amount), 0) as total_amount,
                    COUNT(DISTINCT s.id) as total_invoices,
                    COALESCE(SUM(r.total_refund_amount), 0) as total_returns,
                    COUNT(DISTINCT r.id) as return_count,
                    COUNT(DISTINCT s.created_by) as cashier_count
                FROM sales s
                LEFT JOIN returns r ON s.id = r.sale_id
                WHERE s.sale_type = 'cash'";

        if ($from && $to) {
            $sql .= " AND DATE(s.created_at) BETWEEN :from AND :to";
            $stmt = $db->prepare($sql);
            $stmt->execute(['from' => $from, 'to' => $to]);
        } else {
            $stmt = $db->prepare($sql);
            $stmt->execute();
        }

        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    /**
     * الحصول على إحصائيات المبيعات الآجلة
     */
    public function getCreditStats($from = null, $to = null) {
        $db = Database::getInstance();
        
        $sql = "SELECT 
                    COALESCE(SUM(s.total_amount), 0) as total_amount,
                    COUNT(DISTINCT s.id) as total_invoices,
                    COALESCE(SUM(s.paid_amount), 0) as total_paid,
                    COALESCE(SUM(s.remaining_amount), 0) as total_remaining,
                    COUNT(DISTINCT s.customer_id) as customer_count,
                    COALESCE(SUM(r.total_refund_amount), 0) as total_returns,
                    COUNT(DISTINCT r.id) as return_count
                FROM sales s
                LEFT JOIN returns r ON s.id = r.sale_id
                WHERE s.sale_type = 'credit'";

        if ($from && $to) {
            $sql .= " AND DATE(s.created_at) BETWEEN :from AND :to";
            $stmt = $db->prepare($sql);
            $stmt->execute(['from' => $from, 'to' => $to]);
        } else {
            $stmt = $db->prepare($sql);
            $stmt->execute();
        }

        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    /**
     * الحصول على إحصائيات المخزون
     */
    public function getInventoryStats() {
        $db = Database::getInstance();
        
        $sql = "SELECT 
                    COUNT(DISTINCT p.id) as total_products,
                    COALESCE(SUM(mi.cartons_remaining * p.units_per_carton), 0) as total_units,
                    COALESCE(SUM(mi.cartons_remaining * mi.cost_price_carton), 0) as total_value,
                    COUNT(CASE WHEN sh.status = 'low_stock' THEN 1 END) as low_stock_count,
                    COUNT(CASE WHEN sh.status = 'out_of_stock' THEN 1 END) as out_of_stock_count,
                    COUNT(CASE WHEN mi.expiry_date < CURDATE() THEN 1 END) as expired_count
                FROM products p
                LEFT JOIN main_inventory mi ON p.id = mi.product_id
                LEFT JOIN shelf_inventory sh ON mi.id = sh.main_inventory_id
                WHERE p.is_active = 1";

        $stmt = $db->prepare($sql);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    /**
     * الحصول على إحصائيات المنتجات
     */
    public function getProductsStats() {
        $db = Database::getInstance();
        
        $sql = "SELECT 
                    COUNT(DISTINCT p.id) as active_products,
                    COUNT(DISTINCT c.id) as category_count,
                    COALESCE(AVG(sh.selling_price_unit), 0) as avg_price,
                    COALESCE(MAX(sh.selling_price_unit), 0) as max_price,
                    COALESCE(MIN(sh.selling_price_unit), 0) as min_price
                FROM products p
                LEFT JOIN categories c ON p.category_id = c.id
                LEFT JOIN main_inventory mi ON p.id = mi.product_id
                LEFT JOIN shelf_inventory sh ON mi.id = sh.main_inventory_id
                WHERE p.is_active = 1";

        $stmt = $db->prepare($sql);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    /**
     * الحصول على تقارير المبيعات النقدية كاملة
     */
    public function getCashSalesReports($from = null, $to = null) {
        $db = Database::getInstance();
        
        $sql = "SELECT 
                    s.invoice_number,
                    DATE_FORMAT(s.created_at, '%Y-%m-%d %H:%i') as created_at,
                    p.name as product_name,
                    p.barcode,
                    si.quantity,
                    si.price_unit,
                    si.subtotal,
                    u.full_name as cashier_name,
                    COALESCE(r.return_count, 0) as return_count,
                    COALESCE(r.return_amount, 0) as return_amount
                FROM sales s
                INNER JOIN sale_items si ON s.id = si.sale_id
                INNER JOIN shelf_inventory sh ON si.shelf_inventory_id = sh.id
                INNER JOIN main_inventory mi ON sh.main_inventory_id = mi.id
                INNER JOIN products p ON mi.product_id = p.id
                INNER JOIN users u ON s.created_by = u.id
                LEFT JOIN (
                    SELECT 
                        r.sale_id,
                        COUNT(DISTINCT r.id) as return_count,
                        SUM(r.total_refund_amount) as return_amount
                    FROM returns r
                    GROUP BY r.sale_id
                ) r ON s.id = r.sale_id
                WHERE s.sale_type = 'cash'";

        if ($from && $to) {
            $sql .= " AND DATE(s.created_at) BETWEEN :from AND :to";
        }

        $sql .= " ORDER BY s.created_at DESC";

        $stmt = $db->prepare($sql);
        
        if ($from && $to) {
            $stmt->execute(['from' => $from, 'to' => $to]);
        } else {
            $stmt->execute();
        }

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * الحصول على تقارير المبيعات الآجلة كاملة
     */
    public function getCreditSalesReports($from = null, $to = null) {
        $db = Database::getInstance();
        
        $sql = "SELECT 
                    s.invoice_number,
                    DATE_FORMAT(s.created_at, '%Y-%m-%d %H:%i') as created_at,
                    c.name as customer_name,
                    c.phone as customer_phone,
                    p.name as product_name,
                    p.barcode,
                    si.quantity,
                    si.price_unit,
                    si.subtotal,
                    s.total_amount,
                    s.paid_amount,
                    s.remaining_amount,
                    s.payment_status,
                    COALESCE(r.return_count, 0) as return_count,
                    COALESCE(r.return_amount, 0) as return_amount
                FROM sales s
                INNER JOIN customers c ON s.customer_id = c.id
                INNER JOIN sale_items si ON s.id = si.sale_id
                INNER JOIN shelf_inventory sh ON si.shelf_inventory_id = sh.id
                INNER JOIN main_inventory mi ON sh.main_inventory_id = mi.id
                INNER JOIN products p ON mi.product_id = p.id
                LEFT JOIN (
                    SELECT 
                        r.sale_id,
                        COUNT(DISTINCT r.id) as return_count,
                        SUM(r.total_refund_amount) as return_amount
                    FROM returns r
                    GROUP BY r.sale_id
                ) r ON s.id = r.sale_id
                WHERE s.sale_type = 'credit'";

        if ($from && $to) {
            $sql .= " AND DATE(s.created_at) BETWEEN :from AND :to";
        }

        $sql .= " ORDER BY s.created_at DESC";

        $stmt = $db->prepare($sql);
        
        if ($from && $to) {
            $stmt->execute(['from' => $from, 'to' => $to]);
        } else {
            $stmt->execute();
        }

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * الحصول على تقارير المخزون
     */
    public function getInventoryReports() {
        $db = Database::getInstance();
        
        $sql = "SELECT 
                    p.id,
                    p.name as product_name,
                    p.barcode,
                    c.name as category_name,
                    COALESCE((
                        SELECT SUM(mi2.cartons_quantity * p2.units_per_carton)
                        FROM main_inventory mi2
                        INNER JOIN products p2 ON mi2.product_id = p2.id
                        WHERE mi2.product_id = p.id
                    ), 0) as total_quantity,
                    COALESCE((
                        SELECT SUM(sh.units_remaining)
                        FROM shelf_inventory sh
                        INNER JOIN main_inventory mi3 ON sh.main_inventory_id = mi3.id
                        WHERE mi3.product_id = p.id
                    ), 0) as current_quantity,
                    COALESCE((
                        SELECT SUM(sh.selling_price_unit * sh.units_remaining)
                        FROM shelf_inventory sh
                        INNER JOIN main_inventory mi4 ON sh.main_inventory_id = mi4.id
                        WHERE mi4.product_id = p.id
                    ), 0) as total_value,
                    COUNT(CASE WHEN mi.expiry_date < CURDATE() THEN 1 END) as expired_count,
                    MIN(mi.expiry_date) as nearest_expiry,
                    CASE 
                        WHEN COALESCE((
                            SELECT SUM(sh.units_remaining)
                            FROM shelf_inventory sh
                            INNER JOIN main_inventory mi3 ON sh.main_inventory_id = mi3.id
                            WHERE mi3.product_id = p.id
                        ), 0) = 0 THEN 'out_of_stock'
                        WHEN COALESCE((
                            SELECT SUM(sh.units_remaining)
                            FROM shelf_inventory sh
                            INNER JOIN main_inventory mi3 ON sh.main_inventory_id = mi3.id
                            WHERE mi3.product_id = p.id
                        ), 0) < 10 THEN 'low_stock'
                        ELSE 'available'
                    END as stock_status
                FROM products p
                LEFT JOIN categories c ON p.category_id = c.id
                LEFT JOIN main_inventory mi ON p.id = mi.product_id
                WHERE p.is_active = 1
                GROUP BY p.id
                ORDER BY p.name ASC";

        $stmt = $db->prepare($sql);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * الحصول على تقارير المنتجات
     */
    public function getProductsReports() {
        $db = Database::getInstance();
        
        $sql = "SELECT 
                    p.id as product_id,
                    p.name as product_name,
                    p.barcode,
                    c.name as category_name,
                    COALESCE((
                        SELECT SUM(sh.units_remaining)
                        FROM shelf_inventory sh
                        INNER JOIN main_inventory mi ON sh.main_inventory_id = mi.id
                        WHERE mi.product_id = p.id
                    ), 0) as current_quantity,
                    COALESCE((
                        SELECT sh.selling_price_unit
                        FROM shelf_inventory sh
                        INNER JOIN main_inventory mi ON sh.main_inventory_id = mi.id
                        WHERE mi.product_id = p.id
                        LIMIT 1
                    ), 0) as selling_price,
                    COALESCE((
                        SELECT mi.cost_price_unit
                        FROM main_inventory mi
                        WHERE mi.product_id = p.id
                        LIMIT 1
                    ), 0) as cost_price,
                    COALESCE((
                        SELECT COUNT(DISTINCT s.id)
                        FROM sales s
                        INNER JOIN sale_items si ON s.id = si.sale_id
                        INNER JOIN shelf_inventory sh ON si.shelf_inventory_id = sh.id
                        INNER JOIN main_inventory mi ON sh.main_inventory_id = mi.id
                        WHERE mi.product_id = p.id AND s.sale_type = 'cash'
                    ), 0) as cash_sales_count,
                    COALESCE((
                        SELECT COUNT(DISTINCT s.id)
                        FROM sales s
                        INNER JOIN sale_items si ON s.id = si.sale_id
                        INNER JOIN shelf_inventory sh ON si.shelf_inventory_id = sh.id
                        INNER JOIN main_inventory mi ON sh.main_inventory_id = mi.id
                        WHERE mi.product_id = p.id AND s.sale_type = 'credit'
                    ), 0) as credit_sales_count
                FROM products p
                LEFT JOIN categories c ON p.category_id = c.id
                WHERE p.is_active = 1
                ORDER BY p.name ASC";

        $stmt = $db->prepare($sql);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * الحصول على سجل منتج محدد
     */
    public function getProductHistory($productId, $from = null, $to = null) {
        $db = Database::getInstance();
        
        // معلومات المنتج
        $productSql = "SELECT 
                            p.id,
                            p.name,
                            p.barcode,
                            p.units_per_carton,
                            c.name as category_name
                        FROM products p
                        LEFT JOIN categories c ON p.category_id = c.id
                        WHERE p.id = :id";
        $productStmt = $db->prepare($productSql);
        $productStmt->execute(['id' => $productId]);
        $product = $productStmt->fetch(PDO::FETCH_ASSOC);

        if (!$product) {
            return null;
        }

        // المدخلات (الدفعات)
        $entriesSql = "SELECT 
                            mi.id,
                            mi.batch_number,
                            mi.cartons_quantity,
                            mi.cartons_remaining,
                            mi.cost_price_carton,
                            mi.cost_price_unit,
                            mi.selling_price_unit,
                            mi.expiry_date,
                            DATE_FORMAT(mi.entry_date, '%Y-%m-%d') as entry_date,
                            mi.notes
                        FROM main_inventory mi
                        WHERE mi.product_id = :id
                        ORDER BY mi.entry_date DESC";
        $entriesStmt = $db->prepare($entriesSql);
        $entriesStmt->execute(['id' => $productId]);
        $entries = $entriesStmt->fetchAll(PDO::FETCH_ASSOC);

        // تحليل المبيعات
        $salesSql = "SELECT 
                        si.price_unit,
                        COUNT(DISTINCT si.id) as sale_count,
                        SUM(si.quantity) as total_quantity,
                        SUM(si.subtotal) as total_amount,
                        SUM(CASE WHEN s.sale_type = 'credit' THEN si.quantity ELSE 0 END) as credit_quantity,
                        SUM(CASE WHEN s.sale_type = 'cash' THEN si.quantity ELSE 0 END) as cash_quantity
                    FROM sale_items si
                    INNER JOIN shelf_inventory sh ON si.shelf_inventory_id = sh.id
                    INNER JOIN main_inventory mi ON sh.main_inventory_id = mi.id
                    INNER JOIN sales s ON si.sale_id = s.id
                    WHERE mi.product_id = :id";

        if ($from && $to) {
            $salesSql .= " AND DATE(s.created_at) BETWEEN :from AND :to";
        }

        $salesSql .= " GROUP BY si.price_unit ORDER BY si.price_unit DESC";

        $salesStmt = $db->prepare($salesSql);
        
        $params = ['id' => $productId];
        if ($from && $to) {
            $params['from'] = $from;
            $params['to'] = $to;
        }
        
        $salesStmt->execute($params);
        $salesAnalysis = $salesStmt->fetchAll(PDO::FETCH_ASSOC);

        // المتبقي حسب FIFO
        $remainingSql = "SELECT 
                            mi.id,
                            mi.batch_number,
                            mi.cartons_remaining,
                            mi.cost_price_carton,
                            mi.cost_price_unit,
                            mi.selling_price_unit,
                            mi.expiry_date,
                            DATE_FORMAT(mi.entry_date, '%Y-%m-%d') as entry_date,
                            COALESCE(SUM(sh.units_remaining), 0) as units_remaining
                        FROM main_inventory mi
                        LEFT JOIN shelf_inventory sh ON mi.id = sh.main_inventory_id
                        WHERE mi.product_id = :id AND mi.cartons_remaining > 0
                        GROUP BY mi.id
                        ORDER BY mi.entry_date ASC";
        $remainingStmt = $db->prepare($remainingSql);
        $remainingStmt->execute(['id' => $productId]);
        $remaining = $remainingStmt->fetchAll(PDO::FETCH_ASSOC);

        return [
            'product' => $product,
            'entries' => $entries,
            'sales_analysis' => $salesAnalysis,
            'remaining' => $remaining
        ];
    }

    // ==================== دوال API لواجهة تحليلات المنتج ====================



    /**
 * تحليل المبيعات لمنتج محدد - حساب الربح من main_inventory
 */
public function getProductSalesAnalysis($productId, $from = null, $to = null) {
    $db = Database::getInstance();
    
    // استعلام محسن يجلب سعر التكلفة من main_inventory
    $sql = "SELECT 
                s.id as sale_id,
                s.invoice_number,
                DATE_FORMAT(s.created_at, '%Y-%m-%d %H:%i') as sale_date,
                s.sale_type,
                si.quantity,
                si.price_unit as selling_price,
                si.subtotal,
                -- جلب سعر التكلفة من main_inventory (cost_price_unit)
                mi.cost_price_unit as cost_price,
                -- حساب الربح: (سعر البيع - سعر التكلفة) × الكمية
                (si.price_unit - mi.cost_price_unit) * si.quantity as profit,
                -- هامش الربح كنسبة مئوية
                ROUND(((si.price_unit - mi.cost_price_unit) / si.price_unit) * 100, 2) as profit_margin,
                sh.shelf_code,
                u.full_name as cashier_name,
                c.name as customer_name
            FROM sale_items si
            INNER JOIN shelf_inventory sh ON si.shelf_inventory_id = sh.id
            INNER JOIN main_inventory mi ON sh.main_inventory_id = mi.id
            INNER JOIN sales s ON si.sale_id = s.id
            LEFT JOIN users u ON s.created_by = u.id
            LEFT JOIN customers c ON s.customer_id = c.id
            WHERE mi.product_id = :product_id";
    
    $params = ['product_id' => $productId];
    
    if ($from && $to) {
        $sql .= " AND DATE(s.created_at) BETWEEN :from AND :to";
        $params['from'] = $from;
        $params['to'] = $to;
    }
    
    $sql .= " ORDER BY s.created_at DESC";
    
    $stmt = $db->prepare($sql);
    $stmt->execute($params);
    $details = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // تجميع البيانات حسب سعر البيع
    $byPrice = [];
    $totalRevenue = 0;
    $totalCost = 0;
    $totalProfit = 0;
    $cashTotal = 0;
    $creditTotal = 0;
    
    foreach ($details as $sale) {
        $price = (float)$sale['selling_price'];
        $quantity = (int)$sale['quantity'];
        $revenue = (float)$sale['subtotal'];
        $cost = (float)$sale['cost_price'] * $quantity;
        $profit = (float)$sale['profit'];
        
        if (!isset($byPrice[$price])) {
            $byPrice[$price] = [
                'price_unit' => $price,
                'total_quantity' => 0,
                'total_amount' => 0,
                'total_cost' => 0,
                'total_profit' => 0,
                'cash_quantity' => 0,
                'credit_quantity' => 0
            ];
        }
        
        $byPrice[$price]['total_quantity'] += $quantity;
        $byPrice[$price]['total_amount'] += $revenue;
        $byPrice[$price]['total_cost'] += $cost;
        $byPrice[$price]['total_profit'] += $profit;
        
        if ($sale['sale_type'] === 'cash') {
            $byPrice[$price]['cash_quantity'] += $quantity;
            $cashTotal += $revenue;
        } else {
            $byPrice[$price]['credit_quantity'] += $quantity;
            $creditTotal += $revenue;
        }
        
        $totalRevenue += $revenue;
        $totalCost += $cost;
        $totalProfit += $profit;
    }
    
    // ترتيب حسب السعر
    krsort($byPrice);
    $byPrice = array_values($byPrice);
    
    // الإحصائيات العامة
    $stats = [
        'total_revenue' => round($totalRevenue, 2),
        'total_cost' => round($totalCost, 2),
        'total_profit' => round($totalProfit, 2),
        'total_cash_sales' => round($cashTotal, 2),
        'total_credit_sales' => round($creditTotal, 2),
        'profit_margin' => $totalRevenue > 0 ? round(($totalProfit / $totalRevenue) * 100, 2) : 0,
        'total_units_sold' => array_sum(array_column($details, 'quantity')),
        'total_invoices' => count(array_unique(array_column($details, 'sale_id'))),
        'cash_invoices' => count(array_unique(array_filter($details, function($s) { return $s['sale_type'] === 'cash'; }))),
        'credit_invoices' => count(array_unique(array_filter($details, function($s) { return $s['sale_type'] === 'credit'; })))
    ];
    
    return [
        'by_price' => $byPrice,
        'details' => $details,
        'stats' => $stats
    ];
}
 

/**
 * جلب تفاصيل الدفعات للمنتج مع إحصائيات المبيعات والربح
 */
public function getProductBatches($productId) {
    $db = Database::getInstance();
    
    $sql = "SELECT 
                mi.id,
                mi.batch_number,
                mi.cartons_quantity,
                mi.cartons_remaining,
                mi.cost_price_carton,
                mi.cost_price_unit,
                mi.selling_price_unit,
                mi.expiry_date,
                DATE_FORMAT(mi.entry_date, '%Y-%m-%d') as entry_date,
                p.units_per_carton,
                (mi.cartons_remaining * p.units_per_carton) as total_units_remaining,
                (mi.cartons_remaining * mi.cost_price_carton) as total_cost_value,
                DATEDIFF(mi.expiry_date, CURDATE()) as days_to_expiry,
                -- إجمالي المبيعات النقدية
                COALESCE((
                    SELECT SUM(si.subtotal)
                    FROM sale_items si
                    INNER JOIN shelf_inventory sh ON si.shelf_inventory_id = sh.id
                    INNER JOIN sales s ON si.sale_id = s.id
                    WHERE sh.main_inventory_id = mi.id AND s.sale_type = 'cash'
                ), 0) as cash_total,
                -- إجمالي المبيعات الآجلة
                COALESCE((
                    SELECT SUM(si.subtotal)
                    FROM sale_items si
                    INNER JOIN shelf_inventory sh ON si.shelf_inventory_id = sh.id
                    INNER JOIN sales s ON si.sale_id = s.id
                    WHERE sh.main_inventory_id = mi.id AND s.sale_type = 'credit'
                ), 0) as credit_total,
                -- كمية المبيعات النقدية
                COALESCE((
                    SELECT SUM(si.quantity)
                    FROM sale_items si
                    INNER JOIN shelf_inventory sh ON si.shelf_inventory_id = sh.id
                    INNER JOIN sales s ON si.sale_id = s.id
                    WHERE sh.main_inventory_id = mi.id AND s.sale_type = 'cash'
                ), 0) as cash_quantity,
                -- كمية المبيعات الآجلة
                COALESCE((
                    SELECT SUM(si.quantity)
                    FROM sale_items si
                    INNER JOIN shelf_inventory sh ON si.shelf_inventory_id = sh.id
                    INNER JOIN sales s ON si.sale_id = s.id
                    WHERE sh.main_inventory_id = mi.id AND s.sale_type = 'credit'
                ), 0) as credit_quantity
            FROM main_inventory mi
            INNER JOIN products p ON mi.product_id = p.id
            WHERE mi.product_id = :product_id
            ORDER BY mi.entry_date DESC";
    
    $stmt = $db->prepare($sql);
    $stmt->execute(['product_id' => $productId]);
    $batches = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // حساب الربح لكل دفعة
    foreach ($batches as &$batch) {
        $totalRevenue = (float)$batch['cash_total'] + (float)$batch['credit_total'];
        $totalQuantity = (int)$batch['cash_quantity'] + (int)$batch['credit_quantity'];
        $costPerUnit = (float)$batch['cost_price_unit'];
        $totalCost = $totalQuantity * $costPerUnit;
        $profit = $totalRevenue - $totalCost;
        
        $batch['total_revenue'] = round($totalRevenue, 2);
        $batch['total_profit'] = round($profit, 2);
        $batch['total_quantity'] = $totalQuantity;
        $batch['profit_margin'] = $totalRevenue > 0 ? round(($profit / $totalRevenue) * 100, 2) : 0;
    }
    
    return $batches;
}
   
/**
 * جلب مبيعات دفعة محددة مع حساب الربح
 */
public function getBatchSales($batchId) {
    $db = Database::getInstance();
    
    $sql = "SELECT 
                s.id as sale_id,
                s.invoice_number,
                DATE_FORMAT(s.created_at, '%Y-%m-%d %H:%i') as sale_date,
                s.sale_type,
                si.quantity,
                si.price_unit,
                si.subtotal,
                mi.cost_price_unit as cost_price,
                -- حساب الربح: (سعر البيع - سعر التكلفة) × الكمية
                (si.price_unit - mi.cost_price_unit) * si.quantity as profit,
                sh.shelf_code,
                u.full_name as cashier_name,
                c.name as customer_name
            FROM sale_items si
            INNER JOIN shelf_inventory sh ON si.shelf_inventory_id = sh.id
            INNER JOIN main_inventory mi ON sh.main_inventory_id = mi.id
            INNER JOIN sales s ON si.sale_id = s.id
            LEFT JOIN users u ON s.created_by = u.id
            LEFT JOIN customers c ON s.customer_id = c.id
            WHERE mi.id = :batch_id
            ORDER BY s.created_at DESC";
    
    $stmt = $db->prepare($sql);
    $stmt->execute(['batch_id' => $batchId]);
    $sales = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // التأكد من وجود subtotal
    foreach ($sales as &$sale) {
        if ($sale['subtotal'] == 0 || $sale['subtotal'] === null) {
            $sale['subtotal'] = $sale['quantity'] * $sale['price_unit'];
        }
        if ($sale['profit'] === null) {
            $sale['profit'] = $sale['subtotal'] - ($sale['quantity'] * $sale['cost_price']);
        }
        $sale['cost_at_sale'] = $sale['cost_price'];
    }
    
    return $sales;
}
/*
 * جلب تفاصيل المخزون الكاملة للمنتج مع حساب الربح المتوقع
 */
    /**
     * جلب تفاصيل المخزون الكاملة للمنتج
     */
    public function getProductInventoryDetails($productId) {
        $db = Database::getInstance();
        
        // 1. جلب معلومات المنتج
        $productSql = "SELECT 
                            p.id,
                            p.name,
                            p.barcode,
                            p.units_per_carton,
                            c.name as category_name
                        FROM products p
                        LEFT JOIN categories c ON p.category_id = c.id
                        WHERE p.id = :id";
        $productStmt = $db->prepare($productSql);
        $productStmt->execute(['id' => $productId]);
        $product = $productStmt->fetch(PDO::FETCH_ASSOC);
        
        // 2. جلب المخزون في المخزن الرئيسي
        $mainSql = "SELECT 
                        mi.id,
                        mi.batch_number,
                        mi.cartons_remaining,
                        mi.cost_price_carton,
                        mi.cost_price_unit,
                        mi.selling_price_unit,
                        mi.expiry_date,
                        p.units_per_carton,
                        (mi.cartons_remaining * p.units_per_carton) as total_units,
                        (mi.cartons_remaining * mi.cost_price_carton) as total_cost,
                        DATEDIFF(mi.expiry_date, CURDATE()) as days_to_expiry
                    FROM main_inventory mi
                    INNER JOIN products p ON mi.product_id = p.id
                    WHERE mi.product_id = :product_id AND mi.cartons_remaining > 0
                    ORDER BY mi.entry_date ASC";
        $mainStmt = $db->prepare($mainSql);
        $mainStmt->execute(['product_id' => $productId]);
        $mainInventory = $mainStmt->fetchAll(PDO::FETCH_ASSOC);
        
        // 3. جلب المخزون على الرفوف
        $shelfSql = "SELECT 
                        sh.id,
                        sh.shelf_code,
                        sh.units_remaining,
                        sh.selling_price_unit,
                        sh.status,
                        DATE_FORMAT(sh.added_at, '%Y-%m-%d %H:%i') as added_at,
                        (sh.units_remaining * sh.selling_price_unit) as total_value,
                        mi.batch_number,
                        mi.cost_price_unit
                    FROM shelf_inventory sh
                    INNER JOIN main_inventory mi ON sh.main_inventory_id = mi.id
                    WHERE mi.product_id = :product_id AND sh.units_remaining > 0
                    ORDER BY sh.added_at DESC";
        $shelfStmt = $db->prepare($shelfSql);
        $shelfStmt->execute(['product_id' => $productId]);
        $shelfInventory = $shelfStmt->fetchAll(PDO::FETCH_ASSOC);
        
        // 4. حساب الإحصائيات
        $mainTotal = array_sum(array_column($mainInventory, 'total_units'));
        $mainCartonsTotal = array_sum(array_column($mainInventory, 'cartons_remaining'));
        $shelfTotal = array_sum(array_column($shelfInventory, 'units_remaining'));
        $costValue = array_sum(array_column($mainInventory, 'total_cost'));
        $saleValue = array_sum(array_column($shelfInventory, 'total_value'));
        $avgCost = $mainTotal > 0 ? $costValue / $mainTotal : 0;
        
        return [
            'product' => $product,
            'main_inventory' => $mainInventory,
            'shelf_inventory' => $shelfInventory,
            'main_total' => $mainTotal,
            'main_cartons_total' => $mainCartonsTotal,
            'shelf_total' => $shelfTotal,
            'cost_value' => $costValue,
            'sale_value' => $saleValue,
            'avg_cost' => $avgCost
        ];
    }

    /**
     * جلب المؤشرات السريعة للمنتج
     */
    public function getProductQuickStats($productId) {
        $db = Database::getInstance();
        
        // 1. إجمالي المخزون
        $stockSql = "SELECT 
                        COALESCE(SUM(sh.units_remaining), 0) as total_stock,
                        COALESCE(SUM(sh.units_remaining * sh.selling_price_unit), 0) as stock_value
                    FROM shelf_inventory sh
                    INNER JOIN main_inventory mi ON sh.main_inventory_id = mi.id
                    WHERE mi.product_id = :product_id";
        $stockStmt = $db->prepare($stockSql);
        $stockStmt->execute(['product_id' => $productId]);
        $stock = $stockStmt->fetch(PDO::FETCH_ASSOC);
        
        // 2. إجمالي المبيعات والربح
        $salesSql = "SELECT 
                        COALESCE(SUM(si.quantity), 0) as total_sales,
                        COALESCE(SUM(si.subtotal), 0) as total_revenue,
                        COALESCE(SUM(si.quantity * si.cost_at_sale), 0) as total_cost
                    FROM sale_items si
                    INNER JOIN shelf_inventory sh ON si.shelf_inventory_id = sh.id
                    INNER JOIN main_inventory mi ON sh.main_inventory_id = mi.id
                    WHERE mi.product_id = :product_id";
        $salesStmt = $db->prepare($salesSql);
        $salesStmt->execute(['product_id' => $productId]);
        $sales = $salesStmt->fetch(PDO::FETCH_ASSOC);
        
        $netProfit = $sales['total_revenue'] - $sales['total_cost'];
        $profitMargin = $sales['total_revenue'] > 0 ? ($netProfit / $sales['total_revenue']) * 100 : 0;
        
        return [
            'total_stock' => (int)$stock['total_stock'],
            'stock_value' => (float)$stock['stock_value'],
            'total_sales' => (int)$sales['total_sales'],
            'total_revenue' => (float)$sales['total_revenue'],
            'net_profit' => (float)$netProfit,
            'profit_margin' => round($profitMargin, 2)
        ];
    }

    /**
     * جلب آخر جرد للمنتج
     */
    public function getLastAudit($productId) {
        $db = Database::getInstance();
        
        $sql = "SELECT 
                    ia.id,
                    DATE_FORMAT(ia.audit_date, '%Y-%m-%d %H:%i') as audit_date,
                    ai.expected_qty,
                    ai.actual_qty,
                    ai.difference,
                    ai.reason,
                    u.full_name as user_name
                FROM inventory_audits ia
                INNER JOIN audit_items ai ON ia.id = ai.audit_id
                LEFT JOIN users u ON ia.user_id = u.id
                WHERE ai.product_id = :product_id
                ORDER BY ia.audit_date DESC
                LIMIT 1";
        
        $stmt = $db->prepare($sql);
        $stmt->execute(['product_id' => $productId]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    /**
     * جلب سجل الجرد الكامل للمنتج
     */
    public function getProductAuditHistory($productId) {
        $db = Database::getInstance();
        
        $sql = "SELECT 
                    ia.id,
                    DATE_FORMAT(ia.audit_date, '%Y-%m-%d %H:%i') as audit_date,
                    ia.status,
                    ia.total_discrepancy,
                    u.full_name as user_name,
                    ai.expected_qty,
                    ai.actual_qty,
                    ai.difference,
                    ai.reason
                FROM inventory_audits ia
                INNER JOIN audit_items ai ON ia.id = ai.audit_id
                LEFT JOIN users u ON ia.user_id = u.id
                WHERE ai.product_id = :product_id
                ORDER BY ia.audit_date DESC";
        
        $stmt = $db->prepare($sql);
        $stmt->execute(['product_id' => $productId]);
        $history = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // حساب الإحصائيات
        $stats = [
            'total_count' => count($history),
            'matched_count' => 0,
            'deficit_count' => 0,
            'surplus_count' => 0
        ];
        
        foreach ($history as $item) {
            if ($item['difference'] == 0) {
                $stats['matched_count']++;
            } elseif ($item['difference'] < 0) {
                $stats['deficit_count']++;
            } else {
                $stats['surplus_count']++;
            }
        }
        
        return [
            'history' => $history,
            'stats' => $stats
        ];
    }

    


    /**
     * جرد فعلي - تحديث الكمية
     */
    public function physicalInventory($productId, $actualQty, $reason = '') {
        $db = Database::getInstance();
        
        try {
            $db->beginTransaction();

            // جلب الكمية من مخزون الدفعات (main_inventory)
            $expectedSql = "SELECT COALESCE(SUM(mi.cartons_remaining * p.units_per_carton), 0) as expected_qty
                           FROM main_inventory mi
                           INNER JOIN products p ON mi.product_id = p.id
                           WHERE mi.product_id = :id";
            $expectedStmt = $db->prepare($expectedSql);
            $expectedStmt->execute(['id' => $productId]);
            $expected = (int)$expectedStmt->fetchColumn();

            $difference = $actualQty - $expected;
            $userId = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : 1;

            // إنشاء سجل جرد جديد
            $auditSql = "INSERT INTO inventory_audits (user_id, audit_date, total_discrepancy, status)
                        VALUES (:user_id, NOW(), :discrepancy, 'completed')";
            $auditStmt = $db->prepare($auditSql);
            $auditStmt->execute([
                'user_id' => $userId,
                'discrepancy' => abs($difference)
            ]);
            $auditId = $db->lastInsertId();

            // إضافة عنصر الجرد
            $itemSql = "INSERT INTO audit_items (audit_id, product_id, expected_qty, actual_qty, difference, reason)
                       VALUES (:audit_id, :product_id, :expected, :actual, :difference, :reason)";
            $itemStmt = $db->prepare($itemSql);
            $itemStmt->execute([
                'audit_id' => $auditId,
                'product_id' => $productId,
                'expected' => $expected,
                'actual' => $actualQty,
                'difference' => $difference,
                'reason' => $reason
            ]);

            // تسجيل النشاط
            $logSql = "INSERT INTO activity_logs (user_id, action, details, created_at)
                      VALUES (:user_id, 'physical_inventory', :details, NOW())";
            $logStmt = $db->prepare($logSql);
            $action = $difference > 0 ? 'زيادة' : ($difference < 0 ? 'عجز' : 'مطابق');
            $logStmt->execute([
                'user_id' => $userId,
                'details' => "جرد المنتج ID $productId: متوقع $expected, فعلي $actualQty ($action) - $reason"
            ]);

            $db->commit();

            return [
                'success' => true,
                'message' => $difference == 0 ? 'الجرد مطابق' : ($difference > 0 ? 'زيادة ' . $difference : 'عجز ' . abs($difference)),
                'data' => [
                    'expected' => $expected,
                    'actual' => $actualQty,
                    'difference' => $difference
                ]
            ];

        } catch (Exception $e) {
            if ($db->inTransaction()) {
                $db->rollBack();
            }
            error_log("Physical inventory error: " . $e->getMessage());
            return [
                'success' => false,
                'message' => 'خطأ في الجرد: ' . $e->getMessage()
            ];
        }
    }

    /**
     * تحديث كمية وسبب عملية الجرد المسجلة (قبل التطبيق)
     */
    public function updateAudit($auditId, $actualQty, $reason) {
        $db = Database::getInstance();
        try {
            $db->beginTransaction();
            
            // جلب العملية للتحقق من وجودها وحالتها
            $stmt = $db->prepare("SELECT ia.status, ai.expected_qty, ai.product_id FROM inventory_audits ia 
                                  INNER JOIN audit_items ai ON ia.id = ai.audit_id WHERE ia.id = ?");
            $stmt->execute([$auditId]);
            $audit = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if (!$audit) {
                return ['success' => false, 'message' => 'عملية الجرد غير موجودة'];
            }
            if ($audit['status'] === 'applied') {
                return ['success' => false, 'message' => 'لا يمكن تعديل جرد تم تطبيقه فعلياً'];
            }
            
            $difference = $actualQty - $audit['expected_qty'];
            
            // تحديث التفاصيل
            $updateItem = $db->prepare("UPDATE audit_items SET actual_qty = ?, difference = ?, reason = ? WHERE audit_id = ?");
            $updateItem->execute([$actualQty, $difference, $reason, $auditId]);
            
            // تحديث الإجمالي في السجل الرئيسي
            $updateMain = $db->prepare("UPDATE inventory_audits SET total_discrepancy = ? WHERE id = ?");
            $updateMain->execute([abs($difference), $auditId]);
            
            $userId = $_SESSION['user_id'] ?? 1;
            $db->prepare("INSERT INTO activity_logs (user_id, action, details, created_at) VALUES (?, 'edit_inventory_audit', ?, NOW())")
               ->execute([$userId, "تعديل عملية الجرد $auditId للمنتج {$audit['product_id']}: الكمية الفعلية $actualQty والفرق $difference"]);
            
            $db->commit();
            return ['success' => true];
        } catch (Exception $e) {
            if ($db->inTransaction()) $db->rollBack();
            return ['success' => false, 'message' => 'خطأ أثناء التعديل: ' . $e->getMessage()];
        }
    }

    /**
     * حذف عملية جرد مسجلة (قبل التطبيق)
     */
    public function deleteAudit($auditId) {
        $db = Database::getInstance();
        try {
            $db->beginTransaction();
            
            $stmt = $db->prepare("SELECT status FROM inventory_audits WHERE id = ?");
            $stmt->execute([$auditId]);
            $status = $stmt->fetchColumn();
            
            if ($status === 'applied') {
                return ['success' => false, 'message' => 'لا يمكن حذف جرد تم تطبيقه فعلياً'];
            }
            
            // حذف التفاصيل أولاً (ما لم يكن هناك ON DELETE CASCADE)
            $db->prepare("DELETE FROM audit_items WHERE audit_id = ?")->execute([$auditId]);
            $db->prepare("DELETE FROM inventory_audits WHERE id = ?")->execute([$auditId]);
            
            $userId = $_SESSION['user_id'] ?? 1;
            $db->prepare("INSERT INTO activity_logs (user_id, action, details, created_at) VALUES (?, 'delete_inventory_audit', ?, NOW())")
               ->execute([$userId, "حذف عملية الجرد $auditId"]);
            
            $db->commit();
            return ['success' => true];
        } catch (Exception $e) {
            if ($db->inTransaction()) $db->rollBack();
            return ['success' => false, 'message' => 'خطأ أثناء الحذف: ' . $e->getMessage()];
        }
    }

    /**
     * تطبيق الجرد الفعلي على قاعدة البيانات (تحديث الأرصدة)
     */
    public function applyAuditToDatabase($auditId) {
        $db = Database::getInstance();
        try {
            $db->beginTransaction();
            
            // جلب تفاصيل الجرد
            $stmt = $db->prepare("SELECT ia.status, ai.product_id, ai.difference, ai.actual_qty, ai.expected_qty 
                                  FROM inventory_audits ia 
                                  INNER JOIN audit_items ai ON ia.id = ai.audit_id 
                                  WHERE ia.id = ?");
            $stmt->execute([$auditId]);
            $audit = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if (!$audit) {
                return ['success' => false, 'message' => 'عملية الجرد غير موجودة'];
            }
            if ($audit['status'] === 'applied') {
                return ['success' => false, 'message' => 'هذا الجرد تم تطبيقه مسبقاً'];
            }
            
            $productId = $audit['product_id'];
            $difference = (int)$audit['difference'];
            
            // الحصول على معلومات تحويل الكراتين للمنتج
            $prodStmt = $db->prepare("SELECT units_per_carton FROM products WHERE id = ?");
            $prodStmt->execute([$productId]);
            $unitsPerCarton = (int)$prodStmt->fetchColumn();
            if ($unitsPerCarton <= 0) $unitsPerCarton = 1;

            if ($difference < 0) {
                // عجز: يجب الخصم (نستخدم FIFO على الرفوف أولاً)
                $deficit = abs($difference);
                
                // جلب الرفوف المتاحة لهذا المنتج
                $shelfStmt = $db->prepare("SELECT sh.id, sh.units_remaining 
                                           FROM shelf_inventory sh 
                                           INNER JOIN main_inventory mi ON sh.main_inventory_id = mi.id 
                                           WHERE mi.product_id = ? AND sh.units_remaining > 0 
                                           ORDER BY sh.added_at ASC");
                $shelfStmt->execute([$productId]);
                $shelves = $shelfStmt->fetchAll(PDO::FETCH_ASSOC);
                
                foreach ($shelves as $shelf) {
                    if ($deficit <= 0) break;
                    
                    $available = (int)$shelf['units_remaining'];
                    if ($available <= $deficit) {
                        // تفريغ الرف بالكامل
                        $db->prepare("UPDATE shelf_inventory SET units_remaining = 0, status = 'out_of_stock' WHERE id = ?")
                           ->execute([$shelf['id']]);
                        $deficit -= $available;
                    } else {
                        // خصم جزئي
                        $db->prepare("UPDATE shelf_inventory SET units_remaining = units_remaining - ?, status = CASE WHEN (units_remaining - ?) < 10 THEN 'low_stock' ELSE status END WHERE id = ?")
                           ->execute([$deficit, $deficit, $shelf['id']]);
                        $deficit = 0;
                    }
                }
                
                // إذا لا زال هناك عجز بعد تفريغ كل الرفوف، يجب سحب كراتين من main_inventory وتسويتها
                // لتبسيط العملية وتجنب كسور التعبئة: نعرض رسالة خطأ مؤقتاً إذا كان العجز يتطلب تحطيم كراتين لم تنزل للرف
                // أو نقوم تلقائيا بتحويل كرتون للرف وخصم الباقي
                if ($deficit > 0) {
                    $mainStmt = $db->prepare("SELECT id, cartons_remaining FROM main_inventory WHERE product_id = ? AND cartons_remaining > 0 ORDER BY entry_date ASC");
                    $mainStmt->execute([$productId]);
                    $mains = $mainStmt->fetchAll(PDO::FETCH_ASSOC);
                    
                    foreach ($mains as $main) {
                        if ($deficit <= 0) break;
                        
                        $availableCartons = (int)$main['cartons_remaining'];
                        $availableUnits = $availableCartons * $unitsPerCarton;
                        
                        if ($availableUnits <= $deficit) {
                            $db->prepare("UPDATE main_inventory SET cartons_remaining = 0 WHERE id = ?")->execute([$main['id']]);
                            $deficit -= $availableUnits;
                        } else {
                            // خصم كسور كرتون: ننزل كراتين كاملة تكفي العجز ثم خصم العجز
                            $cartonsNeeded = ceil($deficit / $unitsPerCarton);
                            $db->prepare("UPDATE main_inventory SET cartons_remaining = cartons_remaining - ? WHERE id = ?")
                               ->execute([$cartonsNeeded, $main['id']]);
                            
                            $surplusFromBreak = ($cartonsNeeded * $unitsPerCarton) - $deficit;
                            
                            // إضافة الفائض للرف (Surplus From Break)
                            if ($surplusFromBreak > 0) {
                                // محاولة إيجاد رف
                                $lastShelf = $db->prepare("SELECT id FROM shelf_inventory WHERE main_inventory_id = ? ORDER BY added_at DESC LIMIT 1");
                                $lastShelf->execute([$main['id']]);
                                $shelfId = $lastShelf->fetchColumn();
                                
                                if ($shelfId) {
                                    $db->prepare("UPDATE shelf_inventory SET units_remaining = units_remaining + ? WHERE id = ?")
                                       ->execute([$surplusFromBreak, $shelfId]);
                                } else {
                                    // إنشاء رف جديد
                                    $priceStmt = $db->prepare("SELECT selling_price_unit FROM main_inventory WHERE id = ?");
                                    $priceStmt->execute([$main['id']]);
                                    $price = (float)$priceStmt->fetchColumn();
                                    
                                    $sysCode = 'SYS-TR-' . date('His') . rand(10,99);
                                    $db->prepare("INSERT INTO shelf_inventory (main_inventory_id, shelf_code, units_remaining, selling_price_unit) VALUES (?, ?, ?, ?)")
                                       ->execute([$main['id'], $sysCode, $surplusFromBreak, $price]);
                                }
                            }
                            $deficit = 0;
                        }
                    }
                }
                
                // إذا لم يُغطَ العجز بالكامل (حالة نادرة جداً ألا تكفي البضاعة أصلاً)
                // يتم تجاهلها حيث سيصبح المجموع 0
            } elseif ($difference > 0) {
                // زيادة: يجب الإضافة (نقوم بتجميع القطع كراتين إذا بلغت أو تجاوزت سعة الكرتون)
                $surplus = $difference;
                
                $lastShelfStmt = $db->prepare("SELECT sh.id, sh.units_remaining, sh.main_inventory_id 
                                               FROM shelf_inventory sh 
                                               INNER JOIN main_inventory mi ON sh.main_inventory_id = mi.id 
                                               WHERE mi.product_id = ? 
                                               ORDER BY sh.added_at DESC LIMIT 1");
                $lastShelfStmt->execute([$productId]);
                $shelf = $lastShelfStmt->fetch(PDO::FETCH_ASSOC);
                
                if ($shelf) {
                    $totalUnits = $shelf['units_remaining'] + $surplus;
                    
                    if ($unitsPerCarton > 1 && $totalUnits >= $unitsPerCarton) {
                        // تجميع القطع الزائدة إلى كراتين في المخزن الرئيسي
                        $cartonsToAdd = floor($totalUnits / $unitsPerCarton);
                        $remainingPieces = $totalUnits % $unitsPerCarton;
                        
                        $db->prepare("UPDATE main_inventory SET cartons_remaining = cartons_remaining + ? WHERE id = ?")
                           ->execute([$cartonsToAdd, $shelf['main_inventory_id']]);
                           
                        $db->prepare("UPDATE shelf_inventory SET units_remaining = ? WHERE id = ?")
                           ->execute([$remainingPieces, $shelf['id']]);
                    } else {
                        // إضافة عادية للرف لأنها لم تبلغ سعة الكرتون
                        $db->prepare("UPDATE shelf_inventory SET units_remaining = ? WHERE id = ?")
                           ->execute([$totalUnits, $shelf['id']]);
                    }
                } else {
                    // إذا لم يوجد رف مسبق، نبحث عن آخر دفعة في المخزن الرئيسي
                    $lastMainStmt = $db->prepare("SELECT id, selling_price_unit FROM main_inventory WHERE product_id = ? ORDER BY entry_date DESC LIMIT 1");
                    $lastMainStmt->execute([$productId]);
                    $mainLog = $lastMainStmt->fetch(PDO::FETCH_ASSOC);
                    
                    if ($mainLog) {
                        if ($unitsPerCarton > 1 && $surplus >= $unitsPerCarton) {
                            $cartonsToAdd = floor($surplus / $unitsPerCarton);
                            $remainingPieces = $surplus % $unitsPerCarton;
                            
                            $db->prepare("UPDATE main_inventory SET cartons_remaining = cartons_remaining + ? WHERE id = ?")
                               ->execute([$cartonsToAdd, $mainLog['id']]);
                               
                            if ($remainingPieces > 0) {
                                $sysCode = 'SYS-OVR-' . date('His') . rand(10,99);
                                $db->prepare("INSERT INTO shelf_inventory (main_inventory_id, shelf_code, units_remaining, selling_price_unit) VALUES (?, ?, ?, ?)")
                                   ->execute([$mainLog['id'], $sysCode, $remainingPieces, $mainLog['selling_price_unit']]);
                            }
                        } else {
                            $sysCode = 'SYS-OVR-' . date('His') . rand(10,99);
                            $db->prepare("INSERT INTO shelf_inventory (main_inventory_id, shelf_code, units_remaining, selling_price_unit) VALUES (?, ?, ?, ?)")
                               ->execute([$mainLog['id'], $sysCode, $surplus, $mainLog['selling_price_unit']]);
                        }
                    } else {
                        throw new Exception("لا يوجد أي سجل إدخال للمخزن لهذا المنتج لإضافة الزيادة إليه.");
                    }
                }
            }
            
            // تحديث حالة عملية الجرد لتصبح مطبقة
            $db->prepare("UPDATE inventory_audits SET status = 'applied' WHERE id = ?")
               ->execute([$auditId]);
            
            $userId = $_SESSION['user_id'] ?? 1;
            $db->prepare("INSERT INTO activity_logs (user_id, action, details, created_at) VALUES (?, 'apply_inventory_audit', ?, NOW())")
               ->execute([$userId, "تطبيق الجرد $auditId فعلياً على النظام (تحديث المخزون). الفرق: $difference"]);

            $db->commit();
            return ['success' => true];
        } catch (Exception $e) {
            if ($db->inTransaction()) $db->rollBack();
            return ['success' => false, 'message' => 'خطأ أثناء التطبيق: ' . $e->getMessage()];
        }
    }
}