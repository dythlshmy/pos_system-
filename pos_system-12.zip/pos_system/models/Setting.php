<?php
require_once __DIR__ . '/../core/Model.php';

class Setting extends Model {
    protected $table = 'settings';
    protected $primaryKey = 'setting_key';
    public $incrementing = false;
    protected $keyType = 'string';

    /**
     * الحصول على قيمة إعداد معين
     * @param string $key مفتاح الإعداد
     * @param mixed $default القيمة الافتراضية إذا لم يوجد
     * @return mixed
     */
    public function get($key, $default = null) {
        $sql = "SELECT setting_value FROM {$this->table} WHERE setting_key = ?";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([$key]);
        $result = $stmt->fetch();
        
        return $result ? $result['setting_value'] : $default;
    }

    /**
     * حفظ أو تحديث إعداد
     * @param string $key مفتاح الإعداد
     * @param mixed $value القيمة
     * @return bool
     */
    public function set($key, $value) {
        $sql = "INSERT INTO {$this->table} (setting_key, setting_value) 
                VALUES (?, ?) 
                ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)";
        $stmt = $this->db->prepare($sql);
        return $stmt->execute([$key, $value]);
    }

    /**
     * الحصول على جميع إعدادات الطباعة والنسخ الاحتياطي
     * @return array
     */
    public function getPrintSettings() {
        $settings = [];
        
        // جلب الإعدادات المهمة للطباعة والنسخ الاحتياطي
        $keys = [
            'print_enabled',
            'print_save_path',
            'print_open_automatically',
            'print_header_text',
            'print_footer_text',
            'print_company_info',
            'print_template_id',
            'store_name',
            'backup_path',
            'backup_hour',
            'backup_minute',
            'backup_ampm',
            'backup_enabled'
        ];
        
        foreach ($keys as $key) {
            $settings[$key] = $this->get($key);
        }
        
        return $settings;
    }

    /**
     * حفظ إعدادات الطباعة دفعة واحدة
     * @param array $data مصفوفة الإعدادات (key => value)
     * @return bool
     */
    public function savePrintSettings($data) {
        try {
            $this->db->beginTransaction();
            
            foreach ($data as $key => $value) {
                $this->set($key, $value);
            }
            
            $this->db->commit();
            return true;
            
        } catch (Exception $e) {
            $this->db->rollBack();
            error_log("Error saving print settings: " . $e->getMessage());
            return false;
        }
    }

    /**
     * الحصول على مسار حفظ الملفات (مع التأكد من وجوده)
     * @return string
     */
    public function getSavePath() {
        $path = $this->get('print_save_path', 'C:/invoices/');
        
        // التأكد من أن المسار ينتهي بفاصل
        $path = rtrim($path, '/\\') . DIRECTORY_SEPARATOR;
        
        return $path;
    }

    /**
     * التحقق من وجود مسار الحفظ وصلاحيات الكتابة
     * @return array ['success' => bool, 'message' => string]
     */
    public function validateSavePath() {
        $path = $this->getSavePath();
        
        if (!is_dir($path)) {
            // محاولة إنشاء المجلد
            if (!mkdir($path, 0777, true)) {
                return [
                    'success' => false,
                    'message' => 'المسار المحدد غير موجود ولا يمكن إنشاؤه'
                ];
            }
        }
        
        if (!is_writable($path)) {
            return [
                'success' => false,
                'message' => 'لا يمكن الكتابة على المسار المحدد'
            ];
        }
        
        return [
            'success' => true,
            'message' => 'المسار صالح وجاهز للاستخدام'
        ];
    }

    /**
     * الحصول على نص معلومات الشركة كـ array
     * @return array
     */
    public function getCompanyInfoArray() {
        $info = $this->get('print_company_info', "سوبر ماركت النخبة\nهاتف: 0123456789\nالعنوان: المدينة - الحي");
        $lines = explode("\n", $info);
        
        $result = [
            'name' => $lines[0] ?? 'سوبر ماركت النخبة',
            'phone' => '',
            'address' => '',
            'tax' => ''
        ];
        
        foreach ($lines as $line) {
            if (strpos($line, 'هاتف:') !== false) {
                $result['phone'] = trim(str_replace('هاتف:', '', $line));
            } elseif (strpos($line, 'عنوان:') !== false) {
                $result['address'] = trim(str_replace('عنوان:', '', $line));
            } elseif (strpos($line, 'ضريبي:') !== false || strpos($line, 'tax:') !== false) {
                $result['tax'] = trim(str_replace(['ضريبي:', 'tax:'], '', $line));
            }
        }
        
        return $result;
    }

    /**
     * إنشاء HTML الفاتورة
     */
    /**
 * إنشاء HTML الفاتورة
 */
/**
 * إنشاء HTML الفاتورة
 */
public function generateInvoiceHTML($saleData, $items) {
    $settings = $this->getPrintSettings();
    
    // ===== قراءة نص رأس الفاتورة =====
    $headerText = isset($settings['print_header_text']) && $settings['print_header_text'] !== '' 
                  ? $settings['print_header_text'] 
                  : '';  // لا توجد بيانات افتراضية، فارغ إذا لم يكتب المستخدم شيئاً
    
    // ===== قراءة نص تذييل الفاتورة =====
    $footerText = isset($settings['print_footer_text']) && $settings['print_footer_text'] !== '' 
                  ? $settings['print_footer_text'] 
                  : '';  // لا توجد بيانات افتراضية
    
    // ===== قراءة معلومات الشركة (بدون بيانات افتراضية) =====
    $companyInfoRaw = isset($settings['print_company_info']) && $settings['print_company_info'] !== '' 
                      ? $settings['print_company_info'] 
                      : '';  // فارغ إذا لم يكتب المستخدم شيئاً
    
    // تقسيم معلومات الشركة إلى أسطر
    $companyLines = [];
    if (!empty($companyInfoRaw)) {
        $companyLines = explode("\n", $companyInfoRaw);
        // إزالة الأسطر الفارغة
        $companyLines = array_filter($companyLines, function($line) {
            return trim($line) !== '';
        });
    }
    
    $itemsHtml = '';
    $total = 0;
    foreach ($items as $item) {
        $subtotal = $item['quantity'] * $item['price'];
        $total += $subtotal;
        $productName = isset($item['name']) ? $item['name'] : (isset($item['product_name']) ? $item['product_name'] : 'منتج');
        $itemsHtml .= "
            <tr>
                <td>" . htmlspecialchars($productName) . "</td>
                <td class='center'>{$item['quantity']}</td>
                <td class='right'>" . number_format($item['price'], 2) . "</td>
                <td class='right'>" . number_format($subtotal, 2) . "</td>
            </tr>
        ";
    }

    $templateId = isset($settings['print_template_id']) ? $settings['print_template_id'] : '2';
    $templateStyle = $this->getTemplateStyles($templateId);
    
    // بناء HTML معلومات الشركة (فقط البيانات التي كتبها المستخدم)
    $companyHtml = '';
    foreach ($companyLines as $line) {
        $companyHtml .= "<div>" . htmlspecialchars(trim($line)) . "</div>";
    }
    
    // اسم البائع
    $sellerName = 'admin';
    if (isset($_SESSION['user_name'])) {
        $sellerName = $_SESSION['user_name'];
    } elseif (isset($_SESSION['full_name'])) {
        $sellerName = $_SESSION['full_name'];
    }
    
    // العميل
    $customerHtml = '';
    if (isset($saleData['customer_name']) && $saleData['customer_name']) {
        $customerHtml = "<div>👥 العميل: " . htmlspecialchars($saleData['customer_name']) . "</div>";
    }
    
    $html = "<!DOCTYPE html>
    <html dir='rtl'>
    <head>
        <meta charset='UTF-8'>
        <title>فاتورة رقم {$saleData['invoice_number']}</title>
        <style>
            * { margin: 0; padding: 0; box-sizing: border-box; }
            body { margin: 0; padding: 20px; font-family: 'Courier New', monospace; background: #f5f5f5; }
            .invoice { max-width: 80mm; margin: 0 auto; background: white; }
            .header { text-align: center; padding: 15px; background: " . ($templateId == '2' ? 'linear-gradient(135deg, #667eea, #764ba2)' : '#f8f9fa') . "; color: " . ($templateId == '2' ? 'white' : '#333') . "; }
            .header h1 { margin: 0; font-size: 18px; }
            .company-details { font-size: 11px; padding: 12px; text-align: center; border-bottom: 1px solid #eee; background: white; }
            .company-details div { margin: 3px 0; }
            .info { padding: 12px; font-size: 11px; background: #f8f9fa; border-bottom: 1px solid #eee; }
            .info div { margin: 4px 0; }
            .items-table { width: 100%; border-collapse: collapse; font-size: 11px; }
            .items-table th { background: " . ($templateId == '2' ? '#667eea' : '#f8f9fa') . "; color: " . ($templateId == '2' ? 'white' : '#333') . "; padding: 8px; text-align: center; }
            .items-table td { padding: 8px; text-align: center; border-bottom: 1px solid #eee; }
            .center { text-align: center; }
            .right { text-align: left; }
            .total { padding: 12px; background: #f8f9fa; border-top: 2px solid #eee; }
            .total-row { display: flex; justify-content: space-between; margin-bottom: 5px; font-size: 12px; }
            .grand-total { font-size: 14px; font-weight: bold; color: #28a745; }
            .footer { padding: 12px; text-align: center; font-size: 10px; color: #6c757d; border-top: 1px solid #eee; }
            .divider { border-top: 1px dashed #ccc; margin: 5px 0; }
            {$templateStyle}
        </style>
    </head>
    <body>
        <div class='invoice'>";
    
    // رأس الفاتورة (فقط إذا كان المستخدم كتب نصاً)
    if (!empty($headerText)) {
        $html .= "
            <div class='header'>
                <h1>" . htmlspecialchars($headerText) . "</h1>
            </div>";
    }
    
    // معلومات الشركة (فقط إذا كان المستخدم كتب بيانات)
    if (!empty($companyHtml)) {
        $html .= "
            <div class='company-details'>
                {$companyHtml}
            </div>";
    }
    
    $html .= "
            <div class='divider'></div>
            
            <div class='info'>
                <div>📄 رقم الفاتورة: {$saleData['invoice_number']}</div>
                <div>📅 التاريخ: " . date('Y-m-d H:i:s') . "</div>
                <div>👤 البائع: {$sellerName}</div>
                {$customerHtml}
            </div>
            
            <div class='divider'></div>
            
            <table class='items-table'>
                <thead>
                    <tr>
                        <th>المنتج</th>
                        <th>الكمية</th>
                        <th>السعر</th>
                        <th>الإجمالي</th>
                    </tr>
                </thead>
                <tbody>
                    {$itemsHtml}
                </tbody>
            </table>
            
            <div class='divider'></div>
            
            <div class='total'>
                <div class='total-row'>
                    <span>💰 الإجمالي:</span>
                    <span>" . number_format($total, 2) . " ريال</span>
                </div>
                <div class='total-row'>
                    <span>💵 المدفوع:</span>
                    <span>" . number_format($saleData['paid_amount'], 2) . " ريال</span>
                </div>
                <div class='total-row grand-total'>
                    <span>✅ المتبقي:</span>
                    <span>" . number_format($saleData['remaining_amount'], 2) . " ريال</span>
                </div>
            </div>
            
            <div class='divider'></div>";
    
    // تذييل الفاتورة (فقط إذا كان المستخدم كتب نصاً)
    if (!empty($footerText)) {
        $html .= "
            <div class='footer'>
                " . htmlspecialchars($footerText) . "
            </div>";
    }
    
    $html .= "
        </div>
    </body>
    </html>";
    
    return $html;
}

    /**
     * الحصول على أنماط CSS حسب التصميم
     */
    private function getTemplateStyles($templateId) {
        switch($templateId) {
            case '1': // كلاسيكي
                return "
                    body { font-family: 'Courier New', monospace; }
                    .header { border-bottom: 2px dashed #000; }
                    .divider { border-top: 1px dashed #000; }
                ";
            case '2': // حديث
                return "
                    body { font-family: 'Segoe UI', sans-serif; }
                    .header { background: linear-gradient(135deg, #667eea, #764ba2); color: white; padding: 15px; border-radius: 10px; }
                    th { background: #667eea; color: white; }
                    .divider { border-top: 1px solid #667eea; }
                ";
            case '3': // فاخر
                return "
                    body { font-family: 'Times New Roman', serif; }
                    .header { border: 2px solid #b8860b; padding: 15px; background: #fbf7e9; border-radius: 10px; }
                    th { background: #b8860b; color: white; }
                    .divider { border-top: 2px solid #b8860b; }
                ";
            case '4': // مبسط
                return "
                    body { font-family: 'Courier New', monospace; }
                    * { color: black !important; background: white !important; }
                    .header { border-bottom: 1px solid #000; }
                    .divider { border-top: 1px solid #000; }
                ";
            default:
                return "";
        }
    }

    /**
     * حفظ الفاتورة كـ HTML
     */
    public function saveInvoice($saleId, $saleData, $items) {
        try {
            // التحقق من تفعيل الطباعة
            if ($this->get('print_enabled', '0') !== '1') {
                return ['success' => false, 'message' => 'نظام الطباعة غير مفعل'];
            }
            
            // التحقق من المسار
            $pathCheck = $this->validateSavePath();
            if (!$pathCheck['success']) {
                return $pathCheck;
            }
            
            // إنشاء HTML
            $html = $this->generateInvoiceHTML($saleData, $items);
            
            // اسم الملف
            $fileName = $saleData['invoice_number'] . '.html';
            $filePath = $this->getSavePath() . $fileName;
            
            // حفظ الملف
            if (file_put_contents($filePath, $html)) {
                return [
                    'success' => true,
                    'message' => 'تم حفظ الفاتورة بنجاح',
                    'file_path' => $filePath
                ];
            }
            
            return [
                'success' => false,
                'message' => 'فشل في حفظ الفاتورة'
            ];
            
        } catch (Exception $e) {
            error_log("Save invoice error: " . $e->getMessage());
            return [
                'success' => false,
                'message' => 'خطأ في حفظ الفاتورة: ' . $e->getMessage()
            ];
        }
    }
}