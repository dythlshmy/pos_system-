<?php
require_once __DIR__ . '/../core/Model.php';

class SaleItem extends Model {
    protected $table = 'sale_items';
    protected $primaryKey = 'id';

    /**
     * إضافة عنصر إلى الفاتورة
     */
    public function createItem($data) {
        $sql = "INSERT INTO {$this->table} 
                (sale_id, shelf_inventory_id, main_inventory_id, batch_number, 
                 expiry_date_at_sale, quantity, price_unit, cost_at_sale, subtotal) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        
        $stmt = $this->db->prepare($sql);
        return $stmt->execute([
            $data['sale_id'],
            $data['shelf_inventory_id'],
            $data['main_inventory_id'],
            $data['batch_number'] ?? null,
            $data['expiry_date_at_sale'] ?? null,
            $data['quantity'],
            $data['price_unit'],
            $data['cost_at_sale'] ?? 0,
            $data['subtotal']
        ]);
    }

    /**
     * الحصول على عناصر فاتورة معينة
     */
    public function getBySaleId($saleId) {
        $sql = "SELECT si.*, p.name as product_name, p.barcode,
                       sh.shelf_code, mi.batch_number, mi.expiry_date
                FROM {$this->table} si
                JOIN shelf_inventory sh ON si.shelf_inventory_id = sh.id
                JOIN main_inventory mi ON sh.main_inventory_id = mi.id
                JOIN products p ON mi.product_id = p.id
                WHERE si.sale_id = ?
                ORDER BY si.id ASC";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([$saleId]);
        return $stmt->fetchAll();
    }

    /**
     * حذف عناصر فاتورة (للإرجاع)
     */
    public function deleteBySaleId($saleId) {
        $sql = "DELETE FROM {$this->table} WHERE sale_id = ?";
        $stmt = $this->db->prepare($sql);
        return $stmt->execute([$saleId]);
    }

    /**
     * ===== الدوال المضافة (الجديدة) =====
     */

    /**
     * إضافة عدة عناصر دفعة واحدة
     */
    public function createItems($items) {
        $success = true;
        foreach ($items as $item) {
            if (!$this->createItem($item)) {
                $success = false;
                break;
            }
        }
        return $success;
    }

    /**
     * الحصول على إجمالي مبيعات منتج معين
     */
    public function getProductSalesTotal($productId, $from = null, $to = null) {
        $sql = "SELECT 
                    SUM(si.quantity) as total_quantity,
                    SUM(si.subtotal) as total_amount,
                    COUNT(DISTINCT si.sale_id) as sale_count
                FROM {$this->table} si
                JOIN shelf_inventory sh ON si.shelf_inventory_id = sh.id
                JOIN main_inventory mi ON sh.main_inventory_id = mi.id
                WHERE mi.product_id = ?";
        
        $params = [$productId];
        
        if ($from && $to) {
            $sql .= " AND DATE(si.created_at) BETWEEN ? AND ?";
            $params[] = $from;
            $params[] = $to;
        }
        
        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetch();
    }

    /**
     * الحصول على تفاصيل مبيعات منتج (تحليلي)
     */
    public function getProductSalesDetails($productId, $from = null, $to = null) {
        $sql = "SELECT 
                    si.price_unit,
                    SUM(si.quantity) as quantity,
                    SUM(si.subtotal) as total
                FROM {$this->table} si
                JOIN shelf_inventory sh ON si.shelf_inventory_id = sh.id
                JOIN main_inventory mi ON sh.main_inventory_id = mi.id
                WHERE mi.product_id = ?";
        
        $params = [$productId];
        
        if ($from && $to) {
            $sql .= " AND DATE(si.created_at) BETWEEN ? AND ?";
            $params[] = $from;
            $params[] = $to;
        }
        
        $sql .= " GROUP BY si.price_unit ORDER BY si.price_unit DESC";
        
        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }

    /**
     * الحصول على إجمالي مبيعات اليوم
     */
    public function getTodayTotal() {
        $today = date('Y-m-d');
        $sql = "SELECT SUM(subtotal) as total 
                FROM {$this->table} si
                WHERE DATE(si.created_at) = ?";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([$today]);
        return $stmt->fetchColumn() ?: 0;
    }

    /**
     * الحصول على أكثر المنتجات مبيعاً
     */
    public function getTopProducts($limit = 10, $from = null, $to = null) {
        $sql = "SELECT 
                    p.id,
                    p.name,
                    p.barcode,
                    SUM(si.quantity) as total_quantity,
                    SUM(si.subtotal) as total_amount,
                    COUNT(DISTINCT si.sale_id) as sale_count
                FROM {$this->table} si
                JOIN shelf_inventory sh ON si.shelf_inventory_id = sh.id
                JOIN main_inventory mi ON sh.main_inventory_id = mi.id
                JOIN products p ON mi.product_id = p.id
                WHERE 1=1";
        
        $params = [];
        
        if ($from && $to) {
            $sql .= " AND DATE(si.created_at) BETWEEN ? AND ?";
            $params[] = $from;
            $params[] = $to;
        }
        
        $sql .= " GROUP BY p.id 
                  ORDER BY total_quantity DESC 
                  LIMIT " . intval($limit);
        
        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }

    /**
     * الحصول على إحصائيات المبيعات حسب الفترة
     */
    public function getSalesStats($from, $to) {
        $sql = "SELECT 
                    DATE(si.created_at) as sale_date,
                    COUNT(DISTINCT si.sale_id) as invoices,
                    SUM(si.quantity) as total_items,
                    SUM(si.subtotal) as total_amount
                FROM {$this->table} si
                WHERE DATE(si.created_at) BETWEEN ? AND ?
                GROUP BY DATE(si.created_at)
                ORDER BY sale_date DESC";
        
        $stmt = $this->db->prepare($sql);
        $stmt->execute([$from, $to]);
        return $stmt->fetchAll();
    }

    /**
     * البحث في عناصر الفواتير
     */
    public function search($keyword) {
        $sql = "SELECT si.*, p.name as product_name, p.barcode,
                       s.invoice_number, s.created_at as sale_date
                FROM {$this->table} si
                JOIN shelf_inventory sh ON si.shelf_inventory_id = sh.id
                JOIN main_inventory mi ON sh.main_inventory_id = mi.id
                JOIN products p ON mi.product_id = p.id
                JOIN sales s ON si.sale_id = s.id
                WHERE p.name LIKE ? OR p.barcode LIKE ? OR s.invoice_number LIKE ?
                ORDER BY si.created_at DESC
                LIMIT 50";
        
        $searchTerm = '%' . $keyword . '%';
        $stmt = $this->db->prepare($sql);
        $stmt->execute([$searchTerm, $searchTerm, $searchTerm]);
        return $stmt->fetchAll();
    }

    /**
     * الحصول على عناصر فاتورة معينة (مع تفاصيل أكثر)
     */
    public function getDetailedBySaleId($saleId) {
        $sql = "SELECT 
                    si.*,
                    p.id as product_id,
                    p.name as product_name,
                    p.barcode,
                    sh.shelf_code,
                    mi.batch_number,
                    mi.expiry_date,
                    c.name as category_name
                FROM {$this->table} si
                JOIN shelf_inventory sh ON si.shelf_inventory_id = sh.id
                JOIN main_inventory mi ON sh.main_inventory_id = mi.id
                JOIN products p ON mi.product_id = p.id
                LEFT JOIN categories c ON p.category_id = c.id
                WHERE si.sale_id = ?
                ORDER BY si.id ASC";
        
        $stmt = $this->db->prepare($sql);
        $stmt->execute([$saleId]);
        return $stmt->fetchAll();
    }
}