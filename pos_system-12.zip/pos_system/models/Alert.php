<?php
require_once __DIR__ . '/../core/Model.php';

class Alert extends Model {
    protected $table = 'alerts';
    protected $primaryKey = 'id';

    /**
     * إنشاء تنبيه جديد
     */
    public function createAlert($type, $message) {
        $sql = "INSERT INTO {$this->table} (type, message, is_read) VALUES (?, ?, 0)";
        $stmt = $this->db->prepare($sql);
        return $stmt->execute([$type, $message]);
    }

    /**
     * الحصول على التنبيهات غير المقروءة
     */
    public function getUnread() {
        $sql = "SELECT * FROM {$this->table} WHERE is_read = 0 ORDER BY created_at DESC";
        $stmt = $this->db->query($sql);
        return $stmt->fetchAll();
    }

    /**
     * الحصول على جميع التنبيهات - مع LIMIT صحيح
     */
    public function getAll($limit = 100) {
        $sql = "SELECT * FROM {$this->table} ORDER BY created_at DESC LIMIT " . (int)$limit;
        $stmt = $this->db->query($sql);
        return $stmt->fetchAll();
    }

    /**
     * تحديد تنبيه كمقروء
     */
    public function markAsRead($id) {
        $sql = "UPDATE {$this->table} SET is_read = 1 WHERE id = ?";
        $stmt = $this->db->prepare($sql);
        return $stmt->execute([$id]);
    }

    /**
     * تحديد جميع التنبيهات كمقروءة
     */
    public function markAllAsRead() {
        $sql = "UPDATE {$this->table} SET is_read = 1 WHERE is_read = 0";
        $stmt = $this->db->prepare($sql);
        return $stmt->execute();
    }

    /**
     * حذف تنبيه
     */
    public function deleteAlert($id) {
        $sql = "DELETE FROM {$this->table} WHERE id = ?";
        $stmt = $this->db->prepare($sql);
        return $stmt->execute([$id]);
    }

    /**
     * التحقق من وجود تنبيهات نشطة
     */
    public function checkAlerts() {
        $alerts = [];
        
        // تنبيهات انتهاء الصلاحية
        $sql = "SELECT p.name, i.expiry_date 
                FROM main_inventory i
                JOIN products p ON i.product_id = p.id
                WHERE i.expiry_date < DATE_ADD(CURDATE(), INTERVAL 30 DAY)
                AND i.cartons_remaining > 0";
        $stmt = $this->db->query($sql);
        $expiring = $stmt->fetchAll();
        
        foreach ($expiring as $item) {
            $daysLeft = (strtotime($item['expiry_date']) - time()) / (60*60*24);
            if ($daysLeft < 0) {
                $type = 'expired';
                $message = 'منتهي الصلاحية: ' . $item['name'];
            } elseif ($daysLeft <= 7) {
                $type = 'expiry';
                $message = 'سينتهي خلال ' . round($daysLeft) . ' أيام: ' . $item['name'];
            } else {
                $type = 'expiry';
                $message = 'قريب الانتهاء: ' . $item['name'] . ' (' . round($daysLeft) . ' يوم)';
            }
            
            $alerts[] = ['type' => $type, 'message' => $message];
        }
        
        // تنبيهات المخزون المنخفض
        $sql = "SELECT p.name, SUM(i.cartons_remaining) as total_cartons
                FROM main_inventory i
                JOIN products p ON i.product_id = p.id
                GROUP BY p.id
                HAVING total_cartons < 5";
        $stmt = $this->db->query($sql);
        $lowStock = $stmt->fetchAll();
        
        foreach ($lowStock as $item) {
            $alerts[] = [
                'type' => 'stock_low',
                'message' => 'مخزون منخفض: ' . $item['name'] . ' (' . $item['total_cartons'] . ' كرتون)'
            ];
        }
        
        return $alerts;
    }

    /**
     * تحديث التنبيهات
     */
    public function refreshAlerts() {
        // حذف التنبيهات القديمة
        $sql = "DELETE FROM {$this->table} WHERE created_at < DATE_SUB(NOW(), INTERVAL 7 DAY)";
        $this->db->exec($sql);
        
        // إنشاء تنبيهات جديدة
        $newAlerts = $this->checkAlerts();
        
        foreach ($newAlerts as $alert) {
            // التحقق من عدم وجود تنبيه مماثل
            $sql = "SELECT COUNT(*) as count FROM {$this->table} 
                    WHERE type = ? AND message = ? AND is_read = 0";
            $stmt = $this->db->prepare($sql);
            $stmt->execute([$alert['type'], $alert['message']]);
            $result = $stmt->fetch();
            
            if ($result['count'] == 0) {
                $this->createAlert($alert['type'], $alert['message']);
            }
        }
    }

    /**
     * الحصول على إحصائيات التنبيهات
     */
    public function getStats() {
        $sql = "SELECT 
                COUNT(*) as total,
                COUNT(CASE WHEN type = 'expiry' THEN 1 END) as expiry_count,
                COUNT(CASE WHEN type = 'expired' THEN 1 END) as expired_count,
                COUNT(CASE WHEN type = 'stock_low' THEN 1 END) as low_stock_count,
                COUNT(CASE WHEN is_read = 0 THEN 1 END) as unread_count
                FROM {$this->table}";
        $stmt = $this->db->query($sql);
        return $stmt->fetch();
    }
}