<?php
/**
 * ملف فحص شامل لنظام الترخيص مع التحقق من الأمان ومقارنة البصمة
 * المسار: /pos_system/test_fingerprint.php
 * التاريخ: 2026-03-15
 */

// ============================================
// تهيئة النظام
// ============================================

error_reporting(E_ALL);
ini_set('display_errors', 1);

define('BASE_PATH', __DIR__ . DIRECTORY_SEPARATOR);
define('BASE_URL', 'http://localhost/pos_system');

require_once BASE_PATH . 'config/constants.php';
require_once BASE_PATH . 'config/database.php';
require_once BASE_PATH . 'core/Fingerprint.php';
require_once BASE_PATH . 'core/JWTValidator.php';
require_once BASE_PATH . 'models/LicenseModel.php';

session_start();

// ============================================
// دوال مساعدة
// ============================================

function statusBadge($status) {
    if ($status === true || $status === 'active' || $status === 'success' || $status === 'running' || $status === 'matched') {
        return '<span style="background: #28a745; color: white; padding: 3px 10px; border-radius: 20px; font-size: 12px;">✅ ناجح</span>';
    } elseif ($status === false || $status === 'inactive' || $status === 'error' || $status === 'stopped' || $status === 'mismatched') {
        return '<span style="background: #dc3545; color: white; padding: 3px 10px; border-radius: 20px; font-size: 12px;">❌ فشل</span>';
    } elseif ($status === 'warning') {
        return '<span style="background: #ffc107; color: #333; padding: 3px 10px; border-radius: 20px; font-size: 12px;">⚠️ تحذير</span>';
    } else {
        return '<span style="background: #6c757d; color: white; padding: 3px 10px; border-radius: 20px; font-size: 12px;">⏸️ غير معروف</span>';
    }
}

function securityBadge($isSecure) {
    if ($isSecure) {
        return '<span style="background: #28a745; color: white; padding: 5px 15px; border-radius: 20px; font-size: 13px;">🔒 آمن</span>';
    } else {
        return '<span style="background: #dc3545; color: white; padding: 5px 15px; border-radius: 20px; font-size: 13px;">🔓 غير آمن</span>';
    }
}

function formatBytes($bytes) {
    if ($bytes > 1024*1024) return round($bytes/1024/1024, 2) . ' MB';
    if ($bytes > 1024) return round($bytes/1024, 2) . ' KB';
    return $bytes . ' B';
}

function formatUptime($seconds) {
    $days = floor($seconds / 86400);
    $hours = floor(($seconds % 86400) / 3600);
    $minutes = floor(($seconds % 3600) / 60);
    $secs = $seconds % 60;
    
    $parts = [];
    if ($days > 0) $parts[] = $days . ' يوم';
    if ($hours > 0) $parts[] = $hours . ' ساعة';
    if ($minutes > 0) $parts[] = $minutes . ' دقيقة';
    if ($secs > 0) $parts[] = $secs . ' ثانية';
    
    return implode('، ', $parts);
}

function getServerLoad() {
    if (PHP_OS_FAMILY === 'Windows') {
        $output = shell_exec('wmic cpu get loadpercentage /value 2>&1');
        if ($output && preg_match('/LoadPercentage=(\d+)/', $output, $matches)) {
            return (int)$matches[1];
        }
        return 0;
    } else {
        $load = sys_getloadavg();
        return round($load[0] * 100, 2);
    }
}

function getMemoryUsage() {
    if (PHP_OS_FAMILY === 'Windows') {
        $output = shell_exec('wmic OS get FreePhysicalMemory,TotalVisibleMemorySize /value 2>&1');
        if ($output && preg_match('/FreePhysicalMemory=(\d+)/', $output, $free) &&
            preg_match('/TotalVisibleMemorySize=(\d+)/', $output, $total)) {
            return [
                'total' => (int)$total[1] * 1024,
                'free' => (int)$free[1] * 1024,
                'used' => ((int)$total[1] - (int)$free[1]) * 1024
            ];
        }
    } else {
        $meminfo = file_get_contents('/proc/meminfo');
        preg_match('/MemTotal:\s+(\d+)/', $meminfo, $total);
        preg_match('/MemAvailable:\s+(\d+)/', $meminfo, $available);
        if (isset($total[1]) && isset($available[1])) {
            return [
                'total' => $total[1] * 1024,
                'free' => $available[1] * 1024,
                'used' => ($total[1] - $available[1]) * 1024
            ];
        }
    }
    return null;
}

function checkSystemServices() {
    $services = [];
    
    if (PHP_OS_FAMILY === 'Windows') {
        $mysql = shell_exec('sc query MySQL 2>&1');
        $services['mysql'] = (strpos($mysql, 'RUNNING') !== false);
        
        $apache = shell_exec('sc query Apache2.4 2>&1');
        $services['apache'] = (strpos($apache, 'RUNNING') !== false);
    } else {
        $mysql = shell_exec('systemctl is-active mysql 2>&1');
        $services['mysql'] = (trim($mysql) === 'active');
        
        $apache = shell_exec('systemctl is-active apache2 2>&1');
        $services['apache'] = (trim($apache) === 'active');
    }
    
    return $services;
}

function getSessionStatus() {
    return [
        'active' => isset($_SESSION) && count($_SESSION) > 0,
        'user_logged_in' => isset($_SESSION['user_id']),
'license_activated' => isset($_SESSION['license_status']) && $_SESSION['license_status']['status'] === 'active',        'session_id' => session_id(),
        'session_count' => count($_SESSION)
    ];
}

// ============================================
// دوال التحقق الأمني ومقارنة البصمة
// ============================================

/**
 * مقارنة بصمة الجهاز الحالية مع المخزنة
 */
function compareDeviceFingerprints($current, $stored) {
    $comparison = [
        'cpu' => [
            'current' => $current['cpu'] ?? '',
            'stored' => $stored['cpu_id'] ?? $stored['cpu'] ?? '',
            'match' => ($current['cpu'] ?? '') === ($stored['cpu_id'] ?? $stored['cpu'] ?? '')
        ],
        'motherboard' => [
            'current' => $current['motherboard'] ?? '',
            'stored' => $stored['motherboard_serial'] ?? $stored['motherboard'] ?? '',
            'match' => ($current['motherboard'] ?? '') === ($stored['motherboard_serial'] ?? $stored['motherboard'] ?? '')
        ],
        'disk' => [
            'current' => $current['disk'] ?? '',
            'stored' => $stored['disk_serial'] ?? $stored['disk'] ?? '',
            'match' => ($current['disk'] ?? '') === ($stored['disk_serial'] ?? $stored['disk'] ?? '')
        ],
        'computer' => [
            'current' => $current['computer'] ?? '',
            'stored' => $stored['computer_name'] ?? $stored['computer'] ?? '',
            'match' => ($current['computer'] ?? '') === ($stored['computer_name'] ?? $stored['computer'] ?? '')
        ],
        'uuid' => [
            'current' => $current['uuid'] ?? '',
            'stored' => $stored['os_uuid'] ?? $stored['uuid'] ?? '',
            'match' => ($current['uuid'] ?? '') === ($stored['os_uuid'] ?? $stored['uuid'] ?? '')
        ]
    ];
    
    $allMatch = true;
    foreach ($comparison as $key => $data) {
        if (!$data['match']) {
            $allMatch = false;
            break;
        }
    }
    
    return [
        'details' => $comparison,
        'all_match' => $allMatch
    ];
}

/**
 * التحقق من محاولات السرقة (تغيير الجهاز)
 */
function checkTheftAttempts($db) {
    try {
        // البحث عن تراخيص تم إبطالها بسبب تغيير الجهاز
        $stmt = $db->query("
            SELECT l.*, d.computer_name, d.cpu_id, ll.details, ll.created_at
            FROM licenses l
            JOIN license_logs ll ON l.id = ll.license_id
            JOIN devices d ON l.device_id = d.id
            WHERE ll.action = 'device_changed'
            ORDER BY ll.created_at DESC
            LIMIT 10
        ");
        return $stmt->fetchAll();
    } catch (Exception $e) {
        return [];
    }
}

/**
 * التحقق من محاولات التفعيل الفاشلة
 */
function checkFailedAttempts($db) {
    try {
        $stmt = $db->query("
            SELECT * FROM license_logs 
            WHERE action = 'failed_activation' 
            ORDER BY created_at DESC 
            LIMIT 10
        ");
        return $stmt->fetchAll();
    } catch (Exception $e) {
        return [];
    }
}

/**
 * التحقق من التراخيص المنتهية
 */
function checkExpiredLicenses($db) {
    try {
        $stmt = $db->query("
            SELECT l.*, d.computer_name 
            FROM licenses l
            JOIN devices d ON l.device_id = d.id
            WHERE l.status = 'expired'
            ORDER BY l.expiry_date DESC
            LIMIT 10
        ");
        return $stmt->fetchAll();
    } catch (Exception $e) {
        return [];
    }
}

// ============================================
// بدء الاختبارات
// ============================================

$start_time = $_SERVER['REQUEST_TIME'] ?? time();
$uptime = time() - $start_time;
$server_load = getServerLoad();
$memory = getMemoryUsage();
$services = checkSystemServices();
$session_status = getSessionStatus();

// جمع بصمة الجهاز الحالي
$fingerprint = new Fingerprint();
$current_device = $fingerprint->collect();
$fingerprint_key = $fingerprint->generateFingerprintKey();

// الاتصال بقاعدة البيانات
$db = Database::getInstance();

// البحث عن الترخيص النشط للجهاز الحالي
$active_license = null;
$stored_device = null;
$comparison_result = null;

try {
    $sql = "SELECT l.*, d.* FROM licenses l
            JOIN devices d ON l.device_id = d.id
            WHERE d.cpu_id = :cpu 
            AND d.motherboard_serial = :mb 
            AND d.disk_serial = :disk
            AND l.status = 'active'
            ORDER BY l.id DESC LIMIT 1";
    
    $stmt = $db->prepare($sql);
    $stmt->execute([
        'cpu' => $current_device['cpu'],
        'mb' => $current_device['motherboard'],
        'disk' => $current_device['disk']
    ]);
    
    $active_license = $stmt->fetch();
    
    if ($active_license) {
        $stored_device = [
            'cpu_id' => $active_license['cpu_id'],
            'motherboard_serial' => $active_license['motherboard_serial'],
            'disk_serial' => $active_license['disk_serial'],
            'computer_name' => $active_license['computer_name'],
            'os_uuid' => $active_license['os_uuid']
        ];
        $comparison_result = compareDeviceFingerprints($current_device, $stored_device);
    }
} catch (Exception $e) {
    // تجاهل الخطأ
}

// جلب آخر التحققات
$verifications = [];
try {
    $stmt = $db->query("SELECT * FROM license_verifications ORDER BY verified_at DESC LIMIT 10");
    $verifications = $stmt->fetchAll();
} catch (Exception $e) {
    // جدول غير موجود
}

// جلب محاولات السرقة
$theft_attempts = checkTheftAttempts($db);

// جلب المحاولات الفاشلة
$failed_attempts = checkFailedAttempts($db);

// جلب التراخيص المنتهية
$expired_licenses = checkExpiredLicenses($db);

?>
<!DOCTYPE html>
<html dir="rtl" lang="ar">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>🔐 فحص أمني شامل لنظام الترخيص</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Tajawal', 'Segoe UI', sans-serif;
            background: #f4f7fa;
            padding: 30px;
        }
        
        .container {
            max-width: 1400px;
            margin: 0 auto;
        }
        
        h1 {
            text-align: center;
            color: #1a1a2e;
            margin-bottom: 30px;
            font-size: 32px;
        }
        
        .header {
            background: white;
            border-radius: 12px;
            padding: 25px;
            margin-bottom: 30px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.05);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .timestamp {
            color: #666;
            font-size: 14px;
        }
        
        .security-header {
            background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
            color: white;
            padding: 20px;
            border-radius: 12px;
            margin-bottom: 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .security-title {
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .stat-card {
            background: white;
            border-radius: 12px;
            padding: 20px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.05);
        }
        
        .stat-title {
            font-size: 14px;
            color: #666;
            margin-bottom: 10px;
        }
        
        .stat-value {
            font-size: 28px;
            font-weight: bold;
            color: #1a1a2e;
        }
        
        .test-section {
            background: white;
            border-radius: 12px;
            padding: 25px;
            margin-bottom: 30px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.05);
        }
        
        .section-title {
            font-size: 20px;
            color: #1a1a2e;
            margin-bottom: 20px;
            padding-bottom: 10px;
            border-bottom: 2px solid #f0f0f0;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .test-table {
            width: 100%;
            border-collapse: collapse;
        }
        
        .test-table th {
            text-align: right;
            padding: 12px;
            background: #f8f9fa;
            color: #495057;
            font-weight: 600;
            font-size: 14px;
        }
        
        .test-table td {
            padding: 12px;
            border-bottom: 1px solid #f0f0f0;
            font-size: 14px;
        }
        
        .test-table tr:hover {
            background: #f8f9fa;
        }
        
        .code-box {
            background: #1a1a2e;
            color: #fff;
            padding: 20px;
            border-radius: 8px;
            font-family: 'Courier New', monospace;
            font-size: 14px;
            overflow-x: auto;
            margin: 15px 0;
            direction: ltr;
            text-align: left;
        }
        
        .success-badge {
            background: #d4edda;
            color: #155724;
            padding: 8px 15px;
            border-radius: 20px;
            font-size: 14px;
            display: inline-block;
        }
        
        .error-badge {
            background: #f8d7da;
            color: #721c24;
            padding: 8px 15px;
            border-radius: 20px;
            font-size: 14px;
            display: inline-block;
        }
        
        .warning-badge {
            background: #fff3cd;
            color: #856404;
            padding: 8px 15px;
            border-radius: 20px;
            font-size: 14px;
            display: inline-block;
        }
        
        .key-display {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 20px;
            border-radius: 8px;
            margin: 15px 0;
            word-break: break-all;
            font-family: monospace;
            direction: ltr;
            text-align: left;
        }
        
        .progress-bar {
            width: 100%;
            height: 10px;
            background: #f0f0f0;
            border-radius: 5px;
            overflow: hidden;
            margin: 10px 0;
        }
        
        .progress-fill {
            height: 100%;
            background: linear-gradient(90deg, #28a745, #20c997);
            border-radius: 5px;
            transition: width 0.3s ease;
        }
        
        .btn {
            background: #1a1a2e;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 6px;
            cursor: pointer;
            font-size: 14px;
            transition: all 0.3s;
            margin: 5px;
        }
        
        .btn:hover {
            background: #16213e;
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(26,26,46,0.3);
        }
        
        .btn-success {
            background: #28a745;
        }
        
        .btn-success:hover {
            background: #218838;
        }
        
        .btn-danger {
            background: #dc3545;
        }
        
        .btn-danger:hover {
            background: #c82333;
        }
        
        .device-info {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 15px;
            margin: 20px 0;
        }
        
        .info-card {
            background: #f8f9fa;
            padding: 15px;
            border-radius: 8px;
            border-right: 3px solid #1a1a2e;
        }
        
        .info-label {
            font-size: 12px;
            color: #666;
            margin-bottom: 5px;
        }
        
        .info-value {
            font-family: monospace;
            font-size: 14px;
            color: #1a1a2e;
            word-break: break-all;
        }
        
        .status-indicator {
            display: inline-block;
            width: 12px;
            height: 12px;
            border-radius: 50%;
            margin-left: 5px;
        }
        
        .status-running { background: #28a745; box-shadow: 0 0 10px #28a745; animation: pulse 2s infinite; }
        .status-stopped { background: #dc3545; }
        .status-warning { background: #ffc107; }
        
        @keyframes pulse {
            0% { opacity: 1; transform: scale(1); }
            50% { opacity: 0.5; transform: scale(1.1); }
            100% { opacity: 1; transform: scale(1); }
        }
        
        .live-indicator {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 10px 20px;
            background: #1a1a2e;
            color: white;
            border-radius: 30px;
            font-size: 14px;
        }
        
        .comparison-row {
            display: flex;
            justify-content: space-between;
            padding: 10px;
            margin: 5px 0;
            background: #f8f9fa;
            border-radius: 5px;
        }
        
        .match-yes { color: #28a745; font-weight: bold; }
        .match-no { color: #dc3545; font-weight: bold; }
    </style>
</head>
<body>
    <div class="container">
        <h1>🔐 فحص أمني شامل لنظام الترخيص</h1>
        
        <!-- الهيدر الأمني -->
        <div class="security-header">
            <div class="security-title">
                <span style="font-size: 24px;">🛡️</span>
                <div>
                    <h2>الوضع الأمني للنظام</h2>
                    <p>آخر تحديث: <?php echo date('Y-m-d H:i:s'); ?></p>
                </div>
            </div>
            <div>
                <?php 
                $isSecure = $active_license && $comparison_result && $comparison_result['all_match'];
                echo securityBadge($isSecure);
                ?>
            </div>
        </div>
        
        <!-- بطاقات سريعة -->
        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-title">⏱️ وقت التشغيل</div>
                <div class="stat-value"><?php echo formatUptime($uptime); ?></div>
            </div>
            <div class="stat-card">
                <div class="stat-title">🔑 حالة الترخيص</div>
                <div class="stat-value"><?php echo $active_license ? 'مفعل' : 'غير مفعل'; ?></div>
            </div>
            <div class="stat-card">
                <div class="stat-title">📊 محاولات فاشلة</div>
                <div class="stat-value"><?php echo count($failed_attempts); ?></div>
            </div>
            <div class="stat-card">
                <div class="stat-title">⚠️ إنذارات أمنية</div>
                <div class="stat-value"><?php echo count($theft_attempts); ?></div>
            </div>
        </div>
        
        <!-- ========== قسم مقارنة البصمة والأمان ========== -->
        <div class="test-section">
            <div class="section-title">
                <span>🔬</span>
                <span>1. مقارنة بصمة الجهاز (التحقق من السرقة)</span>
            </div>
            
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
                <!-- العمود الأيمن: الجهاز الحالي -->
                <div style="background: #f8f9fa; padding: 20px; border-radius: 8px;">
                    <h3 style="margin-bottom: 15px; color: #1a1a2e;">🖥️ الجهاز الحالي</h3>
                    <?php foreach ($current_device as $key => $value): ?>
                    <div class="comparison-row">
                        <span><strong><?php echo $key; ?>:</strong></span>
                        <span style="font-family: monospace;"><?php echo htmlspecialchars($value); ?></span>
                    </div>
                    <?php endforeach; ?>
                    <p style="margin-top: 15px;">🔑 بصمة الجهاز: <code><?php echo $fingerprint_key; ?></code></p>
                </div>
                
                <!-- العمود الأيسر: الجهاز المخزن -->
                <div style="background: #f8f9fa; padding: 20px; border-radius: 8px;">
                    <h3 style="margin-bottom: 15px; color: #1a1a2e;">💾 الجهاز المخزن في قاعدة البيانات</h3>
                    <?php if ($stored_device): ?>
                        <?php foreach ($stored_device as $key => $value): ?>
                        <div class="comparison-row">
                            <span><strong><?php echo $key; ?>:</strong></span>
                            <span style="font-family: monospace;"><?php echo htmlspecialchars($value); ?></span>
                        </div>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <p style="color: #999; text-align: center;">لا يوجد جهاز مخزن</p>
                    <?php endif; ?>
                </div>
            </div>
            
            <!-- نتائج المقارنة -->
            <?php if ($comparison_result): ?>
            <div style="margin-top: 20px; padding: 20px; background: <?php echo $comparison_result['all_match'] ? '#d4edda' : '#f8d7da'; ?>; border-radius: 8px;">
                <h4 style="margin-bottom: 15px;">📊 نتائج المقارنة:</h4>
                
                <table class="test-table">
                    <thead>
                        <tr>
                            <th>المكون</th>
                            <th>الحالي</th>
                            <th>المخزن</th>
                            <th>التطابق</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($comparison_result['details'] as $key => $data): ?>
                        <tr>
                            <td><strong><?php echo $key; ?></strong></td>
                            <td><code><?php echo htmlspecialchars($data['current']); ?></code></td>
                            <td><code><?php echo htmlspecialchars($data['stored']); ?></code></td>
                            <td><?php echo $data['match'] ? '✅' : '❌'; ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                
                <div style="margin-top: 15px; text-align: center;">
                    <?php if ($comparison_result['all_match']): ?>
                    <span class="success-badge">✅ الجهاز متطابق - لا توجد محاولة سرقة</span>
                    <?php else: ?>
                    <span class="error-badge">🚨 تحذير: الجهاز غير متطابق! قد تكون هناك محاولة سرقة</span>
                    <?php endif; ?>
                </div>
            </div>
            <?php endif; ?>
        </div>
        
        <!-- ========== قسم التحقق من الترخيص ========== -->
        <div class="test-section">
            <div class="section-title">
                <span>📋</span>
                <span>2. حالة الترخيص الحالية</span>
            </div>
            
            <?php if ($active_license): ?>
            <table class="test-table">
                <tr>
                    <th>المعلومة</th>
                    <th>القيمة</th>
                </tr>
                <tr>
                    <td>حالة الترخيص</td>
                    <td><?php echo statusBadge('active'); ?></td>
                </tr>
                <tr>
                    <td>مفتاح الترخيص</td>
                    <td><code><?php echo $active_license['license_key']; ?></code></td>
                </tr>
                <tr>
                    <td>تاريخ الانتهاء</td>
                    <td><?php echo $active_license['expiry_date']; ?></td>
                </tr>
                <tr>
                    <td>تاريخ التفعيل</td>
                    <td><?php echo $active_license['activated_at']; ?></td>
                </tr>
                <tr>
                    <td>آخر تحقق</td>
                    <td><?php echo $active_license['last_verified'] ?? 'لم يتم التحقق بعد'; ?></td>
                </tr>
            </table>
            
            <?php
            // حساب الأيام المتبقية
            $expiry = new DateTime($active_license['expiry_date']);
            $now = new DateTime();
            $days_remaining = $now->diff($expiry)->days;
            ?>
            <div style="margin-top: 15px;">
                <div style="display: flex; justify-content: space-between; margin-bottom: 5px;">
                    <span>الأيام المتبقية: <strong><?php echo $days_remaining; ?></strong></span>
                    <span><?php echo $days_remaining < 7 ? '⚠️ قريب من الانتهاء' : '✅ طبيعي'; ?></span>
                </div>
                <div class="progress-bar">
                    <?php 
                    $total_days = 365; // نفترض سنة
                    $percent = min(($days_remaining / $total_days) * 100, 100);
                    ?>
                    <div class="progress-fill" style="width: <?php echo $percent; ?>%;"></div>
                </div>
            </div>
            
            <?php else: ?>
            <p style="text-align: center; color: #999; padding: 30px;">لا يوجد ترخيص نشط لهذا الجهاز</p>
            <?php endif; ?>
        </div>
        
        <!-- ========== قسم سجل التحققات ========== -->
        <div class="test-section">
            <div class="section-title">
                <span>📝</span>
                <span>3. آخر التحققات (license_verifications)</span>
            </div>
            
            <?php if (!empty($verifications)): ?>
            <table class="test-table">
                <thead>
                    <tr>
                        <th>التاريخ</th>
                        <th>معرف الترخيص</th>
                        <th>الحالة</th>
                        <th>IP</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($verifications as $v): ?>
                    <tr>
                        <td><?php echo $v['verified_at']; ?></td>
                        <td><?php echo $v['license_id']; ?></td>
                        <td><?php echo statusBadge($v['verification_status'] === 'success'); ?></td>
                        <td><?php echo $v['ip_address'] ?? '-'; ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            <?php else: ?>
            <p style="text-align: center; color: #999; padding: 20px;">لا توجد سجلات تحقق بعد</p>
            <?php endif; ?>
        </div>
        
        <!-- ========== قسم المحاولات الفاشلة ========== -->
        <div class="test-section">
            <div class="section-title">
                <span>🚫</span>
                <span>4. محاولات التفعيل الفاشلة (أمن)</span>
            </div>
            
            <?php if (!empty($failed_attempts)): ?>
            <table class="test-table">
                <thead>
                    <tr>
                        <th>التاريخ</th>
                        <th>السبب</th>
                        <th>IP</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($failed_attempts as $attempt): ?>
                    <tr>
                        <td><?php echo $attempt['created_at']; ?></td>
                        <td><?php echo htmlspecialchars($attempt['details']); ?></td>
                        <td><?php echo $attempt['ip_address'] ?? '-'; ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            <?php else: ?>
            <p style="text-align: center; color: #28a745; padding: 20px;">✅ لا توجد محاولات فاشلة - النظام آمن</p>
            <?php endif; ?>
        </div>
        
        <!-- ========== قسم محاولات السرقة ========== -->
        <div class="test-section">
            <div class="section-title">
                <span>🚨</span>
                <span>5. محاولات تغيير الجهاز (سرقة)</span>
            </div>
            
            <?php if (!empty($theft_attempts)): ?>
            <table class="test-table">
                <thead>
                    <tr>
                        <th>التاريخ</th>
                        <th>الجهاز</th>
                        <th>التفاصيل</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($theft_attempts as $attempt): ?>
                    <tr>
                        <td><?php echo $attempt['created_at']; ?></td>
                        <td><?php echo $attempt['computer_name'] ?? 'غير معروف'; ?></td>
                        <td><?php echo htmlspecialchars($attempt['details']); ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            <?php else: ?>
            <p style="text-align: center; color: #28a745; padding: 20px;">✅ لا توجد محاولات تغيير جهاز - النظام آمن</p>
            <?php endif; ?>
        </div>
        
        <!-- ========== قسم التراخيص المنتهية ========== -->
        <div class="test-section">
            <div class="section-title">
                <span>⏰</span>
                <span>6. التراخيص المنتهية</span>
            </div>
            
            <?php if (!empty($expired_licenses)): ?>
            <table class="test-table">
                <thead>
                    <tr>
                        <th>المفتاح</th>
                        <th>الجهاز</th>
                        <th>تاريخ الانتهاء</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($expired_licenses as $license): ?>
                    <tr>
                        <td><code><?php echo substr($license['license_key'], 0, 20); ?>...</code></td>
                        <td><?php echo $license['computer_name'] ?? 'غير معروف'; ?></td>
                        <td><?php echo $license['expiry_date']; ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            <?php else: ?>
            <p style="text-align: center; color: #28a745; padding: 20px;">✅ لا توجد تراخيص منتهية</p>
            <?php endif; ?>
        </div>
        
        <!-- ========== معلومات النظام ========== -->
        <div class="test-section">
            <div class="section-title">
                <span>⚙️</span>
                <span>7. معلومات النظام والجلسة</span>
            </div>
            
            <table class="test-table">
                <tr>
                    <th>الخاصية</th>
                    <th>القيمة</th>
                </tr>
                <tr>
                    <td>الجلسة نشطة</td>
                    <td><?php echo statusBadge($session_status['active']); ?></td>
                </tr>
                <tr>
                    <td>مستخدم مسجل</td>
                    <td><?php echo statusBadge($session_status['user_logged_in']); ?></td>
                </tr>
                <tr>
                    <td>الترخيص مفعل في الجلسة</td>
                    <td><?php echo statusBadge($session_status['license_activated']); ?></td>
                </tr>
                <tr>
                    <td>معرف الجلسة</td>
                    <td><code><?php echo $session_status['session_id'] ?: '-'; ?></code></td>
                </tr>
                <tr>
                    <td>MySQL</td>
                    <td><?php echo statusBadge($services['mysql'] ?? false); ?></td>
                </tr>
                <tr>
                    <td>Apache</td>
                    <td><?php echo statusBadge($services['apache'] ?? false); ?></td>
                </tr>
                <?php if ($memory): ?>
                <tr>
                    <td>الذاكرة المستخدمة</td>
                    <td><?php echo formatBytes($memory['used']); ?> من <?php echo formatBytes($memory['total']); ?></td>
                </tr>
                <?php endif; ?>
            </table>
        </div>
        
        <!-- الأزرار -->
        <div style="text-align: center; margin-top: 30px;">
            <button class="btn" onclick="location.reload()">🔄 إعادة الفحص</button>
            <button class="btn btn-success" onclick="window.location.href='license'">📋 صفحة الترخيص</button>
            <button class="btn btn-danger" onclick="if(confirm('⚠️ هل أنت متأكد؟')) window.location.href='license/reset'">⚠️ إعادة تعيين</button>
        </div>
    </div>
    
    <script>
    // تحديث الساعة مباشرة
    function updateClock() {
        const now = new Date();
        const hours = String(now.getHours()).padStart(2, '0');
        const minutes = String(now.getMinutes()).padStart(2, '0');
        const seconds = String(now.getSeconds()).padStart(2, '0');
        const clockElements = document.querySelectorAll('.live-clock');
        clockElements.forEach(el => el.textContent = `${hours}:${minutes}:${seconds}`);
    }
    setInterval(updateClock, 1000);
    </script>
</body>
</html>