<?php
require_once __DIR__ . '/core/Database.php';

try {
    $db = Database::getInstance()->getConnection();
    $stmt = $db->query("SHOW CREATE TABLE shelf_inventory");
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    echo $result['Create Table'];
} catch (Exception $e) {
    echo "Error: " . $e->getMessage();
}
