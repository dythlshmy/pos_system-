<?php
/**
 * تحكم الترخيص - متوافق مع نظام المطور (JWT)
 * الإصدار: 2.0
 * التاريخ: 2026-03-14
 */

class LicenseController extends Controller {
    
    private $licenseModel;
    private $fingerprint;
    private $jwtValidator;
    
    /**
     * المُنشئ - تهيئة الكلاسات المطلوبة
     */
    public function __construct() {
        parent::__construct();
        $this->licenseModel = new LicenseModel();
        $this->fingerprint = new Fingerprint();
        
        // تحميل JWTValidator إذا كان موجوداً
        if (file_exists(BASE_PATH . 'core/JWTValidator.php')) {
            require_once BASE_PATH . 'core/JWTValidator.php';
            $this->jwtValidator = new JWTValidator();
        }
    }
    
    /**
     * صفحة الترخيص الرئيسية
     * يتم عرضها عند عدم وجود ترخيص أو انتهاء صلاحيته
     */
    public function index() {
        // التحقق من حالة الترخيص الحالية
        $status = $this->licenseModel->checkLicenseStatus();
        
        // إذا كان الترخيص نشطاً، انتقل إلى صفحة تسجيل الدخول
        if ($status['status'] === 'active') {
            header('Location: ' . BASE_URL . '/login');
            exit;
        }
        
        // تجهيز البيانات لعرضها في الصفحة
        $data = [
            'page_title' => 'تفعيل الترخيص',
            'status' => $status,
            'fingerprint' => $this->fingerprint->generateFingerprintKey(),
            'current_year' => date('Y')
        ];
        
        // عرض صفحة الترخيص
        $this->view('license/index', $data);
    }
    
    /**
     * تفعيل الترخيص - يستقبل المفتاح من المستخدم ويتحقق منه
     * يستخدم JWTValidator للتحقق من صحة المفتاح
     */
   /**
 * تفعيل الترخيص - يستقبل المفتاح من المستخدم ويتحقق منه
 * يستخدم JWTValidator للتحقق من صحة المفتاح
 */
public function activate() {
    header('Content-Type: application/json');
    
    try {
        $license_key = trim($_POST['license_key'] ?? '');
        
        if (empty($license_key)) {
            throw new Exception('الرجاء إدخال مفتاح الترخيص');
        }
        
        // 1. التحقق من المفتاح
        $validator = new JWTValidator();
        $validation = $validator->validateLicense($license_key);
        
        if (!$validation['success']) {
            throw new Exception($validation['message']);
        }
        
        // 2. جمع بصمة الجهاز
        $current_device = $this->fingerprint->collect();
        
        // 3. مقارنة البيانات
        if ($validation['device_data']['cpu'] !== $current_device['cpu'] ||
            $validation['device_data']['motherboard'] !== $current_device['motherboard'] ||
            $validation['device_data']['disk'] !== $current_device['disk'] ||
            $validation['device_data']['computer'] !== $current_device['computer'] ||
            $validation['device_data']['uuid'] !== $current_device['uuid']) {
            throw new Exception("هذا المفتاح غير مخصص لهذا الجهاز");
        }
        
        // 4. حفظ الترخيص
        $save_result = $this->licenseModel->activateLicense(
            $license_key,
            $current_device,
            $validation['expiry_date']
        );
        
        if (!$save_result['success']) {
            throw new Exception($save_result['message']);
        }
        
        // ========== ✅ تعيين متغيرات الجلسة ==========
        $_SESSION['license_activated'] = true;
        $_SESSION['license_expiry'] = $validation['expiry_date'];
        $_SESSION['license_days'] = $validation['days_remaining'] ?? 0;
        $_SESSION['license_key'] = $license_key;
        $_SESSION['success_message'] = '✅ تم تفعيل الترخيص بنجاح. الرجاء تسجيل الدخول.';
        
        // 5. نجاح
        echo json_encode([
            'success' => true,
            'message' => '✅ تم تفعيل النظام بنجاح',
            'redirect' => BASE_URL . '/login'
        ]);
        
    } catch (Exception $e) {
        echo json_encode([
            'success' => false,
            'message' => $e->getMessage()
        ]);
    }
}
    /**
     * الحصول على بصمة الجهاز الحالية (API)
     */
    public function fingerprint() {
        try {
            $fingerprint_key = $this->fingerprint->generateFingerprintKey();
            $device_data = $this->fingerprint->collect();
            
            $this->json([
                'success' => true,
                'fingerprint' => $fingerprint_key,
                'device_info' => [
                    'cpu' => $this->maskString($device_data['cpu']),
                    'motherboard' => $this->maskString($device_data['motherboard']),
                    'disk' => $this->maskString($device_data['disk']),
                    'computer' => $device_data['computer'],
                    'uuid' => $this->maskString($device_data['uuid'])
                ]
            ]);
        } catch (Exception $e) {
            $this->json([
                'success' => false,
                'message' => 'فشل جمع بصمة الجهاز: ' . $e->getMessage()
            ]);
        }
    }
    
    /**
     * التحقق من حالة الترخيص الحالية (API)
     */
    public function status() {
        try {
            $status = $this->licenseModel->checkLicenseStatus();
            
            // إضافة معلومات إضافية
            if ($status['status'] === 'active') {
                $status['message'] = 'الترخيص ساري المفعول';
                $status['can_access'] = true;
            } else {
                $status['can_access'] = false;
                $status['redirect'] = BASE_URL . '/license';
            }
            
            $this->json($status);
        } catch (Exception $e) {
            $this->json([
                'success' => false,
                'status' => 'error',
                'message' => $e->getMessage()
            ]);
        }
    }
    
    /**
     * تشخيص المفتاح (للمساعدة في حل المشاكل)
     * يمكن الوصول إليها عبر /license/debug?key=POS-XXXX...
     */
    public function debug() {
        // التحقق من صلاحية المدير فقط
        $this->requireAdmin();
        
        $license_key = $_GET['key'] ?? '';
        
        if (empty($license_key)) {
            $this->json([
                'success' => false,
                'message' => 'الرجاء توفير مفتاح للتحليل'
            ]);
        }
        
        if (!$this->jwtValidator) {
            $this->json([
                'success' => false,
                'message' => 'JWTValidator غير موجود'
            ]);
        }
        
        $debug_info = $this->jwtValidator->debugKey($license_key);
        $this->json($debug_info);
    }
    
    /**
     * إعادة تعيين الترخيص (مسح الترخيص الحالي)
     * للاستخدام في حالات الطوارئ فقط
     */
    public function reset() {
        // التحقق من صلاحية المدير فقط
        $this->requireAdmin();
        
        try {
            $result = $this->licenseModel->resetLicense();
            
            if ($result) {
                session_destroy();
                $this->json([
                    'success' => true,
                    'message' => 'تم إعادة تعيين الترخيص بنجاح'
                ]);
            } else {
                $this->json([
                    'success' => false,
                    'message' => 'فشل إعادة تعيين الترخيص'
                ]);
            }
        } catch (Exception $e) {
            $this->json([
                'success' => false,
                'message' => $e->getMessage()
            ]);
        }
    }
    
    /**
     * إخفاء جزء من النص للعرض (لأغراض الأمان)
     */
    private function maskString($string, $visible_chars = 8) {
        if (strlen($string) <= $visible_chars) {
            return $string;
        }
        
        $first = substr($string, 0, 4);
        $last = substr($string, -4);
        $masked = str_repeat('*', min(8, strlen($string) - 8));
        
        return $first . $masked . $last;
    }
// ============================================
// الدوال المساعدة
// ============================================



}