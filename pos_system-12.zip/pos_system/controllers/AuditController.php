<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once __DIR__ . '/../core/Controller.php';
require_once __DIR__ . '/../core/Auth.php';
require_once __DIR__ . '/../core/Middleware.php';
require_once __DIR__ . '/../models/Audit.php';
require_once __DIR__ . '/../models/AuditItem.php';
require_once __DIR__ . '/../models/Product.php';
require_once __DIR__ . '/../models/Inventory.php';
require_once __DIR__ . '/../models/ActivityLog.php';

class AuditController extends Controller {
    
    private $auditModel;
    private $auditItemModel;
    private $productModel;
    private $inventoryModel;
    private $logModel;

    public function __construct() {
        if (!Auth::check()) {
            $this->redirect('login');
        }

        if (!Auth::isAdmin()) {
            header("HTTP/1.0 403 Forbidden");
            die("غير مصرح بالدخول");
        }

        $this->auditModel = new Audit();
        $this->auditItemModel = new AuditItem();
        $this->productModel = new Product();
        $this->inventoryModel = new Inventory();
        $this->logModel = new ActivityLog();
    }

    /**
     * عرض صفحة الجرد
     */
    public function index() {
        $audits = $this->auditModel->getAllWithUser();
        $stats = $this->auditModel->getStats();
        
        $this->view('audit/index', [
            'title' => 'جرد المخزون',
            'audits' => $audits,
            'stats' => $stats
        ]);
    }

    /**
     * بدء جرد جديد
     */
    public function start() {
        header('Content-Type: application/json; charset=utf-8');
        
        try {
            $auditId = $this->auditModel->startAudit(Auth::id());
            $this->logModel->log('start_audit', 'بدأ جرد جديد رقم: ' . $auditId);
            
            echo json_encode([
                'success' => true,
                'audit_id' => $auditId,
                'message' => 'تم بدء الجرد بنجاح'
            ], JSON_UNESCAPED_UNICODE);
            exit;
        } catch (Exception $e) {
            echo json_encode([
                'success' => false,
                'message' => 'خطأ في بدء الجرد: ' . $e->getMessage()
            ], JSON_UNESCAPED_UNICODE);
            exit;
        }
    }

    /**
     * الحصول على المنتجات للجرد
     */
     public function getProducts() {
        try {
            $products = $this->productModel->getAllWithCategory();
            
            foreach ($products as &$product) {
                // حساب الكميات بشكل دقيق من المستودع والرف
                $product['main_qty'] = $this->getMainInventoryQty($product['id']);
                $product['shelf_qty'] = $this->getShelfInventoryQty($product['id']);
                $product['expected_qty'] = $product['main_qty'] + $product['shelf_qty'];
                $product['actual_qty'] = $product['expected_qty'];
            }
            
            $this->json(['success' => true, 'data' => $products]);
            
        } catch (Exception $e) {
            $this->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }
    
    private function getMainInventoryQty($productId) {
        $sql = "SELECT COALESCE(SUM(cartons_remaining * units_per_carton), 0) as total
                FROM main_inventory WHERE product_id = ? AND cartons_remaining > 0";
        $stmt = $this->inventoryModel->db->prepare($sql);
        $stmt->execute([$productId]);
        $row = $stmt->fetch();
        return (int)($row['total'] ?? 0);
    }

    private function getShelfInventoryQty($productId) {
        $sql = "SELECT COALESCE(SUM(s.units_remaining), 0) as total
                FROM shelf_inventory s
                JOIN main_inventory i ON s.main_inventory_id = i.id
                WHERE i.product_id = ? AND s.units_remaining > 0";
        $stmt = $this->inventoryModel->db->prepare($sql);
        $stmt->execute([$productId]);
        $row = $stmt->fetch();
        return (int)($row['total'] ?? 0);
    }

    private function getCategoryName($categoryId) {
        if (!$categoryId) return 'غير محدد';
        $sql = "SELECT name FROM categories WHERE id = ?";
        $stmt = $this->inventoryModel->db->prepare($sql);
        $stmt->execute([$categoryId]);
        $row = $stmt->fetch();
        return $row['name'] ?? 'غير محدد';
    }

    /**
     * حفظ عنصر جرد
     */
    public function saveItem() {
        header('Content-Type: application/json; charset=utf-8');
        
        if (!$this->isPost()) {
            echo json_encode(['success' => false, 'message' => 'طريقة طلب غير صحيحة']);
            exit;
        }

        $auditId = (int)$this->getPost('audit_id');
        $productId = (int)$this->getPost('product_id');
        $expectedQty = (int)$this->getPost('expected_qty');
        $actualQty = (int)$this->getPost('actual_qty');
        $reason = $this->getPost('reason', '');

        if (!$auditId || !$productId) {
            echo json_encode(['success' => false, 'message' => 'جميع الحقول مطلوبة']);
            exit;
        }

        try {
            $result = $this->auditItemModel->addItem($auditId, $productId, $expectedQty, $actualQty, $reason);
            
            if ($result) {
                $product = $this->productModel->find($productId);
                $diff = $actualQty - $expectedQty;
                $diffText = $diff > 0 ? 'زيادة' : ($diff < 0 ? 'عجز' : 'مطابق');
                $this->logModel->log('audit_item', 'تم جرد: ' . ($product['name'] ?? 'منتج') . ' - ' . $diffText . ' (' . abs($diff) . ')');
                
                echo json_encode([
                    'success' => true, 
                    'message' => 'تم حفظ الجرد',
                    'difference' => $diff
                ]);
                exit;
            } else {
                echo json_encode(['success' => false, 'message' => 'فشل في الحفظ']);
                exit;
            }
        } catch (Exception $e) {
            echo json_encode(['success' => false, 'message' => 'خطأ: ' . $e->getMessage()]);
            exit;
        }
    }

    /**
     * إنهاء الجرد
     */
    public function complete() {
        header('Content-Type: application/json; charset=utf-8');
        
        if (!$this->isPost()) {
            echo json_encode(['success' => false, 'message' => 'طريقة طلب غير صحيحة']);
            exit;
        }

        $auditId = (int)$this->getPost('audit_id');
        if (!$auditId) {
            echo json_encode(['success' => false, 'message' => 'معرف الجرد مطلوب']);
            exit;
        }
        
        try {
            $stats = $this->auditItemModel->getStatsByAuditId($auditId);
            $totalDiscrepancy = $stats['total_discrepancy'] ?? 0;
            
            $result = $this->auditModel->completeAudit($auditId, $totalDiscrepancy);
            
            if ($result) {
                $this->logModel->log('complete_audit', 'تم إنهاء الجرد رقم: ' . $auditId . ' - الفروقات: ' . $totalDiscrepancy);
                echo json_encode([
                    'success' => true, 
                    'message' => 'تم إنهاء الجرد',
                    'stats' => $stats
                ]);
                exit;
            } else {
                echo json_encode(['success' => false, 'message' => 'فشل في إنهاء الجرد']);
                exit;
            }
        } catch (Exception $e) {
            echo json_encode(['success' => false, 'message' => 'خطأ: ' . $e->getMessage()]);
            exit;
        }
    }

    /**
     * عرض تقرير الجرد
     */
    public function report($auditId) {
        $auditId = (int)$auditId;
        
        $audit = $this->auditModel->getAudit($auditId);
        if (!$audit) {
            $this->redirect('audit');
            return;
        }
        
        $items = $this->auditItemModel->getByAuditId($auditId);
        $stats = $this->auditItemModel->getStatsByAuditId($auditId);
        
        $data = [
            'title' => 'تقرير الجرد',
            'audit' => $audit,
            'items' => $items,
            'stats' => $stats
        ];
        
        $this->view('audit/report', $data);
    }

    /**
     * تصدير تقرير الجرد إلى CSV
     */
    public function export($auditId) {
        $auditId = (int)$auditId;
        
        $audit = $this->auditModel->getAudit($auditId);
        if (!$audit) {
            $this->redirect('audit');
            return;
        }
        
        $items = $this->auditItemModel->getByAuditId($auditId);
        $stats = $this->auditItemModel->getStatsByAuditId($auditId);
        
        $filename = 'audit_report_' . $auditId . '_' . date('Y-m-d') . '.csv';
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        
        $output = fopen('php://output', 'w');
        fprintf($output, chr(0xEF).chr(0xBB).chr(0xBF)); // BOM للعربية
        
        fputcsv($output, ['تقرير الجرد رقم: ' . $auditId]);
        fputcsv($output, ['التاريخ: ' . $audit['audit_date']]);
        fputcsv($output, ['المسؤول: ' . ($audit['user_name'] ?? 'غير معروف')]);
        fputcsv($output, ['الحالة: ' . ($audit['status'] == 'completed' ? 'مكتمل' : 'قيد التنفيذ')]);
        fputcsv($output, ['إجمالي الفروقات: ' . ($stats['total_discrepancy'] ?? 0) . ' وحدة']);
        fputcsv($output, []);
        
        fputcsv($output, ['#', 'المنتج', 'الباركود', 'الكمية النظرية', 'الكمية الفعلية', 'الفرق', 'الحالة', 'السبب']);
        
        foreach ($items as $index => $item) {
            $status = '';
            if ($item['difference'] > 0) $status = 'زيادة';
            elseif ($item['difference'] < 0) $status = 'عجز';
            else $status = 'مطابق';
            
            fputcsv($output, [
                $index + 1,
                $item['product_name'],
                $item['barcode'],
                $item['expected_qty'],
                $item['actual_qty'],
                $item['difference'],
                $status,
                $item['reason'] ?? ''
            ]);
        }
        
        fclose($output);
        exit;
    }
}