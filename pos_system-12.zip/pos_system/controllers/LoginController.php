<?php
require_once 'core/Controller.php';
require_once 'core/Auth.php';

class LoginController extends Controller {
    
    private $maxAttempts = 15;
    private $lockTime = 30; // seconds
    private $postLockMaxAttempts = 5;
    
    public function index() {
        header("Cache-Control: no-cache, no-store, must-revalidate");
        
        if (Auth::check()) {
            $this->redirectBasedOnRole();
            return;
        }
        
        // جلب حالة القفل والمحاولات من الجلسة
        $lockUntil = $_SESSION['login_lock_until'] ?? 0;
        $attempts = $_SESSION['login_attempts'] ?? 0;
        $currentMax = $_SESSION['login_max_attempts'] ?? $this->maxAttempts;
        
        $isLocked = ($lockUntil > time());
        
        $this->view('login/index', [
            'isLocked' => $isLocked,
            'lockUntil' => $lockUntil,
            'attempts' => $attempts,
            'maxAttempts' => $currentMax
        ]);
    }

  public function login() {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        $this->redirect('login');
        return;
    }
    
    // التحقق من حالة القفل
    $lockUntil = $_SESSION['login_lock_until'] ?? 0;
    if ($lockUntil > time()) {
        $this->view('login/index', [
            'error' => 'النظام مقفل مؤقتاً بسبب كثرة المحاولات الفاشلة. انتظر ' . ($lockUntil - time()) . ' ثانية.',
            'isLocked' => true,
            'lockUntil' => $lockUntil
        ]);
        return;
    }
    
    // إعادة تعيين القفل إذا انتهى وقته
    if ($lockUntil > 0 && $lockUntil <= time()) {
        unset($_SESSION['login_lock_until']);
        $_SESSION['login_attempts'] = 0;
        $_SESSION['login_max_attempts'] = $this->postLockMaxAttempts;
    }
    
    // جلب البيانات من النموذج (تم التعديل: role → username)
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    
    if (empty($username) || empty($password)) {
        $this->handleFailedAttempt('الرجاء إدخال اسم المستخدم وكلمة المرور');
        return;
    }
    
    // البحث عن مستخدم نشط بواسطة اسم المستخدم (تم التعديل)
    try {
        $db = Database::getInstance();
        $sql = "SELECT * FROM users WHERE username = :username AND is_active = 1";
        $stmt = $db->prepare($sql);
        $stmt->execute(['username' => $username]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        $this->handleFailedAttempt('خطأ في قاعدة البيانات');
        return;
    }
    
    // التحقق من صحة كلمة المرور (تم التعديل)
    if ($user && password_verify($password, $user['password'])) {
        // محاولة ناجحة
        $this->resetLoginAttempts();
        
        // تعيين الجلسة - متوافق مع Auth class
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['user_role'] = $user['role'];
        $_SESSION['user_name'] = $user['full_name'];
        $_SESSION['username'] = $user['username'];
        $_SESSION['is_logged_in'] = true;
        $_SESSION['login_type'] = 'normal';
        
        // تحديث آخر تسجيل دخول
        $userModel = new User();
        $userModel->updateLastLogin($user['id']);
        
        $this->logSecurityEvent($user['id'], 'login_success', 'تسجيل دخول ناجح للمستخدم: ' . $username);
        
        // التوجيه حسب الدور
        $this->redirectBasedOnRole();
    } else {
        // محاولة فاشلة
        $this->handleFailedAttempt('اسم المستخدم أو كلمة المرور غير صحيحة');
    }
}
    
    /**
     * عرض نموذج تسجيل الدخول الاحتياطي
     */
    public function showBackupForm() {
        header("Cache-Control: no-cache, no-store, must-revalidate");
        
        if (Auth::check()) {
            $this->redirectBasedOnRole();
            return;
        }
        
        $this->view('login/backup_form');
    }
    
    /**
     * معالجة تسجيل الدخول الاحتياطي - للمديرين فقط
     */
    public function backupLogin() {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->redirect('login');
            return;
        }
        
        $username = trim($_POST['username'] ?? '');
        $backupPassword = $_POST['backup_password'] ?? '';
        
        if (empty($username) || empty($backupPassword)) {
            $this->view('login/backup_form', ['error' => 'يرجى إدخال اسم المستخدم وكلمة المرور الاحتياطية']);
            return;
        }
        
        $userModel = new User();
        $user = $userModel->findByUsername($username);
        
        // التحقق من وجود المستخدم وأنه مدير فقط ونشط
        if (!$user) {
            $this->logSecurityEvent(null, 'backup_login_failed', 'محاولة دخول احتياطي - مستخدم غير موجود: ' . $username);
            $this->view('login/backup_form', ['error' => 'بيانات غير صحيحة']);
            return;
        }
        
        // مهم جداً: فقط المدير يمكنه استخدام كلمة المرور الاحتياطية
        if ($user['role'] !== 'admin') {
            $this->logSecurityEvent($user['id'], 'backup_login_failed', 'محاولة دخول احتياطي من موظف - ممنوع: ' . $username);
            $this->view('login/backup_form', ['error' => 'هذه الميزة متاحة للمديرين فقط']);
            return;
        }
        
        if ($user['is_active'] != 1) {
            $this->logSecurityEvent($user['id'], 'backup_login_failed', 'محاولة دخول احتياطي - حساب غير نشط: ' . $username);
            $this->view('login/backup_form', ['error' => 'الحساب غير نشط، يرجى التواصل مع المدير']);
            return;
        }
        
        // التحقق من وجود كلمة مرور احتياطية
        if (empty($user['backup_password'])) {
            $this->logSecurityEvent($user['id'], 'backup_login_failed', 'محاولة دخول احتياطي - لا توجد كلمة مرور احتياطية: ' . $username);
            $this->view('login/backup_form', ['error' => 'لم يتم تعيين كلمة مرور احتياطية لهذا الحساب']);
            return;
        }
        
        // التحقق من صحة كلمة المرور الاحتياطية
        if (password_verify($backupPassword, $user['backup_password'])) {
            // نجاح الدخول الاحتياطي للمدير فقط
            session_regenerate_id(true);
            
            // تعيين الجلسة - متوافق مع Auth class
            $_SESSION['user_id'] = (int)$user['id'];
            $_SESSION['user_role'] = (string)$user['role'];
            $_SESSION['user_name'] = (string)$user['full_name'];
            $_SESSION['username'] = (string)$user['username'];
            $_SESSION['is_logged_in'] = true;
            $_SESSION['login_type'] = 'backup';
            
            // تحديث آخر تسجيل دخول
            $userModel->updateLastLogin($user['id']);
            
            $this->logSecurityEvent($user['id'], 'backup_login_success', 'تسجيل دخول احتياطي ناجح للمدير: ' . $username);
            $_SESSION['backup_login_notice'] = 'تم تسجيل الدخول باستخدام كلمة المرور الاحتياطية، يرجى تحديث كلمة المرور فوراً';
            
            // التوجيه إلى صفحة إدارة المستخدمين (للمدير)
            $this->redirect('users');
        } else {
            $this->logSecurityEvent($user['id'], 'backup_login_failed', 'فشل التحقق من كلمة المرور الاحتياطية للمدير: ' . $username);
            $this->view('login/backup_form', ['error' => 'كلمة المرور الاحتياطية غير صحيحة']);
        }
    }
    
    /**
     * التوجيه حسب دور المستخدم
     */
    private function redirectBasedOnRole() {
        $role = Auth::role();
        
        if ($role === 'admin') {
            $this->redirect('dashboard');
        } elseif ($role === 'staff') {
            $this->redirect('pos');  // الموظف يذهب مباشرة لنقطة البيع
        } else {
            $this->redirect('dashboard');
        }
    }
    
    public function logout() {
        // تسجيل حدث الخروج
        if (Auth::check()) {
            $this->logSecurityEvent(Auth::id(), 'logout', 'تسجيل خروج');
        }
        
        Auth::logout();
        
        if (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
            header('Content-Type: application/json');
            echo json_encode(['redirect' => BASE_URL . '/login']);
            exit;
        }
        
        header('Location: ' . BASE_URL . '/login');
        exit;
    }
    
    // =============================================
    // دوال مساعدة خاصة بالحماية
    // =============================================
    
    private function handleFailedAttempt($errorMessage) {
        $this->logSecurityEvent(null, 'login_failed', $errorMessage);
        
        $attempts = ($_SESSION['login_attempts'] ?? 0) + 1;
        $_SESSION['login_attempts'] = $attempts;
        
        $currentMax = $_SESSION['login_max_attempts'] ?? $this->maxAttempts;
        
        if ($attempts >= $currentMax) {
            $_SESSION['login_lock_until'] = time() + $this->lockTime;
            $_SESSION['login_attempts'] = 0;
            $_SESSION['login_max_attempts'] = $this->postLockMaxAttempts;
            $errorMessage = 'تم تجاوز الحد المسموح للمحاولات. النظام مقفل لمدة ' . $this->lockTime . ' ثانية.';
        }
        
        $this->view('login/index', [
            'error' => $errorMessage,
            'attempts' => $_SESSION['login_attempts'],
            'maxAttempts' => $currentMax,
            'isLocked' => isset($_SESSION['login_lock_until']) && $_SESSION['login_lock_until'] > time(),
            'lockUntil' => $_SESSION['login_lock_until'] ?? 0
        ]);
        exit;
    }
    
    private function resetLoginAttempts() {
        unset($_SESSION['login_attempts']);
        unset($_SESSION['login_lock_until']);
        unset($_SESSION['login_max_attempts']);
    }
    
    private function logSecurityEvent($userId, $action, $details) {
        try {
            $db = Database::getInstance();
            
            $checkTable = $db->query("SHOW TABLES LIKE 'system_logs'");
            if ($checkTable->rowCount() == 0) {
                $db->exec("
                    CREATE TABLE IF NOT EXISTS `system_logs` (
                        `id` int(11) NOT NULL AUTO_INCREMENT,
                        `user_id` int(11) DEFAULT NULL,
                        `action` varchar(100) NOT NULL,
                        `details` text,
                        `ip_address` varchar(45) DEFAULT NULL,
                        `created_at` datetime NOT NULL,
                        PRIMARY KEY (`id`),
                        KEY `idx_action` (`action`),
                        KEY `idx_created_at` (`created_at`)
                    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
                ");
            }
            
            $sql = "INSERT INTO system_logs (user_id, action, details, ip_address, created_at) 
                    VALUES (:user_id, :action, :details, :ip, NOW())";
            $stmt = $db->prepare($sql);
            $stmt->execute([
                'user_id' => $userId,
                'action' => $action,
                'details' => $details,
                'ip' => $_SERVER['REMOTE_ADDR'] ?? 'unknown'
            ]);
        } catch (Exception $e) {
            error_log("Failed to log security event: " . $e->getMessage());
        }
    }
}
?>