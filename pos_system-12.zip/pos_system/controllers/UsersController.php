<?php
require_once __DIR__ . '/../core/Controller.php';
require_once __DIR__ . '/../core/Auth.php';
require_once __DIR__ . '/../models/User.php';

class UsersController extends Controller {
    
    private $userModel;

    public function __construct() {
        if (!Auth::check()) {
            $this->redirect('login');
        }

        // التحقق من الصلاحية (مدير فقط)
        if (Auth::user()['role'] !== 'admin') {
            $this->redirect('dashboard');
        }

        $this->userModel = new User();
    }

    /**
     * الصفحة الرئيسية لإدارة المستخدمين
     */
    public function index() {
        $data = [
            'title' => 'إدارة المستخدمين',
            'users' => $this->userModel->getAllUsers(),
            'current_user' => Auth::user()
        ];

        $this->view('users/index', $data);
    }

    /**
     * API: الحصول على جميع المستخدمين
     */
    public function getUsers() {
        header('Content-Type: application/json; charset=utf-8');
        
        $users = $this->userModel->getAllUsers();
        $currentUserId = Auth::id();

        echo json_encode([
            'success' => true,
            'data' => $users,
            'current_user_id' => $currentUserId
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }

    /**
     * API: إضافة مستخدم جديد
     */
    public function addUser() {
        header('Content-Type: application/json; charset=utf-8');
        
        if (!$this->isPost()) {
            echo json_encode(['success' => false, 'message' => 'طريقة طلب غير صحيحة']);
            exit;
        }

        $input = json_decode(file_get_contents('php://input'), true);
        
        if (!$input) {
            echo json_encode(['success' => false, 'message' => 'بيانات غير صالحة']);
            exit;
        }

        // التحقق من الحقول الإجبارية
        if (empty($input['username']) || empty($input['password']) || empty($input['full_name']) || empty($input['role'])) {
            echo json_encode(['success' => false, 'message' => 'جميع الحقول الإجبارية مطلوبة']);
            exit;
        }

        // التحقق من طول كلمة المرور
        if (strlen($input['password']) < 6) {
            echo json_encode(['success' => false, 'message' => 'كلمة المرور يجب أن تكون 6 أحرف على الأقل']);
            exit;
        }

        // التحقق من عدم تكرار اسم المستخدم
        if ($this->userModel->findByUsername($input['username'])) {
            echo json_encode(['success' => false, 'message' => 'اسم المستخدم موجود بالفعل']);
            exit;
        }

        // تشفير كلمة المرور
        $input['password'] = password_hash($input['password'], PASSWORD_DEFAULT);

        // إضافة المستخدم
        $result = $this->userModel->createUser($input);

        if ($result) {
            echo json_encode(['success' => true, 'message' => 'تم إضافة المستخدم بنجاح']);
        } else {
            echo json_encode(['success' => false, 'message' => 'فشل إضافة المستخدم']);
        }
        exit;
    }

    /**
     * API: تحديث بيانات مستخدم
     */
    public function updateUser() {
        header('Content-Type: application/json; charset=utf-8');
        
        if (!$this->isPost()) {
            echo json_encode(['success' => false, 'message' => 'طريقة طلب غير صحيحة']);
            exit;
        }

        $input = json_decode(file_get_contents('php://input'), true);
        
        if (!$input) {
            echo json_encode(['success' => false, 'message' => 'بيانات غير صالحة']);
            exit;
        }

        // التحقق من الحقول الإجبارية
        if (empty($input['id']) || empty($input['username']) || empty($input['full_name']) || empty($input['role'])) {
            echo json_encode(['success' => false, 'message' => 'جميع الحقول الإجبارية مطلوبة']);
            exit;
        }

        // التحقق من عدم تعديل المستخدم الحالي
        if ($input['id'] == Auth::id()) {
            echo json_encode(['success' => false, 'message' => 'لا يمكن تعديل بيانات المستخدم الحالي من هنا']);
            exit;
        }

        // التحقق من عدم تكرار اسم المستخدم (لمستخدم آخر)
        $existingUser = $this->userModel->findByUsername($input['username']);
        if ($existingUser && $existingUser['id'] != $input['id']) {
            echo json_encode(['success' => false, 'message' => 'اسم المستخدم موجود بالفعل']);
            exit;
        }

        // تحديث المستخدم
        $result = $this->userModel->updateUser($input['id'], $input);

        if ($result) {
            echo json_encode(['success' => true, 'message' => 'تم تحديث المستخدم بنجاح']);
        } else {
            echo json_encode(['success' => false, 'message' => 'فشل تحديث المستخدم']);
        }
        exit;
    }

    /**
     * API: تغيير كلمة المرور
     */
    public function changePassword() {
        header('Content-Type: application/json; charset=utf-8');
        
        if (!$this->isPost()) {
            echo json_encode(['success' => false, 'message' => 'طريقة طلب غير صحيحة']);
            exit;
        }

        $input = json_decode(file_get_contents('php://input'), true);
        
        if (!$input) {
            echo json_encode(['success' => false, 'message' => 'بيانات غير صالحة']);
            exit;
        }

        $userId = $input['user_id'] ?? 0;
        $newPassword = $input['new_password'] ?? '';
        $confirmPassword = $input['confirm_password'] ?? '';
        $backupPassword = $input['backup_password'] ?? '';

        // التحقق من تطابق كلمات المرور
        if ($newPassword !== $confirmPassword) {
            echo json_encode(['success' => false, 'message' => 'كلمتا المرور غير متطابقتين']);
            exit;
        }

        // التحقق من طول كلمة المرور
        if (strlen($newPassword) < 6) {
            echo json_encode(['success' => false, 'message' => 'كلمة المرور يجب أن تكون 6 أحرف على الأقل']);
            exit;
        }

        // إذا كان المستخدم الحالي، تحقق من كلمة المرور الاحتياطية
        if ($userId == Auth::id()) {
            if (empty($backupPassword)) {
                echo json_encode(['success' => false, 'message' => 'كلمة المرور الاحتياطية مطلوبة لتغيير كلمة مرور المدير']);
                exit;
            }

            $settings = $this->userModel->getBackupPassword();
            if (!$settings || !password_verify($backupPassword, $settings['setting_value'])) {
                echo json_encode(['success' => false, 'message' => 'كلمة المرور الاحتياطية غير صحيحة']);
                exit;
            }
        }

        // تغيير كلمة المرور
        $result = $this->userModel->changePassword($userId, $newPassword);

        if ($result) {
            echo json_encode(['success' => true, 'message' => 'تم تغيير كلمة المرور بنجاح']);
        } else {
            echo json_encode(['success' => false, 'message' => 'فشل تغيير كلمة المرور']);
        }
        exit;
    }

    /**
     * API: تعطيل/تفعيل مستخدم
     */
    public function toggleUser() {
        header('Content-Type: application/json; charset=utf-8');
        
        if (!$this->isPost()) {
            echo json_encode(['success' => false, 'message' => 'طريقة طلب غير صحيحة']);
            exit;
        }

        $input = json_decode(file_get_contents('php://input'), true);
        
        if (!$input) {
            echo json_encode(['success' => false, 'message' => 'بيانات غير صالحة']);
            exit;
        }

        $userId = $input['user_id'] ?? 0;
        $action = $input['action'] ?? ''; // 'activate' or 'deactivate'

        // منع تعطيل المستخدم الحالي
        if ($userId == Auth::id()) {
            echo json_encode(['success' => false, 'message' => 'لا يمكن تغيير حالة المستخدم الحالي']);
            exit;
        }

        $status = ($action === 'activate') ? 1 : 0;
        $result = $this->userModel->updateStatus($userId, $status);

        if ($result) {
            $message = ($action === 'activate') ? 'تم تفعيل المستخدم بنجاح' : 'تم تعطيل المستخدم بنجاح';
            echo json_encode(['success' => true, 'message' => $message]);
        } else {
            echo json_encode(['success' => false, 'message' => 'فشل تحديث حالة المستخدم']);
        }
        exit;
    }

    /**
     * API: الحصول على كلمة المرور الاحتياطية
     */
    public function getBackupPassword() {
        header('Content-Type: application/json; charset=utf-8');
        
        $settings = $this->userModel->getBackupPassword();
        
        echo json_encode([
            'success' => true,
            'exists' => !empty($settings)
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }

    /**
     * API: تحديث كلمة المرور الاحتياطية
     */
       /**
     * API: تحديث كلمة المرور الاحتياطية للمستخدم الحالي تلقائياً
     */
  public function updateBackupPassword() {
    header('Content-Type: application/json; charset=utf-8');
    
    $currentUserId = Auth::id();
    $input = json_decode(file_get_contents('php://input'), true);
    $newPassword = $input['new_password'] ?? '';

    // 1. التحقق من الطول (أمان إضافي)
    if (strlen($newPassword) < 6) {
        echo json_encode(['success' => false, 'message' => 'كلمة المرور قصيرة جداً']);
        exit;
    }

    // 2. جلب البيانات للفحص المتقاطع (منع التكرار)
    $allPasswords = $this->userModel->getAllPasswordsForValidation();

    foreach ($allPasswords as $row) {
        // أ. فحص: هل تطابق كلمة مرور أساسية (لأي مستخدم)؟
        if (password_verify($newPassword, $row['password'])) {
            echo json_encode(['success' => false, 'message' => 'لا يمكن استخدام كلمة مرور مستخدمة حالياً في النظام']);
            exit;
        }

        // ب. فحص: هل تطابق كلمة مرور احتياطية (لأي مستخدم)؟
        if (!empty($row['backup_password']) && password_verify($newPassword, $row['backup_password'])) {
            echo json_encode(['success' => false, 'message' => 'كلمة المرور هذه مستخدمة مسبقاً ككلمة احتياطية']);
            exit;
        }
    }

    // 3. التشفير والحفظ إذا اجتازت الشروط
    $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);
    $result = $this->userModel->updateBackupPassword($currentUserId, $hashedPassword);

    if ($result) {
        echo json_encode(['success' => true, 'message' => 'تم حفظ كلمة المرور الاحتياطية بنجاح']);
    } else {
        echo json_encode(['success' => false, 'message' => 'فشل الحفظ، تأكد من وجود عمود backup_password']);
    }
    exit;
}


}