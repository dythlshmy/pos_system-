<?php
require_once __DIR__ . '/../core/Controller.php';
require_once __DIR__ . '/../core/Auth.php';

class TestController extends Controller {
    
    public function __construct() {
        // لا نتحقق من Auth هنا حتى نتمكن من الاختبار
    }
    
    public function index() {
        // إيقاف جميع القيود مؤقتاً
        error_reporting(E_ALL);
        ini_set('display_errors', 1);
        
        header('Content-Type: text/html; charset=utf-8');
        
        echo "<!DOCTYPE html>
        <html dir='rtl'>
        <head>
            <title>اختبار النظام</title>
            <style>
                body { font-family: Arial; padding: 20px; background: #f0f2f5; }
                .container { max-width: 1200px; margin: 0 auto; }
                .card { background: white; border-radius: 10px; padding: 20px; margin-bottom: 20px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
                h1 { color: #1a237e; }
                table { width: 100%; border-collapse: collapse; margin-top: 10px; }
                th { background: #1a237e; color: white; padding: 10px; }
                td { padding: 10px; border-bottom: 1px solid #e0e0e0; }
                .success { color: #2e7d32; background: #e8f5e8; padding: 10px; border-radius: 5px; }
                .error { color: #c62828; background: #ffebee; padding: 10px; border-radius: 5px; }
            </style>
        </head>
        <body>
            <div class='container'>
                <h1>🔍 اختبار جلب بيانات الفاتورة</h1>";
        
        try {
            $db = Database::getInstance();
            
            // 1. التحقق من وجود المبيعات
            echo "<div class='card'>";
            echo "<h2>1. فحص جدول المبيعات</h2>";
            
            $stmt = $db->query("SELECT COUNT(*) as count FROM sales");
            $count = $stmt->fetch()['count'];
            
            if ($count > 0) {
                echo "<p class='success'>✅ تم العثور على <strong>$count</strong> فاتورة في قاعدة البيانات</p>";
                
                // عرض آخر 5 فواتير
                $stmt = $db->query("SELECT * FROM sales ORDER BY created_at DESC LIMIT 5");
                $sales = $stmt->fetchAll();
                
                echo "<table>";
                echo "<tr><th>ID</th><th>رقم الفاتورة</th><th>النوع</th><th>الإجمالي</th><th>المدفوع</th><th>التاريخ</th></tr>";
                
                foreach ($sales as $sale) {
                    echo "<tr>";
                    echo "<td>" . $sale['id'] . "</td>";
                    echo "<td>" . $sale['invoice_number'] . "</td>";
                    echo "<td>" . ($sale['sale_type'] == 'cash' ? 'نقدي' : 'آجل') . "</td>";
                    echo "<td>" . $sale['total_amount'] . " ₪</td>";
                    echo "<td>" . $sale['paid_amount'] . " ₪</td>";
                    echo "<td>" . $sale['created_at'] . "</td>";
                    echo "</tr>";
                }
                echo "</table>";
                
                // 2. تفاصيل أول فاتورة
                if (!empty($sales)) {
                    $firstSale = $sales[0];
                    
                    echo "<h3>تفاصيل الفاتورة: " . $firstSale['invoice_number'] . "</h3>";
                    
                    // جلب عناصر الفاتورة
                    $stmt = $db->prepare("
                        SELECT si.*, p.name as product_name 
                        FROM sale_items si
                        JOIN shelf_inventory sh ON si.shelf_inventory_id = sh.id
                        JOIN main_inventory i ON sh.main_inventory_id = i.id
                        JOIN products p ON i.product_id = p.id
                        WHERE si.sale_id = ?
                    ");
                    $stmt->execute([$firstSale['id']]);
                    $items = $stmt->fetchAll();
                    
                    if (!empty($items)) {
                        echo "<table>";
                        echo "<tr><th>المنتج</th><th>الكمية</th><th>السعر</th><th>الإجمالي</th></tr>";
                        foreach ($items as $item) {
                            echo "<tr>";
                            echo "<td>" . $item['product_name'] . "</td>";
                            echo "<td>" . $item['quantity'] . "</td>";
                            echo "<td>" . $item['price_unit'] . " ₪</td>";
                            echo "<td>" . $item['subtotal'] . " ₪</td>";
                            echo "</tr>";
                        }
                        echo "</table>";
                    } else {
                        echo "<p class='error'>❌ لا توجد عناصر لهذه الفاتورة</p>";
                    }
                }
                
            } else {
                echo "<p class='error'>❌ لا توجد فواتير في قاعدة البيانات</p>";
            }
            
            echo "</div>";
            
            // 3. اختبار إعدادات الطباعة
            echo "<div class='card'>";
            echo "<h2>2. إعدادات الطباعة</h2>";
            
            $stmt = $db->query("SELECT * FROM settings WHERE setting_key LIKE 'print_%'");
            $settings = $stmt->fetchAll();
            
            if (!empty($settings)) {
                echo "<table>";
                echo "<tr><th>المفتاح</th><th>القيمة</th></tr>";
                foreach ($settings as $setting) {
                    echo "<tr>";
                    echo "<td>" . $setting['setting_key'] . "</td>";
                    echo "<td>" . $setting['setting_value'] . "</td>";
                    echo "</tr>";
                }
                echo "</table>";
            } else {
                echo "<p class='error'>❌ لا توجد إعدادات طباعة</p>";
            }
            
            echo "</div>";
            
        } catch (Exception $e) {
            echo "<div class='card error'>";
            echo "<h2>❌ خطأ</h2>";
            echo "<p>" . $e->getMessage() . "</p>";
            echo "</div>";
        }
        
        echo "    </div>
        </body>
        </html>";
        exit;
    }
}
?>