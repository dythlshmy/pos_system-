<?php
require_once 'core/Controller.php';
require_once 'core/Auth.php';

class DashboardController extends Controller {
    
    public function index() {
        if (!Auth::check()) {
            $this->redirect('login');
        }

        $stats = $this->getDashboardStats();
        
        $this->view('dashboard/index', [
            'title' => 'لوحة التحكم',
            'stats' => $stats
        ]);
    }
    
    private function getDashboardStats() {
        $db = Database::getInstance();
        
        try {
            $todaySales = $db->query("
                SELECT COUNT(*) as count, COALESCE(SUM(total_amount), 0) as total 
                FROM sales 
                WHERE DATE(created_at) = CURDATE()
            ")->fetch();
            
            $totalProducts = $db->query("SELECT COUNT(*) as count FROM products WHERE is_active = 1")->fetch();
            $totalCustomers = $db->query("SELECT COUNT(*) as count FROM customers WHERE is_active = 1")->fetch();
            
            $lowStock = $db->query("
                SELECT COUNT(*) as count 
                FROM main_inventory 
                WHERE cartons_remaining < 5
            ")->fetch();
            
            return [
                'today_sales_count' => $todaySales['count'] ?? 0,
                'today_sales_total' => $todaySales['total'] ?? 0,
                'total_products' => $totalProducts['count'] ?? 0,
                'total_customers' => $totalCustomers['count'] ?? 0,
                'low_stock' => $lowStock['count'] ?? 0
            ];
            
        } catch (PDOException $e) {
            return [
                'today_sales_count' => 0,
                'today_sales_total' => 0,
                'total_products' => 0,
                'total_customers' => 0,
                'low_stock' => 0
            ];
        }
    }
}