<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once __DIR__ . '/../core/Controller.php';
require_once __DIR__ . '/../core/Auth.php';
require_once __DIR__ . '/../models/ActivityLog.php';
require_once __DIR__ . '/../models/User.php';

class LogController extends Controller {
    
    private $logModel;
    private $userModel;

    public function __construct() {
        if (!Auth::check()) {
            $this->redirect('login');
        }

        $this->logModel = new ActivityLog();
        $this->userModel = new User();
    }

    /**
     * عرض صفحة سجل الحركات
     */
    public function index() {
        $data = [
            'title' => 'سجل الحركات',
            'logs' => $this->logModel->getAllWithUser(100),
            'users' => $this->userModel->all('full_name ASC'),
            'stats' => $this->logModel->getStats()
        ];
        $this->view('logs/index', $data);
    }

    /**
     * البحث في سجل الحركات - نسخة محسنة
     */
    public function search() {
        // مسح أي إخراج سابق
        if (ob_get_level()) ob_clean();
        
        // تعيين header JSON
        header('Content-Type: application/json; charset=utf-8');
        
        try {
            // جلب معاملات البحث من URL
            $search = isset($_GET['search']) ? $_GET['search'] : '';
            $userId = isset($_GET['user_id']) ? $_GET['user_id'] : '';
            $action = isset($_GET['action']) ? $_GET['action'] : '';
            $dateFrom = isset($_GET['date_from']) ? $_GET['date_from'] : '';
            $dateTo = isset($_GET['date_to']) ? $_GET['date_to'] : '';
            
            // بناء معاملات البحث
            $filters = [];
            
            if (!empty($search)) {
                $filters['search'] = $search;
            }
            
            if (!empty($userId)) {
                $filters['user_id'] = $userId;
            }
            
            if (!empty($action)) {
                $filters['action'] = $action;
            }
            
            if (!empty($dateFrom)) {
                $filters['date_from'] = $dateFrom;
            }
            
            if (!empty($dateTo)) {
                $filters['date_to'] = $dateTo;
            }
            
            // تنفيذ البحث
            $logs = $this->logModel->search($filters);
            
            // تجهيز النتائج
            $result = [];
            foreach ($logs as $log) {
                // تحديد نوع الحركة للعرض
                $displayAction = $log['action'];
                $badgeClass = 'badge-default';
                
                if (strpos($log['action'], 'add') !== false) {
                    $displayAction = '➕ إضافة';
                    $badgeClass = 'badge-add';
                } elseif (strpos($log['action'], 'update') !== false) {
                    $displayAction = '✏️ تعديل';
                    $badgeClass = 'badge-update';
                } elseif (strpos($log['action'], 'delete') !== false) {
                    $displayAction = '🗑️ حذف';
                    $badgeClass = 'badge-delete';
                } elseif (strpos($log['action'], 'sell') !== false) {
                    $displayAction = '💰 بيع';
                    $badgeClass = 'badge-sell';
                } elseif (strpos($log['action'], 'move') !== false) {
                    $displayAction = '🔄 نقل';
                    $badgeClass = 'badge-move';
                } elseif (strpos($log['action'], 'login') !== false) {
                    $displayAction = '🔑 دخول';
                    $badgeClass = 'badge-add';
                } elseif (strpos($log['action'], 'logout') !== false) {
                    $displayAction = '🚪 خروج';
                    $badgeClass = 'badge-delete';
                }
                
                $result[] = [
                    'created_at' => $log['created_at'],
                    'date' => date('Y-m-d', strtotime($log['created_at'])),
                    'time' => date('H:i:s', strtotime($log['created_at'])),
                    'user_name' => $log['user_name'] ?? 'غير معروف',
                    'username' => $log['username'] ?? '',
                    'action' => $log['action'],
                    'display_action' => $displayAction,
                    'badge_class' => $badgeClass,
                    'details' => $log['details'],
                    'ip_address' => $log['ip_address'] ?? '-'
                ];
            }
            
            echo json_encode([
                'success' => true,
                'data' => $result,
                'count' => count($result)
            ], JSON_UNESCAPED_UNICODE);
            exit;
            
        } catch (Exception $e) {
            echo json_encode([
                'success' => false,
                'message' => $e->getMessage()
            ], JSON_UNESCAPED_UNICODE);
            exit;
        }
    }

    /**
     * تصدير السجل إلى Excel
     */
    public function export() {
        $filters = [
            'date_from' => $this->getQuery('date_from'),
            'date_to' => $this->getQuery('date_to')
        ];

        $logs = $this->logModel->search($filters);
        
        // إنشاء ملف CSV
        $filename = 'activity_log_' . date('Y-m-d') . '.csv';
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        
        $output = fopen('php://output', 'w');
        fprintf($output, chr(0xEF).chr(0xBB).chr(0xBF)); // BOM للعربية
        
        // رأس الملف
        fputcsv($output, ['التاريخ', 'الوقت', 'المستخدم', 'نوع الحركة', 'التفاصيل', 'IP']);
        
        // البيانات
        foreach ($logs as $log) {
            fputcsv($output, [
                date('Y-m-d', strtotime($log['created_at'])),
                date('H:i:s', strtotime($log['created_at'])),
                $log['user_name'] ?? 'غير معروف',
                $log['action'],
                $log['details'],
                $log['ip_address'] ?? '-'
            ]);
        }
        
        fclose($output);
        exit;
    }

    /**
     * تسجيل حركة (دالة مساعدة)
     */
    public static function log($action, $details) {
        $log = new ActivityLog();
        return $log->log($action, $details);
    }

    /**
 * الحصول على تفاصيل عنصر من رف البيع (AJAX)
 */
public function getShelfItemDetails() {
    // مسح أي إخراج سابق
    if (ob_get_level()) ob_clean();
    
    // تعيين header JSON
    header('Content-Type: application/json; charset=utf-8');
    
    try {
        $id = $this->getQuery('id');
        if (!$id) {
            echo json_encode(['success' => false, 'message' => 'معرف العنصر مطلوب']);
            exit;
        }
        
        // جلب بيانات عنصر الرف
        $shelfItem = $this->shelfModel->find($id);
        if (!$shelfItem) {
            echo json_encode(['success' => false, 'message' => 'العنصر غير موجود']);
            exit;
        }
        
        // جلب بيانات الدفعة المرتبطة
        $batch = $this->inventoryModel->find($shelfItem['main_inventory_id']);
        if (!$batch) {
            echo json_encode(['success' => false, 'message' => 'الدفعة المرتبطة غير موجودة']);
            exit;
        }
        
        // جلب بيانات المنتج
        $product = $this->productModel->find($batch['product_id']);
        
        echo json_encode([
            'success' => true,
            'data' => [
                'shelf_item' => $shelfItem,
                'batch' => $batch,
                'product' => $product
            ]
        ], JSON_UNESCAPED_UNICODE);
        exit;
        
    } catch (Exception $e) {
        echo json_encode([
            'success' => false,
            'message' => 'خطأ: ' . $e->getMessage()
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }
}
}