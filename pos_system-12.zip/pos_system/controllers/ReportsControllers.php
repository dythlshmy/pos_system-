<?php
require_once __DIR__ . '/../core/Controller.php';
require_once __DIR__ . '/../core/Auth.php';
require_once __DIR__ . '/../models/Sale.php';
require_once __DIR__ . '/../models/SaleItem.php';
require_once __DIR__ . '/../models/Product.php';
require_once __DIR__ . '/../models/Customer.php';
require_once __DIR__ . '/../models/Inventory.php';
require_once __DIR__ . '/../models/User.php';
require_once __DIR__ . '/../models/Report.php';

class ReportsControllers extends Controller {
    
    private $saleModel;
    private $saleItemModel;
    private $productModel;
    private $customerModel;
    private $inventoryModel;
    private $userModel;
    private $reportModel;

    public function __construct() {
        if (!Auth::check()) {
            $this->redirect('login');
        }

        // التحقق من الصلاحية (مدير فقط)
        if (Auth::user()['role'] !== 'admin') {
            $this->redirect('dashboard');
        }

        $this->saleModel = new Sale();
        $this->saleItemModel = new SaleItem();
        $this->productModel = new Product();
        $this->customerModel = new Customer();
        $this->inventoryModel = new Inventory();
        $this->userModel = new User();
        $this->reportModel = new Report();
    }

    /**
     * الصفحة الرئيسية للتقارير
     */
    public function index() {
        // الحصول على معايير التقرير من الرابط
        $type = $this->getQuery('type', 'cash');
        $period = $this->getQuery('period', 'daily');
        $dateFrom = $this->getQuery('from');
        $dateTo = $this->getQuery('to');
        
        // حساب التواريخ بناءً على الفترة
        $dates = $this->calculateDates($period, $dateFrom, $dateTo);
        
        // جلب البيانات حسب نوع التقرير
        $reportData = [];
        $stats = [];
        
        switch ($type) {
            case 'cash':
                $reportData = $this->getCashSalesReports($dates['from'], $dates['to']);
                $stats = $this->getCashStats($dates['from'], $dates['to']);
                break;
            case 'credit':
                $reportData = $this->getCreditSalesReports($dates['from'], $dates['to']);
                $stats = $this->getCreditStats($dates['from'], $dates['to']);
                break;
            case 'inventory':
                $reportData = $this->getInventoryReports();
                $stats = $this->getInventoryStats();
                break;
            case 'products':
                $reportData = $this->getProductsReports();
                $stats = $this->getProductsStats();
                break;
        }

        // تجهيز البيانات للعرض
        $data = [
            'title' => 'التقارير والإحصائيات',
            'report_type' => $type,
            'report_period' => $period,
            'date_from' => $dates['from'],
            'date_to' => $dates['to'],
            'stats' => $stats,
            'report_data' => $reportData,
            'custom_dates' => $period === 'custom'
        ];

        $this->view('reports/index', $data);
    }

    /**
     * تصدير التقرير إلى Excel
     */
    public function export() {
        $type = $this->getQuery('type', 'cash');
        $period = $this->getQuery('period', 'daily');
        $dateFrom = $this->getQuery('from');
        $dateTo = $this->getQuery('to');
        
        $dates = $this->calculateDates($period, $dateFrom, $dateTo);
        
        // جلب البيانات حسب النوع
        switch ($type) {
            case 'cash':
                $data = $this->getCashSalesReports($dates['from'], $dates['to'], true);
                $this->exportToExcel($data, 'cash_sales_report', $dates);
                break;
            case 'credit':
                $data = $this->getCreditSalesReports($dates['from'], $dates['to'], true);
                $this->exportToExcel($data, 'credit_sales_report', $dates);
                break;
            case 'inventory':
                $data = $this->getInventoryReports(true);
                $this->exportToExcel($data, 'inventory_report');
                break;
            case 'products':
                $data = $this->getProductsReports(true);
                $this->exportToExcel($data, 'products_report');
                break;
        }
    }

    /**
     * طباعة التقرير
     */
    public function print() {
        $type = $this->getQuery('type', 'cash');
        $period = $this->getQuery('period', 'daily');
        $dateFrom = $this->getQuery('from');
        $dateTo = $this->getQuery('to');
        
        $dates = $this->calculateDates($period, $dateFrom, $dateTo);
        
        switch ($type) {
            case 'cash':
                $data = $this->getCashSalesReports($dates['from'], $dates['to']);
                $stats = $this->getCashStats($dates['from'], $dates['to']);
                break;
            case 'credit':
                $data = $this->getCreditSalesReports($dates['from'], $dates['to']);
                $stats = $this->getCreditStats($dates['from'], $dates['to']);
                break;
            case 'inventory':
                $data = $this->getInventoryReports();
                $stats = $this->getInventoryStats();
                break;
            case 'products':
                $data = $this->getProductsReports();
                $stats = $this->getProductsStats();
                break;
        }

        $this->view('reports/print', [
            'type' => $type,
            'dates' => $dates,
            'stats' => $stats,
            'data' => $data
        ]);
    }

    /**
     * API للحصول على سجل منتج محدد
     */
    public function productsHistory() {
        header('Content-Type: application/json; charset=utf-8');
        
        $productsIds = isset($_GET['ids']) ? explode(',', $_GET['ids']) : [];
        $period = $this->getQuery('period', 'all');
        $dateFrom = $this->getQuery('from');
        $dateTo = $this->getQuery('to');
        
        if (empty($productsIds)) {
            echo json_encode(['success' => false, 'message' => 'لم يتم تحديد منتجات']);
            exit;
        }

        $dates = $this->calculateDates($period, $dateFrom, $dateTo);
        
        $result = [];
        foreach ($productsIds as $productId) {
            $result[] = $this->getProductHistory($productId, $dates['from'], $dates['to']);
        }

        echo json_encode([
            'success' => true,
            'data' => $result
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }

    /**
     * جرد فعلي - تحديث الكمية (الدالة القديمة)
     */
    public function physicalInventory() {
        header('Content-Type: application/json; charset=utf-8');
        
        if (!$this->isPost()) {
            echo json_encode(['success' => false, 'message' => 'طريقة طلب غير صحيحة']);
            exit;
        }

        $input = json_decode(file_get_contents('php://input'), true);
        
        if (!$input) {
            echo json_encode(['success' => false, 'message' => 'بيانات غير صالحة']);
            exit;
        }
        
        $productId = $input['product_id'] ?? 0;
        $actualQty = $input['actual_quantity'] ?? 0;
        $reason = $input['reason'] ?? '';
        
        if (!$productId) {
            echo json_encode(['success' => false, 'message' => 'معرف المنتج مطلوب']);
            exit;
        }
        
        if (!is_numeric($actualQty) || $actualQty < 0) {
            echo json_encode(['success' => false, 'message' => 'الكمية الفعلية غير صالحة']);
            exit;
        }
        
        $result = $this->reportModel->physicalInventory($productId, $actualQty, $reason);
        
        echo json_encode($result);
        exit;
    }

    // ==================== دوال جلب البيانات ====================

    /**
     * تقارير المبيعات النقدية
     */
    private function getCashSalesReports($from = null, $to = null, $all = false) {
        $db = Database::getInstance();
        
        $sql = "SELECT 
                    s.id,
                    s.invoice_number,
                    DATE_FORMAT(s.created_at, '%Y-%m-%d %H:%i') as created_at,
                    s.total_amount,
                    u.full_name as cashier_name,
                    si.id as item_id,
                    si.quantity,
                    si.price_unit,
                    si.subtotal,
                    p.name as product_name,
                    p.barcode,
                    COALESCE(r.return_count, 0) as return_count,
                    COALESCE(r.return_amount, 0) as return_amount
                FROM sales s
                INNER JOIN sale_items si ON s.id = si.sale_id
                INNER JOIN shelf_inventory sh ON si.shelf_inventory_id = sh.id
                INNER JOIN main_inventory mi ON sh.main_inventory_id = mi.id
                INNER JOIN products p ON mi.product_id = p.id
                INNER JOIN users u ON s.created_by = u.id
                LEFT JOIN (
                    SELECT 
                        r.sale_id,
                        COUNT(DISTINCT r.id) as return_count,
                        SUM(r.total_refund_amount) as return_amount
                    FROM returns r
                    GROUP BY r.sale_id
                ) r ON s.id = r.sale_id
                WHERE s.sale_type = 'cash'";

        if ($from && $to) {
            $sql .= " AND DATE(s.created_at) BETWEEN :from AND :to";
        }

        $sql .= " ORDER BY s.created_at DESC";

        $stmt = $db->prepare($sql);
        
        if ($from && $to) {
            $stmt->execute(['from' => $from, 'to' => $to]);
        } else {
            $stmt->execute();
        }

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * تقارير المبيعات الآجلة
     */
    private function getCreditSalesReports($from = null, $to = null, $all = false) {
        $db = Database::getInstance();
        
        $sql = "SELECT 
                    s.id,
                    s.invoice_number,
                    DATE_FORMAT(s.created_at, '%Y-%m-%d %H:%i') as created_at,
                    s.total_amount,
                    s.paid_amount,
                    s.remaining_amount,
                    s.payment_status,
                    c.id as customer_id,
                    c.name as customer_name,
                    c.phone as customer_phone,
                    si.id as item_id,
                    si.quantity,
                    si.price_unit,
                    si.subtotal,
                    p.name as product_name,
                    p.barcode,
                    COALESCE(r.return_count, 0) as return_count,
                    COALESCE(r.return_amount, 0) as return_amount,
                    COALESCE(ph.total_paid, 0) as total_payments
                FROM sales s
                INNER JOIN customers c ON s.customer_id = c.id
                INNER JOIN sale_items si ON s.id = si.sale_id
                INNER JOIN shelf_inventory sh ON si.shelf_inventory_id = sh.id
                INNER JOIN main_inventory mi ON sh.main_inventory_id = mi.id
                INNER JOIN products p ON mi.product_id = p.id
                LEFT JOIN (
                    SELECT 
                        r.sale_id,
                        COUNT(DISTINCT r.id) as return_count,
                        SUM(r.total_refund_amount) as return_amount
                    FROM returns r
                    GROUP BY r.sale_id
                ) r ON s.id = r.sale_id
                LEFT JOIN (
                    SELECT 
                        sale_id,
                        SUM(amount) as total_paid
                    FROM payment_history
                    GROUP BY sale_id
                ) ph ON s.id = ph.sale_id
                WHERE s.sale_type = 'credit'";

        if ($from && $to) {
            $sql .= " AND DATE(s.created_at) BETWEEN :from AND :to";
        }

        $sql .= " ORDER BY s.created_at DESC";

        $stmt = $db->prepare($sql);
        
        if ($from && $to) {
            $stmt->execute(['from' => $from, 'to' => $to]);
        } else {
            $stmt->execute();
        }

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * تقارير الجرد
     */
    private function getInventoryReports($all = false) {
        $db = Database::getInstance();
        
        $sql = "SELECT 
                    p.id,
                    p.name as product_name,
                    p.barcode,
                    c.name as category_name,
                    COALESCE((
                        SELECT SUM(mi2.cartons_quantity * p2.units_per_carton)
                        FROM main_inventory mi2
                        INNER JOIN products p2 ON mi2.product_id = p2.id
                        WHERE mi2.product_id = p.id
                    ), 0) as total_quantity,
                    COALESCE((
                        SELECT SUM(sh.units_remaining)
                        FROM shelf_inventory sh
                        INNER JOIN main_inventory mi3 ON sh.main_inventory_id = mi3.id
                        WHERE mi3.product_id = p.id
                    ), 0) as current_quantity,
                    COALESCE((
                        SELECT SUM(sh.selling_price_unit * sh.units_remaining)
                        FROM shelf_inventory sh
                        INNER JOIN main_inventory mi4 ON sh.main_inventory_id = mi4.id
                        WHERE mi4.product_id = p.id
                    ), 0) as total_value,
                    COUNT(CASE WHEN mi.expiry_date < CURDATE() THEN 1 END) as expired_count,
                    MIN(mi.expiry_date) as nearest_expiry,
                    CASE 
                        WHEN COALESCE((
                            SELECT SUM(sh.units_remaining)
                            FROM shelf_inventory sh
                            INNER JOIN main_inventory mi3 ON sh.main_inventory_id = mi3.id
                            WHERE mi3.product_id = p.id
                        ), 0) = 0 THEN 'out_of_stock'
                        WHEN COALESCE((
                            SELECT SUM(sh.units_remaining)
                            FROM shelf_inventory sh
                            INNER JOIN main_inventory mi3 ON sh.main_inventory_id = mi3.id
                            WHERE mi3.product_id = p.id
                        ), 0) < 10 THEN 'low_stock'
                        ELSE 'available'
                    END as stock_status
                FROM products p
                LEFT JOIN categories c ON p.category_id = c.id
                LEFT JOIN main_inventory mi ON p.id = mi.product_id
                WHERE p.is_active = 1
                GROUP BY p.id
                ORDER BY p.name ASC";

        $stmt = $db->prepare($sql);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * تقارير المنتجات
     */
    private function getProductsReports($all = false) {
        $db = Database::getInstance();
        
        $sql = "SELECT 
                    p.id as product_id,
                    p.name as product_name,
                    p.barcode,
                    c.name as category_name,
                    COALESCE((
                        SELECT SUM(sh.units_remaining)
                        FROM shelf_inventory sh
                        INNER JOIN main_inventory mi ON sh.main_inventory_id = mi.id
                        WHERE mi.product_id = p.id
                    ), 0) as current_quantity,
                    COALESCE((
                        SELECT sh.selling_price_unit
                        FROM shelf_inventory sh
                        INNER JOIN main_inventory mi ON sh.main_inventory_id = mi.id
                        WHERE mi.product_id = p.id
                        LIMIT 1
                    ), 0) as selling_price,
                    COALESCE((
                        SELECT mi.cost_price_unit
                        FROM main_inventory mi
                        WHERE mi.product_id = p.id
                        LIMIT 1
                    ), 0) as cost_price,
                    COALESCE((
                        SELECT COUNT(DISTINCT s.id)
                        FROM sales s
                        INNER JOIN sale_items si ON s.id = si.sale_id
                        INNER JOIN shelf_inventory sh ON si.shelf_inventory_id = sh.id
                        INNER JOIN main_inventory mi ON sh.main_inventory_id = mi.id
                        WHERE mi.product_id = p.id AND s.sale_type = 'cash'
                    ), 0) as cash_sales_count,
                    COALESCE((
                        SELECT COUNT(DISTINCT s.id)
                        FROM sales s
                        INNER JOIN sale_items si ON s.id = si.sale_id
                        INNER JOIN shelf_inventory sh ON si.shelf_inventory_id = sh.id
                        INNER JOIN main_inventory mi ON sh.main_inventory_id = mi.id
                        WHERE mi.product_id = p.id AND s.sale_type = 'credit'
                    ), 0) as credit_sales_count
                FROM products p
                LEFT JOIN categories c ON p.category_id = c.id
                WHERE p.is_active = 1
                ORDER BY p.name ASC";

        $stmt = $db->prepare($sql);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * سجل منتج محدد
     */
    private function getProductHistory($productId, $from = null, $to = null) {
        return $this->reportModel->getProductHistory($productId, $from, $to);
    }

    // ==================== دوال الإحصائيات ====================

    private function getCashStats($from = null, $to = null) {
        return $this->reportModel->getCashStats($from, $to);
    }

    private function getCreditStats($from = null, $to = null) {
        return $this->reportModel->getCreditStats($from, $to);
    }

    private function getInventoryStats() {
        return $this->reportModel->getInventoryStats();
    }

    private function getProductsStats() {
        return $this->reportModel->getProductsStats();
    }

    // ==================== دوال مساعدة ====================

    /**
     * حساب التواريخ بناءً على الفترة
     */
    private function calculateDates($period, $from = null, $to = null) {
        $today = date('Y-m-d');
        
        switch ($period) {
            case 'daily':
                return [
                    'from' => $today,
                    'to' => $today
                ];
            
            case 'weekly':
                $weekStart = date('Y-m-d', strtotime('monday this week'));
                $weekEnd = date('Y-m-d', strtotime('sunday this week'));
                return [
                    'from' => $weekStart,
                    'to' => $weekEnd
                ];
            
            case 'monthly':
                $monthStart = date('Y-m-01');
                $monthEnd = date('Y-m-t');
                return [
                    'from' => $monthStart,
                    'to' => $monthEnd
                ];
            
            case 'semiannual':
                $sixMonthsAgo = date('Y-m-d', strtotime('-6 months'));
                return [
                    'from' => $sixMonthsAgo,
                    'to' => $today
                ];
            
            case 'annual':
                $yearStart = date('Y-01-01');
                $yearEnd = date('Y-12-31');
                return [
                    'from' => $yearStart,
                    'to' => $yearEnd
                ];
            
            case 'custom':
                return [
                    'from' => $from ?: $today,
                    'to' => $to ?: $today
                ];
            
            case 'all':
                return [
                    'from' => null,
                    'to' => null
                ];
            
            default:
                return [
                    'from' => null,
                    'to' => null
                ];
        }
    }

    /**
     * الحصول على سجل الجرد لمنتج محدد
     */
    public function auditHistory() {
        header('Content-Type: application/json; charset=utf-8');
        
        $productId = $this->getQuery('product_id', 0);
        
        if (!$productId) {
            echo json_encode(['success' => false, 'message' => 'معرف المنتج مطلوب']);
            exit;
        }
        
        $result = $this->reportModel->getProductAuditHistory($productId);
        
        echo json_encode([
            'success' => true,
            'data' => $result['history'],
            'stats' => $result['stats']
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }

    /**
     * تصدير إلى Excel (CSV)
     */
    private function exportToExcel($data, $filename, $dates = null) {
        // التحقق من أن البيانات موجودة
        if (empty($data)) {
            $data = [['لا توجد بيانات متاحة']];
        }
        
        // إنشاء محتوى CSV
        $output = fopen('php://temp', 'w');
        fprintf($output, chr(0xEF).chr(0xBB).chr(0xBF)); // UTF-8 BOM
        
        // معلومات التقرير
        if ($dates && isset($dates['from']) && isset($dates['to'])) {
            fputcsv($output, ['تقرير', $filename]);
            fputcsv($output, ['من تاريخ', $dates['from']]);
            fputcsv($output, ['إلى تاريخ', $dates['to']]);
            fputcsv($output, []);
        }
        
        // كتابة البيانات
        if (!empty($data) && is_array($data)) {
            // كتابة الرؤوس (أخذها من أول عنصر)
            $firstRow = reset($data);
            if (is_array($firstRow)) {
                fputcsv($output, array_keys($firstRow));
                
                // كتابة الصفوف
                foreach ($data as $row) {
                    if (is_array($row)) {
                        fputcsv($output, $row);
                    }
                }
            } else {
                fputcsv($output, ['البيانات']);
                foreach ($data as $row) {
                    fputcsv($output, [$row]);
                }
            }
        }
        
        rewind($output);
        $content = stream_get_contents($output);
        fclose($output);
        
        // إرسال الملف
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="' . $filename . '_' . date('Y-m-d') . '.csv"');
        header('Content-Length: ' . strlen($content));
        header('Pragma: no-cache');
        header('Expires: 0');
        
        echo $content;
        exit;
    }

    // ==================== دوال API لواجهة تحليلات المنتج ====================

    /**
     * API: جلب تفاصيل الدفعات للمنتج
     * GET: /reports/product-batches?product_id=123
     */
    public function getProductBatches() {
        header('Content-Type: application/json; charset=utf-8');
        
        $productId = $this->getQuery('product_id', 0);
        
        if (!$productId) {
            echo json_encode(['success' => false, 'message' => 'معرف المنتج مطلوب']);
            exit;
        }
        
        $data = $this->reportModel->getProductBatches($productId);
        
        echo json_encode([
            'success' => true,
            'data' => $data
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }

    /**
     * API: جلب مبيعات دفعة محددة
     * GET: /reports/batch-sales?batch_id=123
     */
    public function getBatchSales() {
        header('Content-Type: application/json; charset=utf-8');
        
        $batchId = $this->getQuery('batch_id', 0);
        
        if (!$batchId) {
            echo json_encode(['success' => false, 'message' => 'معرف الدفعة مطلوب']);
            exit;
        }
        
        $data = $this->reportModel->getBatchSales($batchId);
        
        echo json_encode([
            'success' => true,
            'data' => $data
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }

    /**
     * API: جلب تفاصيل المخزون الكاملة للمنتج
     * GET: /reports/product-inventory-details?product_id=123
     */
    public function getProductInventoryDetails() {
        header('Content-Type: application/json; charset=utf-8');
        
        $productId = $this->getQuery('product_id', 0);
        
        if (!$productId) {
            echo json_encode(['success' => false, 'message' => 'معرف المنتج مطلوب']);
            exit;
        }
        
        $data = $this->reportModel->getProductInventoryDetails($productId);
        
        echo json_encode([
            'success' => true,
            'data' => $data
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }

    /**
     * API: جلب المؤشرات السريعة للمنتج
     * GET: /reports/product-quick-stats?product_id=123
     */
    public function getProductQuickStats() {
        header('Content-Type: application/json; charset=utf-8');
        
        $productId = $this->getQuery('product_id', 0);
        
        if (!$productId) {
            echo json_encode(['success' => false, 'message' => 'معرف المنتج مطلوب']);
            exit;
        }
        
        $data = $this->reportModel->getProductQuickStats($productId);
        
        echo json_encode([
            'success' => true,
            'data' => $data
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }

    /**
     * API: جلب آخر جرد للمنتج
     * GET: /reports/last-audit?product_id=123
     */
    public function getLastAudit() {
        header('Content-Type: application/json; charset=utf-8');
        
        $productId = $this->getQuery('product_id', 0);
        
        if (!$productId) {
            echo json_encode(['success' => false, 'message' => 'معرف المنتج مطلوب']);
            exit;
        }
        
        $data = $this->reportModel->getLastAudit($productId);
        
        echo json_encode([
            'success' => true,
            'data' => $data ?: null
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }

    /**
     * API: حفظ الجرد الفعلي (محسن مع حساب القيمة المالية)
     * POST: /reports/save-physical-inventory
     */
    public function savePhysicalInventory() {
        header('Content-Type: application/json; charset=utf-8');
        
        if (!$this->isPost()) {
            echo json_encode(['success' => false, 'message' => 'طريقة طلب غير صحيحة']);
            exit;
        }

        $input = json_decode(file_get_contents('php://input'), true);
        
        if (!$input) {
            echo json_encode(['success' => false, 'message' => 'بيانات غير صالحة']);
            exit;
        }
        
        $productId = $input['product_id'] ?? 0;
        $actualQty = $input['actual_quantity'] ?? 0;
        $expectedQty = $input['expected_quantity'] ?? 0;
        $difference = $input['difference'] ?? 0;
        $reason = $input['reason'] ?? '';
        
        if (!$productId) {
            echo json_encode(['success' => false, 'message' => 'معرف المنتج مطلوب']);
            exit;
        }
        
        if (!is_numeric($actualQty) || $actualQty < 0) {
            echo json_encode(['success' => false, 'message' => 'الكمية الفعلية غير صالحة']);
            exit;
        }
        
        $db = Database::getInstance();
        
        try {
            $db->beginTransaction();
            
            // 1. إنشاء سجل جرد جديد
            $auditSql = "INSERT INTO inventory_audits (user_id, audit_date, total_discrepancy, status) 
                         VALUES (:user_id, NOW(), :total_discrepancy, 'completed')";
            
            $userId = $_SESSION['user_id'] ?? 1;
            
            $auditStmt = $db->prepare($auditSql);
            $auditStmt->execute([
                'user_id' => $userId,
                'total_discrepancy' => abs($difference)
            ]);
            
            $auditId = $db->lastInsertId();
            
            // 2. إضافة تفاصيل الجرد للمنتج
            $itemSql = "INSERT INTO audit_items (audit_id, product_id, expected_qty, actual_qty, difference, reason) 
                        VALUES (:audit_id, :product_id, :expected_qty, :actual_qty, :difference, :reason)";
            
            $itemStmt = $db->prepare($itemSql);
            $itemStmt->execute([
                'audit_id' => $auditId,
                'product_id' => $productId,
                'expected_qty' => $expectedQty,
                'actual_qty' => $actualQty,
                'difference' => $difference,
                'reason' => $reason
            ]);
            
            // 3. تسجيل في سجل النشاطات
            $logSql = "INSERT INTO activity_logs (user_id, action, details, ip_address) 
                       VALUES (:user_id, 'physical_inventory', :details, :ip)";
            $logStmt = $db->prepare($logSql);
            $logStmt->execute([
                'user_id' => $userId,
                'details' => "جرد المنتج ID {$productId}: متوقع {$expectedQty}, فعلي {$actualQty}, الفرق {$difference} - {$reason}",
                'ip' => $_SERVER['REMOTE_ADDR'] ?? null
            ]);
            
            $db->commit();
            
            echo json_encode([
                'success' => true,
                'message' => 'تم حفظ الجرد بنجاح',
                'audit_id' => $auditId
            ], JSON_UNESCAPED_UNICODE);
            
        } catch (Exception $e) {
            $db->rollBack();
            echo json_encode([
                'success' => false,
                'message' => 'حدث خطأ في حفظ الجرد: ' . $e->getMessage()
            ], JSON_UNESCAPED_UNICODE);
        }
        exit;
    }

    /**
     * API: جلب سجل الجرد الكامل للمنتج
     * GET: /reports/product-audit-history?product_id=123
     */
    public function getProductAuditHistory() {
        header('Content-Type: application/json; charset=utf-8');
        
        $productId = $this->getQuery('product_id', 0);
        
        if (!$productId) {
            echo json_encode(['success' => false, 'message' => 'معرف المنتج مطلوب']);
            exit;
        }
        
        $result = $this->reportModel->getProductAuditHistory($productId);
        
        echo json_encode([
            'success' => true,
            'data' => $result['history'],
            'stats' => $result['stats']
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }

    /**
     * API: تعديل عملية جرد
     * POST: /reports/edit-inventory-audit
     */
    public function editInventoryAudit() {
        header('Content-Type: application/json; charset=utf-8');
        
        if (!$this->isPost()) {
            echo json_encode(['success' => false, 'message' => 'طريقة طلب غير صحيحة']);
            exit;
        }

        $input = json_decode(file_get_contents('php://input'), true);
        
        $auditId = $input['audit_id'] ?? 0;
        $actualQty = $input['actual_qty'] ?? 0;
        $reason = $input['reason'] ?? '';
        
        if (!$auditId || !is_numeric($actualQty) || $actualQty < 0) {
            echo json_encode(['success' => false, 'message' => 'بيانات غير صالحة']);
            exit;
        }
        
        $result = $this->reportModel->updateAudit($auditId, $actualQty, $reason);
        echo json_encode($result, JSON_UNESCAPED_UNICODE);
        exit;
    }

    /**
     * API: حذف عملية جرد
     * POST: /reports/delete-inventory-audit
     */
    public function deleteInventoryAudit() {
        header('Content-Type: application/json; charset=utf-8');
        
        if (!$this->isPost()) {
            echo json_encode(['success' => false, 'message' => 'طريقة طلب غير صحيحة']);
            exit;
        }

        $input = json_decode(file_get_contents('php://input'), true);
        $auditId = $input['audit_id'] ?? 0;
        
        if (!$auditId) {
            echo json_encode(['success' => false, 'message' => 'معرف الجرد مطلوب']);
            exit;
        }
        
        $result = $this->reportModel->deleteAudit($auditId);
        echo json_encode($result, JSON_UNESCAPED_UNICODE);
        exit;
    }

    /**
     * API: تطبيق عملية الجرد وتحديث المخزون
     * POST: /reports/apply-inventory-audit
     */
    public function applyInventoryAudit() {
        header('Content-Type: application/json; charset=utf-8');
        
        if (!$this->isPost()) {
            echo json_encode(['success' => false, 'message' => 'طريقة طلب غير صحيحة']);
            exit;
        }

        $input = json_decode(file_get_contents('php://input'), true);
        $auditId = $input['audit_id'] ?? 0;
        
        if (!$auditId) {
            echo json_encode(['success' => false, 'message' => 'معرف الجرد مطلوب']);
            exit;
        }
        
        $result = $this->reportModel->applyAuditToDatabase($auditId);
        echo json_encode($result, JSON_UNESCAPED_UNICODE);
        exit;
    }

    /**
 * API: تحليل المبيعات للمنتج
 * GET: /reports/product-sales-analysis?product_id=15
 */
public function getProductSalesAnalysis() {
    header('Content-Type: application/json; charset=utf-8');
    
    try {
        $productId = $this->getQuery('product_id', 0);
        $from = $this->getQuery('from');
        $to = $this->getQuery('to');
        
        if (!$productId) {
            echo json_encode(['success' => false, 'message' => 'معرف المنتج مطلوب']);
            exit;
        }
        
        // استدعاء الدالة من Model
        $data = $this->reportModel->getProductSalesAnalysis($productId, $from, $to);
        
        echo json_encode([
            'success' => true,
            'data' => $data
        ], JSON_UNESCAPED_UNICODE);
        exit;
        
    } catch (Exception $e) {
        echo json_encode([
            'success' => false,
            'message' => $e->getMessage(),
            'file' => $e->getFile(),
            'line' => $e->getLine()
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }
}            
}