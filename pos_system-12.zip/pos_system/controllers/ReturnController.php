<?php
// ===== تعطيل جميع الاشعارات والأخطاء =====
error_reporting(0); // عدم عرض أي أخطاء
ini_set('display_errors', 0); // إخفاء الأخطاء
ini_set('display_startup_errors', 0); // إخفاء أخطاء بدء التشغيل
ini_set('log_errors', 0); // تعطيل تسجيل الأخطاء

// منع عرض أي مخرجات غير متوقعة
ob_start();

// تعطيل تقارير الأخطاء في PHP
if (function_exists('xdebug_disable')) {
    xdebug_disable();
}

// تجاهل جميع التحذيرات والأخطاء (لكن تنفيذ الكود يستمر)
set_error_handler(function($errno, $errstr, $errfile, $errline) {
    return true; // تجاهل الخطأ
}, E_ALL);

// تجاهل الأخطاء القاتلة
register_shutdown_function(function() {
    $error = error_get_last();
    if ($error) {
        // لا تفعل شيئاً - فقط تجاهل
        ob_end_clean();
    }
});

// باقي الكود...
require_once __DIR__ . '/../core/Controller.php';
require_once __DIR__ . '/../core/Auth.php';
require_once __DIR__ . '/../models/Sale.php';
require_once __DIR__ . '/../models/SaleItem.php';
require_once __DIR__ . '/../models/Product.php';
require_once __DIR__ . '/../models/Inventory.php';
require_once __DIR__ . '/../models/Shelf.php';
require_once __DIR__ . '/../models/Customer.php';
require_once __DIR__ . '/../models/ActivityLog.php';

class ReturnController extends Controller {
    
    private $saleModel;
    private $saleItemModel;
    private $productModel;
    private $inventoryModel;
    private $shelfModel;
    private $customerModel;
    private $logModel;

    public function __construct() {
        if (!Auth::check()) {
            $this->redirect('login');
        }

        $this->saleModel = new Sale();
        $this->saleItemModel = new SaleItem();
        $this->productModel = new Product();
        $this->inventoryModel = new Inventory();
        $this->shelfModel = new Shelf();
        $this->customerModel = new Customer();
        $this->logModel = new ActivityLog();
    }

    /**
     * البحث عن فاتورة للإرجاع
     */
    /**
 * البحث عن فاتورة للإرجاع - نسخة كاملة
 */
/**
 * البحث عن فاتورة للإرجاع - نسخة محدثة مع عرض رقم الرف
 */

/**
 * البحث عن فاتورة للإرجاع - مع التحقق من الكميات المتبقية للإرجاع
 */
public function searchInvoice() {
    if (ob_get_level()) ob_clean();
    header('Content-Type: application/json; charset=utf-8');
    
    $invoiceNumber = isset($_GET['invoice']) ? trim($_GET['invoice']) : '';
    
    if (empty($invoiceNumber)) {
        echo json_encode(['success' => false, 'message' => 'رقم الفاتورة مطلوب']);
        exit;
    }

    try {
        $db = Database::getInstance();
        
        // البحث عن الفاتورة
        $sql = "SELECT s.*, c.name as customer_name, c.current_balance as customer_balance,
                       c.credit_limit, c.id as customer_id
                FROM sales s
                LEFT JOIN customers c ON s.customer_id = c.id
                WHERE s.invoice_number = ?";
        $stmt = $db->prepare($sql);
        $stmt->execute([$invoiceNumber]);
        $sale = $stmt->fetch();
        
        if (!$sale) {
            echo json_encode(['success' => false, 'message' => 'الفاتورة غير موجودة']);
            exit;
        }

        // جلب إجمالي المرتجعات السابقة
        $returnedSql = "SELECT COALESCE(SUM(total_refund_amount), 0) as total_returned 
                        FROM returns 
                        WHERE sale_id = ?";
        $returnedStmt = $db->prepare($returnedSql);
        $returnedStmt->execute([$sale['id']]);
        $returned = $returnedStmt->fetch();
        $totalReturned = $returned ? floatval($returned['total_returned']) : 0;
        
        $returnableAmount = $sale['paid_amount'] - $totalReturned;
        if ($returnableAmount < 0) $returnableAmount = 0;

        // جلب عناصر الفاتورة مع كميات المرتجعات السابقة
        $sql = "SELECT si.*, 
                       p.name as product_name, 
                       p.barcode, 
                       p.id as product_id,
                       mi.batch_number, 
                       mi.expiry_date,
                       sh.shelf_code,
                       COALESCE(r.returned_quantity, 0) as returned_quantity
                FROM sale_items si
                JOIN shelf_inventory sh ON si.shelf_inventory_id = sh.id
                JOIN main_inventory mi ON sh.main_inventory_id = mi.id
                JOIN products p ON mi.product_id = p.id
                LEFT JOIN (
                    SELECT sale_item_id, COALESCE(SUM(quantity), 0) as returned_quantity
                    FROM return_items 
                    GROUP BY sale_item_id
                ) r ON si.id = r.sale_item_id
                WHERE si.sale_id = ?
                ORDER BY si.id ASC";
        $stmt = $db->prepare($sql);
        $stmt->execute([$sale['id']]);
        $items = $stmt->fetchAll();
        
        // حساب الكمية المتاحة للإرجاع لكل عنصر
        foreach ($items as &$item) {
            $item['returned_quantity'] = intval($item['returned_quantity'] ?? 0);
            $item['available_for_return'] = intval($item['quantity']) - $item['returned_quantity'];
            if ($item['available_for_return'] < 0) $item['available_for_return'] = 0;
        }
        
        echo json_encode([
            'success' => true,
            'data' => [
                'sale' => $sale,
                'items' => $items,
                'total_returned' => $totalReturned,
                'returnable_amount' => $returnableAmount
            ]
        ], JSON_UNESCAPED_UNICODE);
        exit;
        
    } catch (Exception $e) {
        error_log("Search invoice error: " . $e->getMessage());
        echo json_encode([
            'success' => false,
            'message' => 'خطأ في البحث: ' . $e->getMessage()
        ]);
        exit;
    }
}
/**
 * معالجة الإرجاع - نسخة متكاملة مع تحديث رصيد العميل
 */
public function processReturn() {
    header('Content-Type: application/json; charset=utf-8');
    
    if (!$this->isPost()) {
        echo json_encode(['success' => false, 'message' => 'طريقة طلب غير صحيحة']);
        exit;
    }

    $input = json_decode(file_get_contents('php://input'), true);
    
    if (!$input) {
        echo json_encode(['success' => false, 'message' => 'بيانات غير صالحة']);
        exit;
    }

    $db = Database::getInstance();
    
    try {
        $db->beginTransaction();

        $saleId = $input['sale_id'];
        $returnItems = $input['items'];
        $refundMethod = $input['refund_method'];
        $totalRefund = 0;

        // التحقق من الفاتورة
        $checkSaleSql = "SELECT id, total_amount, paid_amount, remaining_amount, sale_type, customer_id 
                        FROM sales WHERE id = ?";
        $checkSaleStmt = $db->prepare($checkSaleSql);
        $checkSaleStmt->execute([$saleId]);
        $sale = $checkSaleStmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$sale) {
            throw new Exception("الفاتورة غير موجودة");
        }

        // إنشاء رقم إرجاع
        $returnNumber = 'RET-' . date('Ymd') . '-' . rand(1000, 9999);

        // إدراج سجل الإرجاع الرئيسي
        $returnSql = "INSERT INTO returns (sale_id, return_number, total_refund_amount, refund_method, reason, created_by) 
                      VALUES (?, ?, ?, ?, ?, ?)";
        $returnStmt = $db->prepare($returnSql);
        $returnStmt->execute([
            $saleId,
            $returnNumber,
            0,
            $refundMethod,
            $input['reason'] ?? '',
            Auth::id()
        ]);

        $returnId = $db->lastInsertId();

        // مصفوفة لتخزين عناصر الإرجاع
        $returnItemsData = [];

        // معالجة كل عنصر مرتجع
        foreach ($returnItems as $item) {
            if (!$item['selected'] || $item['quantity'] <= 0) continue;

            $saleItemId = $item['sale_item_id'];
            $quantity = $item['quantity'];
            $price = $item['price'];
            $subtotal = $quantity * $price;
            $totalRefund += $subtotal;

            // ===== التحقق من الكمية المتاحة للإرجاع =====
            $checkReturnedSql = "SELECT COALESCE(SUM(quantity), 0) as total_returned 
                                FROM return_items 
                                WHERE sale_item_id = ?";
            $checkReturnedStmt = $db->prepare($checkReturnedSql);
            $checkReturnedStmt->execute([$saleItemId]);
            $returned = $checkReturnedStmt->fetch(PDO::FETCH_ASSOC);
            $totalReturned = $returned['total_returned'] ?? 0;

            // التحقق من الكمية المباعة الأصلية
            $checkQtySql = "SELECT quantity FROM sale_items WHERE id = ?";
            $checkQtyStmt = $db->prepare($checkQtySql);
            $checkQtyStmt->execute([$saleItemId]);
            $soldQty = $checkQtyStmt->fetchColumn();
            
            $availableForReturn = $soldQty - $totalReturned;
            
            if ($quantity > $availableForReturn) {
                throw new Exception("الكمية المرتجعة ($quantity) أكبر من المتاح ($availableForReturn)");
            }

            // ===== إدراج عنصر الإرجاع في جدول return_items =====
            $returnItemSql = "INSERT INTO return_items (return_id, sale_item_id, quantity, price, subtotal) 
                              VALUES (?, ?, ?, ?, ?)";
            $returnItemStmt = $db->prepare($returnItemSql);
            $returnItemStmt->execute([
                $returnId,
                $saleItemId,
                $quantity,
                $price,
                $subtotal
            ]);

            // تخزين بيانات العنصر للإستخدام لاحقاً
            $returnItemsData[] = [
                'sale_item_id' => $saleItemId,
                'quantity' => $quantity,
                'price' => $price,
                'subtotal' => $subtotal
            ];

            // جلب معلومات المنتج مع رقم الرف
            $shelfSql = "SELECT si.shelf_code, si.shelf_inventory_id,
                                sh.main_inventory_id,
                                mi.product_id,
                                p.name as product_name,
                                p.units_per_carton
                         FROM sale_items si
                         LEFT JOIN shelf_inventory sh ON si.shelf_inventory_id = sh.id
                         LEFT JOIN main_inventory mi ON sh.main_inventory_id = mi.id
                         LEFT JOIN products p ON mi.product_id = p.id
                         WHERE si.id = ?";
            $shelfStmt = $db->prepare($shelfSql);
            $shelfStmt->execute([$saleItemId]);
            $shelfInfo = $shelfStmt->fetch(PDO::FETCH_ASSOC);

            if (!$shelfInfo) {
                throw new Exception("لم يتم العثور على معلومات الرف للعنصر: $saleItemId");
            }

            $shelfCode = $shelfInfo['shelf_code'];
            $mainInventoryId = $shelfInfo['main_inventory_id'];
            $productId = $shelfInfo['product_id'];
            $productName = $shelfInfo['product_name'];
            $unitsPerCarton = $shelfInfo['units_per_carton'] ?: 1;

            // التحقق من وجود المنتج
            if (!$productId) {
                $tempBarcode = 'TEMP-' . time() . '-' . rand(1000, 9999);
                $insertProductSql = "INSERT INTO products (name, barcode, units_per_carton, is_active) 
                                     VALUES (?, ?, ?, 1)";
                $insertProductStmt = $db->prepare($insertProductSql);
                $insertProductStmt->execute([$productName, $tempBarcode, $unitsPerCarton]);
                $productId = $db->lastInsertId();
            }

            // البحث عن الرف الأصلي
            $checkShelfSql = "SELECT id, units_remaining FROM shelf_inventory WHERE shelf_code = ?";
            $checkShelfStmt = $db->prepare($checkShelfSql);
            $checkShelfStmt->execute([$shelfCode]);
            $existingShelf = $checkShelfStmt->fetch(PDO::FETCH_ASSOC);

            if ($existingShelf) {
                // الرف لا يزال موجوداً
                $updateShelfSql = "UPDATE shelf_inventory 
                                   SET units_remaining = units_remaining + ?,
                                       status = 'available'
                                   WHERE shelf_code = ?";
                $updateShelfStmt = $db->prepare($updateShelfSql);
                $updateShelfStmt->execute([$quantity, $shelfCode]);
                
                $updateMainSql = "UPDATE main_inventory 
                                  SET cartons_remaining = cartons_remaining + 1
                                  WHERE id = ?";
                $updateMainStmt = $db->prepare($updateMainSql);
                $updateMainStmt->execute([$mainInventoryId]);
                
            } else {
                // الرف غير موجود
                $findBatchSql = "SELECT id FROM main_inventory 
                                 WHERE product_id = ? AND cartons_remaining > 0 
                                 ORDER BY expiry_date ASC 
                                 LIMIT 1";
                $findBatchStmt = $db->prepare($findBatchSql);
                $findBatchStmt->execute([$productId]);
                $existingBatch = $findBatchStmt->fetch();

                $newMainInventoryId = null;

                if ($existingBatch) {
                    $newMainInventoryId = $existingBatch['id'];
                    $updateMainSql = "UPDATE main_inventory 
                                      SET cartons_remaining = cartons_remaining + 1
                                      WHERE id = ?";
                    $updateMainStmt = $db->prepare($updateMainSql);
                    $updateMainStmt->execute([$newMainInventoryId]);
                } else {
                    $batchNumber = 'RET-BATCH-' . date('Ymd') . '-' . rand(1000, 9999);
                    $costPriceCarton = $price * $unitsPerCarton;
                    $expiryDate = date('Y-m-d', strtotime('+1 year'));

                    $newMainSql = "INSERT INTO main_inventory 
                                  (product_id, batch_number, cartons_quantity, cartons_remaining, 
                                   cost_price_carton, cost_price_unit, selling_price_unit, expiry_date, notes)
                                  VALUES (?, ?, 1, 1, ?, ?, ?, ?, 'منتج مرتجع')";
                    $newMainStmt = $db->prepare($newMainSql);
                    $newMainStmt->execute([
                        $productId,
                        $batchNumber,
                        $costPriceCarton,
                        $price,
                        $price,
                        $expiryDate
                    ]);
                    $newMainInventoryId = $db->lastInsertId();
                }

                $newShelfCode = $shelfCode ?: ('SHELF-' . date('Ymd') . '-' . rand(1000, 9999));
                
                $insertShelfSql = "INSERT INTO shelf_inventory 
                                  (shelf_code, main_inventory_id, units_remaining, selling_price_unit, status, added_at)
                                  VALUES (?, ?, ?, ?, 'available', NOW())";
                $insertShelfStmt = $db->prepare($insertShelfSql);
                $insertShelfStmt->execute([
                    $newShelfCode,
                    $newMainInventoryId,
                    $quantity,
                    $price
                ]);
            }
        }

        // ===== تحديث الفاتورة =====
        $newPaidAmount = $sale['paid_amount'] - $totalRefund;
        $newRemainingAmount = $sale['total_amount'] - $newPaidAmount;
        
        if ($newPaidAmount < 0) $newPaidAmount = 0;
        if ($newRemainingAmount < 0) $newRemainingAmount = 0;
        
        $updateSaleSql = "UPDATE sales 
                          SET paid_amount = ?,
                              remaining_amount = ?
                          WHERE id = ?";
        $updateSaleStmt = $db->prepare($updateSaleSql);
        $updateSaleStmt->execute([$newPaidAmount, $newRemainingAmount, $saleId]);

        // ===== تحديث رصيد العميل بشكل صحيح =====
        if ($sale['customer_id']) {
            // الحالة 1: فاتورة آجلة والإرجاع نقدي (نخفض رصيد العميل)
            if ($sale['sale_type'] === 'credit' && $refundMethod === 'cash') {
                $updateCustomerSql = "UPDATE customers 
                                      SET current_balance = current_balance - ?
                                      WHERE id = ?";
                $updateCustomerStmt = $db->prepare($updateCustomerSql);
                $updateCustomerStmt->execute([$totalRefund, $sale['customer_id']]);
                
                error_log("تم تحديث رصيد العميل {$sale['customer_id']}: خصم {$totalRefund} ريال (إرجاع نقدي من فاتورة آجلة)");
            }
            
            // الحالة 2: فاتورة نقدية والإرجاع إلى رصيد العميل (نزيد رصيد العميل)
            else if ($sale['sale_type'] === 'cash' && $refundMethod === 'customer_balance') {
                $updateCustomerSql = "UPDATE customers 
                                      SET current_balance = current_balance + ?
                                      WHERE id = ?";
                $updateCustomerStmt = $db->prepare($updateCustomerSql);
                $updateCustomerStmt->execute([$totalRefund, $sale['customer_id']]);
                
                error_log("تم تحديث رصيد العميل {$sale['customer_id']}: إضافة {$totalRefund} ريال (إرجاع إلى رصيد العميل)");
            }
            
            // الحالة 3: فاتورة آجلة والإرجاع إلى رصيد العميل (تخفيض الرصيد)
            else if ($sale['sale_type'] === 'credit' && $refundMethod === 'customer_balance') {
                $updateCustomerSql = "UPDATE customers 
                                      SET current_balance = current_balance - ?
                                      WHERE id = ?";
                $updateCustomerStmt = $db->prepare($updateCustomerSql);
                $updateCustomerStmt->execute([$totalRefund, $sale['customer_id']]);
                
                error_log("تم تحديث رصيد العميل {$sale['customer_id']}: خصم {$totalRefund} ريال (إرجاع إلى رصيد العميل من فاتورة آجلة)");
            }
            
            // الحالة 4: فاتورة آجلة والإرجاع نقدي (تم التعامل معها أعلاه)
            // الحالة 5: فاتورة نقدية والإرجاع نقدي (لا تأثير على رصيد العميل)
        }

        // تحديث إجمالي الإرجاع
        $updateReturnSql = "UPDATE returns SET total_refund_amount = ? WHERE id = ?";
        $updateReturnStmt = $db->prepare($updateReturnSql);
        $updateReturnStmt->execute([$totalRefund, $returnId]);

        $db->commit();

        // حساب الكميات الجديدة للرد
        $updatedItems = [];
        foreach ($returnItemsData as $returnedItem) {
            $calcSql = "SELECT 
                            COALESCE(SUM(quantity), 0) as total_returned,
                            (SELECT quantity FROM sale_items WHERE id = ?) as sold_quantity
                        FROM return_items 
                        WHERE sale_item_id = ?";
            $calcStmt = $db->prepare($calcSql);
            $calcStmt->execute([$returnedItem['sale_item_id'], $returnedItem['sale_item_id']]);
            $calc = $calcStmt->fetch(PDO::FETCH_ASSOC);
            
            $updatedItems[] = [
                'sale_item_id' => $returnedItem['sale_item_id'],
                'returned_quantity' => $calc['total_returned'],
                'available_for_return' => $calc['sold_quantity'] - $calc['total_returned']
            ];
        }

        echo json_encode([
            'success' => true,
            'message' => 'تم الإرجاع بنجاح',
            'return_number' => $returnNumber,
            'total_refund' => $totalRefund,
            'new_paid_amount' => $newPaidAmount,
            'new_remaining' => $newRemainingAmount,
            'updated_items' => $updatedItems
        ], JSON_UNESCAPED_UNICODE);
        exit;

    } catch (Exception $e) {
        $db->rollBack();
        error_log("Return error: " . $e->getMessage());
        echo json_encode([
            'success' => false,
            'message' => 'خطأ في الإرجاع: ' . $e->getMessage()
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }
}
    
}