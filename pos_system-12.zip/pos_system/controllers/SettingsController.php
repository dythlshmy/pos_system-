<?php
require_once __DIR__ . '/../core/Controller.php';
require_once __DIR__ . '/../core/Auth.php';
require_once __DIR__ . '/../core/Middleware.php';
require_once __DIR__ . '/../models/Setting.php';
require_once __DIR__ . '/../models/ActivityLog.php';

class SettingsController extends Controller {
    
    private $settingModel;
    private $logModel;

    public function __construct() {
        // التحقق من تسجيل الدخول
        if (!Auth::check()) {
            $this->redirect('login');
        }

        // التحقق من الصلاحية (admin فقط) باستثناء النسخ الآلي
        if (!Auth::isAdmin() && strpos($_SERVER['REQUEST_URI'], 'auto-backup') === false) {
            header("HTTP/1.0 403 Forbidden");
            die("غير مصرح بالدخول إلى هذه الصفحة");
        }

        $this->settingModel = new Setting();
        $this->logModel = new ActivityLog();
    }

    /**
     * عرض صفحة إعدادات الطباعة
     */
    public function index() {
        $data = [
            'title' => 'إعدادات الطباعة',
            'settings' => $this->settingModel->getPrintSettings(),
            'company_info' => $this->settingModel->getCompanyInfoArray(),
            'save_path_valid' => $this->settingModel->validateSavePath()
        ];
        
        $this->view('settings/index', $data);
    }

    /**
     * حفظ إعدادات الطباعة (AJAX)
     */
    public function save() {
        if (!$this->isPost()) {
            $this->json(['success' => false, 'message' => 'طريقة طلب غير صحيحة'], 405);
            return;
        }

        // جمع البيانات من POST
        $settings = [
            'print_enabled' => $this->getPost('print_enabled') === 'on' ? '1' : '0',
            'print_save_path' => $this->getPost('print_save_path', 'C:/invoices/'),
            'print_open_automatically' => $this->getPost('print_open_automatically') === 'on' ? '1' : '0',
            'print_header_text' => $this->getPost('print_header_text', 'سوبر ماركت النخبة'),
            'print_footer_text' => $this->getPost('print_footer_text', 'شكراً لزيارتكم'),
            'print_company_info' => $this->getPost('print_company_info'),
            'print_template_id' => $this->getPost('print_template_id', '1'),
            'store_name' => $this->getPost('store_name', 'نظام الكاشير'),
            
            // Backup settings
            'backup_path' => $this->getPost('backup_path', ''),
            'backup_hour' => $this->getPost('backup_hour', ''),
            'backup_minute' => $this->getPost('backup_minute', ''),
            'backup_ampm' => $this->getPost('backup_ampm', ''),
            'backup_enabled' => $this->getPost('backup_enabled', '0')
        ];

        // التحقق من صحة المسار
        $this->settingModel->set('print_save_path', $settings['print_save_path']);
        $pathValidation = $this->settingModel->validateSavePath();
        
        if (!$pathValidation['success']) {
            $this->json(['success' => false, 'message' => $pathValidation['message']]);
            return;
        }

        // حفظ الإعدادات
        $result = $this->settingModel->savePrintSettings($settings);
        
        if ($result) {
            // تسجيل النشاط
            $this->logModel->log('settings_saved', 'تم تحديث إعدادات الطباعة');
            
            $this->json([
                'success' => true, 
                'message' => 'تم حفظ الإعدادات بنجاح',
                'settings' => $settings
            ]);
        } else {
            $this->json(['success' => false, 'message' => 'فشل في حفظ الإعدادات']);
        }
    }

    /**
     * اختبار الطباعة (AJAX)
     */
    public function testPrint() {
        try {
            // جلب الإعدادات الحالية
            $settings = $this->settingModel->getPrintSettings();
            
            // التحقق من صحة المسار
            $pathValidation = $this->settingModel->validateSavePath();
            if (!$pathValidation['success']) {
                $this->json(['success' => false, 'message' => $pathValidation['message']]);
                return;
            }

            // إنشاء فاتورة تجريبية
            $testInvoice = $this->generateTestInvoice();
            
            // محاكاة إنشاء ملف PDF (سنقوم بتحسينها لاحقاً)
            $fileName = 'test_invoice_' . date('Ymd_His') . '.pdf';
            $filePath = $this->settingModel->getSavePath() . $fileName;
            
            // هنا سيتم إنشاء ملف PDF فعلياً في المرحلة القادمة
            
            $this->json([
                'success' => true,
                'message' => 'تم إنشاء الفاتورة التجريبية بنجاح',
                'invoice' => $testInvoice,
                'settings' => $settings,
                'file_path' => $filePath
            ]);
            
        } catch (Exception $e) {
            $this->json(['success' => false, 'message' => 'خطأ: ' . $e->getMessage()]);
        }
    }

    /**
     * تصدير قاعدة البيانات (AJAX)
     */
    /**
     * تصدير قاعدة البيانات مع استثناء التراخيص
     */
    public function exportDb() {
        try {
            $db = $this->settingModel->getConnection();
            $sqlScript = "-- POS System Backup\n";
            $sqlScript .= "-- Generation Time: " . date('Y-m-d H:i:s') . "\n\n";
            $sqlScript .= "SET FOREIGN_KEY_CHECKS = 0;\n";
            $sqlScript .= "SET SQL_MODE = 'NO_AUTO_VALUE_ON_ZERO';\n";
            $sqlScript .= "SET time_zone = '+00:00';\n\n";

            // جلب الجداول والواجهات
            $tables = $db->query('SHOW FULL TABLES')->fetchAll(PDO::FETCH_NUM);

            foreach ($tables as $table) {
                $tableName = $table[0];
                $isView = ($table[1] === 'VIEW');

                // *** استثناء جدول التراخيص ***
                if ($tableName === 'licenses') {
                    continue;
                }

                if ($isView) {
                    $sqlScript .= "DROP VIEW IF EXISTS `$tableName`;\n";
                    $viewQuery = $db->query("SHOW CREATE VIEW `$tableName`")->fetch(PDO::FETCH_NUM);
                    $createViewSql = $viewQuery[1];
                    // تنظيف الـ DEFINER لضمان التوافق
                    $createViewSql = preg_replace('/DEFINER=`[^`]+`@`[^`]+`/', 'DEFINER=CURRENT_USER', $createViewSql);
                    $sqlScript .= $createViewSql . ";\n\n";
                } else {
                    $sqlScript .= "DROP TABLE IF EXISTS `$tableName`;\n";
                    $tableQuery = $db->query("SHOW CREATE TABLE `$tableName`")->fetch(PDO::FETCH_NUM);
                    $sqlScript .= $tableQuery[1] . ";\n\n";

                    $rows = $db->query("SELECT * FROM `$tableName`")->fetchAll(PDO::FETCH_ASSOC);
                    foreach ($rows as $row) {
                        // *** استثناء قيم الترخيص داخل جدول الإعدادات ***
                        if ($tableName === 'settings') {
                            $key = $row['setting_key'] ?? '';
                            if (stripos($key, 'license') !== false || stripos($key, 'activation') !== false) {
                                continue;
                            }
                        }

                        $columns = array_keys($row);
                        $values = array_values($row);
                        $escapedValues = array_map(function($v) use ($db) {
                            return ($v === null) ? 'NULL' : $db->quote($v);
                        }, $values);

                        $sqlScript .= "INSERT INTO `$tableName` (`" . implode('`, `', $columns) . "`) VALUES (" . implode(', ', $escapedValues) . ");\n";
                    }
                    $sqlScript .= "\n";
                }
            }

            $sqlScript .= "SET FOREIGN_KEY_CHECKS = 1;";

            header('Content-Type: application/sql');
            header('Content-Disposition: attachment; filename="pos_clean_backup_' . date('Ymd_His') . '.sql"');
            echo $sqlScript;
            exit;

        } catch (Exception $e) {
            die("Error: " . $e->getMessage());
        }
    }

    /**
     * استيراد قاعدة البيانات (AJAX)
     */
    public function importDb() {
        if (!$this->isPost() || !isset($_FILES['backup_file'])) {
            $this->json(['success' => false, 'message' => 'طريقة طلب غير صحيحة أو لم يتم إرسال ملف']);
            return;
        }
        
        $file = $_FILES['backup_file'];
        
        if ($file['error'] !== UPLOAD_ERR_OK) {
            $this->json(['success' => false, 'message' => 'خطأ في رفع الملف']);
            return;
        }

        $extension = pathinfo($file['name'], PATHINFO_EXTENSION);
        if (strtolower($extension) !== 'sql') {
            $this->json(['success' => false, 'message' => 'صيغة الملف غير مدعومة. يرجى رفع ملف SQL فقط.']);
            return;
        }
        
        try {
            $sqlContent = file_get_contents($file['tmp_name']);
            if (empty($sqlContent)) {
                 throw new Exception("الملف فارغ");
            }

            $db = Database::getInstance();
            
            // Disable foreign key checks temporarily for import safety
            $db->exec('SET FOREIGN_KEY_CHECKS = 0');
            
            // Execute the raw SQL content
            // NOTE: This assumes the SQL is well-formed. PDO exec can run multiple queries if enabled.
            $db->exec($sqlContent);
            
            // Re-enable foreign key checks
            $db->exec('SET FOREIGN_KEY_CHECKS = 1');
            
            $this->logModel->log('db_imported', 'تم استيراد قاعدة البيانات من نسخة احتياطية');
            $this->json(['success' => true, 'message' => 'تم استيراد قاعدة البيانات بنجاح']);
            
        } catch (Exception $e) {
            $this->json(['success' => false, 'message' => 'حدث خطأ أثناء الاستيراد: ' . $e->getMessage()]);
        }
    }

    /**
     * إعادة ضبط النظام (AJAX)
     */
    public function resetSystem() {
        if (!$this->isPost()) {
            $this->json(['success' => false, 'message' => 'طريقة طلب غير صحيحة']);
            return;
        }
        
        try {
            $db = Database::getInstance();
            
            $db->exec('SET FOREIGN_KEY_CHECKS = 0');
            
            // قائمة الجداول التي سيتم تفريغها (نستثني جدول المستخدمين مثلاً حتى لا يفقد الأدمن حق الدخول، أو نضيف أدمن افتراضي)
            $tablesToTruncate = [
                'activity_logs', 
                'invoice_items', 
                'invoices', 
                'returns', 
                'return_items',
                'inventory_movements',
                'products',
                'categories',
                'customers',
                'shelves'
                // لا تحذف users لتجنب الخروج الدائم
            ];
            
            foreach ($tablesToTruncate as $table) {
                // Verify table exists first
                $check = $db->query("SHOW TABLES LIKE '$table'");
                if($check->rowCount() > 0) {
                    $db->exec("TRUNCATE TABLE `$table`");
                }
            }
            
            $db->exec('SET FOREIGN_KEY_CHECKS = 1');
            
            $this->logModel->log('system_reset', 'تم إجراء إعادة ضبط النظام بنجاح بالكامل');
            $this->json(['success' => true, 'message' => 'تم إعادة ضبط النظام بنجاح']);
            
        } catch (Exception $e) {
            $this->json(['success' => false, 'message' => 'حدث خطأ أثناء إعادة ضبط النظام: ' . $e->getMessage()]);
        }
    }

    /**
     * توليد فاتورة تجريبية للاختبار
     */
    private function generateTestInvoice() {
        return [
            'invoice_number' => 'TEST-' . date('Ymd') . '-001',
            'date' => date('Y-m-d H:i:s'),
            'seller' => 'المستخدم: ' . Auth::name(),
            'items' => [
                [
                    'name' => 'منتج تجريبي 1',
                    'quantity' => 2,
                    'price' => 15.00,
                    'total' => 30.00
                ],
                [
                    'name' => 'منتج تجريبي 2',
                    'quantity' => 1,
                    'price' => 25.00,
                    'total' => 25.00
                ],
                [
                    'name' => 'منتج تجريبي 3',
                    'quantity' => 3,
                    'price' => 10.00,
                    'total' => 30.00
                ]
            ],
            'total' => 85.00
        ];
    }

    /**
     * تنفيذ النسخ الاحتياطي التلقائي (يتم استدعاؤه بخلفية النظام)
     */
       /**
     * النسخ الاحتياطي التلقائي (نظيف من التراخيص)
     */
    public function autoBackup() {
        try {
            $backupEnabled = $this->settingModel->get('backup_enabled', '0');
            if ($backupEnabled !== '1') return;

            $backupTime = $this->settingModel->get('backup_time', '00:00');
            $currentTime = date('H:i');
            $today = date('Y-m-d');
            $backupDateKey = 'last_backup_date';
            $lastBackupDate = $this->settingModel->get($backupDateKey, '');

            if ($lastBackupDate === $today || $currentTime < $backupTime) return;

            $db = $this->settingModel->getConnection();
            $sqlScript = "SET FOREIGN_KEY_CHECKS = 0;\n";

            $tables = $db->query('SHOW FULL TABLES')->fetchAll(PDO::FETCH_NUM);

            foreach ($tables as $table) {
                $tableName = $table[0];
                if ($table[1] === 'VIEW' || $tableName === 'licenses') continue; // تخطي التراخيص والواجهات

                $rows = $db->query("SELECT * FROM `$tableName`")->fetchAll(PDO::FETCH_ASSOC);
                foreach ($rows as $row) {
                    // *** استثناء بيانات التفعيل من جدول الإعدادات ***
                    if ($tableName === 'settings') {
                        $key = $row['setting_key'] ?? '';
                        if (stripos($key, 'license') !== false || stripos($key, 'activation') !== false) {
                            continue;
                        }
                    }
                    
                    $columns = array_keys($row);
                    $values = array_values($row);
                    $escapedValues = array_map(function($v) use ($db) {
                        return ($v === null) ? 'NULL' : $db->quote($v);
                    }, $values);
                    $sqlScript .= "INSERT INTO `$tableName` (`" . implode('`, `', $columns) . "`) VALUES (" . implode(', ', $escapedValues) . ");\n";
                }
            }
            $sqlScript .= "SET FOREIGN_KEY_CHECKS = 1;";

            $backupPath = $this->settingModel->get('backup_path', 'C:/backups/');
            if (!is_dir($backupPath)) mkdir($backupPath, 0777, true);
            
            $filename = 'pos_clean_auto_' . date('Ymd_His') . '.sql';
            if (file_put_contents($backupPath . $filename, $sqlScript)) {
                $this->settingModel->set($backupDateKey, $today);
                // حذف النسخ القديمة
                foreach (glob($backupPath . 'pos_clean_auto_*.sql') as $f) {
                    if (basename($f) !== $filename) @unlink($f);
                }
            }
        } catch (Exception $e) {
            error_log("Auto backup error: " . $e->getMessage());
        }
    }

}