<?php
require_once __DIR__ . '/../core/Controller.php';
require_once __DIR__ . '/../core/Auth.php';
require_once __DIR__ . '/../models/Customer.php';
require_once __DIR__ . '/../models/Sale.php';
require_once __DIR__ . '/../models/PaymentHistory.php';

class CustomersController extends Controller {
    
    private $customerModel;
    private $saleModel;
    private $paymentModel;

    public function __construct() {
        if (!Auth::check()) {
            $this->redirect('login');
            return;
        }
        $this->customerModel = new Customer();
        $this->saleModel = new Sale();
        $this->paymentModel = new PaymentHistory();
    }

    /**
     * عرض صفحة العملاء
     */
    public function index() {
        $data = [
            'title' => 'إدارة العملاء',
            'customers' => $this->customerModel->getActive()
        ];
        $this->view('customers/index', $data);
    }

    /**
     * جلب جميع العملاء
     */
    public function getAll() {
        header('Content-Type: application/json; charset=utf-8');
        
        try {
            $customers = $this->customerModel->getActive();
            echo json_encode(['success' => true, 'data' => $customers]);
            return;
        } catch (Exception $e) {
            echo json_encode([
                'success' => false, 
                'message' => '❌ خطأ في جلب البيانات: ' . $e->getMessage()
            ]);
            return;
        }
    }

    /**
     * جلب إحصائيات العملاء
     */
    public function getStatistics() {
        header('Content-Type: application/json; charset=utf-8');
        
        try {
            $db = Database::getInstance();
            
            // إجمالي العملاء
            $stmt = $db->query("SELECT COUNT(*) FROM customers WHERE is_active = 1");
            $total = $stmt->fetchColumn();
            
            // إجمالي الديون
            $stmt = $db->query("SELECT COALESCE(SUM(current_balance), 0) FROM customers WHERE is_active = 1");
            $debts = $stmt->fetchColumn();
            
            // العملاء المتجاوزين للحد
            $stmt = $db->query("SELECT COUNT(*) FROM customers WHERE current_balance > credit_limit AND is_active = 1");
            $exceeded = $stmt->fetchColumn();
            
            echo json_encode([
                'success' => true,
                'data' => [
                    'total_customers' => (int)$total,
                    'total_debts' => (float)$debts,
                    'exceeded_customers' => (int)$exceeded
                ]
            ]);
            return;
            
        } catch (Exception $e) {
            echo json_encode([
                'success' => false, 
                'message' => '❌ خطأ في جلب الإحصائيات: ' . $e->getMessage()
            ]);
            return;
        }
    }

    /**
     * جلب بيانات عميل معين
     */
    public function getCustomerData() {
        header('Content-Type: application/json; charset=utf-8');
        
        $customerId = isset($_GET['id']) ? (int)$_GET['id'] : 0;
        
        if (!$customerId) {
            echo json_encode([
                'success' => false, 
                'message' => '❌ خطأ: معرف العميل مطلوب'
            ]);
            return;
        }

        try {
            $db = Database::getInstance();
            
            // بيانات العميل
            $stmt = $db->prepare("SELECT * FROM customers WHERE id = ?");
            $stmt->execute([$customerId]);
            $customer = $stmt->fetch();
            
            if (!$customer) {
                echo json_encode([
                    'success' => false, 
                    'message' => '❌ خطأ: العميل غير موجود في النظام'
                ]);
                return;
            }
            
            // فواتير العميل
            $stmt = $db->prepare("
                SELECT s.*, 
                       GROUP_CONCAT(p.name SEPARATOR '||') as products
                FROM sales s
                LEFT JOIN sale_items si ON s.id = si.sale_id
                LEFT JOIN shelf_inventory sh ON si.shelf_inventory_id = sh.id
                LEFT JOIN main_inventory mi ON sh.main_inventory_id = mi.id
                LEFT JOIN products p ON mi.product_id = p.id
                WHERE s.customer_id = ?
                GROUP BY s.id
                ORDER BY s.created_at DESC
            ");
            $stmt->execute([$customerId]);
            $invoices = $stmt->fetchAll();
            
            // ملخص
            $totalPurchases = 0;
            $totalPayments = 0;
            foreach ($invoices as $inv) {
                $totalPurchases += $inv['total_amount'];
                $totalPayments += $inv['paid_amount'];
            }
            
            echo json_encode([
                'success' => true,
                'data' => [
                    'customer' => $customer,
                    'invoices' => $invoices,
                    'summary' => [
                        'total_purchases' => (float)$totalPurchases,
                        'total_payments' => (float)$totalPayments,
                        'current_balance' => (float)$customer['current_balance'],
                        'available' => (float)($customer['credit_limit'] - $customer['current_balance'])
                    ]
                ]
            ]);
            return;
            
        } catch (Exception $e) {
            echo json_encode([
                'success' => false, 
                'message' => '❌ خطأ في جلب بيانات العميل: ' . $e->getMessage()
            ]);
            return;
        }
    }

    /**
     * إضافة عميل جديد
     */
    public function add() {
        header('Content-Type: application/json; charset=utf-8');
        
        if (!$this->isPost()) {
            echo json_encode([
                'success' => false, 
                'message' => '❌ خطأ: طريقة الطلب غير صحيحة'
            ]);
            return;
        }

        $input = json_decode(file_get_contents('php://input'), true);
        
        $name = isset($input['name']) ? trim($input['name']) : '';
        $limit = isset($input['credit_limit']) ? (float)$input['credit_limit'] : 0;
        
        if (empty($name)) {
            echo json_encode([
                'success' => false, 
                'message' => '❌ خطأ: اسم العميل مطلوب'
            ]);
            return;
        }

        try {
            $db = Database::getInstance();
            
            $sql = "INSERT INTO customers (name, phone, email, credit_limit, payment_due_date, is_active, created_at)
                    VALUES (?, ?, ?, ?, ?, 1, NOW())";
            $stmt = $db->prepare($sql);
            $result = $stmt->execute([
                $name,
                isset($input['phone']) ? $input['phone'] : null,
                isset($input['email']) ? $input['email'] : null,
                $limit,
                isset($input['payment_due_date']) ? $input['payment_due_date'] : null
            ]);
            
            if ($result) {
                echo json_encode([
                    'success' => true, 
                    'message' => '✅ تم إضافة العميل بنجاح'
                ]);
            } else {
                echo json_encode([
                    'success' => false, 
                    'message' => '❌ فشل إضافة العميل: خطأ في قاعدة البيانات'
                ]);
            }
            return;
            
        } catch (Exception $e) {
            echo json_encode([
                'success' => false, 
                'message' => '❌ خطأ في إضافة العميل: ' . $e->getMessage()
            ]);
            return;
        }
    }

    /**
     * تحديث بيانات عميل
     */
    public function update() {
        header('Content-Type: application/json; charset=utf-8');
        
        if (!$this->isPost()) {
            echo json_encode([
                'success' => false, 
                'message' => '❌ خطأ: طريقة الطلب غير صحيحة'
            ]);
            return;
        }

        $input = json_decode(file_get_contents('php://input'), true);
        
        $id = isset($input['id']) ? (int)$input['id'] : 0;
        $name = isset($input['name']) ? trim($input['name']) : '';
        $limit = isset($input['credit_limit']) ? (float)$input['credit_limit'] : 0;
        
        if (!$id || empty($name)) {
            echo json_encode([
                'success' => false, 
                'message' => '❌ خطأ: بيانات غير صالحة'
            ]);
            return;
        }

        try {
            $db = Database::getInstance();
            
            $sql = "UPDATE customers 
                    SET name = ?, phone = ?, email = ?, credit_limit = ?, payment_due_date = ?
                    WHERE id = ?";
            $stmt = $db->prepare($sql);
            $result = $stmt->execute([
                $name,
                isset($input['phone']) ? $input['phone'] : null,
                isset($input['email']) ? $input['email'] : null,
                $limit,
                isset($input['payment_due_date']) ? $input['payment_due_date'] : null,
                $id
            ]);
            
            if ($result) {
                echo json_encode([
                    'success' => true, 
                    'message' => '✅ تم تحديث البيانات بنجاح'
                ]);
            } else {
                echo json_encode([
                    'success' => false, 
                    'message' => '❌ فشل تحديث البيانات'
                ]);
            }
            return;
            
        } catch (Exception $e) {
            echo json_encode([
                'success' => false, 
                'message' => '❌ خطأ في تحديث البيانات: ' . $e->getMessage()
            ]);
            return;
        }
    }

    /**
     * حذف عميل (تعطيل) مع التحقق من الديون
     */
    public function delete() {
        header('Content-Type: application/json; charset=utf-8');
        
        // التحقق من أن الطلب من نوع DELETE
        if ($_SERVER['REQUEST_METHOD'] !== 'DELETE') {
            echo json_encode([
                'success' => false, 
                'message' => '❌ خطأ: طريقة الطلب غير صحيحة'
            ]);
            return;
        }
        
        $id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
        
        if (!$id) {
            echo json_encode([
                'success' => false, 
                'message' => '❌ خطأ: معرف العميل مطلوب'
            ]);
            return;
        }

        $db = Database::getInstance();
        
        try {
            // التحقق من وجود ديون غير مسددة
            $checkSql = "SELECT 
                            current_balance,
                            (SELECT COUNT(*) FROM sales WHERE customer_id = ? AND remaining_amount > 0) as unpaid_invoices
                        FROM customers 
                        WHERE id = ?";
            $checkStmt = $db->prepare($checkSql);
            $checkStmt->execute([$id, $id]);
            $customer = $checkStmt->fetch();
            
            if (!$customer) {
                echo json_encode([
                    'success' => false, 
                    'message' => '❌ خطأ: العميل غير موجود'
                ]);
                return;
            }
            
            // التحقق من الرصيد
            if ($customer['current_balance'] > 0) {
                echo json_encode([
                    'success' => false, 
                    'message' => '❌ لا يمكن حذف العميل: لديه ديون مستحقة بمبلغ ' . number_format($customer['current_balance'], 2) . ' ريال'
                ]);
                return;
            }
            
            // التحقق من الفواتير غير المسددة
            if ($customer['unpaid_invoices'] > 0) {
                echo json_encode([
                    'success' => false, 
                    'message' => '❌ لا يمكن حذف العميل: لديه ' . $customer['unpaid_invoices'] . ' فواتير غير مسددة'
                ]);
                return;
            }
            
            // إذا اجتاز التحقق، يتم الحذف (تعطيل)
            $sql = "UPDATE customers SET is_active = 0 WHERE id = ?";
            $stmt = $db->prepare($sql);
            $result = $stmt->execute([$id]);
            
            if ($result) {
                // تسجيل عملية الحذف في سجل النشاطات
                $logSql = "INSERT INTO activity_logs (user_id, action, details, ip_address, created_at) 
                           VALUES (?, 'delete_customer', ?, ?, NOW())";
                $logStmt = $db->prepare($logSql);
                $logStmt->execute([
                    Auth::id(),
                    'تم حذف العميل رقم: ' . $id,
                    $_SERVER['REMOTE_ADDR'] ?? '::1'
                ]);
                
                echo json_encode([
                    'success' => true, 
                    'message' => '✅ تم حذف العميل بنجاح'
                ]);
            } else {
                echo json_encode([
                    'success' => false, 
                    'message' => '❌ فشل حذف العميل: خطأ في قاعدة البيانات'
                ]);
            }
            return;
            
        } catch (Exception $e) {
            error_log("Delete customer error: " . $e->getMessage());
            echo json_encode([
                'success' => false, 
                'message' => '❌ حدث خطأ في النظام: ' . $e->getMessage()
            ]);
            return;
        }
    }

    /**
     * التحقق من رصيد العميل قبل الحذف
     */
    public function checkBalance() {
        header('Content-Type: application/json; charset=utf-8');
        
        $id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
        
        if (!$id) {
            echo json_encode([
                'has_debt' => false, 
                'has_unpaid_invoices' => false,
                'message' => '❌ معرف العميل مطلوب'
            ]);
            return;
        }

        try {
            $db = Database::getInstance();
            
            $sql = "SELECT 
                        current_balance,
                        (SELECT COUNT(*) FROM sales WHERE customer_id = ? AND remaining_amount > 0) as unpaid_invoices
                    FROM customers 
                    WHERE id = ?";
            $stmt = $db->prepare($sql);
            $stmt->execute([$id, $id]);
            $customer = $stmt->fetch();
            
            if (!$customer) {
                echo json_encode([
                    'has_debt' => false, 
                    'has_unpaid_invoices' => false,
                    'message' => '❌ العميل غير موجود'
                ]);
                return;
            }
            
            echo json_encode([
                'has_debt' => $customer['current_balance'] > 0,
                'balance' => number_format($customer['current_balance'], 2),
                'has_unpaid_invoices' => $customer['unpaid_invoices'] > 0,
                'invoices_count' => $customer['unpaid_invoices']
            ]);
            return;
            
        } catch (Exception $e) {
            echo json_encode([
                'has_debt' => false, 
                'has_unpaid_invoices' => false,
                'message' => '❌ خطأ في التحقق: ' . $e->getMessage()
            ]);
            return;
        }
    }

    /**
     * تصفية العملاء بالتاريخ
     */
    public function filterByDate() {
        header('Content-Type: application/json; charset=utf-8');
        
        $from = isset($_GET['from']) ? $_GET['from'] : null;
        $to = isset($_GET['to']) ? $_GET['to'] : null;
        
        if (!$from || !$to) {
            echo json_encode([
                'success' => false, 
                'message' => '❌ خطأ: التاريخ من وإلى مطلوب'
            ]);
            return;
        }

        try {
            $db = Database::getInstance();
            
            $sql = "SELECT DISTINCT c.* 
                    FROM customers c
                    LEFT JOIN sales s ON c.id = s.customer_id
                    WHERE c.is_active = 1
                    AND DATE(s.created_at) BETWEEN ? AND ?
                    ORDER BY c.name ASC";
            $stmt = $db->prepare($sql);
            $stmt->execute([$from, $to]);
            $customers = $stmt->fetchAll();
            
            echo json_encode(['success' => true, 'data' => $customers]);
            return;
            
        } catch (Exception $e) {
            echo json_encode([
                'success' => false, 
                'message' => '❌ خطأ في التصفية: ' . $e->getMessage()
            ]);
            return;
        }
    }

    /**
     * معالجة الدفعة
     */
    public function processPayment() {
        header('Content-Type: application/json; charset=utf-8');
        
        if (!$this->isPost()) {
            echo json_encode([
                'success' => false, 
                'message' => '❌ خطأ: طريقة الطلب غير صحيحة'
            ]);
            return;
        }

        $input = json_decode(file_get_contents('php://input'), true);
        
        $customerId = isset($input['customer_id']) ? (int)$input['customer_id'] : 0;
        $amount = isset($input['amount']) ? (float)$input['amount'] : 0;
        $invoices = isset($input['invoices']) ? $input['invoices'] : [];
        
        if (!$customerId) {
            echo json_encode([
                'success' => false, 
                'message' => '❌ خطأ: معرف العميل مطلوب'
            ]);
            return;
        }
        
        if ($amount <= 0) {
            echo json_encode([
                'success' => false, 
                'message' => '❌ خطأ: المبلغ يجب أن يكون أكبر من صفر'
            ]);
            return;
        }
        
        if (empty($invoices)) {
            echo json_encode([
                'success' => false, 
                'message' => '❌ خطأ: الرجاء اختيار فواتير للتسديد'
            ]);
            return;
        }

        $db = Database::getInstance();
        
        try {
            $db->beginTransaction();
            
            // توزيع المبلغ على الفواتير
            $remaining = $amount;
            foreach ($invoices as $invoiceId) {
                if ($remaining <= 0) break;
                
                // جلب المتبقي في الفاتورة
                $stmt = $db->prepare("SELECT remaining_amount FROM sales WHERE id = ?");
                $stmt->execute([$invoiceId]);
                $invoiceRemaining = $stmt->fetchColumn();
                
                $paymentAmount = min($remaining, $invoiceRemaining);
                
                // تحديث الفاتورة
                $stmt = $db->prepare("
                    UPDATE sales 
                    SET paid_amount = paid_amount + ?,
                        remaining_amount = remaining_amount - ?
                    WHERE id = ?
                ");
                $stmt->execute([$paymentAmount, $paymentAmount, $invoiceId]);
                
                $remaining -= $paymentAmount;
            }
            
            // تحديث رصيد العميل
            $stmt = $db->prepare("UPDATE customers SET current_balance = current_balance - ? WHERE id = ?");
            $stmt->execute([$amount, $customerId]);
            
            // تسجيل الدفعة
            $stmt = $db->prepare("
                INSERT INTO payment_history (customer_id, amount, payment_method, notes, created_by, payment_date)
                VALUES (?, ?, 'cash', ?, ?, NOW())
            ");
            $stmt->execute([$customerId, $amount, 'تسديد دفعة', Auth::id()]);
            
            $db->commit();
            
            echo json_encode([
                'success' => true, 
                'message' => '✅ تم تسديد مبلغ ' . number_format($amount, 2) . ' ريال بنجاح'
            ]);
            return;
            
        } catch (Exception $e) {
            $db->rollBack();
            echo json_encode([
                'success' => false, 
                'message' => '❌ خطأ في عملية التسديد: ' . $e->getMessage()
            ]);
            return;
        }
    }

    /**
     * إنشاء كشف حساب
     */
    public function generateStatement() {
        header('Content-Type: application/json; charset=utf-8');
        
        if (!$this->isPost()) {
            echo json_encode([
                'success' => false, 
                'message' => '❌ خطأ: طريقة الطلب غير صحيحة'
            ]);
            return;
        }

        $input = json_decode(file_get_contents('php://input'), true);
        
        $customerId = isset($input['customer_id']) ? (int)$input['customer_id'] : 0;
        $dateFrom = isset($input['date_from']) ? $input['date_from'] : date('Y-m-01');
        $dateTo = isset($input['date_to']) ? $input['date_to'] : date('Y-m-d');
        
        if (!$customerId) {
            echo json_encode([
                'success' => false, 
                'message' => '❌ خطأ: معرف العميل مطلوب'
            ]);
            return;
        }

        try {
            $db = Database::getInstance();
            
            // بيانات العميل
            $stmt = $db->prepare("SELECT * FROM customers WHERE id = ?");
            $stmt->execute([$customerId]);
            $customer = $stmt->fetch();
            
            if (!$customer) {
                echo json_encode([
                    'success' => false, 
                    'message' => '❌ خطأ: العميل غير موجود'
                ]);
                return;
            }
            
            // الفواتير
            $stmt = $db->prepare("
                SELECT *, 'invoice' as transaction_type, created_at as transaction_date, total_amount as debit, 0 as credit
                FROM sales 
                WHERE customer_id = ? AND DATE(created_at) BETWEEN ? AND ?
            ");
            $stmt->execute([$customerId, $dateFrom, $dateTo]);
            $invoices = $stmt->fetchAll();
            
            // المدفوعات
            $stmt = $db->prepare("
                SELECT *, 'payment' as transaction_type, payment_date as transaction_date, 0 as debit, amount as credit
                FROM payment_history 
                WHERE customer_id = ? AND DATE(payment_date) BETWEEN ? AND ?
            ");
            $stmt->execute([$customerId, $dateFrom, $dateTo]);
            $payments = $stmt->fetchAll();
            
            // دمج وترتيب
            $transactions = array_merge($invoices, $payments);
            usort($transactions, function($a, $b) {
                return strtotime($a['transaction_date']) - strtotime($b['transaction_date']);
            });
            
            // حساب الرصيد التراكمي
            $runningBalance = 0;
            foreach ($transactions as &$trans) {
                if ($trans['transaction_type'] === 'invoice') {
                    $runningBalance += $trans['debit'];
                } else {
                    $runningBalance -= $trans['credit'];
                }
                $trans['running_balance'] = $runningBalance;
            }
            
            // ملخص
            $summary = [
                'total_invoices' => (float)array_sum(array_column($invoices, 'total_amount')),
                'total_payments' => (float)array_sum(array_column($payments, 'amount')),
                'total_returns' => 0,
                'final_balance' => (float)$runningBalance
            ];
            
            echo json_encode([
                'success' => true,
                'data' => [
                    'customer' => $customer,
                    'transactions' => $transactions,
                    'date_from' => $dateFrom,
                    'date_to' => $dateTo,
                    'generated_at' => date('Y-m-d H:i:s'),
                    'summary' => $summary
                ]
            ]);
            return;
            
        } catch (Exception $e) {
            echo json_encode([
                'success' => false, 
                'message' => '❌ خطأ في إنشاء كشف الحساب: ' . $e->getMessage()
            ]);
            return;
        }
    }
}