<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once __DIR__ . '/../core/Controller.php';
require_once __DIR__ . '/../core/Auth.php';
require_once __DIR__ . '/../models/Alert.php';
require_once __DIR__ . '/../models/ActivityLog.php';

class AlertController extends Controller {
    
    private $alertModel;
    private $logModel;

    public function __construct() {
        if (!Auth::check()) {
            $this->redirect('login');
        }

        $this->alertModel = new Alert();
        $this->logModel = new ActivityLog();
        
        // تحديث التنبيهات تلقائياً عند فتح الصفحة
        $this->alertModel->refreshAlerts();
    }

    /**
     * عرض صفحة التنبيهات
     */
    public function index() {
        $data = [
            'title' => 'التنبيهات',
            'alerts' => $this->alertModel->getAll(100),
            'stats' => $this->alertModel->getStats()
        ];
        $this->view('alerts/index', $data);
    }

    /**
     * الحصول على التنبيهات غير المقروءة (AJAX)
     */
    public function getUnread() {
        // مسح أي إخراج سابق
        if (ob_get_level()) ob_clean();
        
        // تعيين header JSON
        header('Content-Type: application/json; charset=utf-8');
        
        try {
            $alerts = $this->alertModel->getUnread();
            $stats = $this->alertModel->getStats();
            
            echo json_encode([
                'success' => true,
                'data' => $alerts,
                'count' => $stats['unread_count'] ?? 0
            ], JSON_UNESCAPED_UNICODE);
            exit;
            
        } catch (Exception $e) {
            error_log("Alert error: " . $e->getMessage());
            echo json_encode([
                'success' => false,
                'message' => $e->getMessage()
            ], JSON_UNESCAPED_UNICODE);
            exit;
        }
    }

    /**
     * تحديد تنبيه كمقروء
     */
    public function markRead() {
        // مسح أي إخراج سابق
        if (ob_get_level()) ob_clean();
        
        header('Content-Type: application/json; charset=utf-8');
        
        if (!$this->isPost()) {
            echo json_encode(['success' => false, 'message' => 'طريقة طلب غير صحيحة']);
            exit;
        }

        $id = $this->getPost('id');
        
        if (!$id) {
            echo json_encode(['success' => false, 'message' => 'معرف التنبيه مطلوب']);
            exit;
        }
        
        try {
            $result = $this->alertModel->markAsRead($id);
            
            if ($result) {
                $this->logModel->log('mark_alert_read', 'تم تحديد تنبيه كمقروء رقم: ' . $id);
                echo json_encode(['success' => true, 'message' => 'تم التحديد']);
                exit;
            } else {
                echo json_encode(['success' => false, 'message' => 'فشل في التحديد']);
                exit;
            }
            
        } catch (Exception $e) {
            echo json_encode(['success' => false, 'message' => $e->getMessage()]);
            exit;
        }
    }

    /**
     * تحديد جميع التنبيهات كمقروءة
     */
    public function markAllRead() {
        // مسح أي إخراج سابق
        if (ob_get_level()) ob_clean();
        
        header('Content-Type: application/json; charset=utf-8');
        
        if (!$this->isPost()) {
            echo json_encode(['success' => false, 'message' => 'طريقة طلب غير صحيحة']);
            exit;
        }
        
        try {
            $result = $this->alertModel->markAllAsRead();
            
            if ($result) {
                $this->logModel->log('mark_all_alerts_read', 'تم تحديد جميع التنبيهات كمقروءة');
                echo json_encode(['success' => true, 'message' => 'تم تحديد الكل']);
                exit;
            } else {
                echo json_encode(['success' => false, 'message' => 'فشل في التحديد']);
                exit;
            }
            
        } catch (Exception $e) {
            echo json_encode(['success' => false, 'message' => $e->getMessage()]);
            exit;
        }
    }

    /**
     * حذف تنبيه
     */
    public function delete() {
        // مسح أي إخراج سابق
        if (ob_get_level()) ob_clean();
        
        header('Content-Type: application/json; charset=utf-8');
        
        if (!Auth::isAdmin()) {
            echo json_encode(['success' => false, 'message' => 'غير مصرح']);
            exit;
        }
        
        if (!$this->isPost()) {
            echo json_encode(['success' => false, 'message' => 'طريقة طلب غير صحيحة']);
            exit;
        }
        
        $id = $this->getPost('id');
        
        if (!$id) {
            echo json_encode(['success' => false, 'message' => 'معرف التنبيه مطلوب']);
            exit;
        }
        
        try {
            $result = $this->alertModel->deleteAlert($id);
            
            if ($result) {
                $this->logModel->log('delete_alert', 'تم حذف تنبيه رقم: ' . $id);
                echo json_encode(['success' => true, 'message' => 'تم الحذف']);
                exit;
            } else {
                echo json_encode(['success' => false, 'message' => 'فشل في الحذف']);
                exit;
            }
            
        } catch (Exception $e) {
            echo json_encode(['success' => false, 'message' => $e->getMessage()]);
            exit;
        }
    }

    /**
     * تحديث التنبيهات يدوياً
     */
    public function refresh() {
        // مسح أي إخراج سابق
        if (ob_get_level()) ob_clean();
        
        header('Content-Type: application/json; charset=utf-8');
        
        if (!Auth::isAdmin()) {
            echo json_encode(['success' => false, 'message' => 'غير مصرح']);
            exit;
        }
        
        try {
            $this->alertModel->refreshAlerts();
            $this->logModel->log('refresh_alerts', 'تم تحديث التنبيهات يدوياً');
            
            echo json_encode(['success' => true, 'message' => 'تم تحديث التنبيهات']);
            exit;
            
        } catch (Exception $e) {
            echo json_encode(['success' => false, 'message' => $e->getMessage()]);
            exit;
        }
    }
}