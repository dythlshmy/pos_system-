<?php

class ShortcutController {

    private $db;
    private $userId;
    private $role;

    public function __construct() {
        $this->db = Database::getInstance();
        $this->userId = Auth::id();
        $this->role = Auth::role(); // 'admin' or 'employee'
        
        if (!$this->userId) {
            $this->jsonResponse(['success' => false, 'message' => 'Unauthorized'], 401);
        }
    }

    private function jsonResponse($data, $statusCode = 200) {
        http_response_code($statusCode);
        header('Content-Type: application/json');
        echo json_encode($data);
        exit;
    }

    // Load everything for the active user & interface
    public function load() {
        if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
            $this->jsonResponse(['success' => false, 'message' => 'Invalid method'], 405);
        }

        $interface_name = $_GET['interface_name'] ?? 'global';

        // Get general settings
        $stmt = $this->db->prepare("SELECT * FROM shortcut_settings WHERE user_id = ? AND interface_name = ?");
        $stmt->execute([$this->userId, $interface_name]);
        $settings = $stmt->fetch(PDO::FETCH_ASSOC) ?: ['sys_active' => 1, 'nav_active' => 1, 'adding_active' => 1];

        // Get elements state
        $stmt = $this->db->prepare("SELECT element_id, is_active FROM shortcut_elements_state WHERE user_id = ? AND interface_name = ?");
        $stmt->execute([$this->userId, $interface_name]);
        $elements_state = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // Get shortcuts
        $stmt = $this->db->prepare("SELECT * FROM user_shortcuts WHERE user_id = ? AND interface_name = ?");
        $stmt->execute([$this->userId, $interface_name]);
        $shortcuts = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $this->jsonResponse([
            'success' => true,
            'settings' => $settings,
            'elements_state' => $elements_state,
            'shortcuts' => $shortcuts
        ]);
    }

    // Save general settings
    public function saveSettings() {
        $data = json_decode(file_get_contents('php://input'), true);
        $interface_name = $data['interface_name'] ?? 'global';
        $sys_active = $data['sys_active'] ?? 1;
        $nav_active = $data['nav_active'] ?? 1;
        $adding_active = $data['adding_active'] ?? 1;

        $stmt = $this->db->prepare("
            INSERT INTO shortcut_settings (user_id, interface_name, sys_active, nav_active, adding_active) 
            VALUES (?, ?, ?, ?, ?) 
            ON DUPLICATE KEY UPDATE 
            sys_active = VALUES(sys_active), nav_active = VALUES(nav_active), adding_active = VALUES(adding_active)
        ");
        
        $success = $stmt->execute([$this->userId, $interface_name, $sys_active, $nav_active, $adding_active]);
        $this->jsonResponse(['success' => $success]);
    }

    // Save element toggle state
    public function saveElementState() {
        $data = json_decode(file_get_contents('php://input'), true);
        $interface_name = $data['interface_name'] ?? 'global';
        $element_id = $data['element_id'] ?? '';
        $is_active = $data['is_active'] ?? 1;

        if (!$element_id) {
            $this->jsonResponse(['success' => false, 'message' => 'Missing element ID'], 400);
        }

        $stmt = $this->db->prepare("
            INSERT INTO shortcut_elements_state (user_id, interface_name, element_id, is_active) 
            VALUES (?, ?, ?, ?) 
            ON DUPLICATE KEY UPDATE is_active = VALUES(is_active)
        ");
        
        $success = $stmt->execute([$this->userId, $interface_name, $element_id, $is_active]);
        $this->jsonResponse(['success' => $success]);
    }

    // Add or Update a shortcut
    public function saveShortcut() {
        $data = json_decode(file_get_contents('php://input'), true);
        $interface_name = $data['interface_name'] ?? 'global';
        $modifier = $data['modifier'] ?? '';
        $key_char = strtolower($data['key_char'] ?? '');
        $target_element = $data['target_element'] ?? '';
        
        if (!$key_char || !$target_element) {
            $this->jsonResponse(['success' => false, 'message' => 'Missing required shortcut data'], 400);
        }

        // Conflict check: Check if this exact shortcut is already registered for this user/interface, but for a DIFFERENT element
        $stmt = $this->db->prepare("SELECT id, target_element FROM user_shortcuts WHERE user_id = ? AND interface_name = ? AND modifier = ? AND key_char = ?");
        $stmt->execute([$this->userId, $interface_name, $modifier, $key_char]);
        $existing = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($existing) {
            if ($existing['target_element'] !== $target_element) {
                // Update the existing target
                $updateStmt = $this->db->prepare("UPDATE user_shortcuts SET target_element = ? WHERE id = ?");
                $updateStmt->execute([$target_element, $existing['id']]);
                
                $this->jsonResponse([
                    'success' => true, 
                    'message' => '⚠️ تم تحديث الاختصار وربطه بالعنصر الجديد (تم تجاوز القديم).'
                ]);
            }
            // If it's the exact same, just return success
            $this->jsonResponse(['success' => true]);
        }

        // Insert new
        $stmt = $this->db->prepare("
            INSERT INTO user_shortcuts (user_id, interface_name, modifier, key_char, target_element) 
            VALUES (?, ?, ?, ?, ?)
        ");
        
        $success = $stmt->execute([$this->userId, $interface_name, $modifier, $key_char, $target_element]);
        
        $this->jsonResponse(['success' => $success]);
    }

    // Delete a shortcut
    public function deleteShortcut() {
        $data = json_decode(file_get_contents('php://input'), true);
        $id = $data['id'] ?? null;

        if (!$id) {
            $this->jsonResponse(['success' => false, 'message' => 'Missing shortcut ID'], 400);
        }

        $stmt = $this->db->prepare("DELETE FROM user_shortcuts WHERE id = ? AND user_id = ?");
        $success = $stmt->execute([$id, $this->userId]);
        
        $this->jsonResponse(['success' => $success]);
    }
}
