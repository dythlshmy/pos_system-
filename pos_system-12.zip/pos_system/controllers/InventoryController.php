<?php
// ✅ أضف هذا في أول السطر الثاني
error_reporting(E_ALL);
ini_set('display_errors', 1);

// التأكد من عدم تضمين الملف مرتين
if (class_exists('InventoryController', false)) {
    return;
}

require_once __DIR__ . '/../core/Controller.php';
require_once __DIR__ . '/../core/Auth.php';
require_once __DIR__ . '/../core/Middleware.php';
require_once __DIR__ . '/../models/Category.php';
require_once __DIR__ . '/../models/Product.php';
require_once __DIR__ . '/../models/Inventory.php';
require_once __DIR__ . '/../models/Shelf.php';
require_once __DIR__ . '/../models/ActivityLog.php';

class InventoryController extends Controller {
    
    private $categoryModel;
    private $productModel;
    private $inventoryModel;
    private $shelfModel;

    public function __construct() {
        if (!Auth::check()) {
            $this->redirect('login');
        }

        $this->categoryModel = new Category();
        $this->productModel = new Product();
        $this->inventoryModel = new Inventory();
        $this->shelfModel = new Shelf();
    }

    // ===== الصفحات الرئيسية =====
    public function index() {
        Middleware::handle($_REQUEST, function() {
            $data = [
                'title' => 'المخزن الرئيسي',
                'categories' => $this->categoryModel->getAllActive(),
                'products' => $this->productModel->getAllWithCategory(),
                'stats' => $this->inventoryModel->getStats(),
                'batches' => $this->inventoryModel->getAllWithProduct()
            ];
            $this->view('inventory/index', $data);
        }, 'admin');
    }

   /**
 * صفحة رف البيع - معدلة مع جميع المتغيرات المطلوبة
 */
/**
 * صفحة رف البيع - معدلة بالكامل
 */
public function shelf() {
    Middleware::handle($_REQUEST, function() {
        // جلب بيانات الرف
        $shelves = $this->shelfModel->getAllWithDetails();
        
        // تجهيز البيانات للعرض مع التأكد من وجود جميع الحقول
        foreach ($shelves as &$shelf) {
            // التأكد من وجود product_id
            if (empty($shelf['product_id']) && !empty($shelf['main_inventory_id'])) {
                $batch = $this->inventoryModel->find($shelf['main_inventory_id']);
                $shelf['product_id'] = $batch['product_id'] ?? null;
            }
            
            // جلب اسم المنتج إذا كان ناقصاً
            if (empty($shelf['product_name']) && !empty($shelf['product_id'])) {
                $product = $this->productModel->find($shelf['product_id']);
                $shelf['product_name'] = $product['name'] ?? 'منتج غير معروف';
                $shelf['barcode'] = $product['barcode'] ?? '';
                $shelf['units_per_carton'] = $product['units_per_carton'] ?? 1;
            }
            
            // حساب عدد الكراتين (افتراضي 1)
            $shelf['cartons_count'] = 1;
        }
        
        // جلب إحصائيات الرف
        $stats = $this->shelfModel->getStats();
        
        // التأكد من وجود جميع القيم في الإحصائيات
        $stats = array_merge([
            'total_shelves' => 0,
            'total_units' => 0,
            'available_count' => 0,
            'low_stock_count' => 0,
            'expired_count' => 0,
            'total_value' => 0,
            'total_profit' => 0
        ], $stats ?: []);
        
        // جلب أقدم وأحدث منتج
        $oldestProduct = $this->shelfModel->getOldestProduct();
        $latestProduct = $this->shelfModel->getLatestProduct();
        
        // جلب آخر الدفعات المرفوعة
        $recentBatches = $this->inventoryModel->getRecentBatches(10);
        
        $data = [
            'title' => 'رف البيع',
            'shelves' => $shelves,
            'stats' => $stats,
            'oldest_product' => $oldestProduct,
            'latest_product' => $latestProduct,
            'recentBatches' => $recentBatches,
            'products' => $this->productModel->getAllWithCategory()
        ];
        
        $this->view('inventory/shelf', $data);
    });
}
    // ===== دوال المنتجات =====
  /**
 * الحصول على المنتجات - نسخة نهائية ومضمونة
 */
public function getProducts() {
    // منع أي إخراج قبل JSON
    ob_clean();
    
    // تعيين header JSON
    header('Content-Type: application/json');
    header('X-Content-Type-Options: nosniff');
    
    try {
        // التحقق من POST
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            echo json_encode(['success' => false, 'message' => 'يجب استخدام POST']);
            exit;
        }

        // جلب المنتجات مباشرة
        $products = $this->productModel->getAllWithCategory();
        
        // التأكد من أن النتيجة مصفوفة
        if (!is_array($products)) {
            $products = [];
        }
        
        // إرجاع النتيجة
        echo json_encode([
            'success' => true, 
            'data' => $products,
            'count' => count($products)
        ], JSON_UNESCAPED_UNICODE);
        exit;
        
    } catch (Exception $e) {
        echo json_encode([
            'success' => false, 
            'message' => 'خطأ: ' . $e->getMessage()
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }
}
    public function addProduct() {
        if (!$this->isPost()) {
            $this->json(['success' => false, 'message' => 'طريقة طلب غير صحيحة'], 405);
            return;
        }

        $name = $this->getPost('name');
        $barcode = $this->getPost('barcode');
        $categoryId = $this->getPost('category_id');
        $unitsPerCarton = $this->getPost('units_per_carton');

        if (empty($name) || empty($barcode) || empty($unitsPerCarton)) {
            $this->json(['success' => false, 'message' => 'جميع الحقول المطلوبة يجب أن تمتلئ']);
            return;
        }

        $result = $this->productModel->createProduct([
            'name' => $name,
            'barcode' => $barcode,
            'category_id' => $categoryId ?: null,
            'units_per_carton' => $unitsPerCarton
        ]);

        $this->json($result);
    }

    public function updateProduct() {
        if (!$this->isPost()) {
            $this->json(['success' => false, 'message' => 'طريقة طلب غير صحيحة'], 405);
            return;
        }

        $id = $this->getPost('id');
        if (!$id) {
            $this->json(['success' => false, 'message' => 'معرف المنتج مطلوب']);
            return;
        }

        $result = $this->productModel->updateProduct($id, [
            'name' => $this->getPost('name'),
            'barcode' => $this->getPost('barcode'),
            'category_id' => $this->getPost('category_id'),
            'units_per_carton' => $this->getPost('units_per_carton')
        ]);

        $this->json($result);
    }

    /**
     * حذف منتج نهائياً مع جميع بياناته من جميع الجداول (AJAX)
     */
  /**
 * حذف منتج نهائياً مع جميع بياناته من جميع الجداول (AJAX)
 */
public function deleteProduct() {
    if (!$this->isPost()) {
        $this->json(['success' => false, 'message' => 'طريقة طلب غير صحيحة'], 405);
        return;
    }

    $id = $this->getPost('id');
    if (!$id) {
        $this->json(['success' => false, 'message' => 'معرف المنتج مطلوب']);
        return;
    }

    // التحقق من الصلاحية (admin فقط)
    if (!Auth::isAdmin()) {
        $this->json(['success' => false, 'message' => 'غير مصرح بالحذف']);
        return;
    }

    try {
        // بدء معاملة باستخدام الدالة الموجودة في Model
        $this->inventoryModel->beginTransaction();

        // 1. الحصول على جميع الدفعات المرتبطة بالمنتج
        $batches = $this->inventoryModel->getByProduct($id);
        
        foreach ($batches as $batch) {
            $batchId = $batch['id'];
            
            // 2. حذف من sale_items (عناصر المبيعات) المرتبطة بهذه الدفعة
            $sql1 = "DELETE FROM sale_items WHERE shelf_inventory_id IN 
                    (SELECT id FROM shelf_inventory WHERE main_inventory_id = ?)";
            
            // استخدام دالة query الموجودة في Model
            $this->inventoryModel->query($sql1, [$batchId]);
            
            // 3. حذف من shelf_inventory (رف البيع)
            $shelfItems = $this->shelfModel->getByBatchId($batchId);
            foreach ($shelfItems as $item) {
                $this->shelfModel->delete($item['id']);
            }
            
            // 4. حذف من main_inventory (المخزن الرئيسي)
            $this->inventoryModel->delete($batch['id']);
        }

        // 5. حذف المنتج نفسه من جدول products
        $result = $this->productModel->delete($id);

        // تأكيد المعاملة
        $this->inventoryModel->commit();

        if ($result) {
            // تسجيل النشاط
            $this->logActivity('delete_product', 'تم حذف المنتج وجميع بياناته نهائياً: ' . $id);
            $this->json(['success' => true, 'message' => 'تم حذف المنتج وجميع بياناته بنجاح']);
        } else {
            $this->json(['success' => false, 'message' => 'فشل في حذف المنتج']);
        }

    } catch (Exception $e) {
        // إلغاء المعاملة في حالة الخطأ
        $this->inventoryModel->rollBack();
        error_log("Error deleting product: " . $e->getMessage());
        $this->json(['success' => false, 'message' => 'خطأ في قاعدة البيانات: ' . $e->getMessage()]);
    }
}

    // ===== دوال الدفعات =====
    public function addBatch() {
        if (!$this->isPost()) {
            $this->json(['success' => false, 'message' => 'طريقة طلب غير صحيحة'], 405);
            return;
        }

        $productId = $this->getPost('product_id');
        $batchNumber = $this->getPost('batch_number');
        $cartonsQuantity = $this->getPost('cartons_quantity');
        $costPriceCarton = $this->getPost('cost_price_carton');
        $sellingPriceUnit = $this->getPost('selling_price_unit');
        $expiryDate = $this->getPost('expiry_date');

        if (empty($productId) || empty($batchNumber) || empty($cartonsQuantity) || 
            empty($costPriceCarton) || empty($sellingPriceUnit) || empty($expiryDate)) {
            $this->json(['success' => false, 'message' => 'جميع الحقول المطلوبة يجب أن تمتلئ']);
            return;
        }

        $product = $this->productModel->find($productId);
        if (!$product) {
            $this->json(['success' => false, 'message' => 'المنتج غير موجود']);
            return;
        }

        $result = $this->inventoryModel->addBatch([
            'product_id' => $productId,
            'batch_number' => $batchNumber,
            'cartons_quantity' => $cartonsQuantity,
            'cost_price_carton' => $costPriceCarton,
            'selling_price_unit' => $sellingPriceUnit,
            'expiry_date' => $expiryDate,
            'units_per_carton' => $product['units_per_carton'],
            'notes' => $this->getPost('notes')
        ]);

        if ($result['success']) {
            // التحقق مما إذا كان المنتج ليس لديه أي كراتين مفتوحة على الرف
            $shelfCheckSql = "SELECT COUNT(*) as open_cartons 
                              FROM shelf_inventory s
                              JOIN main_inventory i ON s.main_inventory_id = i.id
                              WHERE i.product_id = ? AND s.units_remaining > 0";
            $shelfCheckResult = $this->inventoryModel->rawOne($shelfCheckSql, [$productId]);
            
            // إذا لم يكن هناك أي كرتون على الرف، ارفع تلقائياً أول كرتون
            if (($shelfCheckResult['open_cartons'] ?? 0) == 0) {
                // استدعاء دالة الرفع إلى الرف
                $this->inventoryModel->moveToShelf($result['batch_id']);
                $result['message'] .= ' وتم رفع أول كرتون إلى الرف تلقائياً.';
            }
        }

        $this->json($result);
    }

    public function getBatches() {
        if (!$this->isPost()) {
            $this->json(['success' => false, 'message' => 'طريقة طلب غير صحيحة'], 405);
            return;
        }

        $productId = $this->getPost('product_id');
        if (!$productId) {
            $this->json(['success' => false, 'message' => 'معرف المنتج مطلوب']);
            return;
        }

        $batches = $this->inventoryModel->getByProduct($productId);
        $this->json(['success' => true, 'data' => $batches]);
    }

    public function deleteBatch() {
        if (!$this->isPost()) {
            $this->json(['success' => false, 'message' => 'طريقة طلب غير صحيحة'], 405);
            return;
        }

        $id = $this->getPost('id');
        if (!$id) {
            $this->json(['success' => false, 'message' => 'معرف الدفعة مطلوب']);
            return;
        }

        // التحقق من الصلاحية
        if (!Auth::isAdmin()) {
            $this->json(['success' => false, 'message' => 'غير مصرح بالحذف']);
            return;
        }

        $result = $this->inventoryModel->deleteBatch($id);
        $this->json($result);
    }

    public function getBatchDetails() {
        $id = $this->getQuery('id');
        if (!$id) {
            $this->json(['success' => false, 'message' => 'معرف الدفعة مطلوب']);
            return;
        }
        
        $batch = $this->inventoryModel->find($id);
        if (!$batch) {
            $this->json(['success' => false, 'message' => 'الدفعة غير موجودة']);
            return;
        }
        
        $product = $this->productModel->find($batch['product_id']);
        $shelfItems = $this->shelfModel->getByBatchId($id);
        
        $this->json([
            'success' => true,
            'data' => [
                'batch' => $batch,
                'product' => $product,
                'shelf_items' => $shelfItems
            ]
        ]);
    }

    public function updateBatch() {
        if (!$this->isPost()) {
            $this->json(['success' => false, 'message' => 'طريقة طلب غير صحيحة'], 405);
            return;
        }
        
        $id = $this->getPost('id');
        if (!$id) {
            $this->json(['success' => false, 'message' => 'معرف الدفعة مطلوب']);
            return;
        }
        
        if (!Auth::isAdmin()) {
            $this->json(['success' => false, 'message' => 'غير مصرح بالتعديل']);
            return;
        }
        
        $data = [
            'cost_price_carton' => $this->getPost('cost_price_carton'),
            'selling_price_unit' => $this->getPost('selling_price_unit'),
            'expiry_date' => $this->getPost('expiry_date'),
            'notes' => $this->getPost('notes')
        ];
        
        $data = array_filter($data, function($value) {
            return $value !== null && $value !== '';
        });
        
        if (empty($data)) {
            $this->json(['success' => false, 'message' => 'لا توجد بيانات للتحديث']);
            return;
        }
        
        $result = $this->inventoryModel->update($id, $data);
        
        if ($result) {
            $this->logActivity('update_batch', 'تم تحديث الدفعة رقم: ' . $id);
            $this->json(['success' => true, 'message' => 'تم تحديث الدفعة بنجاح']);
        } else {
            $this->json(['success' => false, 'message' => 'فشل في تحديث الدفعة']);
        }
    }

    // ===== دوال رف البيع =====
    public function moveToShelf() {
        if (!$this->isPost()) {
            $this->json(['success' => false, 'message' => 'طريقة طلب غير صحيحة'], 405);
            return;
        }

        $batchId = $this->getPost('batch_id');
        if (!$batchId) {
            $this->json(['success' => false, 'message' => 'معرف الدفعة مطلوب']);
            return;
        }

        $result = $this->inventoryModel->moveToShelf($batchId);
        $this->json($result);
    }

    public function moveFifo() {
        if (!$this->isPost()) {
            $this->json(['success' => false, 'message' => 'طريقة طلب غير صحيحة'], 405);
            return;
        }

        $productId = $this->getPost('product_id');
        if (!$productId) {
            $this->json(['success' => false, 'message' => 'معرف المنتج مطلوب']);
            return;
        }

        $batch = $this->inventoryModel->getOldestBatch($productId);
        if (!$batch) {
            $this->json(['success' => false, 'message' => 'لا توجد دفعات متاحة لهذا المنتج']);
            return;
        }

        $result = $this->inventoryModel->moveToShelf($batch['id']);
        $this->json($result);
    }

    public function getShelf() {
        $filters = [
            'status' => $this->getQuery('status', 'all'),
            'search' => $this->getQuery('search', ''),
            'sort' => $this->getQuery('sort', '')
        ];

        $shelves = $this->shelfModel->search($filters);
        $this->json(['success' => true, 'data' => $shelves]);
    }

    public function sellFromShelf() {
        if (!$this->isPost()) {
            $this->json(['success' => false, 'message' => 'طريقة طلب غير صحيحة'], 405);
            return;
        }

        $shelfId = $this->getPost('shelf_id');
        $quantity = $this->getPost('quantity');
        $saleType = $this->getPost('sale_type', 'cash');
        $customerId = $this->getPost('customer_id');

        if (!$shelfId || !$quantity) {
            $this->json(['success' => false, 'message' => 'البيانات غير مكتملة']);
            return;
        }

        $result = $this->shelfModel->sellUnits($shelfId, $quantity, $saleType, $customerId);
        $this->json($result);
    }

    // ===== دوال الفلاتر والبحث =====
    public function filter() {
        $filters = [];
        
        if ($this->getQuery('search')) {
            $filters['search'] = $this->getQuery('search');
        }
        
        if ($this->getQuery('product_id')) {
            $filters['product_id'] = $this->getQuery('product_id');
        }
        
        if ($this->getQuery('category_id')) {
            $filters['category_id'] = $this->getQuery('category_id');
        }
        
        $status = $this->getQuery('status');
        if ($status) {
            switch ($status) {
                case 'expired':
                    $filters['expiry_status'] = 'expired';
                    break;
                case 'expiring':
                    $filters['expiry_status'] = 'expiring_soon';
                    break;
                case 'low':
                    $filters['stock_status'] = 'low';
                    break;
                case 'out':
                    $filters['stock_status'] = 'out';
                    break;
            }
        }
        
        if ($this->getQuery('date_from')) {
            $filters['date_from'] = $this->getQuery('date_from');
        }
        if ($this->getQuery('date_to')) {
            $filters['date_to'] = $this->getQuery('date_to');
        }
        
        $batches = $this->inventoryModel->search($filters);
        $this->json(['success' => true, 'data' => $batches]);
    }

    public function searchByBarcode() {
        $keyword = $this->getQuery('barcode');
        if (!$keyword || strlen($keyword) < 2) {
            $this->json(['success' => true, 'data' => []]);
            return;
        }
        
        $products = $this->productModel->search($keyword);
        $this->json(['success' => true, 'data' => $products]);
    }

    public function getProduct() {
        $id = $this->getQuery('id');
        if (!$id) {
            $this->json(['success' => false, 'message' => 'معرف المنتج مطلوب']);
            return;
        }
        
        $product = $this->productModel->find($id);
        $this->json(['success' => true, 'data' => $product]);
    }


    public function checkPermission() {
        $this->json(['isAdmin' => Auth::isAdmin()]);
    }

    // ===== دوال مساعدة =====
    private function logActivity($action, $details) {
        if (isset($_SESSION['user_id'])) {
            $logModel = new ActivityLog();
            $logModel->log($action, $details, $_SESSION['user_id']);
        }
    }

    // ===== دوال الاختبار =====
    public function test() {
        $this->json(['success' => true, 'message' => 'الاختبار يعمل']);
    }

    public function testPost() {
        $this->json([
            'success' => true, 
            'message' => 'POST يعمل بشكل صحيح',
            'received' => $_POST,
            'method' => $_SERVER['REQUEST_METHOD']
        ]);
    }

    /**
 * دالة اختبار POST بسيطة جداً
 */
public function testSimplePost() {
    // مسح أي إخراج سابق
    if (ob_get_level()) ob_clean();
    
    // تعيين header JSON
    header('Content-Type: application/json');
    
    // إرجاع JSON بسيط
    echo json_encode([
        'success' => true,
        'message' => 'POST يعمل!',
        'time' => date('Y-m-d H:i:s')
    ]);
    exit;
} 
/**
 * الحصول على معلومات إضافية للرف (AJAX)
 */
public function getShelfInfo() {
    try {
        $stats = $this->shelfModel->getStats();
        $oldestProduct = $this->shelfModel->getOldestProduct();
        $latestProduct = $this->shelfModel->getLatestProduct();
        
        $this->json([
            'success' => true,
            'stats' => $stats,
            'oldest_product' => $oldestProduct ? [
                'name' => $oldestProduct['product_name'] ?? '',
                'added_at' => $oldestProduct['added_at'] ?? ''
            ] : null,
            'latest_product' => $latestProduct ? [
                'name' => $latestProduct['product_name'] ?? '',
                'added_at' => $latestProduct['added_at'] ?? ''
            ] : null
        ]);
    } catch (Exception $e) {
        $this->json(['success' => false, 'message' => $e->getMessage()]);
    }
}

/**
 * تحديث كرتون في الرف (AJAX)
 */
/**
 * تحديث كرتون في الرف (AJAX) - تأكد من وجودها
 */
public function updateShelfItem() {
    if (!$this->isPost()) {
        $this->json(['success' => false, 'message' => 'طريقة طلب غير صحيحة']);
        return;
    }

    $id = $this->getPost('id');
    $units = $this->getPost('units_remaining');
    $price = $this->getPost('selling_price_unit');
    $status = $this->getPost('status');

    if (!$id) {
        $this->json(['success' => false, 'message' => 'معرف العنصر مطلوب']);
        return;
    }

    $data = [];
    if ($units !== null) $data['units_remaining'] = $units;
    if ($price !== null) $data['selling_price_unit'] = $price;
    if ($status !== null) $data['status'] = $status;

    $result = $this->shelfModel->updateShelf($id, $data);
    $this->json($result);
}

/**
 * حذف كرتون من الرف (AJAX) - تأكد من وجودها
 */
public function deleteShelfItem() {
    if (!$this->isPost()) {
        $this->json(['success' => false, 'message' => 'طريقة طلب غير صحيحة']);
        return;
    }

    $id = $this->getPost('id');
    if (!$id) {
        $this->json(['success' => false, 'message' => 'معرف العنصر مطلوب']);
        return;
    }

    if (!Auth::isAdmin()) {
        $this->json(['success' => false, 'message' => 'غير مصرح بالحذف']);
        return;
    }

    $result = $this->shelfModel->removeFromShelf($id, 'حذف يدوي');
    $this->json($result);
}


/**
 * حذف كرتون من الرف (AJAX)
 */

/**
 * الحصول على تفاصيل عنصر من رف البيع (AJAX) - نسخة مبسطة
 */
public function getShelfItemDetails() {
    header('Content-Type: application/json; charset=utf-8');
    
    try {
        $id = $this->getQuery('id');
        if (!$id) {
            echo json_encode(['success' => false, 'message' => 'معرف العنصر مطلوب']);
            exit;
        }
        
        // جلب بيانات عنصر الرف
        $shelfItem = $this->shelfModel->find($id);
        if (!$shelfItem) {
            echo json_encode(['success' => false, 'message' => 'العنصر غير موجود']);
            exit;
        }
        
        // جلب بيانات المنتج المرتبط
        $batch = $this->inventoryModel->find($shelfItem['main_inventory_id']);
        $product = null;
        if ($batch) {
            $product = $this->productModel->find($batch['product_id']);
        }
        
        echo json_encode([
            'success' => true,
            'data' => [
                'shelf_item' => $shelfItem,
                'product' => $product ?: ['name' => 'غير معروف', 'barcode' => '---']
            ]
        ], JSON_UNESCAPED_UNICODE);
        exit;
        
    } catch (Exception $e) {
        echo json_encode([
            'success' => false,
            'message' => 'خطأ: ' . $e->getMessage()
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }
}
/**
 * البحث في الرف (AJAX) - نسخة محسنة
 */
public function searchShelf() {
    try {
        $filters = [];
        
        // فلتر الحالة
        $status = $this->getQuery('status', 'all');
        if ($status !== 'all') {
            $filters['status'] = $status;
        }
        
        // فلتر البحث النصي
        $search = $this->getQuery('search', '');
        if (!empty($search)) {
            $filters['search'] = $search;
        }
        
        // فلتر الباركود
        $barcode = $this->getQuery('barcode', '');
        if (!empty($barcode)) {
            $filters['barcode'] = $barcode;
        }
        
        // فلتر الترتيب
        $sort = $this->getQuery('sort', '');
        if (!empty($sort)) {
            $filters['sort'] = $sort;
        }
        
        $shelves = $this->shelfModel->search($filters);
        
        // تجهيز البيانات للإرجاع
        foreach ($shelves as &$shelf) {
            // إضافة اسم المنتج إذا كان ناقصاً
            if (empty($shelf['product_name']) && !empty($shelf['product_id'])) {
                $product = $this->productModel->find($shelf['product_id']);
                $shelf['product_name'] = $product['name'] ?? 'منتج غير معروف';
            }
            
            // حساب النسبة المئوية
            $maxUnits = $shelf['units_per_carton'] ?? 30;
            $shelf['percentage'] = $maxUnits > 0 ? round(($shelf['units_remaining'] / $maxUnits) * 100) : 0;
        }
        
        $this->json(['success' => true, 'data' => $shelves]);
        
    } catch (Exception $e) {
        $this->json(['success' => false, 'message' => $e->getMessage()]);
    }
}
/**
 * API: إضافة قسم جديد
 */
public function addCategory() {
    header('Content-Type: application/json; charset=utf-8');
    
    // التحقق من تسجيل الدخول
    if (!Auth::check()) {
        echo json_encode(['success' => false, 'message' => 'يجب تسجيل الدخول أولاً']);
        exit;
    }

    // التحقق من طريقة الطلب
    if (!$this->isPost()) {
        echo json_encode(['success' => false, 'message' => 'طريقة طلب غير صحيحة']);
        exit;
    }

    // قراءة المدخلات
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (!$input) {
        echo json_encode(['success' => false, 'message' => 'بيانات غير صالحة']);
        exit;
    }

    $name = trim($input['name'] ?? '');
    $description = trim($input['description'] ?? '');

    if (empty($name)) {
        echo json_encode(['success' => false, 'message' => 'اسم القسم مطلوب']);
        exit;
    }

    require_once __DIR__ . '/../models/Category.php';
    $categoryModel = new Category();

    // التحقق من عدم تكرار الاسم
    if ($categoryModel->findByName($name)) {
        echo json_encode(['success' => false, 'message' => 'اسم القسم موجود بالفعل']);
        exit;
    }

    $data = [
        'name' => $name,
        'description' => $description,
        'is_active' => 1
    ];

    $result = $categoryModel->add($data);

    if ($result) {
        // جلب جميع الأقسام للتحديث
        $categories = $categoryModel->getAllActive();
        
        echo json_encode([
            'success' => true,
            'message' => 'تم إضافة القسم بنجاح',
            'categories' => $categories
        ], JSON_UNESCAPED_UNICODE);
    } else {
        echo json_encode(['success' => false, 'message' => 'فشل إضافة القسم']);
    }
    exit;
}

/**
 * API: الحصول على جميع الأقسام
 */
public function getCategories() {
    header('Content-Type: application/json; charset=utf-8');
    
    if (!Auth::check()) {
        echo json_encode(['success' => false, 'message' => 'يجب تسجيل الدخول أولاً']);
        exit;
    }
    
    require_once __DIR__ . '/../models/Category.php';
    $categoryModel = new Category();
    
    $categories = $categoryModel->getAllActive();
    
    echo json_encode([
        'success' => true,
        'categories' => $categories
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

/**
 * API: تحديث قسم
 */
public function updateCategory() {
    header('Content-Type: application/json; charset=utf-8');
    
    if (!Auth::check()) {
        echo json_encode(['success' => false, 'message' => 'يجب تسجيل الدخول أولاً']);
        exit;
    }

    if (!$this->isPost()) {
        echo json_encode(['success' => false, 'message' => 'طريقة طلب غير صحيحة']);
        exit;
    }

    $input = json_decode(file_get_contents('php://input'), true);
    
    if (!$input) {
        echo json_encode(['success' => false, 'message' => 'بيانات غير صالحة']);
        exit;
    }

    $id = $input['id'] ?? 0;
    $name = trim($input['name'] ?? '');
    $description = trim($input['description'] ?? '');

    if (!$id || empty($name)) {
        echo json_encode(['success' => false, 'message' => 'بيانات غير صالحة']);
        exit;
    }

    require_once __DIR__ . '/../models/Category.php';
    $categoryModel = new Category();

    // التحقق من عدم تكرار الاسم (لمستخدم آخر)
    $existing = $categoryModel->findByName($name);
    if ($existing && $existing['id'] != $id) {
        echo json_encode(['success' => false, 'message' => 'اسم القسم موجود بالفعل']);
        exit;
    }

    $data = [
        'name' => $name,
        'description' => $description,
        'is_active' => $input['is_active'] ?? 1
    ];

    $result = $categoryModel->update($id, $data);

    if ($result) {
        echo json_encode([
            'success' => true,
            'message' => 'تم تحديث القسم بنجاح'
        ], JSON_UNESCAPED_UNICODE);
    } else {
        echo json_encode(['success' => false, 'message' => 'فشل تحديث القسم']);
    }
    exit;
}

/**
 * API: تعطيل قسم
 */
public function deactivateCategory() {
    header('Content-Type: application/json; charset=utf-8');
    
    if (!Auth::check()) {
        echo json_encode(['success' => false, 'message' => 'يجب تسجيل الدخول أولاً']);
        exit;
    }

    if (!$this->isPost()) {
        echo json_encode(['success' => false, 'message' => 'طريقة طلب غير صحيحة']);
        exit;
    }

    $input = json_decode(file_get_contents('php://input'), true);
    
    if (!$input) {
        echo json_encode(['success' => false, 'message' => 'بيانات غير صالحة']);
        exit;
    }

    $id = $input['id'] ?? 0;

    if (!$id) {
        echo json_encode(['success' => false, 'message' => 'معرف القسم مطلوب']);
        exit;
    }

    require_once __DIR__ . '/../models/Category.php';
    $categoryModel = new Category();

    // التحقق من وجود منتجات في القسم
    if ($categoryModel->hasProducts($id)) {
        echo json_encode(['success' => false, 'message' => 'لا يمكن تعطيل قسم به منتجات']);
        exit;
    }

    $result = $categoryModel->deactivate($id);

    if ($result) {
        echo json_encode([
            'success' => true,
            'message' => 'تم تعطيل القسم بنجاح'
        ], JSON_UNESCAPED_UNICODE);
    } else {
        echo json_encode(['success' => false, 'message' => 'فشل تعطيل القسم']);
    }
    exit;
}

/**
 * API: تفعيل قسم
 */
public function activateCategory() {
    header('Content-Type: application/json; charset=utf-8');
    
    if (!Auth::check()) {
        echo json_encode(['success' => false, 'message' => 'يجب تسجيل الدخول أولاً']);
        exit;
    }

    if (!$this->isPost()) {
        echo json_encode(['success' => false, 'message' => 'طريقة طلب غير صحيحة']);
        exit;
    }

    $input = json_decode(file_get_contents('php://input'), true);
    
    if (!$input) {
        echo json_encode(['success' => false, 'message' => 'بيانات غير صالحة']);
        exit;
    }

    $id = $input['id'] ?? 0;

    if (!$id) {
        echo json_encode(['success' => false, 'message' => 'معرف القسم مطلوب']);
        exit;
    }

    require_once __DIR__ . '/../models/Category.php';
    $categoryModel = new Category();

    $result = $categoryModel->activate($id);

    if ($result) {
        echo json_encode([
            'success' => true,
            'message' => 'تم تفعيل القسم بنجاح'
        ], JSON_UNESCAPED_UNICODE);
    } else {
        echo json_encode(['success' => false, 'message' => 'فشل تفعيل القسم']);
    }
    exit;
}
}