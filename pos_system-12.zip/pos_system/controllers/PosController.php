<?php
// ===== تعطيل جميع الاشعارات والأخطاء =====
error_reporting(0); // عدم عرض أي أخطاء
ini_set('display_errors', 0); // إخفاء الأخطاء
ini_set('display_startup_errors', 0); // إخفاء أخطاء بدء التشغيل
ini_set('log_errors', 0); // تعطيل تسجيل الأخطاء

// منع عرض أي مخرجات غير متوقعة
ob_start();

// تعطيل تقارير الأخطاء في PHP
if (function_exists('xdebug_disable')) {
    xdebug_disable();
}

// تجاهل جميع التحذيرات والأخطاء (لكن تنفيذ الكود يستمر)
set_error_handler(function($errno, $errstr, $errfile, $errline) {
    return true; // تجاهل الخطأ
}, E_ALL);

// تجاهل الأخطاء القاتلة
register_shutdown_function(function() {
    $error = error_get_last();
    if ($error) {
        // لا تفعل شيئاً - فقط تجاهل
        ob_end_clean();
    }
});

// باقي الكود...
require_once __DIR__ . '/../core/Controller.php';
require_once __DIR__ . '/../core/Auth.php';
require_once __DIR__ . '/../models/Sale.php';
require_once __DIR__ . '/../models/SaleItem.php';
require_once __DIR__ . '/../models/Customer.php';
require_once __DIR__ . '/../models/Product.php';
require_once __DIR__ . '/../models/Inventory.php';
require_once __DIR__ . '/../models/Shelf.php';
require_once __DIR__ . '/../models/Setting.php';
require_once __DIR__ . '/../models/ActivityLog.php';

class PosController extends Controller {
    
    private $saleModel;
    private $saleItemModel;
    private $customerModel;
    private $productModel;
    private $inventoryModel;
    private $shelfModel;
    private $settingModel;
    private $logModel;

    public function __construct() {
        if (!Auth::check()) {
            $this->redirect('login');
        }

        $this->saleModel = new Sale();
        $this->saleItemModel = new SaleItem();
        $this->customerModel = new Customer();
        $this->productModel = new Product();
        $this->inventoryModel = new Inventory();
        $this->shelfModel = new Shelf();
        $this->settingModel = new Setting();
        $this->logModel = new ActivityLog();
    }

    /**
     * صفحة نقطة البيع
     */
    public function index() {
        $data = [
            'title' => 'نقطة البيع',
            'customers' => $this->customerModel->getActive(),
            'print_settings' => $this->settingModel->getPrintSettings()
        ];
        
        $this->view('pos/index', $data);
    }

    /**
     * البحث عن المنتجات بالاسم أو الباركود (AJAX)
     */

    /**
 * البحث عن المنتجات (AJAX)
 */
/**
 * البحث عن المنتجات - ترجع مصفوفة دائماً
 */
public function searchProducts() {
    // مسح أي إخراج سابق
    if (ob_get_level()) ob_clean();
    
    // تعيين header JSON
    header('Content-Type: application/json; charset=utf-8');
    
    try {
        $query = isset($_GET['q']) ? trim($_GET['q']) : '';
        
        if (empty($query) || strlen($query) < 1) {
            echo json_encode([]); // مصفوفة فارغة
            exit;
        }

        $db = Database::getInstance();
        $searchTerm = "%$query%";
        
        $sql = "SELECT p.id, p.name, p.barcode, 
                       COALESCE((SELECT s.selling_price_unit FROM shelf_inventory s JOIN main_inventory mi ON s.main_inventory_id = mi.id WHERE mi.product_id = p.id AND s.units_remaining > 0 ORDER BY s.id ASC LIMIT 1), 0) as price,
                       COALESCE((SELECT SUM(s.units_remaining) FROM shelf_inventory s JOIN main_inventory mi ON s.main_inventory_id = mi.id WHERE mi.product_id = p.id AND s.units_remaining > 0), 0) as quantity,
                       (SELECT s.id FROM shelf_inventory s JOIN main_inventory mi ON s.main_inventory_id = mi.id WHERE mi.product_id = p.id AND s.units_remaining > 0 ORDER BY s.id ASC LIMIT 1) as shelf_id,
                       (SELECT s.shelf_code FROM shelf_inventory s JOIN main_inventory mi ON s.main_inventory_id = mi.id WHERE mi.product_id = p.id AND s.units_remaining > 0 ORDER BY s.id ASC LIMIT 1) as shelf_code,
                       (SELECT mi.id FROM shelf_inventory s JOIN main_inventory mi ON s.main_inventory_id = mi.id WHERE mi.product_id = p.id AND s.units_remaining > 0 ORDER BY s.id ASC LIMIT 1) as main_inventory_id
                FROM products p
                WHERE (p.name LIKE ? OR p.barcode LIKE ?) AND p.is_active = 1
                ORDER BY p.name ASC
                LIMIT 20";
        
        $stmt = $db->prepare($sql);
        $stmt->execute([$searchTerm, $searchTerm]);
        $products = $stmt->fetchAll();
        
        // تأكد من إرجاع مصفوفة دائماً
        if (!$products) {
            $products = [];
        }
        
        echo json_encode($products, JSON_UNESCAPED_UNICODE);
        exit;
        
    } catch (Exception $e) {
        error_log("Search error: " . $e->getMessage());
        echo json_encode([]);
        exit;
    }
}

/**
 * البحث بالباركود
 */
public function searchByBarcode() {
    // مسح أي إخراج سابق
    if (ob_get_level()) ob_clean();
    
    // تعيين header JSON
    header('Content-Type: application/json; charset=utf-8');
    
    try {
        $barcode = isset($_GET['barcode']) ? trim($_GET['barcode']) : '';
        
        if (empty($barcode)) {
            echo json_encode(['success' => false, 'message' => 'باركود مطلوب']);
            exit;
        }

        $db = Database::getInstance();
        
        $sql = "SELECT p.id, p.name, p.barcode, 
                       COALESCE((SELECT s.selling_price_unit FROM shelf_inventory s JOIN main_inventory mi ON s.main_inventory_id = mi.id WHERE mi.product_id = p.id AND s.units_remaining > 0 ORDER BY s.id ASC LIMIT 1), 0) as price,
                       COALESCE((SELECT SUM(s.units_remaining) FROM shelf_inventory s JOIN main_inventory mi ON s.main_inventory_id = mi.id WHERE mi.product_id = p.id AND s.units_remaining > 0), 0) as quantity,
                       (SELECT s.id FROM shelf_inventory s JOIN main_inventory mi ON s.main_inventory_id = mi.id WHERE mi.product_id = p.id AND s.units_remaining > 0 ORDER BY s.id ASC LIMIT 1) as shelf_id,
                       (SELECT s.shelf_code FROM shelf_inventory s JOIN main_inventory mi ON s.main_inventory_id = mi.id WHERE mi.product_id = p.id AND s.units_remaining > 0 ORDER BY s.id ASC LIMIT 1) as shelf_code,
                       (SELECT mi.id FROM shelf_inventory s JOIN main_inventory mi ON s.main_inventory_id = mi.id WHERE mi.product_id = p.id AND s.units_remaining > 0 ORDER BY s.id ASC LIMIT 1) as main_inventory_id
                FROM products p
                WHERE p.barcode = ? AND p.is_active = 1
                LIMIT 1";
        
        $stmt = $db->prepare($sql);
        $stmt->execute([$barcode]);
        $product = $stmt->fetch();
        
        if ($product) {
            echo json_encode([
                'success' => true,
                'product' => $product
            ], JSON_UNESCAPED_UNICODE);
        } else {
            echo json_encode([
                'success' => false,
                'message' => 'المنتج غير موجود'
            ]);
        }
        exit;
        
    } catch (Exception $e) {
        error_log("Barcode error: " . $e->getMessage());
        echo json_encode([
            'success' => false,
            'message' => 'خطأ في البحث: ' . $e->getMessage()
        ]);
        exit;
    }
}

/**
 * معالجة البيع - مع التحقق من الكميات قبل التنفيذ
 */
/**
 * معالجة البيع - نسخة محدثة مع حفظ رقم الرف
 */
public function processSale() {
    // مسح أي إخراج سابق
    if (ob_get_level()) ob_clean();
    
    // تعيين header JSON
    header('Content-Type: application/json; charset=utf-8');
    
    if (!$this->isPost()) {
        echo json_encode(['success' => false, 'message' => 'طريقة طلب غير صحيحة']);
        exit;
    }

    $input = json_decode(file_get_contents('php://input'), true);
    
    if (!$input) {
        echo json_encode(['success' => false, 'message' => 'بيانات غير صالحة']);
        exit;
    }

    // الحصول على اتصال قاعدة البيانات
    $db = Database::getInstance();
    
    try {
        // بدء المعاملة
        $db->beginTransaction();

        // ===== التحقق من الكميات قبل البدء =====
        foreach ($input['items'] as $item) {
            $shelfId = $item['shelf_id'];
            $requestedQty = $item['quantity'];
            
            // التحقق من أن الكمية المطلوبة موجبة
            if ($requestedQty <= 0) {
                throw new Exception('الكمية المطلوبة غير صالحة (يجب أن تكون أكبر من 0)');
            }
            
            // التحقق من الكمية في الرف
            $checkSql = "SELECT units_remaining, status FROM shelf_inventory WHERE id = ?";
            $checkStmt = $db->prepare($checkSql);
            $checkStmt->execute([$shelfId]);
            $shelf = $checkStmt->fetch();
            
            if (!$shelf) {
                throw new Exception('المنتج غير موجود في الرف');
            }
            
            if ($shelf['units_remaining'] <= 0) {
                throw new Exception('المنتج غير متوفر (الكمية: 0)');
            }
            
            if ($shelf['status'] === 'expired') {
                throw new Exception('المنتج منتهي الصلاحية');
            }
            
            if ($requestedQty > $shelf['units_remaining']) {
                $extraNeeded = $requestedQty - $shelf['units_remaining'];
                // التحقق من وجود كراتين في المخزن الرئيسي
                $checkMainSql = "SELECT i.cartons_remaining, p.units_per_carton 
                                 FROM shelf_inventory s
                                 JOIN main_inventory i ON s.main_inventory_id = i.id
                                 JOIN products p ON i.product_id = p.id
                                 WHERE s.id = ?";
                $checkMainStmt = $db->prepare($checkMainSql);
                $checkMainStmt->execute([$shelfId]);
                $mainCheck = $checkMainStmt->fetch();
                
                if (!$mainCheck || $mainCheck['cartons_remaining'] <= 0) {
                    throw new Exception("الكمية المطلوبة ($requestedQty) أكبر من المتوفر (" . $shelf['units_remaining'] . ") ولا توجد كراتين في المخزن للتعويض");
                }
                
                if ($extraNeeded > $mainCheck['units_per_carton']) {
                    throw new Exception("الكمية المطلوبة ($requestedQty) تتطلب أكثر من كرتون أخر إضافي، يرجى البيع على دفعات");
                }
            }
        }

        // إنشاء رقم فاتورة
        $invoiceNumber = 'INV-' . date('Ymd') . '-' . rand(1000, 9999);

        // حساب المتبقي
        $remaining = $input['total_amount'] - $input['paid_amount'];
        $customerId = isset($input['customer_id']) && $input['customer_id'] ? $input['customer_id'] : null;
        $createdBy = Auth::id();

        // إدراج الفاتورة في جدول sales
        $saleSql = "INSERT INTO sales (invoice_number, customer_id, sale_type, total_amount, paid_amount, remaining_amount, discount, created_by) 
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        $saleStmt = $db->prepare($saleSql);
        $saleResult = $saleStmt->execute([
            $invoiceNumber,
            $customerId,
            $input['sale_type'],
            $input['total_amount'],
            $input['paid_amount'],
            $remaining,
            $input['discount'] ?? 0,
            $createdBy
        ]);

        if (!$saleResult) {
            throw new Exception('فشل في حفظ الفاتورة');
        }

        $saleId = $db->lastInsertId();

        // إدراج عناصر الفاتورة وتحديث المخزون
        foreach ($input['items'] as &$item) {
            $subtotal = $item['quantity'] * $item['price'];
            
            // ===== التعديل المهم: جلب اسم المنتج ورقم الرف =====
            $productSql = "SELECT p.name, sh.shelf_code 
                          FROM products p
                          LEFT JOIN main_inventory mi ON p.id = mi.product_id
                          LEFT JOIN shelf_inventory sh ON mi.id = sh.main_inventory_id
                          WHERE p.id = ? AND sh.id = ?
                          LIMIT 1";
            $productStmt = $db->prepare($productSql);
            $productStmt->execute([$item['product_id'], $item['shelf_id']]);
            $product = $productStmt->fetch();
            
            $item['name'] = $product ? $product['name'] : 'منتج غير معروف';
            $shelfCode = $product ? $product['shelf_code'] : null;
            
            // ===== التعديل لآلية الإحلال التلقائي للرف =====
            // 1. جلب بيانات الرف الحالية
            $shelfCheckSql = "SELECT * FROM shelf_inventory WHERE id = ?";
            $shelfCheckStmt = $db->prepare($shelfCheckSql);
            $shelfCheckStmt->execute([$item['shelf_id']]);
            $currentShelf = $shelfCheckStmt->fetch();
            
            if (!$currentShelf) throw new Exception('سجل الرف غير موجود');

            $currentRemaining = $currentShelf['units_remaining'];
            $newRemaining = $currentRemaining - $item['quantity'];
            $currentMainInventoryId = $currentShelf['main_inventory_id'];
            
            // للحصول على سعر التكلفة الأصلي للدفعة الحالية
            $invCostSql = "SELECT i.cost_price_unit, p.units_per_carton, i.product_id 
                           FROM main_inventory i
                           JOIN products p ON i.product_id = p.id
                           WHERE i.id = ?";
            $invCostStmt = $db->prepare($invCostSql);
            $invCostStmt->execute([$currentMainInventoryId]);
            $invData = $invCostStmt->fetch();
            $costAtSale = $invData ? $invData['cost_price_unit'] : ($item['cost'] ?? 0);
            
            // 2. تطبيق خوارزمية الإحلال التلقائي إذا كانت الكمية المطلوبة أكبر
         // 2. تطبيق خوارزمية الإحلال التلقائي إذا كانت الكمية المطلوبة أكبر
            if ($newRemaining < 0) {
                // ===== التحقق من حالة الرفع التلقائي من ملف AutoStock.json =====
                $autoStockFile = __DIR__ . '/../database/AutoStock.json';
                $autoRestockEnabled = false;
                
                if (file_exists($autoStockFile)) {
                    $content = file_get_contents($autoStockFile);
                    $autoStockData = json_decode($content, true);
                    $autoRestockEnabled = isset($autoStockData['enabled']) ? (bool)$autoStockData['enabled'] : false;
                }
                
                // إذا كان الرفع التلقائي معطلاً، نرفض عملية الإحلال
                if (!$autoRestockEnabled) {
                    throw new Exception('التواصل مع المدير للسماح برفع كرتون، الكمية المتوفرة في الرف غير كافية (' . $currentRemaining . ' وحدة) والمطلوب (' . $item['quantity'] . ' وحدة)، ولا يمكن سحب كرتون من المخزن. يرجى تفعيل الرفع التلقائي من الإعدادات أو تقليل الكمية المطلوبة');
                }
                // ===== نهاية التحقق =====
                
                // سحب أقدم كرتون جديد من المخزن الرئيسي (FIFO)
                $fifoSql = "SELECT * FROM main_inventory 
                            WHERE product_id = ? AND cartons_remaining > 0
                            ORDER BY expiry_date ASC, entry_date ASC
                            LIMIT 1";
                $fifoStmt = $db->prepare($fifoSql);
                $fifoStmt->execute([$invData['product_id']]);
                $oldestBatch = $fifoStmt->fetch();

                if (!$oldestBatch) {
                    throw new Exception('الكمية المطلوبة غير متاحة، ولا توجد كراتين في المخزن الرئيسي');
                }

                // قسم الكرتون من المخزن
                $updateMainSql = "UPDATE main_inventory SET cartons_remaining = cartons_remaining - 1 WHERE id = ?";
                $updateMainStmt = $db->prepare($updateMainSql);
                $updateMainStmt->execute([$oldestBatch['id']]);

                // تصفير الوحدات القديمة، وإضافة السعة الجديدة، ثم الخصم
                $newRemaining = $invData['units_per_carton'] - ($item['quantity'] - $currentRemaining);
                
                if ($newRemaining < 0) {
                    throw new Exception('الكمية المطلوبة أكبر من سعة كرتون واحد إضافي، يرجى البيع على دفعات');
                }

                $currentMainInventoryId = $oldestBatch['id'];
                $costAtSale = $oldestBatch['cost_price_unit'];
            }

            // ===== إدراج عنصر الفاتورة واستخدام التكلفة الصحيحة =====
            // ملاحظة: تأكد من وجود عمود shelf_code في جدول sale_items
            $itemSql = "INSERT INTO sale_items (sale_id, shelf_inventory_id, shelf_code, quantity, price_unit, cost_at_sale, subtotal) 
                        VALUES (?, ?, ?, ?, ?, ?, ?)";
            $itemStmt = $db->prepare($itemSql);
            $itemResult = $itemStmt->execute([
                $saleId,
                $item['shelf_id'],
                $shelfCode,
                $item['quantity'],
                $item['price'],
                $costAtSale, // التكلفة المحسوبة
                $subtotal
            ]);

            if (!$itemResult) {
                throw new Exception('فشل في حفظ عناصر الفاتورة');
            }

            // 3. التحديث النهائي للرف
            $updateShelfSql = "UPDATE shelf_inventory 
                                SET units_remaining = ?,
                                    main_inventory_id = ?,
                                    status = CASE 
                                        WHEN ? <= 0 THEN 'out_of_stock'
                                        WHEN ? < 5 THEN 'low_stock'
                                        ELSE 'available'
                                    END,
                                    updated_at = NOW()
                                WHERE id = ?";
            $updateStmt = $db->prepare($updateShelfSql);
            $updateResult = $updateStmt->execute([
                $newRemaining,
                $currentMainInventoryId,
                $newRemaining,
                $newRemaining,
                $item['shelf_id']
            ]);

            if (!$updateResult) {
                throw new Exception('فشل في تحديث المخزون');
            }
        }

        // تحديث رصيد العميل إذا كان بيع آجل
        if ($input['sale_type'] === 'credit' && $customerId) {
            $customerSql = "SELECT current_balance FROM customers WHERE id = ?";
            $customerStmt = $db->prepare($customerSql);
            $customerStmt->execute([$customerId]);
            $customer = $customerStmt->fetch();

            if ($customer) {
                $newBalance = $customer['current_balance'] + $input['total_amount'];
                $updateCustomerSql = "UPDATE customers SET current_balance = ? WHERE id = ?";
                $updateCustomerStmt = $db->prepare($updateCustomerSql);
                $updateCustomerStmt->execute([$newBalance, $customerId]);
            }
        }

        // تأكيد المعاملة
        $db->commit();

        // تسجيل النشاط
        $this->logModel->log('process_sale', 'تم إنشاء فاتورة جديدة: ' . $invoiceNumber);

        // ===== نظام الرفع التلقائي المتزامن =====
        if (isset($_SESSION['auto_restock_enabled']) && $_SESSION['auto_restock_enabled']) {
            try {
                $this->inventoryModel->autoRestockShelf();
            } catch (Exception $e) {
                error_log("Auto restock after sale failed: " . $e->getMessage());
            }
        }
        // ==========================================

        // الحصول على إعدادات الطباعة
        $printSettings = $this->settingModel->getPrintSettings();

        // تجهيز بيانات الفاتورة للطباعة
        $saleData = [
            'invoice_number' => $invoiceNumber,
            'total_amount' => $input['total_amount'],
            'paid_amount' => $input['paid_amount'],
            'remaining_amount' => $remaining,
            'customer_name' => $this->getCustomerName($customerId)
        ];

        // طباعة الفاتورة إذا كانت مفعلة
        $printResult = null;
        if ($printSettings['print_enabled'] === '1') {
            $printResult = $this->settingModel->saveInvoice($saleId, $saleData, $input['items']);
        }

        echo json_encode([
            'success' => true,
            'message' => 'تمت عملية البيع بنجاح',
            'sale_id' => $saleId,
            'invoice_number' => $invoiceNumber,
            'print' => $printResult,
            'auto_open' => $printSettings['print_open_automatically'] === '1'
        ], JSON_UNESCAPED_UNICODE);
        exit;

    } catch (Exception $e) {
        $db->rollBack();
        error_log("Process sale error: " . $e->getMessage());
        echo json_encode([
            'success' => false,
            'message' => 'خطأ في عملية البيع: ' . $e->getMessage()
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }
}
/**
 * تحديث مخزون الرف
 */
private function updateShelfInventory($shelfId, $quantity) {
    $sql = "UPDATE shelf_inventory 
            SET units_remaining = units_remaining - ?,
                status = CASE 
                    WHEN units_remaining - ? <= 0 THEN 'out_of_stock'
                    WHEN units_remaining - ? < 5 THEN 'low_stock'
                    ELSE status
                END,
                updated_at = NOW()
            WHERE id = ?";
    $stmt = $this->shelfModel->db->prepare($sql);
    return $stmt->execute([$quantity, $quantity, $quantity, $shelfId]);
}

    /**
     * تحديث مخزون الرف
     */
   
    /**
     * الحصول على اسم العميل
     */
    private function getCustomerName($customerId) {
        if (!$customerId) return null;
        $customer = $this->customerModel->find($customerId);
        return $customer ? $customer['name'] : null;
    }

    /**
     * البحث عن فاتورة للإرجاع (AJAX) - محسّن
     */
    public function searchInvoice() {
        $invoiceNumber = $this->getQuery('invoice', '');
        
        if (empty($invoiceNumber)) {
            $this->json(['success' => false, 'message' => 'رقم الفاتورة مطلوب']);
            return;
        }

        try {
            // البحث عن الفاتورة مع معلومات العميل
            $sql = "SELECT s.*, c.name as customer_name, c.current_balance as customer_balance
                    FROM sales s
                    LEFT JOIN customers c ON s.customer_id = c.id
                    WHERE s.invoice_number LIKE ?";
            $stmt = $this->saleModel->db->prepare($sql);
            $stmt->execute(["%$invoiceNumber%"]);
            $sale = $stmt->fetch();
            
            if (!$sale) {
                $this->json(['success' => false, 'message' => 'الفاتورة غير موجودة']);
                return;
            }

            // جلب عناصر الفاتورة مع تفاصيل المنتج
            $sql = "SELECT si.*, p.name as product_name, p.barcode,
                           sh.shelf_code, mi.batch_number, mi.expiry_date,
                           mi.product_id
                    FROM sale_items si
                    JOIN shelf_inventory sh ON si.shelf_inventory_id = sh.id
                    JOIN main_inventory mi ON sh.main_inventory_id = mi.id
                    JOIN products p ON mi.product_id = p.id
                    WHERE si.sale_id = ?
                    ORDER BY si.id ASC";
            $stmt = $this->saleItemModel->db->prepare($sql);
            $stmt->execute([$sale['id']]);
            $items = $stmt->fetchAll();
            
            $this->json([
                'success' => true,
                'data' => [
                    'sale' => $sale,
                    'items' => $items
                ]
            ]);
            
        } catch (Exception $e) {
            error_log("Invoice search error: " . $e->getMessage());
            $this->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /**
     * إعادة طباعة فاتورة
     */
    public function reprintInvoice() {
        $saleId = $this->getPost('sale_id');
        
        if (!$saleId) {
            $this->json(['success' => false, 'message' => 'معرف الفاتورة مطلوب']);
            return;
        }

        try {
            $sale = $this->saleModel->find($saleId);
            if (!$sale) {
                $this->json(['success' => false, 'message' => 'الفاتورة غير موجودة']);
                return;
            }

            $items = $this->saleItemModel->getBySaleId($saleId);
            
            $saleData = [
                'invoice_number' => $sale['invoice_number'],
                'total_amount' => $sale['total_amount'],
                'paid_amount' => $sale['paid_amount'],
                'remaining_amount' => $sale['remaining_amount'],
                'customer_name' => $this->getCustomerName($sale['customer_id'])
            ];

            $printResult = $this->settingModel->saveInvoice($saleId, $saleData, $items);
            
            $this->json($printResult);
            
        } catch (Exception $e) {
            $this->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /**
 * تحميل الفاتورة كملف
 */
public function downloadInvoice() {
    $file = $this->getQuery('file');
    
    if (!$file) {
        $this->json(['success' => false, 'message' => 'الملف مطلوب']);
        return;
    }
    
    $filePath = $this->settingModel->getSavePath() . $file;
    
    if (!file_exists($filePath)) {
        $this->json(['success' => false, 'message' => 'الملف غير موجود']);
        return;
    }
    
    header('Content-Type: text/html; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . basename($filePath) . '"');
    header('Content-Length: ' . filesize($filePath));
    readfile($filePath);
    exit;
}
/**
 * التحقق من الكميات المتاحة في الرف قبل البيع
 */
public function checkQuantities() {
    header('Content-Type: application/json; charset=utf-8');
    
    if (!$this->isPost()) {
        echo json_encode(['success' => false, 'message' => 'طريقة طلب غير صحيحة']);
        exit;
    }

    $items = json_decode(file_get_contents('php://input'), true);
    
    if (!$items) {
        echo json_encode(['success' => false, 'message' => 'بيانات غير صالحة']);
        exit;
    }

    try {
        $problems = [];
        $allAvailable = true;
        
        foreach ($items as $item) {
            $shelfId = $item['shelf_id'];
            $requestedQty = $item['quantity'];
            $productName = isset($item['name']) ? $item['name'] : 'منتج';
            
            // التحقق من أن الكمية المطلوبة موجبة
            if ($requestedQty <= 0) {
                $problems[] = [
                    'name' => $productName,
                    'requested' => $requestedQty,
                    'available' => 0,
                    'message' => 'كمية غير صالحة'
                ];
                $allAvailable = false;
                continue;
            }
            
            // التحقق من الكمية المتاحة في الرف
            $sql = "SELECT s.units_remaining, p.name as product_name
                    FROM shelf_inventory s
                    JOIN main_inventory i ON s.main_inventory_id = i.id
                    JOIN products p ON i.product_id = p.id
                    WHERE s.id = ?";
            
            $stmt = $this->shelfModel->db->prepare($sql);
            $stmt->execute([$shelfId]);
            $result = $stmt->fetch();
            
            if (!$result) {
                $problems[] = [
                    'name' => $productName,
                    'requested' => $requestedQty,
                    'available' => 0,
                    'message' => 'المنتج غير موجود في الرف'
                ];
                $allAvailable = false;
                continue;
            }
            
            $availableQty = $result['units_remaining'];
            
            // التحقق من أن الكمية المتاحة موجبة
            if ($availableQty <= 0) {
                $problems[] = [
                    'name' => $result['product_name'],
                    'requested' => $requestedQty,
                    'available' => $availableQty,
                    'message' => 'المنتج غير متوفر (الكمية: ' . $availableQty . ')'
                ];
                $allAvailable = false;
                continue;
            }
            
            if ($requestedQty > $availableQty) {
                $extraNeeded = $requestedQty - $availableQty;
                
                // ===== التحقق من حالة الرفع التلقائي من ملف AutoStock.json =====
                $autoStockFile = __DIR__ . '/../database/AutoStock.json';
                $autoRestockEnabled = false;
                
                if (file_exists($autoStockFile)) {
                    $content = file_get_contents($autoStockFile);
                    $autoStockData = json_decode($content, true);
                    $autoRestockEnabled = isset($autoStockData['enabled']) ? (bool)$autoStockData['enabled'] : false;
                }
                
                // إذا كان الرفع التلقائي معطلاً، نضيف مشكلة مباشرة دون التحقق من المخزن
                if (!$autoRestockEnabled) {
                    $problems[] = [
                        'name' => $result['product_name'],
                        'requested' => $requestedQty,
                        'available' => $availableQty,
                        'message' => 'نظام الرفع التلقائي معطل، الكمية المتوفرة (' . $availableQty . ') غير كافية ولا يمكن سحب كرتون من المخزن'
                    ];
                    $allAvailable = false;
                } else {
                    // التحقق من المخزن الرئيسي للتعويض (نفس الكود الأصلي)
                    $mainInvSql = "SELECT SUM(i.cartons_remaining) as total_cartons, p.units_per_carton
                                FROM main_inventory i
                                JOIN products p ON i.product_id = p.id
                                WHERE i.product_id = (SELECT product_id FROM main_inventory WHERE id = (SELECT main_inventory_id FROM shelf_inventory WHERE id = ?))";
                    $mainInvStmt = $this->shelfModel->db->prepare($mainInvSql);
                    $mainInvStmt->execute([$shelfId]);
                    $mainCheck = $mainInvStmt->fetch();
                    
                    if (!$mainCheck || $mainCheck['total_cartons'] <= 0) {
                        $problems[] = [
                            'name' => $result['product_name'],
                            'requested' => $requestedQty,
                            'available' => $availableQty,
                            'message' => 'الكمية المطلوبة أكبر من المتوفر وليس هناك كراتين إضافية بالمخزن'
                        ];
                        $allAvailable = false;
                    } else if ($extraNeeded > $mainCheck['units_per_carton']) {
                        $problems[] = [
                            'name' => $result['product_name'],
                            'requested' => $requestedQty,
                            'available' => $availableQty + $mainCheck['units_per_carton'],
                            'message' => 'الكمية المطلوبة تحتاج سحب أكثر من كرتون واحد، يرجى تقسيم البيع'
                        ];
                        $allAvailable = false;
                    }
                }
                // ===== نهاية التعديل =====
            }
        }
        
        if ($allAvailable) {
            echo json_encode(['success' => true]);
        } else {
            echo json_encode([
                'success' => false,
                'problems' => $problems
            ]);
        }
        
    } catch (Exception $e) {
        error_log("Check quantities error: " . $e->getMessage());
        echo json_encode([
            'success' => false,
            'message' => 'خطأ في التحقق من الكميات: ' . $e->getMessage()
        ]);
    }
}

}