<?php
require_once __DIR__ . '/../core/Controller.php';
require_once __DIR__ . '/../core/Auth.php';

class AutoRestockController extends Controller {
    
    private $autoStockFile;

    public function __construct() {
        // التحقق من تسجيل الدخول
        if (!Auth::check()) {
            $this->json(['success' => false, 'message' => 'غير مصرح'], 401);
            exit;
        }

        // تحديد مسار ملف التخزين
        $this->autoStockFile = __DIR__ . '/../database/AutoStock.json';
    }

    /**
     * قراءة حالة الرفع التلقائي من ملف JSON
     * @return bool
     */
    private function getAutoRestockStatusFromFile() {
        if (!file_exists($this->autoStockFile)) {
            // إذا لم يكن الملف موجوداً، ننشئه بالقيمة الافتراضية false
            $this->saveAutoRestockStatusToFile(false);
            return false;
        }

        $content = file_get_contents($this->autoStockFile);
        $data = json_decode($content, true);
        return isset($data['enabled']) ? (bool)$data['enabled'] : false;
    }

    /**
     * حفظ حالة الرفع التلقائي في ملف JSON
     * @param bool $enabled
     * @return bool
     */
    private function saveAutoRestockStatusToFile($enabled) {
        $data = ['enabled' => (bool)$enabled];
        $json = json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
        return file_put_contents($this->autoStockFile, $json, LOCK_EX) !== false;
    }

    /**
     * تنفيذ الرفع الذكي
     */
    public function execute() {
        header('Content-Type: application/json; charset=utf-8');
        
        try {
            $db = Database::getInstance();
            $db->beginTransaction();
            
            $restocked = [];
            $failed = [];
            
            // جلب المنتجات التي نفدت من الرف (إجمالي القطع المتبقية <= 0) ولكن يتوفر لها كراتين في المخزن
            $query = "
                SELECT p.id as product_id, p.name as product_name, p.units_per_carton,
                       (SELECT COALESCE(SUM(units_remaining), 0) 
                        FROM shelf_inventory s 
                        JOIN main_inventory m ON s.main_inventory_id = m.id 
                        WHERE m.product_id = p.id) as total_on_shelf,
                       (SELECT SUM(cartons_remaining) 
                        FROM main_inventory 
                        WHERE product_id = p.id) as total_in_main
                FROM products p
                HAVING total_on_shelf <= 0 AND total_in_main > 0
            ";
            
            $stmt = $db->query($query);
            $productsNeedingRestock = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            foreach ($productsNeedingRestock as $product) {
                $unitsPerCarton = (int)$product['units_per_carton'];
                if ($unitsPerCarton <= 0) $unitsPerCarton = 1;
                
                // جلب أقدم دفعة متوفرة لتطبيق سياسة FIFO
                $batchStmt = $db->prepare("SELECT id, batch_number, selling_price_unit FROM main_inventory WHERE product_id = ? AND cartons_remaining > 0 ORDER BY entry_date ASC LIMIT 1");
                $batchStmt->execute([$product['product_id']]);
                $batch = $batchStmt->fetch(PDO::FETCH_ASSOC);
                
                if ($batch) {
                    // خصم كرتون واحد
                    $db->prepare("UPDATE main_inventory SET cartons_remaining = cartons_remaining - 1 WHERE id = ?")
                       ->execute([$batch['id']]);
                    
                    // تحويل الكرتون إلى قطع في الرف
                    $shelfCode = 'RF-AUTO-' . date('His') . rand(10, 99);
                    $db->prepare("INSERT INTO shelf_inventory (main_inventory_id, shelf_code, units_remaining, selling_price_unit) VALUES (?, ?, ?, ?)")
                       ->execute([$batch['id'], $shelfCode, $unitsPerCarton, $batch['selling_price_unit']]);
                    
                    $restocked[] = [
                        'product' => $product['product_name'],
                        'batch' => $batch['batch_number'],
                        'shelf_code' => $shelfCode
                    ];
                    
                    // تسجيل العملية
                    $userId = $_SESSION['user_id'] ?? 1;
                    $db->prepare("INSERT INTO activity_logs (user_id, action, details, created_at) VALUES (?, 'auto_restock', ?, NOW())")
                       ->execute([$userId, "تم رفع كرتون من المنتج {$product['product_name']} (الدفعة {$batch['batch_number']}) إلى الرف تلقائياً."]);
                } else {
                    $failed[] = $product['product_name'];
                }
            }
            
            $db->commit();
            
            echo json_encode([
                'success' => true,
                'message' => 'تم فحص الرفوف وإنجاز عملية الرفع بنجاح',
                'restocked' => $restocked,
                'failed' => $failed
            ], JSON_UNESCAPED_UNICODE);
            exit;
            
        } catch (Exception $e) {
            if (isset($db) && $db->inTransaction()) {
                $db->rollBack();
            }
            error_log("AutoRestock Error: " . $e->getMessage());
            
            echo json_encode([
                'success' => false,
                'message' => 'حدث خطأ: ' . $e->getMessage()
            ], JSON_UNESCAPED_UNICODE);
            exit;
        }
    }

    /**
     * التحقق من حالة الرف (يستخدم لعرض الإشعارات فقط إن لزم)
     */
    public function check() {
        header('Content-Type: application/json; charset=utf-8');
        
        try {
            $db = Database::getInstance();
            $connection = $db->getConnection();
            $query = "
                SELECT p.name as product_name
                FROM products p
                HAVING 
                    (SELECT COALESCE(SUM(units_remaining), 0) FROM shelf_inventory s JOIN main_inventory m ON s.main_inventory_id = m.id WHERE m.product_id = p.id) <= 0 
                    AND 
                    (SELECT SUM(cartons_remaining) FROM main_inventory WHERE product_id = p.id) > 0
            ";
            $stmt = $connection->query($query);
            $products = $stmt->fetchAll(PDO::FETCH_COLUMN);
            
            echo json_encode([
                'success' => true,
                'needs_restock' => count($products) > 0,
                'count' => count($products),
                'products' => $products
            ], JSON_UNESCAPED_UNICODE);
            exit;
            
        } catch (Exception $e) {
            echo json_encode([
                'success' => false,
                'message' => 'خطأ في التحقق: ' . $e->getMessage()
            ], JSON_UNESCAPED_UNICODE);
            exit;
        }
    }

    /**
     * تفعيل/تعطيل الرفع التلقائي (تخزين في ملف JSON)
     */
    public function toggle() {
        header('Content-Type: application/json; charset=utf-8');
        
        try {
            $enabled = $this->getPost('enabled') === 'true';
            
            if ($this->saveAutoRestockStatusToFile($enabled)) {
                echo json_encode([
                    'success' => true,
                    'enabled' => $enabled,
                    'message' => $enabled ? 'تم تفعيل الرفع التلقائي' : 'تم تعطيل الرفع التلقائي'
                ], JSON_UNESCAPED_UNICODE);
            } else {
                echo json_encode([
                    'success' => false,
                    'message' => 'فشل في حفظ حالة الرفع التلقائي'
                ], JSON_UNESCAPED_UNICODE);
            }
            exit;
            
        } catch (Exception $e) {
            echo json_encode([
                'success' => false,
                'message' => 'خطأ في التبديل: ' . $e->getMessage()
            ], JSON_UNESCAPED_UNICODE);
            exit;
        }
    }

    /**
     * الحصول على حالة الرفع التلقائي (من ملف JSON)
     */
    public function status() {
        header('Content-Type: application/json; charset=utf-8');
        
        try {
            $enabled = $this->getAutoRestockStatusFromFile();
            
            echo json_encode([
                'success' => true,
                'enabled' => $enabled
            ], JSON_UNESCAPED_UNICODE);
            exit;
            
        } catch (Exception $e) {
            echo json_encode([
                'success' => false,
                'enabled' => false,
                'message' => 'خطأ في قراءة الحالة: ' . $e->getMessage()
            ], JSON_UNESCAPED_UNICODE);
            exit;
        }
    }
}